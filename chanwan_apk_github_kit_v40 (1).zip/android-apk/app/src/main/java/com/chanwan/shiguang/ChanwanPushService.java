package com.chanwan.shiguang;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.service.notification.StatusBarNotification;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Iterator;
import java.util.LinkedHashSet;

public class ChanwanPushService extends Service {
    public static final int FG_NOTIF_ID = 1;
    private static final String CH_FG = "chanwan_fg_channel";
    private static final String CH_MSG = "chanwan_msg_channel";
    private static final String BASE_ROOM = "chanwan-suwan-jingchan-live2026";
    private volatile boolean running = true;
    private volatile HttpURLConnection activeConn = null;
    private volatile String activeRole = "";
    private Thread worker;

    @Override
    public void onCreate() {
        super.onCreate();
        createChannels();
        promoteToForegroundSafely();
    }

    private void promoteToForegroundSafely() {
        try {
            Notification n = buildForegroundNotif();
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(FG_NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_REMOTE_MESSAGING);
            } else {
                startForeground(FG_NOTIF_ID, n);
            }
        } catch (Throwable ignored) {}
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        promoteToForegroundSafely();
        String desiredRole = getSharedPreferences("cw_prefs", MODE_PRIVATE).getString("role", "suwan");
        if (worker == null || !worker.isAlive()) {
            running = true;
            worker = new Thread(this::streamLoop);
            worker.start();
        } else if (!desiredRole.equals(activeRole)) {
            HttpURLConnection c = activeConn;
            if (c != null) {
                try { c.disconnect(); } catch (Exception ignored) {}
            }
        }
        return START_STICKY;
    }

    public static void cancelAllMessageNotifs(Context ctx) {
        if (ctx == null) return;
        try {
            NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                StatusBarNotification[] active = nm.getActiveNotifications();
                if (active != null) {
                    for (StatusBarNotification sbn : active) {
                        if (sbn != null && sbn.getId() != FG_NOTIF_ID) {
                            String tag = sbn.getTag();
                            if (tag != null) {
                                try { nm.cancel(tag, sbn.getId()); } catch (Exception ignored) {}
                            }
                            try { nm.cancel(sbn.getId()); } catch (Exception ignored) {}
                        }
                    }
                }
            }
        } catch (Exception ignored) {}
    }

    private void createChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm == null) return;
            NotificationChannel fg = new NotificationChannel(CH_FG, "灿完时光 실시간 연결", NotificationManager.IMPORTANCE_MIN);
            fg.setShowBadge(false);
            nm.createNotificationChannel(fg);

            NotificationChannel msg = new NotificationChannel(CH_MSG, "새 메시지 · 하트 알림", NotificationManager.IMPORTANCE_HIGH);
            msg.enableVibration(true);
            msg.setShowBadge(true);
            nm.createNotificationChannel(msg);
        }
    }

    private Notification buildForegroundNotif() {
        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CH_FG)
                : new Notification.Builder(this);
        return b.setContentTitle("灿完时光")
                .setContentText("실시간 알림 대기 중 💜")
                .setSmallIcon(R.drawable.ic_stat_heart)
                .setNumber(0)
                .setShowWhen(false)
                .setOngoing(true)
                .build();
    }

    private static boolean hasHangul(String s) {
        if (s == null) return false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= '\uAC00' && c <= '\uD7A3') return true;
        }
        return false;
    }

    private static boolean hasCjkNoHangul(String s) {
        if (s == null || hasHangul(s)) return false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= '\u4E00' && c <= '\u9FFF') return true;
        }
        return false;
    }

    private LinkedHashSet<String> loadSeenIds(SharedPreferences prefs) {
        LinkedHashSet<String> set = new LinkedHashSet<>();
        String raw = prefs.getString("seen_ids", "");
        if (raw != null && !raw.isEmpty()) {
            String[] parts = raw.split(",");
            for (String p : parts) {
                String clean = p.trim();
                if (!clean.isEmpty()) set.add(clean);
            }
        }
        return set;
    }

    private void saveSeenIds(SharedPreferences prefs, LinkedHashSet<String> set, String lastId, long streamSec) {
        while (set.size() > 80) {
            Iterator<String> it = set.iterator();
            if (it.hasNext()) {
                it.next();
                it.remove();
            } else {
                break;
            }
        }
        StringBuilder sb = new StringBuilder();
        for (String s : set) {
            if (sb.length() > 0) sb.append(',');
            sb.append(s);
        }
        prefs.edit()
                .putString("last_id", lastId)
                .putString("seen_ids", sb.toString())
                .putLong("last_stream_sec", streamSec)
                .apply();
    }

    private void streamLoop() {
        SharedPreferences initPrefs = getSharedPreferences("cw_prefs", MODE_PRIVATE);
        LinkedHashSet<String> seenIds = loadSeenIds(initPrefs);
        String lastFp = "";
        long lastFpMs = 0L;
        String lastBody = "";
        int lastNotifId = 0;

        while (running) {
            HttpURLConnection conn = null;
            try {
                SharedPreferences prefs = getSharedPreferences("cw_prefs", MODE_PRIVATE);
                String role = prefs.getString("role", "suwan");
                activeRole = role;
                String lastId = prefs.getString("last_id", "");
                long lastStreamSec = prefs.getLong("last_stream_sec", 0L);
                long nowConnSec = System.currentTimeMillis() / 1000L;

                String sinceParam = (!lastId.isEmpty() && lastStreamSec > 0L && (nowConnSec - lastStreamSec) <= 120L)
                        ? ("?since=" + lastId)
                        : "";
                String topic = BASE_ROOM + "-" + role;
                URL url = new URL("https://ntfy.sh/" + topic + "/json" + sinceParam);
                conn = (HttpURLConnection) url.openConnection();
                activeConn = conn;
                conn.setReadTimeout(90000);
                conn.setConnectTimeout(15000);
                conn.connect();

                BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                String line;
                while (running && (line = br.readLine()) != null) {
                    line = line.trim();
                    if (line.isEmpty()) continue;
                    long recvSec = System.currentTimeMillis() / 1000L;
                    JSONObject obj = new JSONObject(line);
                    String ev = obj.optString("event", "");
                    String id = obj.optString("id", "");

                    if ("open".equals(ev) || "keepalive".equals(ev)) {
                        prefs.edit().putLong("last_stream_sec", recvSec).apply();
                        continue;
                    }
                    if (!"message".equals(ev)) continue;

                    if (!id.isEmpty()) {
                        if (seenIds.contains(id)) {
                            prefs.edit().putLong("last_stream_sec", recvSec).apply();
                            continue;
                        }
                        seenIds.add(id);
                        saveSeenIds(prefs, seenIds, id, recvSec);
                    }

                    long msgSec = obj.optLong("time", 0L);
                    if (msgSec > 0L && (recvSec - msgSec) > 120L) {
                        continue;
                    }

                    String title = obj.optString("title", "💜 灿完时光").trim();
                    String body = obj.optString("message", "새 메시지가 도착했어요").trim();
                    if (body.startsWith("⏳ 번역 중") || body.startsWith("⏳ 正在翻译")) {
                        continue;
                    }

                    long nowMs = System.currentTimeMillis();
                    long whenMs = (msgSec > 0L) ? (msgSec * 1000L) : nowMs;

                    // Save latest push payload so opening from notification renders in 0.0s!
                    prefs.edit()
                            .putString("last_push_title", title)
                            .putString("last_push_body", body)
                            .putLong("last_push_when", whenMs)
                            .apply();

                    if (MainActivity.isAppInForeground) {
                        MainActivity.nudgeForegroundWebViewSync();
                        continue;
                    }

                    String fp = title + "|" + body;
                    if (fp.equals(lastFp) && (nowMs - lastFpMs) < 30000L) {
                        continue;
                    }

                    int notifId;
                    if ("suwan".equals(role) && lastNotifId > FG_NOTIF_ID && (nowMs - lastFpMs) < 8000L
                            && hasCjkNoHangul(lastBody) && hasHangul(body)) {
                        notifId = lastNotifId;
                    } else {
                        notifId = (int) ((nowMs & 0x3fffffffL) + 1000L);
                        if (notifId == lastNotifId) notifId++;
                    }

                    lastFp = fp;
                    lastFpMs = nowMs;
                    lastBody = body;
                    lastNotifId = notifId;

                    showMessageNotif(title, body, whenMs, notifId);
                }
            } catch (Exception ignored) {
                try { Thread.sleep(4000); } catch (InterruptedException ie) { break; }
            } finally {
                activeConn = null;
                if (conn != null) {
                    try { conn.disconnect(); } catch (Exception ignored) {}
                }
            }
        }
    }

    private void showMessageNotif(String title, String body, long whenMs, int notifId) {
        Intent open = new Intent(this, MainActivity.class);
        open.putExtra("from_notif", true);
        open.putExtra("notif_title", title);
        open.putExtra("notif_body", body);
        open.putExtra("notif_when", whenMs);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        PendingIntent pi = PendingIntent.getActivity(this, notifId, open, flags);

        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CH_MSG)
                : new Notification.Builder(this);
        b.setContentTitle(title)
                .setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setSmallIcon(R.drawable.ic_stat_heart)
                .setNumber(1)
                .setWhen(whenMs)
                .setShowWhen(true)
                .setAutoCancel(true)
                .setCategory(Notification.CATEGORY_MESSAGE)
                .setVisibility(Notification.VISIBILITY_PRIVATE)
                .setPriority(Notification.PRIORITY_HIGH)
                .setDefaults(Notification.DEFAULT_ALL)
                .setContentIntent(pi);

        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(notifId, b.build());
    }

    @Override
    public void onDestroy() {
        running = false;
        HttpURLConnection c = activeConn;
        if (c != null) {
            try { c.disconnect(); } catch (Exception ignored) {}
        }
        if (worker != null) worker.interrupt();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
