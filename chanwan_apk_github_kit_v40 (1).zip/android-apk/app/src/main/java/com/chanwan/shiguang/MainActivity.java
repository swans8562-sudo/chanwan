package com.chanwan.shiguang;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ServiceWorkerController;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final String APP_URL = "https://swans8562-sudo.github.io/chanwan/";
    private static final int FILE_CHOOSER_REQ = 1001;
    private static final int PERM_REQ = 1002;
    private static final int MIC_PERM_REQ = 1003;

    public static volatile boolean isAppInForeground = false;
    private static volatile MainActivity activeInstance = null;

    private WebView webView;
    private FrameLayout splashOverlay;
    private ValueCallback<Uri[]> filePathCallback;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activeInstance = this;
        updateForegroundState(true);

        FrameLayout root = new FrameLayout(this);
        webView = new WebView(this);
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        splashOverlay = new FrameLayout(this);
        splashOverlay.setBackgroundColor(Color.parseColor("#120d1f"));
        TextView splashText = new TextView(this);
        splashText.setText("✨ 灿完时光 ✨");
        splashText.setTextColor(Color.parseColor("#f5e6ff"));
        splashText.setTextSize(22f);
        splashText.setGravity(Gravity.CENTER);
        splashOverlay.addView(splashText, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER));
        root.addView(splashOverlay, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        setContentView(root);

        CookieManager.getInstance().setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            try {
                ServiceWorkerController.getInstance().getServiceWorkerWebSettings().setAllowContentAccess(true);
                ServiceWorkerController.getInstance().getServiceWorkerWebSettings().setAllowFileAccess(true);
            } catch (Exception ignored) {}
        }

        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setCacheMode(WebSettings.LOAD_DEFAULT);
        ws.setTextZoom(100);
        ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        webView.addJavascriptInterface(new NativeBridge(), "ChanwanNative");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (splashOverlay != null && splashOverlay.getVisibility() == View.VISIBLE) {
                    splashOverlay.animate().alpha(0f).setDuration(160).withEndAction(() -> splashOverlay.setVisibility(View.GONE)).start();
                }
                String inject = "(function(){try{var r=(localStorage.getItem('cw_my_role')||'').trim();if(!r){var s=JSON.parse(localStorage.getItem('chanwan_shiguang_v6_core')||localStorage.getItem('chanwan_shiguang_core_v1')||'{}');r=s.myRole||'suwan';}if(window.ChanwanNative&&r)window.ChanwanNative.setRole(r);}catch(e){}})();";
                view.evaluateJavascript(inject, null);
                handleNotificationOpenIntent(getIntent());
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), FILE_CHOOSER_REQ);
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }

            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_PERM_REQ);
                    }
                    request.grant(request.getResources());
                });
            }
        });

        requestRuntimePermissions();
        startPushService();

        Intent launchIntent = getIntent();
        boolean launchedFromNotif = launchIntent != null && launchIntent.getBooleanExtra("from_notif", false);
        webView.loadUrl(launchedFromNotif ? (APP_URL + "?tab=translator") : APP_URL);
    }

    @Override
    protected void onStart() {
        super.onStart();
        activeInstance = this;
        updateForegroundState(true);
        startPushService();
    }

    @Override
    protected void onResume() {
        super.onResume();
        activeInstance = this;
        if (webView != null) {
            try { webView.onResume(); webView.resumeTimers(); } catch (Exception ignored) {}
        }
        updateForegroundState(true);
        handleNotificationOpenIntent(getIntent());
        nudgeForegroundWebViewSync();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        activeInstance = this;
        if (webView != null) {
            try { webView.onResume(); webView.resumeTimers(); } catch (Exception ignored) {}
        }
        updateForegroundState(true);
        handleNotificationOpenIntent(intent);
    }

    @Override
    protected void onPause() {
        updateForegroundState(false);
        super.onPause();
    }

    @Override
    protected void onStop() {
        updateForegroundState(false);
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        if (activeInstance == this) activeInstance = null;
        updateForegroundState(false);
        super.onDestroy();
    }

    private void updateForegroundState(boolean inFg) {
        isAppInForeground = inFg;
        try {
            getSharedPreferences("cw_prefs", MODE_PRIVATE)
                    .edit()
                    .putBoolean("fg_active", inFg)
                    .putLong("fg_ts", System.currentTimeMillis())
                    .apply();
        } catch (Exception ignored) {}
        if (inFg) {
            ChanwanPushService.cancelAllMessageNotifs(this);
        }
    }

    private void handleNotificationOpenIntent(Intent intent) {
        if (intent == null || !intent.getBooleanExtra("from_notif", false)) return;
        String nTitle = intent.getStringExtra("notif_title");
        String nBody = intent.getStringExtra("notif_body");
        long nWhen = intent.getLongExtra("notif_when", System.currentTimeMillis());
        intent.removeExtra("from_notif");
        ChanwanPushService.cancelAllMessageNotifs(this);

        final String safeTitle = JSONObject.quote(nTitle != null ? nTitle : "");
        final String safeBody = JSONObject.quote(nBody != null ? nBody : "");
        final String js = "(function(){try{"
                + "window.__pendingNotifOpen={title:" + safeTitle + ",body:" + safeBody + ",when:" + nWhen + "};"
                + "if(typeof window.__openChatFromNotification==='function')window.__openChatFromNotification(" + safeTitle + "," + safeBody + "," + nWhen + ");"
                + "else if(typeof window.switchTab==='function')window.switchTab('translator');"
                + "}catch(e){}})();";

        if (webView != null) {
            webView.post(() -> {
                try { webView.evaluateJavascript(js, null); } catch (Exception ignored) {}
            });
            webView.postDelayed(() -> {
                try {
                    ChanwanPushService.cancelAllMessageNotifs(MainActivity.this);
                    webView.evaluateJavascript("if(typeof window.__openChatFromNotification==='function'&&window.__pendingNotifOpen){var p=window.__pendingNotifOpen;window.__pendingNotifOpen=null;window.__openChatFromNotification(p.title,p.body,p.when);}", null);
                } catch (Exception ignored) {}
            }, 350);
        }
    }

    public static void nudgeForegroundWebViewSync() {
        final MainActivity act = activeInstance;
        if (act == null) return;
        act.runOnUiThread(() -> {
            try {
                if (act.webView != null) {
                    act.webView.evaluateJavascript("(function(){try{if(typeof window.__pullFastChatDeltaNow==='function')window.__pullFastChatDeltaNow(true);else if(typeof window.__pullCloudSync==='function')window.__pullCloudSync('live_push');}catch(e){}})();", null);
                }
            } catch (Exception ignored) {}
        });
    }

    private void requestRuntimePermissions() {
        if (Build.VERSION.SDK_INT >= 23) {
            List<String> need = new ArrayList<>();
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                need.add(Manifest.permission.POST_NOTIFICATIONS);
            }
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                need.add(Manifest.permission.RECORD_AUDIO);
            }
            if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                need.add(Manifest.permission.CAMERA);
            }
            if (!need.isEmpty()) {
                requestPermissions(need.toArray(new String[0]), PERM_REQ);
            }
        }
    }

    private void startPushService() {
        try {
            Intent svc = new Intent(this, ChanwanPushService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(svc);
            } else {
                startService(svc);
            }
        } catch (Throwable ignored) {}
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_CHOOSER_REQ) {
            if (filePathCallback == null) return;
            Uri[] results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    public class NativeBridge {
        @JavascriptInterface
        public void setRole(String role) {
            if (role == null) return;
            String clean = role.trim().equals("jingchan") ? "jingchan" : "suwan";
            SharedPreferences prefs = getSharedPreferences("cw_prefs", MODE_PRIVATE);
            String prev = prefs.getString("role", "");
            if (!clean.equals(prev)) {
                prefs.edit().putString("role", clean).apply();
                startPushService();
            }
        }

        @JavascriptInterface
        public void clearNotifications() {
            ChanwanPushService.cancelAllMessageNotifs(MainActivity.this);
        }

        @JavascriptInterface
        public boolean isForeground() {
            return isAppInForeground;
        }

        @JavascriptInterface
        public boolean hasMicPermission() {
            if (Build.VERSION.SDK_INT < 23) return true;
            return checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
        }

        @JavascriptInterface
        public void requestMicPermission() {
            if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_PERM_REQ));
            }
        }

        @JavascriptInterface
        public void openAppSettings() {
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                    intent.setData(Uri.fromParts("package", getPackageName(), null));
                    startActivity(intent);
                } catch (Exception ignored) {}
            });
        }
    }
}
