            else if (actTab === 'diary') {
              if (typeof renderComplimentJar === 'function') renderComplimentJar();
              if (typeof renderCoupleQuizzes === 'function') renderCoupleQuizzes();
              if (typeof renderDrawQuizzes === 'function') renderDrawQuizzes();
              if (typeof renderRpsGame === 'function') renderRpsGame();
              if (typeof renderTruthDare === 'function') renderTruthDare();
              renderDiaryQaMemos(); renderBucketAndAlbum(); renderCoupons();
              if (typeof renderCoupleCalendar === 'function') renderCoupleCalendar();
              if (typeof renderBalanceGame === 'function') renderBalanceGame();
              if (typeof renderDateStampMap === 'function') renderDateStampMap();
            } else if (actTab === 'learn') renderLearn();
            else if (actTab === 'anniversary') renderAnniversary();
            if (Array.isArray(state.chat?.messages) && state.chat.messages.some(m => m && m.__tempPushPreview)) {
              const realPartnerMsgs = state.chat.messages.filter(m => m && !m.__tempPushPreview);
              if (newestPartnerMsg || realPartnerMsgs.some(m => m && m.ts && (Date.now() - Number(m.ts)) < 180000)) {
                state.chat.messages = realPartnerMsgs;
                chatChanged = true;
              }
            }
            if (newestPartnerMsg) {
              const myR = state.myRole || 'suwan';
              const pTs = Number(newestPartnerMsg.ts || Date.now());
              (state.chat?.messages || []).forEach(m => {
                const _ns = (m && (m.sender === 'jingchan' || String(m.sender || '').includes('靖灿'))) ? 'jingchan' : 'suwan';
                if (m && _ns === myR && !m.readByPartner && Number(m.ts || 0) > 0 && Number(m.ts || 0) <= pTs) { m.readByPartner = true; m.deliveryStatus = 'sent'; }
              });
            }
            const __pMsgAgeMs = (newestPartnerMsg && newestPartnerMsg.ts) ? (Date.now() - Number(newestPartnerMsg.ts)) : 0;
            const __isFreshPartnerMsg = !!(newestPartnerMsg && !newestPartnerMsg.read && (!newestPartnerMsg.ts || (__pMsgAgeMs >= -60000 && __pMsgAgeMs < 120000)));
            if (isLiveEvent && __isFreshPartnerMsg) {
              try { const tb = document.getElementById('chatTypingIndicator'); if (tb) tb.classList.add('hidden'); } catch (_) {}
              const pName = newestPartnerMsg.sender === 'suwan' ? '수완(完)' : '靖灿(灿)';
              const origTxtN = String(newestPartnerMsg.original || '');
              const rawTrN = String(newestPartnerMsg.translated || '').trim();
              const trTxtN = isPendingTransStr(rawTrN) ? '' : rawTrN;
              const origIsKoN = /[가-힣]/.test(origTxtN) && !/[\u4e00-\u9fff]/.test(origTxtN);
              const koOnlyBody = origIsKoN ? origTxtN : (trTxtN || origTxtN);
              const zhOnlyBody = origIsKoN ? (trTxtN || origTxtN) : origTxtN;
              const pDispKo = (newestPartnerMsg.sender === 'jingchan' || String(newestPartnerMsg.sender || '').includes('靖灿')) ? '징찬' : '수완';
              const pDispZh = pDispKo === '징찬' ? '靖灿' : '秀完';
              pushNotification('💬', `${pDispKo}의 새 메시지`, `${pDispZh}发来新消息`, koOnlyBody, zhOnlyBody, 'translator', 'messenger', 'post', false, (pDispKo === '징찬' ? 'jingchan' : 'suwan'), newestPartnerMsg.id);
              const trPanel = document.getElementById('tab-translator');
              if (trPanel && trPanel.classList.contains('active') && !document.hidden) {
                if (typeof window.__emitChatReadIfVisible === 'function') window.__emitChatReadIfVisible(false);
                const __mlCheck = document.getElementById('chatMessagesList');
                const __nearBot = !__mlCheck || (__mlCheck.scrollHeight - __mlCheck.scrollTop - __mlCheck.clientHeight) < 160;
                if (__nearBot && typeof window.__scrollChatToBottom === 'function') window.__scrollChatToBottom(true);
              }
            }
          }
          return changed;
        }

        async function fetchWithTimeout(url, options, timeoutMs) {
          const ctrl = new AbortController();
          const timer = setTimeout(() => ctrl.abort(), timeoutMs || SYNC_FETCH_TIMEOUT_MS);
          try {
            return await fetch(url, { ...(options || {}), signal: ctrl.signal });
          } finally {
            clearTimeout(timer);
          }
        }

        function sbHeaders(extra) {
          return {
            'apikey': SUPABASE_KEY,
            'Content-Type': 'application/json',
            ...(extra || {})
          };
        }

        // ---- 3rd Server: Zero-Dependency China-Direct EMQX MQTT over WSS (wss://broker.emqx.io:8084/mqtt) ----
        const __cwBootEpoch = Date.now();
        let emqxWs = null;
        let emqxConnected = false;
        let emqxLastOkTs = 0;
        let emqxPingTimer = null;
        let emqxReconnectTimer = null;
        let emqxSubscribedRoom = '';
        let emqxPendingQueue = [];
        const emqxEnc = new TextEncoder();
        const emqxDec = new TextDecoder();

        function mqttEncodeLen(len) {
          const out = [];
          do {
            let b = len % 128;
            len = Math.floor(len / 128);
            if (len > 0) b |= 128;
            out.push(b);
          } while (len > 0);
          return out;
        }
        function mqttStr(s) {
          const b = emqxEnc.encode(String(s || ''));
          return new Uint8Array([(b.length >> 8) & 255, b.length & 255, ...b]);
        }
        function mqttPacket(headerByte, parts) {
          const total = parts.reduce((a, p) => a + p.length, 0);
          const rem = mqttEncodeLen(total);
          const buf = new Uint8Array(1 + rem.length + total);
          buf[0] = headerByte;
          rem.forEach((v, i) => { buf[1 + i] = v; });
          let off = 1 + rem.length;
          for (const p of parts) { buf.set(p, off); off += p.length; }
          return buf;
        }
        function getEmqxTopic(room) {
          return 'chanwan/v16/' + String(room || DEFAULT_COUPLE_ROOM).replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 48) + '/sync';
        }
        function publishEmqxBackup(room, jsonStr) {
          if (!jsonStr) return false;
          if (!emqxWs || !emqxConnected || emqxWs.readyState !== 1) {
            // Queue for instant flush on CONNACK so Mainland China messages NEVER drop during reconnect!
            emqxPendingQueue.push({ room, jsonStr, ts: Date.now() });
            if (emqxPendingQueue.length > 15) emqxPendingQueue = emqxPendingQueue.slice(-15);
            connectEmqxChinaDirect();
            return false;
          }
          try {
            const sendWire = (wireStr) => {
              if (!emqxWs || !emqxConnected || emqxWs.readyState !== 1 || !wireStr) return false;
              const topicBytes = mqttStr(getEmqxTopic(room));
              const payloadBytes = emqxEnc.encode(wireStr);
              if (payloadBytes.length > 780000) return false;
              emqxWs.send(mqttPacket(0x30, [topicBytes, payloadBytes]));
              emqxLastOkTs = Date.now();
              return true;
            };
            if (window.__isE2eeActive && window.__isE2eeActive()) {
              e2eeWrapString(jsonStr).then(encStr => sendWire(encStr)).catch(() => {});
              return true;
            }
            return sendWire(jsonStr);
          } catch (_) { return false; }
        }
        function connectEmqxChinaDirect() {
          const room = getSyncRoomCode();
          if (!room) return;
          if (typeof navigator !== 'undefined' && navigator.onLine === false) return;
          if (emqxWs && (emqxWs.readyState === 0 || emqxWs.readyState === 1) && emqxSubscribedRoom === room) return;
          try { if (emqxWs) emqxWs.close(); } catch (_) {}
          emqxConnected = false;
          emqxSubscribedRoom = room;
          try {
            const ws = new WebSocket('wss://broker.emqx.io:8084/mqtt', 'mqtt');
            ws.binaryType = 'arraybuffer';
            emqxWs = ws;
            ws.onopen = () => {
              const cid = 'cw_' + myDeviceClientId.slice(-10) + '_' + Math.random().toString(36).slice(2, 6);
              const vh = new Uint8Array([0, 4, 77, 81, 84, 84, 4, 2, 0, 30]); // MQTT 3.1.1, clean, keepalive 30s
              ws.send(mqttPacket(0x10, [vh, mqttStr(cid)]));
            };
            ws.onmessage = (ev) => {
              try {
                const u = new Uint8Array(ev.data);
                let pos = 0;
                while (pos < u.length) {
                  const type = u[pos] >> 4;
                  const flags = u[pos] & 0x0f;
                  pos++;
                  let mult = 1, remLen = 0, b = 0;
                  do {
                    if (pos >= u.length) return;
                    b = u[pos++];
                    remLen += (b & 127) * mult;
                    mult *= 128;
                  } while ((b & 128) !== 0);
                  const endPos = pos + remLen;
                  if (endPos > u.length) return;
                  if (type === 2) { // CONNACK
                    emqxConnected = true;
                    emqxLastOkTs = Date.now();
                    lastSyncOkTs = Math.max(lastSyncOkTs, emqxLastOkTs);
                    const subTopic = mqttStr(getEmqxTopic(room));
                    ws.send(mqttPacket(0x82, [new Uint8Array([0, 1]), subTopic, new Uint8Array([0])]));
                    if (emqxPingTimer) clearInterval(emqxPingTimer);
                    emqxPingTimer = setInterval(() => {
                      if (document.hidden) return;
                      if (emqxWs && emqxWs.readyState === 1) {
                        // Zombie-socket watchdog: if no PINGRESP or traffic for >32s, force clean reconnect!
                        if (emqxLastOkTs && (Date.now() - emqxLastOkTs) > 32000) {
                          try { emqxWs.close(); } catch (_) {}
                          emqxConnected = false;
                          connectEmqxChinaDirect();
                          return;
                        }
                        try { emqxWs.send(new Uint8Array([0xC0, 0x00])); } catch (_) {}
                      } else if (!emqxConnected) {
                        connectEmqxChinaDirect();
                      }
                    }, 12000);
                    updateLiveSyncIndicators(true, room);
                    try { if (!document.hidden && typeof window.__broadcastPresenceNow === 'function') window.__broadcastPresenceNow(true, true); } catch (_) {}
                    if (emqxPendingQueue.length) {
                      const qCopy = emqxPendingQueue.slice();
                      emqxPendingQueue = [];
                      let flushedAny = false;
                      qCopy.forEach(item => {
                        if (item && item.jsonStr && publishEmqxBackup(item.room || room, item.jsonStr)) flushedAny = true;
                      });
                      if (flushedAny && typeof window.__markMyPendingMsgsStatus === 'function') {
                        window.__markMyPendingMsgsStatus('sent');
                      }
                    }
                  } else if (type === 13) { // PINGRESP
                    emqxLastOkTs = Date.now();
                  } else if (type === 3) { // PUBLISH
                    const tLen = (u[pos] << 8) | u[pos + 1];
                    let pStart = pos + 2 + tLen;
                    const qos = (flags >> 1) & 3;
                    if (qos > 0) pStart += 2;
                    if (pStart < endPos) {
                      const rawStr = emqxDec.decode(u.subarray(pStart, endPos));
                      emqxLastOkTs = Date.now();
                      lastSyncOkTs = Math.max(lastSyncOkTs, emqxLastOkTs);
                      const isRetainedMqtt = !!(flags & 1);
                      e2eeUnwrapString(rawStr).then((data) => {
                        if (data && data.clientId !== myDeviceClientId) {
                          const pktTs = Number(data.ts || 0);
                          const isFresh = !isRetainedMqtt && (!pktTs || (Date.now() - pktTs) <= 60000) && (Date.now() - __cwBootEpoch) > 3500;
                          if (data.v === 'pro2') mergeIncomingCoupleData(data, isFresh);
                          else if (data.v === 'pro2_signal') handleIncomingChatSignal(data);
                          else if (data.v === 'pro2_media') handleIncomingMediaPacket(data, isFresh);
                          else if (data.v === 'pro2_media_chunk') handleIncomingMediaChunk(data, isFresh);
                        }
                      }).catch(() => {});
                    }
                  }
                  pos = endPos;
                }
              } catch (_) {}
            };
            ws.onclose = () => {
              emqxConnected = false;
              if (emqxPingTimer) { clearInterval(emqxPingTimer); emqxPingTimer = null; }
              if (emqxReconnectTimer) clearTimeout(emqxReconnectTimer);
              emqxReconnectTimer = setTimeout(() => { if (!document.hidden) connectEmqxChinaDirect(); }, 2000);
              updateLiveSyncIndicators(syncTransportMode === 'realtime' || syncTransportMode === 'rest', room);
            };
            ws.onerror = () => { emqxConnected = false; };
          } catch (_) {}
        }

        // ---- Dual-Server Active Backup Relay (ntfy.sh, strictly < 3.6KB UTF-8) ----
        const NTFY_SEEN_IDS = new Set();
        let ntfyLastOkTs = 0;

        function getNtfyTopic(room) {
          return 'chanwan_pro2_' + String(room || DEFAULT_COUPLE_ROOM).replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 48);
        }

        function buildCompactNtfyPacket(coreObj) {
          const base = {
            v: 'pro2',
            ts: Date.now(),
            clientId: myDeviceClientId,
            myRole: state.myRole || 'suwan',
            heartCount: coreObj.heartCount || 0,
            heartResetDate: coreObj.heartResetDate || getKstDateString(),
            startDate: coreObj.startDate || '',
            startDateUpdatedAt: Number(coreObj.startDateUpdatedAt || 0),
            cities: coreObj.cities || null,
            profile: {
              suwanMood: coreObj.profile?.suwanMood,
              jingchanMood: coreObj.profile?.jingchanMood,
              suwanActivity: coreObj.profile?.suwanActivity || '',
              jingchanActivity: coreObj.profile?.jingchanActivity || '',
              suwanActivityUpdatedAt: Number(coreObj.profile?.suwanActivityUpdatedAt || 0),
              jingchanActivityUpdatedAt: Number(coreObj.profile?.jingchanActivityUpdatedAt || 0),
              suwanLastSeen: Number(coreObj.profile?.suwanLastSeen || 0),
              jingchanLastSeen: Number(coreObj.profile?.jingchanLastSeen || 0),
              suwanReadUpToTs: Number(coreObj.profile?.suwanReadUpToTs || 0),
              jingchanReadUpToTs: Number(coreObj.profile?.jingchanReadUpToTs || 0),
              suwanSleep: coreObj.profile?.suwanSleep,
              jingchanSleep: coreObj.profile?.jingchanSleep,
              suwanEnergy: coreObj.profile?.suwanEnergy,
              jingchanEnergy: coreObj.profile?.jingchanEnergy
            },
            hugs: coreObj.hugs || null,
            lavender: coreObj.lavender || null,
            complimentJar: (coreObj.complimentJar || []).slice(0, 2),
            coupleQuizzes: (coreObj.coupleQuizzes || []).slice(0, 2),
            chat: {
              messages: (coreObj.chat?.messages || []).slice(-4).map(m => ({
                id: m.id, ts: m.ts, sender: m.sender, time: m.time,
                original: String(m.original || '').slice(0, 220),
                translated: String(m.translated || '').slice(0, 220),
                pronunciation: String(m.pronunciation || '').slice(0, 120),
                tone: m.tone || '', engine: m.engine || '', tgtLang: m.tgtLang || '',
                accuracy: m.accuracy || 0, editedAt: m.editedAt || 0, readByPartner: !!m.readByPartner, reactions: m.reactions || []
              })),
              qaAnswers: (coreObj.chat?.qaAnswers || []).slice(0, 2)
            },
            diaries: (coreObj.diaries || []).slice(0, 1),
            memos: (coreObj.memos || []).slice(0, 1),
            deletedMsgIds: (coreObj.deletedMsgIds || []).slice(-10),
            deletedAlbumIds: (coreObj.deletedAlbumIds || []).slice(-15),
            rpsGame: coreObj.rpsGame || null,
            truthDare: coreObj.truthDare ? { activeCard: coreObj.truthDare.activeCard, updatedAt: coreObj.truthDare.updatedAt, history: (coreObj.truthDare.history || []).slice(0, 3) } : null
          };
          let str = JSON.stringify(base);
          if (new Blob([str]).size > 3500) {
            base.truthDare = null;
            base.complimentJar = [];
            base.coupleQuizzes = [];
            base.chat.qaAnswers = [];
            base.diaries = [];
            base.memos = [];
            base.cities = null;
            base.lavender = null;
            str = JSON.stringify(base);
          }
          if (new Blob([str]).size > 3500) {
            // Ultra-compact chat-priority fallback so ntfy NEVER returns null when sending messages!
            const chatOnly = {
              v: 'pro2', ts: Date.now(), clientId: myDeviceClientId, myRole: state.myRole || 'suwan',
              chat: { messages: (coreObj.chat?.messages || []).slice(-2).map(m => ({
                id: m.id, ts: m.ts, sender: m.sender, time: m.time,
                original: String(m.original || '').slice(0, 180),
                translated: String(m.translated || '').slice(0, 180),
                tone: m.tone || '', nuance: String(m.nuance || '').slice(0, 80),
                accuracy: m.accuracy || 0, editedAt: m.editedAt || 0, readByPartner: !!m.readByPartner, reactions: m.reactions || []
              })) },
              deletedMsgIds: (coreObj.deletedMsgIds || []).slice(-6)
            };
            str = JSON.stringify(chatOnly);
          }
          return new Blob([str]).size <= 3850 ? str : null;
        }

        function buildEmqxFastPacket(coreObj) {
          if (!coreObj) return null;
          const pkt = {
            v: 'pro2',
            ts: Date.now(),
            clientId: myDeviceClientId,
            myRole: state.myRole || 'suwan',
            heartCount: coreObj.heartCount || 0,
            heartResetDate: coreObj.heartResetDate || getKstDateString(),
            startDate: coreObj.startDate || '',
            startDateUpdatedAt: Number(coreObj.startDateUpdatedAt || 0),
            cities: coreObj.cities || null,
            profile: {
              suwanMood: coreObj.profile?.suwanMood,
              jingchanMood: coreObj.profile?.jingchanMood,
              suwanMoodUpdatedAt: Number(coreObj.profile?.suwanMoodUpdatedAt || 0),
              jingchanMoodUpdatedAt: Number(coreObj.profile?.jingchanMoodUpdatedAt || 0),
              suwanActivity: coreObj.profile?.suwanActivity || '',
              jingchanActivity: coreObj.profile?.jingchanActivity || '',
              suwanActivityUpdatedAt: Number(coreObj.profile?.suwanActivityUpdatedAt || 0),
              jingchanActivityUpdatedAt: Number(coreObj.profile?.jingchanActivityUpdatedAt || 0),
              suwanLastSeen: Number(coreObj.profile?.suwanLastSeen || 0),
              jingchanLastSeen: Number(coreObj.profile?.jingchanLastSeen || 0),
              suwanReadUpToTs: Number(coreObj.profile?.suwanReadUpToTs || 0),
              jingchanReadUpToTs: Number(coreObj.profile?.jingchanReadUpToTs || 0),
              suwanSleep: coreObj.profile?.suwanSleep,
              jingchanSleep: coreObj.profile?.jingchanSleep,
              suwanEnergy: coreObj.profile?.suwanEnergy,
              jingchanEnergy: coreObj.profile?.jingchanEnergy
            },
            hugs: coreObj.hugs || null,
            makerLayout: coreObj.makerLayout || null,
            lavender: coreObj.lavender || null,
            learn: coreObj.learn || undefined,
            complimentJar: (coreObj.complimentJar || []).slice(0, 4),
            coupleQuizzes: (coreObj.coupleQuizzes || []).slice(0, 4),
            chat: {
              pinnedMsg: coreObj.chat?.pinnedMsg || null,
              messages: (coreObj.chat?.messages || []).slice(-8).map(m => ({
                id: m.id, ts: m.ts, sender: m.sender, time: m.time,
                original: String(m.original || '').slice(0, 500),
                translated: String(m.translated || '').slice(0, 500),
                altTranslated: String(m.altTranslated || '').slice(0, 400),
                pronunciation: String(m.pronunciation || '').slice(0, 220),
                tone: m.tone || '', toneZh: m.toneZh || '', nuance: String(m.nuance || '').slice(0, 180), nuanceZh: String(m.nuanceZh || '').slice(0, 180),
                engine: m.engine || '', tgtLang: m.tgtLang || '',
                accuracy: m.accuracy || 0, editedAt: m.editedAt || 0, readByPartner: !!m.readByPartner, reactions: m.reactions || [],
                replyTo: m.replyTo || null, sticker: m.sticker || '', stickerIdx: m.stickerIdx
              })),
              qaAnswers: (coreObj.chat?.qaAnswers || []).slice(0, 3)
            },
            diaries: (coreObj.diaries || []).slice(0, 2),
            memos: (coreObj.memos || []).slice(0, 2),
            deletedMsgIds: (coreObj.deletedMsgIds || []).slice(-15),
            deletedAlbumIds: (coreObj.deletedAlbumIds || []).slice(-20),
            rpsGame: coreObj.rpsGame || null,
            truthDare: coreObj.truthDare ? { activeCard: coreObj.truthDare.activeCard, updatedAt: coreObj.truthDare.updatedAt, history: (coreObj.truthDare.history || []).slice(0, 6) } : null,
            drawQuizzes: (coreObj.drawQuizzes || []).slice(0, 4),
            albumFolders: Array.isArray(coreObj.albumFolders) ? coreObj.albumFolders : undefined,
            albumFoldersCustomized: !!coreObj.albumFoldersCustomized,
            albumFoldersUpdatedAt: Number(coreObj.albumFoldersUpdatedAt || 0),
            albumMeta: coreObj.albumMeta || undefined,
            customFoods: Array.isArray(coreObj.customFoods) ? coreObj.customFoods.slice(0, 30) : undefined,
            balanceGame: coreObj.balanceGame || undefined,
            dateStamps: coreObj.dateStamps || undefined,
            schedules: (coreObj.schedules || []).slice(0, 20),
            buckets: (coreObj.buckets || []).slice(0, 20),
            coupons: (coreObj.coupons || []).slice(0, 15),
            anniversaries: (coreObj.anniversaries || []).slice(0, 15),
            capsules: (coreObj.capsules || []).slice(0, 10)
          };
          try { return JSON.stringify(pkt); } catch (_) { return null; }
        }

        async function pushNtfyBackup(room, bodyStr) {
          if (!room || !bodyStr) return false;
          try {
            const wireBody = await e2eeWrapString(bodyStr);
            if (!wireBody || new Blob([wireBody]).size > 3950) return false;
            const res = await fetchWithTimeout(`https://ntfy.sh/${encodeURIComponent(getNtfyTopic(room))}`, {
              method: 'POST',
              headers: { 'Content-Type': 'text/plain; charset=utf-8' },
              body: wireBody
            }, 8000);
            if (res.ok) { ntfyLastOkTs = Date.now(); return true; }
          } catch (_) {}
          return false;
        }

        try {
          const savedNtfyIds = JSON.parse(localStorage.getItem('cw_ntfy_seen_ids_v1') || '[]');
          if (Array.isArray(savedNtfyIds)) savedNtfyIds.forEach(x => NTFY_SEEN_IDS.add(x));
        } catch (_) {}
        async function pollNtfyBackup(room, isLive) {
          if (!room) return false;
          try {
            const res = await fetchWithTimeout(`https://ntfy.sh/${encodeURIComponent(getNtfyTopic(room))}/json?poll=1&since=10m`, {}, 8000);
            if (!res.ok) return false;
            ntfyLastOkTs = Date.now();
            const text = await res.text();
            let mergedAny = false;
            let addedSeen = false;
            const nowSec = Math.floor(Date.now() / 1000);
            for (const line of text.split('\n')) {
              if (!line.trim()) continue;
              try {
                const env = JSON.parse(line);
                if (!env || env.event !== 'message' || !env.message) continue;
                if (env.id && NTFY_SEEN_IDS.has(env.id)) continue;
                if (env.id) {
                  NTFY_SEEN_IDS.add(env.id);
                  addedSeen = true;
                  if (NTFY_SEEN_IDS.size > 200) NTFY_SEEN_IDS.delete(NTFY_SEEN_IDS.values().next().value);
                }
                const data = await e2eeUnwrapString(env.message);
                if (!data || data.clientId === myDeviceClientId) continue;
                const ageSec = env.time ? (nowSec - Number(env.time)) : 0;
                const liveNow = !!isLive && ageSec <= 90;
                if (data.v === 'pro2') {
                  if (mergeIncomingCoupleData(data, liveNow)) mergedAny = true;
                } else if (data.v === 'pro2_signal') {
                  handleIncomingChatSignal(data);
                }
              } catch (_) {}
            }
            if (addedSeen) {
              try { localStorage.setItem('cw_ntfy_seen_ids_v1', JSON.stringify(Array.from(NTFY_SEEN_IDS).slice(-120))); } catch (_) {}
            }
            return mergedAny;
          } catch (_) { return false; }
        }

        let __sbHasKindCol = null;
        try {
          const cachedK = localStorage.getItem('cw_sb_has_kind_col_v1');
          if (cachedK === '0') __sbHasKindCol = false;
          else if (cachedK === '1') __sbHasKindCol = true;
        } catch (_) {}

        function stripSbKindParam(url) {
          return String(url || '')
            .replace(/&kind=eq\.[a-zA-Z0-9_-]+/g, '')
            .replace(/\?kind=eq\.[a-zA-Z0-9_-]+&/g, '?');
        }

        async function fetchSbEventsCompat(url, timeoutMs) {
          const useUrl = (__sbHasKindCol === false) ? stripSbKindParam(url) : url;
          let res = await fetchWithTimeout(useUrl, { headers: sbHeaders() }, timeoutMs || SYNC_FETCH_TIMEOUT_MS);
          if (res.status === 400 && useUrl.includes('kind=eq.')) {
            __sbHasKindCol = false;
            try { localStorage.setItem('cw_sb_has_kind_col_v1', '0'); } catch (_) {}
            res = await fetchWithTimeout(stripSbKindParam(url), { headers: sbHeaders() }, timeoutMs || SYNC_FETCH_TIMEOUT_MS);
          } else if (res.ok && useUrl.includes('kind=eq.') && __sbHasKindCol === null) {
            __sbHasKindCol = true;
            try { localStorage.setItem('cw_sb_has_kind_col_v1', '1'); } catch (_) {}
          }
          return res;
        }

        let __sbEventsUnavailable = false;
        async function insertSupabaseEvent(room, kind, payloadObj) {
          if (__sbEventsUnavailable) return false;
          const wirePayload = await e2eeWrapPayload(payloadObj);
          const timeoutVal = kind === 'media' ? Math.max(SYNC_FETCH_TIMEOUT_MS, 20000) : SYNC_FETCH_TIMEOUT_MS;
          const postBody = (includeKind) => JSON.stringify(includeKind
            ? { room_id: room, client_id: myDeviceClientId, kind: kind || 'delta', payload: wirePayload }
            : { room_id: room, client_id: myDeviceClientId, payload: wirePayload });

          let res = await fetchWithTimeout(`${SUPABASE_URL}/rest/v1/couple_sync_events`, {
            method: 'POST',
            headers: sbHeaders({ 'Prefer': 'return=representation' }),
            body: postBody(__sbHasKindCol !== false)
          }, timeoutVal);

          if (res.status === 400 && __sbHasKindCol !== false) {
            __sbHasKindCol = false;
            try { localStorage.setItem('cw_sb_has_kind_col_v1', '0'); } catch (_) {}
            res = await fetchWithTimeout(`${SUPABASE_URL}/rest/v1/couple_sync_events`, {
              method: 'POST',
              headers: sbHeaders({ 'Prefer': 'return=representation' }),
              body: postBody(false)
            }, timeoutVal);
          } else if (res.ok && __sbHasKindCol === null) {
            __sbHasKindCol = true;
            try { localStorage.setItem('cw_sb_has_kind_col_v1', '1'); } catch (_) {}
          }

          if ([400, 401, 403, 404, 422].includes(res.status)) {
            __sbEventsUnavailable = true;
            return false;
          }
          if (!res.ok) throw new Error('sb_insert_' + res.status);
          sbLastOkTs = Date.now();
          lastSyncOkTs = Date.now();
          try {
            const rows = await res.json();
            if (Array.isArray(rows) && rows[0] && rows[0].id) {
              processedEventIds.add(rows[0].id);
            }
          } catch (_) {}
          return true;
        }

        async function upsertSupabaseStateSnapshot(room, payloadObj, customTimeoutMs) {
          const wirePayload = await e2eeWrapPayload(payloadObj);
          const res = await fetchWithTimeout(`${SUPABASE_URL}/rest/v1/couple_sync_state?on_conflict=room_id`, {
            method: 'POST',
            headers: sbHeaders({ 'Prefer': 'resolution=merge-duplicates,return=minimal' }),
            body: JSON.stringify({
              room_id: room,
              payload: wirePayload,
              updated_at: Date.now()
            })
          }, customTimeoutMs || SYNC_FETCH_TIMEOUT_MS);
          if (!res.ok) throw new Error('sb_upsert_' + res.status);
          sbLastOkTs = Date.now();
          lastSyncOkTs = Date.now();
          return true;
        }

        // ==================== Prime 4 v58: Schema-Proof Permanent Cloud Media Vault inside couple_sync_state ====================
        // Uses proven couple_sync_state (room_id PK + payload JSONB) so albums, voice letters, avatars & chat media NEVER vanish even if couple_sync_events fails!
        const CW_VM_UPLOADED_KEY = 'cw_vm_uploaded_keys_v67';
        function getUploadedVaultSet() {
          try {
            const arr = JSON.parse(localStorage.getItem(CW_VM_UPLOADED_KEY) || '[]');
            return new Set(Array.isArray(arr) ? arr : []);
          } catch (_) { return new Set(); }
        }
        function markVaultKeyUploaded(vKey) {
          if (!vKey) return;
          try {
            const s = getUploadedVaultSet();
            s.add(vKey);
            const arr = Array.from(s).slice(-500);
            localStorage.setItem(CW_VM_UPLOADED_KEY, JSON.stringify(arr));
          } catch (_) {}
        }
        function cwSafeVaultKey(rawKey) {
          return String(rawKey || '').replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 72) || ('vk_' + Date.now());
        }
        function deriveDeterministicVaultKey(kind, meta, fallbackId) {
          const m = meta || {};
          if (kind === 'album_photo' || kind === 'album_video') return cwSafeVaultKey('alb_' + (m.albumId || fallbackId));
          if (kind === 'voice_letter') return cwSafeVaultKey('vl_' + (m.id || fallbackId));
          if (kind === 'avatar') return cwSafeVaultKey('av_' + (m.target || 'suwan'));
          if (kind === 'custom_voice') {
            let h = 0;
            const s = String(m.phrase || fallbackId || '');
            for (let i = 0; i < s.length; i++) h = ((h << 5) - h + s.charCodeAt(i)) | 0;
            return cwSafeVaultKey('cv_' + Math.abs(h).toString(36));
          }
          if (kind === 'chat_photo' || kind === 'chat_video' || kind === 'chat_voice') {
            return cwSafeVaultKey('cm_' + (m.msgId || fallbackId) + (m.batchIdx !== undefined ? '_' + m.batchIdx : ''));
          }
          return cwSafeVaultKey(kind + '_' + fallbackId);
        }

        // Dedicated Cloud Study Vault (${room}__learn_vault_v1): NEVER shrinks unless explicit resetAt > cloudResetAt!
        let __cachedCloudLearn = null;
        async function syncCloudLearnVault(room, forcePush) {
          if (!room) return false;
          const lRoom = `${room}__learn_vault_v1`;
          let changedLocal = false;
          try {
            const res = await fetchWithTimeout(`${SUPABASE_URL}/rest/v1/couple_sync_state?room_id=eq.${encodeURIComponent(lRoom)}&select=payload`, { headers: sbHeaders() }, 10000);
            if (res.ok) {
              sbLastOkTs = Date.now();
              const arr = await res.json();
              if (Array.isArray(arr) && arr[0] && arr[0].payload) {
                const dec = await e2eeUnwrapPayload(arr[0].payload);
                if (dec && dec.learn && typeof dec.learn === 'object') {
                  __cachedCloudLearn = dec.learn;
                  const beforeS = JSON.stringify(state.learn || {});
                  const merged = mergeLearnMonotonic(state.learn, dec.learn);
                  if (JSON.stringify(merged) !== beforeS) {
                    state.learn = merged;
                    changedLocal = true;
                    try { idbPut('learn_vault_v1', state.learn); } catch (_) {}
                    saveState(false);
                    try { renderLearn(); renderHome(); } catch (_) {}
                  }
                }
              }
            }
          } catch (_) {}

          const curL = state.learn || {};
          const hasProgress = Number(curL.xp || 0) > 0 || Number(curL.solved || 0) > 0 || (curL.praiseStickers || []).length > 0 || Number(curL.resetAt || 0) > 0;
          if (hasProgress) {
            const safeOut = __cachedCloudLearn ? mergeLearnMonotonic(__cachedCloudLearn, curL) : curL;
            if (forcePush || !__cachedCloudLearn || JSON.stringify(safeOut) !== JSON.stringify(__cachedCloudLearn)) {
              __cachedCloudLearn = safeOut;
              try {
                await upsertSupabaseStateSnapshot(lRoom, { v: 'cw_learn_vault_v1', updatedAt: Date.now(), learn: safeOut }, 12000);
              } catch (_) {}
            }
          }
          return changedLocal;
        }
        window.__syncCloudLearnVaultNow = () => syncCloudLearnVault(getSyncRoomCode(), true);

        let __cwManifestQueue = Promise.resolve();
        async function fetchCloudVaultManifest(room) {
          const mRoom = `${room}__vault_manifest_v1`;
          try {
            const res = await fetchWithTimeout(`${SUPABASE_URL}/rest/v1/couple_sync_state?room_id=eq.${encodeURIComponent(mRoom)}&select=payload,updated_at`, { headers: sbHeaders() }, 10000);
            if (!res.ok) return [];
            sbLastOkTs = Date.now();
            const arr = await res.json();
            if (Array.isArray(arr) && arr[0] && arr[0].payload) {
              const dec = await e2eeUnwrapPayload(arr[0].payload);
              if (dec && Array.isArray(dec.items)) return dec.items;
            }
          } catch (_) {}
          return [];
        }

        function appendCloudVaultManifest(room, entry) {
          __cwManifestQueue = __cwManifestQueue.then(async () => {
            try {
              const curItems = await fetchCloudVaultManifest(room);
              const map = new Map();
              for (const it of curItems) {
                if (it && it.key) map.set(it.key, it);
              }
              map.set(entry.key, entry);
              const merged = Array.from(map.values()).sort((a, b) => Number(a.ts || 0) - Number(b.ts || 0)).slice(-450);
              await upsertSupabaseStateSnapshot(`${room}__vault_manifest_v1`, {
                v: 'cw_vault_manifest_v1',
                updatedAt: Date.now(),
                items: merged
              }, 12000);
            } catch (_) {}
          }).catch(() => {});
          return __cwManifestQueue;
        }

        async function saveVaultItemToCloudState(room, itemKey, kind, meta, rawDataUrl) {
          if (!room || !itemKey || !rawDataUrl || !String(rawDataUrl).startsWith('data:')) return false;
          const safeKey = cwSafeVaultKey(itemKey);
          const dataStr = (kind === 'voice_letter' || kind === 'chat_voice' || kind === 'custom_voice')
            ? normalizeAudioDataUrl(String(rawDataUrl))
            : String(rawDataUrl);
          const CHUNK_LEN = 220000;
          const totalChunks = Math.max(1, Math.ceil(dataStr.length / CHUNK_LEN));
          const nowTs = Date.now();
          const roleNow = (meta && (meta.sender || meta.authorRole)) || state.myRole || 'suwan';
          try {
            if (totalChunks === 1) {
              await upsertSupabaseStateSnapshot(`${room}__vm__${safeKey}`, {
                v: 'cw_vm_v1',
                itemKey: safeKey,
                kind,
                myRole: roleNow,
                meta: meta || {},
                dataUrl: dataStr,
                ts: nowTs
              }, 18000);
            } else {
              for (let c = 0; c < totalChunks; c += 3) {
                const jobs = [];
                for (let j = c; j < Math.min(totalChunks, c + 3); j++) {
                  jobs.push(upsertSupabaseStateSnapshot(`${room}__vm__${safeKey}__c${j}`, {
                    v: 'cw_vm_chunk_v1',
                    itemKey: safeKey,
                    idx: j,
                    total: totalChunks,
                    data: dataStr.slice(j * CHUNK_LEN, (j + 1) * CHUNK_LEN)
                  }, 20000));
                }
                const resList = await Promise.allSettled(jobs);
                if (resList.some(r => r.status !== 'fulfilled')) throw new Error('vm_chunk_failed');
              }
              await upsertSupabaseStateSnapshot(`${room}__vm__${safeKey}`, {
                v: 'cw_vm_head_v1',
                itemKey: safeKey,
                kind,
                myRole: roleNow,
                meta: meta || {},
                chunks: totalChunks,
                ts: nowTs
              }, 15000);
            }
            await appendCloudVaultManifest(room, { key: safeKey, kind, chunks: totalChunks, ts: nowTs });
            markVaultKeyUploaded(safeKey);
            return true;
          } catch (_) {
            return false;
          }
        }

        function isVaultEntryAlreadyLocal(entry) {
          if (!entry || !entry.key) return false;
          const k = entry.key;
          const delAlb = new Set(Array.isArray(state.deletedAlbumIds) ? state.deletedAlbumIds : []);
          const delVl = new Set(Array.isArray(state.deletedVoiceIds) ? state.deletedVoiceIds : []);
          if (entry.kind === 'album_photo' || entry.kind === 'album_video') {
            const rawId = k.replace(/^alb_/, '');
            if (delAlb.has(rawId)) return true;
            return (state.albums || []).some(a => a && a.dataUrl && cwSafeVaultKey('alb_' + a.id) === k);
          }
          if (entry.kind === 'voice_letter') {
            const rawId = k.replace(/^vl_/, '');
            if (delVl.has(rawId)) return true;
            return (state.voiceLetters || []).some(v => v && v.audioUrl && cwSafeVaultKey('vl_' + v.id) === k);
          }
          if (entry.kind === 'avatar') {
            if (k === 'av_suwan') return !!(state.profile && state.profile.suwanAvatar);
            if (k === 'av_jingchan') return !!(state.profile && state.profile.jingchanAvatar);
          }
          if (entry.kind === 'chat_photo' || entry.kind === 'chat_video' || entry.kind === 'chat_voice') {
            const rawMid = k.replace(/^cm_/, '').replace(/_\d+$/, '');
            const delMsg = new Set(Array.isArray(state.deletedMsgIds) ? state.deletedMsgIds : []);
            if (delMsg.has(rawMid)) return true;
            return (state.chat?.messages || []).some(m => m && (m.id === rawMid || cwSafeVaultKey('cm_' + m.id) === k) && !!(m.photoUrl || m.videoUrl || m.audioUrl));
          }
          if (entry.kind === 'custom_voice') {
            for (const [phr, u] of Object.entries(state.customVoices || {})) {
              if (u && deriveDeterministicVaultKey('custom_voice', { phrase: phr }, phr) === k) return true;
            }
          }
          return false;
        }

        async function restoreVaultBatchParallel(room, manifestList) {
          if (!room || !Array.isArray(manifestList) || !manifestList.length) return 0;
          // Prioritize avatars + newest items FIRST so recent chat/album photos appear in <0.8s!
          const ordered = manifestList.slice().reverse().sort((a, b) => {
            const aAv = (a && a.kind === 'avatar') ? 1 : 0;
            const bAv = (b && b.kind === 'avatar') ? 1 : 0;
            if (aAv !== bAv) return bAv - aAv;
            return Number(b?.ts || 0) - Number(a?.ts || 0);
          });
          const missing = ordered.filter(it => it && it.key && !isVaultEntryAlreadyLocal(it));
          let count = 0;
          for (let i = 0; i < missing.length; i += 4) {
            const batch = missing.slice(i, i + 4);
            const res = await Promise.all(batch.map(it => restoreVaultEntryFromCloudState(room, it).catch(() => false)));
            res.forEach(ok => { if (ok) count++; });
            if (count > 0 && i === 0) {
              try { renderHome(); renderChat(); renderBucketAndAlbum(); if (typeof renderVoiceLetters === 'function') renderVoiceLetters(); } catch (_) {}
            }
          }
          return count;
        }

        // Fast 1-Request Recent Media Pack (${room}__recent_media_v1): delivers avatars + recent chat/album photos & voices in 1 HTTP call!
        let __lastRecentPackPushSig = '';
        async function pushRecentMediaPack(room) {
          if (!room) return false;
          try {
            const delAlb = new Set(Array.isArray(state.deletedAlbumIds) ? state.deletedAlbumIds : []);
            const delMsg = new Set(Array.isArray(state.deletedMsgIds) ? state.deletedMsgIds : []);
            const avatars = {};
            if (state.profile?.suwanAvatar && String(state.profile.suwanAvatar).length <= 240000) avatars.suwan = state.profile.suwanAvatar;
            if (state.profile?.jingchanAvatar && String(state.profile.jingchanAvatar).length <= 240000) avatars.jingchan = state.profile.jingchanAvatar;

            const recentAlbums = (state.albums || [])
              .filter(a => a && a.id && !delAlb.has(a.id) && a.dataUrl && String(a.dataUrl).startsWith('data:image/') && String(a.dataUrl).length <= 210000)
              .slice(0, 14)
              .map(a => ({
                id: a.id, authorRole: a.authorRole || state.myRole || 'suwan',
                dataUrl: a.dataUrl, mediaType: 'image',
                caption: a.caption || '', translated: a.translated || '',
                date: a.date || '', category: a.category || '✨ 일상 순간', source: a.source || 'album'
              }));

            const recentChatMedia = (state.chat?.messages || [])
              .filter(m => m && m.id && !delMsg.has(m.id) && ((m.photoUrl && String(m.photoUrl).length <= 210000) || (m.audioUrl && String(m.audioUrl).length <= 240000)))
              .slice(-12)
              .map(m => ({
                id: m.id, ts: m.ts, sender: m.sender, time: m.time,
                original: m.original || '', translated: m.translated || '', tgtLang: m.tgtLang || '',
                photoCat: m.photoCat || '✨ 일상 순간',
                photoUrl: (m.photoUrl && String(m.photoUrl).length <= 210000) ? m.photoUrl : '',
                audioUrl: (m.audioUrl && String(m.audioUrl).length <= 240000) ? normalizeAudioDataUrl(m.audioUrl) : ''
              }));

            const recentVoices = (state.voiceLetters || [])
              .filter(v => v && v.id && v.audioUrl && String(v.audioUrl).length <= 240000)
              .slice(0, 8)
              .map(v => ({
                id: v.id, sender: v.sender || state.myRole || 'suwan', tag: v.tag || '🎙️',
                note: v.note || '', translated: v.translated || '', date: v.date || '', time: v.time || '',
                audioUrl: normalizeAudioDataUrl(v.audioUrl)
              }));

            if (!Object.keys(avatars).length && !recentAlbums.length && !recentChatMedia.length && !recentVoices.length) return false;
            const sig = `${avatars.suwan ? avatars.suwan.length : 0}|${avatars.jingchan ? avatars.jingchan.length : 0}|${recentAlbums.map(x => x.id).join(',')}|${recentChatMedia.map(x => x.id).join(',')}|${recentVoices.map(x => x.id).join(',')}`;
            if (sig === __lastRecentPackPushSig) return true;
            __lastRecentPackPushSig = sig;
            await upsertSupabaseStateSnapshot(`${room}__recent_media_v1`, {
              v: 'cw_recent_media_v1',
              updatedAt: Date.now(),
              avatars,
              albums: recentAlbums,
              chatMedia: recentChatMedia,
              voices: recentVoices
            }, 18000);
            return true;
          } catch (_) { return false; }
        }

        async function pullRecentMediaPack(room, showFeedback) {
          if (!room) room = getSyncRoomCode();
          if (!room) return false;
          try {
            const res = await fetchWithTimeout(`${SUPABASE_URL}/rest/v1/couple_sync_state?room_id=eq.${encodeURIComponent(room + '__recent_media_v1')}&select=payload`, { headers: sbHeaders() }, 12000);
            if (!res.ok) return false;
            const arr = await res.json();
            if (!Array.isArray(arr) || !arr[0] || !arr[0].payload) return false;
            const pack = await e2eeUnwrapPayload(arr[0].payload);
            if (!pack || pack.v !== 'cw_recent_media_v1') return false;

            let changed = false;
            const delAlb = new Set(Array.isArray(state.deletedAlbumIds) ? state.deletedAlbumIds : []);
            const delMsg = new Set(Array.isArray(state.deletedMsgIds) ? state.deletedMsgIds : []);
            const delVl = new Set(Array.isArray(state.deletedVoiceIds) ? state.deletedVoiceIds : []);

            if (pack.avatars && typeof pack.avatars === 'object') {
              if (!state.profile) state.profile = {};
              if (pack.avatars.suwan && !state.profile.suwanAvatar) { state.profile.suwanAvatar = pack.avatars.suwan; changed = true; }
              if (pack.avatars.jingchan && !state.profile.jingchanAvatar) { state.profile.jingchanAvatar = pack.avatars.jingchan; changed = true; }
            }
            if (Array.isArray(pack.albums)) {
              if (!Array.isArray(state.albums)) state.albums = [];
              for (const pa of pack.albums) {
                if (!pa || !pa.id || delAlb.has(pa.id) || !pa.dataUrl) continue;
                const ex = state.albums.find(x => x && x.id === pa.id);
                if (!ex) { state.albums.push({ ...pa, comments: [] }); changed = true; }
                else if (!ex.dataUrl) { ex.dataUrl = pa.dataUrl; changed = true; }
              }
            }
            if (Array.isArray(pack.chatMedia)) {
              if (!Array.isArray(state.chat.messages)) state.chat.messages = [];
              for (const pcm of pack.chatMedia) {
                if (!pcm || !pcm.id || delMsg.has(pcm.id)) continue;
                const exM = state.chat.messages.find(x => x && x.id === pcm.id);
                if (exM) {
                  if (pcm.photoUrl && !exM.photoUrl) { exM.photoUrl = pcm.photoUrl; changed = true; }
                  if (pcm.audioUrl && !exM.audioUrl) { exM.audioUrl = normalizeAudioDataUrl(pcm.audioUrl); changed = true; }
                } else if (pcm.photoUrl || pcm.audioUrl) {
                  state.chat.messages.push({
                    id: pcm.id, ts: pcm.ts || Date.now(), sender: pcm.sender || 'suwan', time: pcm.time || '',
                    original: pcm.original || (pcm.photoUrl ? '사진을 보냈어요 📷' : '🎙️ 음성 메시지'),
                    translated: pcm.translated || '', tgtLang: pcm.tgtLang || '',
                    photoCat: pcm.photoCat || '✨ 일상 순간',
                    photoUrl: pcm.photoUrl || '', audioUrl: pcm.audioUrl ? normalizeAudioDataUrl(pcm.audioUrl) : '',
                    reactions: []
                  });
                  state.chat.messages = sortChatMessagesStable(state.chat.messages);
                  changed = true;
                }
              }
            }
            if (Array.isArray(pack.voices)) {
              if (!Array.isArray(state.voiceLetters)) state.voiceLetters = [];
              for (const pv of pack.voices) {
                if (!pv || !pv.id || delVl.has(pv.id) || !pv.audioUrl) continue;
                if (!state.voiceLetters.some(x => x && x.id === pv.id && x.audioUrl)) {
                  state.voiceLetters.push({ ...pv, audioUrl: normalizeAudioDataUrl(pv.audioUrl) });
                  changed = true;
                }
              }
            }
            if (changed) {
              persistMediaVaultsNow(true);
              saveState(false);
              try { renderHome(); renderChat(); renderBucketAndAlbum(); if (typeof renderVoiceLetters === 'function') renderVoiceLetters(); updateVaultIndicators(); } catch (_) {}
              if (showFeedback) showToast(state.lang === 'zh' ? '📷 已加载最新照片与语音 ✨' : '📷 최신 사진과 음성을 불러왔어요 ✨');
            }
            return changed;
          } catch (_) { return false; }
        }
        window.__pullRecentMediaNow = (fb) => pullRecentMediaPack(getSyncRoomCode(), !!fb);

        async function restoreVaultEntryFromCloudState(room, entry) {
          if (!room || !entry || !entry.key) return false;
          if (isVaultEntryAlreadyLocal(entry)) return false;
          try {
            const headRoom = `${room}__vm__${entry.key}`;
            const hRes = await fetchWithTimeout(`${SUPABASE_URL}/rest/v1/couple_sync_state?room_id=eq.${encodeURIComponent(headRoom)}&select=payload`, { headers: sbHeaders() }, 16000);
            if (!hRes.ok) return false;
            const hArr = await hRes.json();
            if (!Array.isArray(hArr) || !hArr[0] || !hArr[0].payload) return false;
            const head = await e2eeUnwrapPayload(hArr[0].payload);
            if (!head) return false;

            let fullDataUrl = '';
            if (head.v === 'cw_vm_v1' && head.dataUrl) {
              fullDataUrl = head.dataUrl;
            } else if (head.v === 'cw_vm_head_v1' && Number(head.chunks) > 0) {
              const total = Number(head.chunks);
              const parts = new Array(total);
              for (let c = 0; c < total; c += 4) {
                const keys = [];
                for (let j = c; j < Math.min(total, c + 4); j++) keys.push(`${room}__vm__${entry.key}__c${j}`);
                const cUrl = `${SUPABASE_URL}/rest/v1/couple_sync_state?room_id=in.(${keys.map(x => encodeURIComponent(x)).join(',')})&select=room_id,payload`;
                const cRes = await fetchWithTimeout(cUrl, { headers: sbHeaders() }, 20000);
                if (!cRes.ok) return false;
                const cRows = await cRes.json();
                if (!Array.isArray(cRows)) return false;
                for (const cr of cRows) {
                  const decC = await e2eeUnwrapPayload(cr && cr.payload);
                  if (decC && typeof decC.idx === 'number' && typeof decC.data === 'string') {
                    parts[decC.idx] = decC.data;
                  }
                }
              }
              if (parts.some(p => typeof p !== 'string')) return false;
              fullDataUrl = parts.join('');
            }
            if (!fullDataUrl) return false;
            markVaultKeyUploaded(entry.key);
            return await handleIncomingMediaPacket({
              v: 'pro2_media',
              kind: head.kind || entry.kind,
              mediaId: entry.key,
              ts: head.ts || entry.ts || Date.now(),
              myRole: head.myRole || (head.meta && (head.meta.sender || head.meta.authorRole)) || 'jingchan',
              dataUrl: fullDataUrl,
              meta: head.meta || {}
            }, false, true);
          } catch (_) {
            return false;
          }
        }

        async function flushSyncOutbox() {
          if (isFlushingOutbox) return;
          if (typeof navigator !== 'undefined' && navigator.onLine === false) return;
          const room = getSyncRoomCode();
          if (!room) return;
          let list = loadSyncOutbox();
          if (!list.length) return;
          isFlushingOutbox = true;
          try {
            const remaining = [];
            for (const item of list) {
              if (!item || !item.payloadObj) continue;
              try {
                if (item.kind === 'delta' && item.payloadObj) {
                  const compactOut = buildCompactNtfyPacket(item.payloadObj);
                  if (compactOut) publishEmqxBackup(room, compactOut);
                }
                await insertSupabaseEvent(room, item.kind, item.payloadObj);
                if (item.kind === 'delta') await upsertSupabaseStateSnapshot(room, item.payloadObj);
                lastSyncOkTs = Date.now();
                markMyPendingMsgsStatus('sent');
              } catch (_) {
                item.tries = (item.tries || 0) + 1;
                const maxTries = item.kind === 'media' ? 5 : 2;
                if (item.tries < maxTries) remaining.push(item);
              }
            }
            saveSyncOutbox(remaining);
            updateLiveSyncIndicators(true, room);
          } finally {
            isFlushingOutbox = false;
          }
        }
        window.__flushSyncOutbox = flushSyncOutbox;

        // Reliable mobile video loader: keeps original untouched MP4 up to 9MB (zero corruption!), normalizes bad Android/iOS MIME types!
        window.__prepareVideoDataUrl = async function(file) {
          const readRawNormalized = () => new Promise((resolve, reject) => {
            const r = new FileReader();
            r.onload = () => {
              let out = String(r.result || '');
              if (out.startsWith('data:application/octet-stream;') || out.startsWith('data:;')) {
                out = out.replace(/^data:[^;]*;/, 'data:video/mp4;');
              } else if (out.startsWith('data:video/quicktime;')) {
                out = out.replace(/^data:video\/quicktime;/, 'data:video/mp4;');
              }
              resolve(out);
            };
            r.onerror = reject;
            r.readAsDataURL(file);
          });
          // Up to 9MB: ALWAYS send the original untouched MP4 via 260KB chunked transfer so video+audio NEVER break!
          if (!file || file.size <= 12 * 1024 * 1024) return await readRawNormalized();
          const isZh = state.lang === 'zh';
          const canRec = typeof MediaRecorder !== 'undefined' && typeof HTMLCanvasElement !== 'undefined';
          if (canRec) {
            try {
              showToast(isZh ? '🎬 大视频正在自动优化以便高速跨网发送...' : '🎬 대용량 동영상을 빠르게 보낼 수 있게 최적화 중이에요...');
              const objUrl = URL.createObjectURL(file);
              const vid = document.createElement('video');
              vid.src = objUrl;
              vid.muted = true;
              vid.playsInline = true;
              vid.setAttribute('playsinline', '');
              vid.setAttribute('webkit-playsinline', '');
              vid.style.cssText = 'position:fixed;left:-9999px;top:-9999px;width:16px;height:16px;opacity:0.01;pointer-events:none;';
              document.body.appendChild(vid);
              await new Promise((res, rej) => {
                const t = setTimeout(() => rej(new Error('meta_timeout')), 8000);
                vid.onloadeddata = () => { clearTimeout(t); res(); };
                vid.onerror = () => { clearTimeout(t); rej(new Error('vid_err')); };
              });
              const dur = Math.min(Number(vid.duration || 10), 60);
              const maxDim = 360;
              const scale = Math.min(1, maxDim / Math.max(vid.videoWidth || 360, vid.videoHeight || 360));
              const w = Math.max(160, Math.round((vid.videoWidth || 360) * scale / 2) * 2);
              const h = Math.max(160, Math.round((vid.videoHeight || 360) * scale / 2) * 2);
              const canvas = document.createElement('canvas');
              canvas.width = w; canvas.height = h;
              const ctx = canvas.getContext('2d');
              const cStream = canvas.captureStream(18);
              try {
                const vStream = typeof vid.captureStream === 'function' ? vid.captureStream() : (typeof vid.mozCaptureStream === 'function' ? vid.mozCaptureStream() : null);
                if (vStream) vStream.getAudioTracks().forEach(tr => cStream.addTrack(tr));
              } catch (_) {}
              // Prefer MP4 first for universal Android + iPhone playback
              const mimeCandidates = ['video/mp4', 'video/webm;codecs=vp8,opus', 'video/webm;codecs=vp8', 'video/webm'];
              const pickedMime = mimeCandidates.find(m => { try { return MediaRecorder.isTypeSupported(m); } catch (_) { return false; } }) || '';
              const rec = new MediaRecorder(cStream, pickedMime ? { mimeType: pickedMime, videoBitsPerSecond: 450000 } : { videoBitsPerSecond: 450000 });
              const chunks = [];
              rec.ondataavailable = (ev) => { if (ev.data && ev.data.size > 0) chunks.push(ev.data); };
              const doneP = new Promise((res) => { rec.onstop = () => res(); });
              rec.start(250);
              vid.currentTime = 0;
              await vid.play();
              const startMs = Date.now();
              const maxRecMs = Math.min(dur * 1000 + 400, 18500);
              let drawnFrames = 0;
              await new Promise((res) => {
                const draw = () => {
                  const elapsed = Date.now() - startMs;
                  if (vid.ended || elapsed >= maxRecMs || (elapsed > 1500 && vid.paused)) {
                    try { vid.pause(); } catch (_) {}
                    try { rec.stop(); } catch (_) {}
                    return res();
                  }
                  if (vid.readyState >= 2) {
                    try { ctx.drawImage(vid, 0, 0, w, h); drawnFrames++; } catch (_) {}
                  }
                  requestAnimationFrame(draw);
                };
                requestAnimationFrame(draw);
              });
              await doneP;
              try { cStream.getTracks().forEach(t => t.stop()); } catch (_) {}
              try { vid.removeAttribute('src'); vid.load(); vid.remove(); } catch (_) {}
              try { canvas.width = 0; canvas.height = 0; } catch (_) {}
              URL.revokeObjectURL(objUrl);
              const blob = new Blob(chunks, { type: pickedMime || 'video/mp4' });
              if (drawnFrames >= 12 && blob.size >= 45000 && blob.size <= 9.5 * 1024 * 1024) {
                return await new Promise((resolve, reject) => {
                  const r = new FileReader();
                  r.onload = () => resolve(String(r.result || ''));
                  r.onerror = reject;
                  r.readAsDataURL(blob);
                });
              }
            } catch (_) {
              try { document.querySelectorAll('video[style*="-9999px"]').forEach(el => el.remove()); } catch (__) {}
            }
          }
          showToast(isZh ? '🎬 该视频超过 9MB，建议剪短至 10 秒内发送效果最清晰哦' : '🎬 9MB가 넘는 영상이에요. 10초 이내로 짧게 찍어 보내면 원본 화질로 바로 재생돼요');
          return await readRawNormalized();
        };

        // Reassembly buffer for chunked China<->Korea video & large media transfer
        const __cwChunkBuffer = {};
        async function handleIncomingMediaChunk(pkt, isLiveEvent, allowSelfRecovery) {
          if (!pkt || pkt.v !== 'pro2_media_chunk' || !pkt.transferId) return false;
          if (pkt.clientId && pkt.clientId === myDeviceClientId && !allowSelfRecovery) return false;
          const tid = String(pkt.transferId);
          const total = Math.max(1, Number(pkt.totalChunks || 1));
          const idx = Number(pkt.chunkIndex || 0);
          if (idx < 0 || idx >= total || typeof pkt.chunkData !== 'string') return false;
          if (!__cwChunkBuffer[tid]) {
            __cwChunkBuffer[tid] = {
              total,
              received: 0,
              parts: new Array(total),
              kind: pkt.kind,
              meta: pkt.meta || {},
              clientId: pkt.clientId,
              myRole: pkt.myRole,
              ts: pkt.ts || Date.now(),
              mediaId: pkt.mediaId || tid
            };
          }
          const buf = __cwChunkBuffer[tid];
          if (idx === 0 && pkt.meta && Object.keys(pkt.meta).length) buf.meta = pkt.meta;
          if (buf.parts[idx] === undefined) {
            buf.parts[idx] = pkt.chunkData;
            buf.received++;
            if (isLiveEvent && (buf.kind === 'chat_video' || buf.kind === 'album_video') && buf.total > 2 && (buf.received === 1 || buf.received % 6 === 0)) {
              try { showToast(state.lang === 'zh' ? `🎬 正在接收视频 (${buf.received}/${buf.total})...` : `🎬 동영상 받는 중 (${buf.received}/${buf.total})...`); } catch (_) {}
            }
          }
          if (buf.received >= buf.total) {
            const fullDataUrl = buf.parts.join('');
            delete __cwChunkBuffer[tid];
            return await handleIncomingMediaPacket({
              v: 'pro2_media',
              kind: buf.kind,
              mediaId: buf.mediaId,
              ts: buf.ts,
              clientId: buf.clientId,
              myRole: buf.myRole,
              dataUrl: fullDataUrl,
              meta: buf.meta
            }, allowSelfRecovery ? false : isLiveEvent, allowSelfRecovery);
          }
          return false;
        }

        // Send compressed media (photos, videos, voice messages, voice letters) over BOTH EMQX China Direct + Supabase Seoul!
        // Large files (>340KB, e.g. videos up to 10MB) are automatically split into 260KB chunks so China<->Korea sync NEVER times out!
        async function sendEmqxMediaPaced(room, kind, mediaId, meta, rawStr, nowTs) {
          if (!room || !rawStr) return false;
          if (rawStr.length <= 165000) {
            return publishEmqxBackup(room, JSON.stringify({
              v: 'pro2_media',
              kind,
              mediaId,
              ts: nowTs,
              clientId: myDeviceClientId,
              myRole: (meta && (meta.sender || meta.authorRole)) || state.myRole || 'suwan',
              dataUrl: rawStr,
              meta: meta || {}
            }));
          }
          const EMQX_CHUNK = 150000;
          const totalChunks = Math.ceil(rawStr.length / EMQX_CHUNK);
          let okCnt = 0;
          for (let i = 0; i < totalChunks; i++) {
            const cPkt = {
              v: 'pro2_media_chunk',
              transferId: mediaId,
              mediaId,
              kind,
              chunkIndex: i,
              totalChunks,
              chunkData: rawStr.slice(i * EMQX_CHUNK, (i + 1) * EMQX_CHUNK),
              ts: nowTs,
              clientId: myDeviceClientId,
              myRole: (meta && (meta.sender || meta.authorRole)) || state.myRole || 'suwan',
              meta: i === 0 ? (meta || {}) : {}
            };
            if (publishEmqxBackup(room, JSON.stringify(cPkt))) okCnt++;
            if (i + 1 < totalChunks) await new Promise(r => setTimeout(r, 95));
          }
          return okCnt === totalChunks;
        }

        async function pushMediaSyncPacket(kind, meta, dataUrl, filename) {
          const room = getSyncRoomCode();
          if (!room || !dataUrl || !String(dataUrl).startsWith('data:')) return;
          const rawStr = (kind === 'voice_letter' || kind === 'chat_voice' || kind === 'custom_voice')
            ? normalizeAudioDataUrl(String(dataUrl))
            : String(dataUrl);
          const isZh = state.lang === 'zh';
          const isVidKind = kind === 'chat_video' || kind === 'album_video';
          const mediaId = `${kind}_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
          const vaultKey = deriveDeterministicVaultKey(kind, meta, mediaId);
          const nowTs = Date.now();

          // Channel 1: Instant China-Direct EMQX P2P (150KB paced frames so Qingdao<->Korea never drops packets!)
          const emqxPromise = sendEmqxMediaPaced(room, kind, mediaId, meta, rawStr, nowTs).catch(() => false);
          // Channel 2: Permanent Cloud Vault inside proven couple_sync_state table!
          const vaultPromise = saveVaultItemToCloudState(room, vaultKey, kind, meta, rawStr).catch(() => false);

          // Channel 3: Legacy couple_sync_events (if available on Supabase)
          let eventsOk = false;
          if (!__sbEventsUnavailable && rawStr.length <= 340000) {
            try {
              eventsOk = await insertSupabaseEvent(room, 'media', {
                v: 'pro2_media', kind, mediaId, ts: nowTs, clientId: myDeviceClientId, myRole: state.myRole || 'suwan', dataUrl: rawStr, meta: meta || {}
              });
            } catch (_) {}
          }

          const [emqxOk, vaultOk] = await Promise.all([emqxPromise, vaultPromise]);
          pushRecentMediaPack(room).catch(() => {});
          if (emqxOk || vaultOk || eventsOk) {
            lastSyncOkTs = Date.now();
            updateLiveSyncIndicators(true, room);
            if (isVidKind) {
              try { showToast(isZh ? '🎬 视频发送成功！已同步至对方与永久云金库 ✨' : '🎬 동영상 전송 완료! 상대방과 클라우드 금고에 저장됐어요 ✨'); } catch (_) {}
            }
          } else if (isVidKind) {
            try { showToast(isZh ? '⚠️ 网络波动，部分视频分片未送达，请重试发送' : '⚠️ 네트워크가 불안정해 일부 영상 조각이 못 갔어요. 다시 보내주세요'); } catch (_) {}
          }
        }
        window.__pushMediaSyncPacket = pushMediaSyncPacket;

        let partnerTypingHideTimer = null;
        function sendChatSignal(kind, payload) {
          const room = getSyncRoomCode();
          if (!room) return;
          const pkt = { v: 'pro2_signal', kind, ts: Date.now(), clientId: myDeviceClientId, myRole: state.myRole || 'suwan', ...(payload || {}) };
          // Ephemeral signals go over real-time EMQX + Supabase Broadcast + ntfy (never stored in couple_sync_events)
          const isEphemeral = (kind === 'typing' || kind === 'presence' || kind === 'request_vault_sync');
          if (!isEphemeral) {
            insertSupabaseEvent(room, 'signal', pkt).then(() => {
              lastSyncOkTs = Date.now();
            }).catch(() => {
              enqueueOutboxPacket('signal', pkt, 'signal');
            });
          }
          try {
            if (sbChannel && syncTransportMode === 'realtime' && typeof sbChannel.send === 'function') {
              sbChannel.send({ type: 'broadcast', event: 'cw_sig', payload: pkt }).catch(() => {});
            }
          } catch (_) {}
          try {
            const sStr = JSON.stringify(pkt);
            publishEmqxBackup(room, sStr);
            if (!isEphemeral && new Blob([sStr]).size <= 3800) pushNtfyBackup(room, sStr);
          } catch (_) {}
        }
        window.__sendChatSignal = sendChatSignal;
        let lastReadSignalSentTs = 0;
        let lastReadPartnerMsgTs = 0;
        function emitChatReadIfVisible(force) {
          try {
            if (document.hidden) return;
            const trPanel = document.getElementById('tab-translator');
            if (!trPanel || !trPanel.classList.contains('active')) return;
            if (Array.isArray(state.notifications)) {
              let clearedNotif = false;
              state.notifications.forEach(n => {
                if (n && n.unread && (n.tab === 'translator' || n.fromRole === (state.myRole || 'suwan') || !n.tab || (n.createdAt && (Date.now() - Number(n.createdAt)) >= 86400000))) {
                  n.unread = false;
                  clearedNotif = true;
                }
              });
              if (clearedNotif) {
                saveState(false);
                if (typeof renderNotifications === 'function') renderNotifications();
              }
            }
            const myR = state.myRole || 'suwan';
            let latestPartnerTs = 0;
            (state.chat?.messages || []).forEach(m => {
              if (!m) return;
              const normS = (m.sender === 'jingchan' || String(m.sender || '').includes('靖灿')) ? 'jingchan' : 'suwan';
              if (normS !== myR && Number(m.ts || 0) > latestPartnerTs) latestPartnerTs = Number(m.ts || 0);
            });
            if (!latestPartnerTs) return;
            const now = Date.now();
            if (!state.profile) state.profile = {};
            const myReadKey = myR + 'ReadUpToTs';
            const prevSavedReadTs = Number(state.profile[myReadKey] || 0);
            const watermarkAdvanced = latestPartnerTs > prevSavedReadTs;
            if (watermarkAdvanced) {
              state.profile[myReadKey] = latestPartnerTs;
              saveState(true);
            }
            if (!force && !watermarkAdvanced && latestPartnerTs <= lastReadPartnerMsgTs && (now - lastReadSignalSentTs) < 8000) return;
            lastReadPartnerMsgTs = latestPartnerTs;
            lastReadSignalSentTs = now;
            sendChatSignal('read', { readUpToTs: latestPartnerTs });
          } catch (_) {}
        }
        window.__emitChatReadIfVisible = emitChatReadIfVisible;

        function handleIncomingChatSignal(sig) {
          if (!sig || sig.v !== 'pro2_signal') return;
          if (sig.clientId && sig.clientId === myDeviceClientId) return;
          const pName = sig.myRole === 'suwan' ? '수완(完)' : '靖灿(灿)';
          if (sig.kind === 'request_vault_sync') {
            if (typeof window.__respondToPartnerVaultRequest === 'function') {
              window.__respondToPartnerVaultRequest(sig);
            }
            return;
          }
          if (sig.kind === 'presence' && sig.myRole && sig.myRole !== (state.myRole || 'suwan')) {
            if (!window.__cwPartnerPresence) window.__cwPartnerPresence = { suwan: { online: false, lastSeen: 0 }, jingchan: { online: false, lastSeen: 0 } };
            const prevInfo = window.__cwPartnerPresence[sig.myRole] || { online: false, lastSeen: 0 };
            // Strictly update lastSeen only when screen is actively open (online: true) or transitioning from online -> offline
            const nextLastSeen = sig.online ? Date.now() : (prevInfo.online ? Date.now() : prevInfo.lastSeen);
            window.__cwPartnerPresence[sig.myRole] = { online: !!sig.online, explicitOffline: !sig.online, lastSeen: nextLastSeen };
            if (typeof window.__savePartnerLastSeen === 'function') window.__savePartnerLastSeen(sig.myRole, nextLastSeen);
            if (typeof window.__renderPresenceBadges === 'function') window.__renderPresenceBadges();
            if (sig.online && sig.needReply && !document.hidden && typeof window.__broadcastPresenceNow === 'function') {
              window.__broadcastPresenceNow(true, false);
            }
            return;
          }
          if (sig.kind === 'typing') {
            const myRoleNow = state.myRole || 'suwan';
            if (!sig.myRole || sig.myRole === myRoleNow) return;
            const box = document.getElementById('chatTypingIndicator');
            if (sig.active === false) {
              if (partnerTypingHideTimer) { clearTimeout(partnerTypingHideTimer); partnerTypingHideTimer = null; }
              if (box) box.classList.add('hidden');
              return;
            }
            const ageMs = Math.abs(Date.now() - Number(sig.ts || 0));
            if (!sig.ts || ageMs > 7000) return; // Ignore any stale/cached typing event (>7s old)!
            const dispName = sig.myRole === 'suwan'
              ? (state.lang === 'zh' ? '秀完' : '수완')
              : (state.lang === 'zh' ? '靖灿' : '징찬');
            const txt = document.getElementById('chatTypingText');
            if (txt) txt.textContent = state.lang === 'zh' ? `${dispName} 正在输入中... 💜` : `${dispName}님이 입력 중이에요... 💜`;
            if (box) {
              box.classList.remove('hidden');
              if (typeof window.syncAllTabIconsToStyle === 'function') window.syncAllTabIconsToStyle(null, box);
            }
            if (partnerTypingHideTimer) clearTimeout(partnerTypingHideTimer);
            partnerTypingHideTimer = setTimeout(() => { if (box) box.classList.add('hidden'); }, 3800);
          } else if (sig.kind === 'read') {
            let changed = false;
            const myRole = state.myRole || 'suwan';
            // Strictly require explicit partner role (never self or unknown)
            if (!sig.myRole || sig.myRole === myRole) return;
            // Strictly bound by timestamp so old read signals NEVER falsely mark newer messages as read!
            const readCutoff = Number(sig.readUpToTs || sig.ts || 0);
            if (!readCutoff || readCutoff <= 0) return;
            (state.chat?.messages || []).forEach(m => {
              if (!m || m.readByPartner) return;
              const normS = (m.sender === 'jingchan' || String(m.sender || '').includes('靖灿')) ? 'jingchan' : 'suwan';
              const msgTs = Number(m.ts || 0);
              if (normS === myRole && msgTs > 0 && msgTs <= readCutoff) {
                m.readByPartner = true;
                m.deliveryStatus = 'sent';
                changed = true;
              }
            });
            if (changed) {
              saveState(false);
              if (!updateChatDeliveryBadgesInPlace()) renderChat();
            }
          } else if (sig.kind === 'react' && sig.msgId && Array.isArray(sig.reactions)) {
            const target = (state.chat?.messages || []).find(m => m && m.id === sig.msgId);
            if (target) {
              target.reactions = sig.reactions.slice(0, 12);
              saveState(false); renderChat();
            }
          } else if (sig.kind === 'edit' && sig.msgId && sig.original) {
            const target = (state.chat?.messages || []).find(m => m && m.id === sig.msgId);
            if (target) {
              target.original = sig.original;
              if (sig.translated !== undefined) target.translated = sig.translated;
              if (sig.pronunciation !== undefined) target.pronunciation = sig.pronunciation;
              if (sig.accuracy !== undefined) target.accuracy = sig.accuracy;
              if (sig.engine !== undefined) target.engine = sig.engine;
              if (sig.tgtLang !== undefined) target.tgtLang = sig.tgtLang;
              target.editedAt = sig.editedAt || Date.now();
              saveState(false); renderChat();
            }
          } else if (sig.kind === 'comment' && sig.targetType && sig.targetId && sig.comment && sig.comment.id) {
            const listMap = { diary: state.diaries, memo: state.memos, album: state.albums };
            const arr = listMap[sig.targetType];
            if (Array.isArray(arr)) {
              const target = arr.find(x => x && x.id === sig.targetId);
              if (target) {
                if (!Array.isArray(target.comments)) target.comments = [];
                if (!target.comments.some(c => c && c.id === sig.comment.id)) {
                  target.comments.push(sig.comment);
                  saveState(false);
                  if (sig.targetType === 'album') renderBucketAndAlbum();
                  else renderDiaryQaMemos();
                  const icon = sig.targetType === 'album' ? '🖼️' : (sig.targetType === 'memo' ? '📝' : '💬');
                  pushNotification(icon, `${pName}의 새 답글`, `${pName}发来新评论`, sig.comment.text, sig.comment.translated || sig.comment.text, 'diary', sig.targetType === 'album' ? 'album' : 'diary', 'post', false, sig.myRole);
                }
              }
            }
          }
        }

        const MEDIA_SEEN_KEY = 'chanwan_seen_media_v15';
        try {
          const savedM = JSON.parse(localStorage.getItem(MEDIA_SEEN_KEY) || '[]');
          if (Array.isArray(savedM)) savedM.forEach(x => processedMediaIds.add(x));
        } catch (_) {}
        function markMediaSeen(mid) {
          processedMediaIds.add(mid);
          try { localStorage.setItem(MEDIA_SEEN_KEY, JSON.stringify(Array.from(processedMediaIds).slice(-120))); } catch (_) {}
        }

        async function handleIncomingMediaPacket(pkt, isLiveEvent, allowSelfRecovery) {
          if (!pkt || pkt.v !== 'pro2_media') return false;
          const isSelfPkt = !!(pkt.clientId && pkt.clientId === myDeviceClientId);
          if (isSelfPkt && !allowSelfRecovery) return false;
          if (isSelfPkt) isLiveEvent = false;
          if (isLiveEvent && ((Date.now() - __cwBootEpoch) < 3500 || (pkt.ts && (Date.now() - Number(pkt.ts)) > 90000))) {
            isLiveEvent = false;
          }
          const m = pkt.meta || {};
          const delSet = new Set(Array.isArray(state.deletedMsgIds) ? state.deletedMsgIds : []);
          const delAlbSet = new Set(Array.isArray(state.deletedAlbumIds) ? state.deletedAlbumIds : []);
          if (m.msgId && delSet.has(m.msgId)) return false;
          if ((pkt.kind === 'album_photo' || pkt.kind === 'album_video') && m.albumId && delAlbSet.has(m.albumId)) return false;
          const mid = pkt.mediaId || pkt.mediaUrl || `m_${pkt.ts}`;
          const needsRecovery = (
            (pkt.kind === 'chat_photo' && (!(state.chat?.messages || []).some(x => x && x.id === m.msgId && (x.photoUrl || (Array.isArray(x.photoUrls) && x.photoUrls.length >= Number(m.batchTotal || 1)))) || !(state.albums || []).some(a => a && a.id === (m.albumId || `alb_sync_${m.msgId || ''}`) && a.dataUrl))) ||
            ((pkt.kind === 'album_photo' || pkt.kind === 'album_video') && !(m.albumId && delAlbSet.has(m.albumId)) && !(state.albums || []).some(a => a && a.id === m.albumId && a.dataUrl)) ||
            (pkt.kind === 'chat_video' && (!(state.chat?.messages || []).some(x => x && x.id === m.msgId && x.videoUrl) || !(state.albums || []).some(a => a && a.id === (m.albumId || `alb_sync_${m.msgId || ''}`) && a.dataUrl))) ||
            (pkt.kind === 'chat_voice' && !(state.chat?.messages || []).some(x => x && x.id === m.msgId && x.audioUrl)) ||
            (pkt.kind === 'voice_letter' && !(state.voiceLetters || []).some(v => v && v.id === m.id && v.audioUrl)) ||
            (pkt.kind === 'avatar' && !(m.target === 'suwan' ? state.profile?.suwanAvatar : state.profile?.jingchanAvatar))
          );
          if (isSelfPkt && !needsRecovery) return false;
          if (processedMediaIds.has(mid) && !needsRecovery) return false;
          markMediaSeen(mid);

          const isAudioKind = pkt.kind === 'chat_voice' || pkt.kind === 'voice_letter' || pkt.kind === 'custom_voice';
          const localDataUrl = isAudioKind ? normalizeAudioDataUrl(pkt.dataUrl || '') : String(pkt.dataUrl || '');
          if (!localDataUrl || !localDataUrl.startsWith('data:')) return false;
          if (isAudioKind && !localDataUrl.startsWith('data:audio/')) return false;

          const pName = pkt.myRole === 'suwan' ? '수완(完)' : '靖灿(灿)';
          let changed = false;

          if (pkt.kind === 'chat_photo') {
            if (!Array.isArray(state.chat.messages)) state.chat.messages = [];
            const existingMsg = state.chat.messages.find(x => x && x.id === m.msgId);
            if (existingMsg) {
              if (Number(m.batchTotal || 0) > 1) {
                if (!Array.isArray(existingMsg.photoUrls)) existingMsg.photoUrls = existingMsg.photoUrl ? [existingMsg.photoUrl] : [];
                if (!existingMsg.photoUrls.includes(localDataUrl)) {
                  existingMsg.photoUrls.push(localDataUrl);
                  if (!existingMsg.photoUrl) existingMsg.photoUrl = localDataUrl;
                  changed = true;
                }
              } else if (!existingMsg.photoUrl) {
                existingMsg.photoUrl = localDataUrl;
                changed = true;
              }
            } else {
              ((__m) => { state.chat.messages.push(__m); try { if (__m && __m.sender === (state.myRole || "suwan")) { const __who = __m.sender === "jingchan" ? "靖灿" : "수완"; sendPartnerNativePush(`💌 ${__who}님의 새 메시지`, __m.original || (__m.photoUrl ? "📷 사진을 보냈어요" : (__m.audioUrl ? "🎙️ 음성 메시지를 보냈어요" : "새 메시지가 도착했어요"))); } } catch (_) {} })({
                id: m.msgId || `msg_${Date.now()}`,
                ts: pkt.ts || Date.now(),
                sender: m.sender || pkt.myRole || 'jingchan',
                time: m.time || new Date().toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' }),
                original: m.original || '사진을 보냈어요 📷',
                translated: m.translated || '',
                pronunciation: m.pronunciation || '',
                tone: m.tone || '', nuance: m.nuance || '', engine: m.engine || '', tgtLang: m.tgtLang || '',
                photoUrl: localDataUrl, videoUrl: '', photoCat: m.category || '✨ 일상 순간'
              });
              state.chat.messages = sortChatMessagesStable(state.chat.messages);
              changed = true;
            }
            if (!Array.isArray(state.albums)) state.albums = [];
            const albId = m.albumId || `alb_sync_${m.msgId || Date.now()}`;
            const exChatAlb = state.albums.find(a => a && a.id === albId);
            if (!exChatAlb && !delAlbSet.has(albId)) {
              state.albums.unshift({
                id: albId, authorRole: pkt.myRole || 'jingchan', dataUrl: localDataUrl, mediaType: 'image',
                caption: m.original || '공유된 사진 📷', translated: m.translated || '',
                date: m.date || getKstDateString(), category: m.category || '✨ 일상 순간', source: 'messenger', comments: []
              });
              changed = true;
            } else if (!exChatAlb.dataUrl) {
              exChatAlb.dataUrl = localDataUrl;
              changed = true;
            }
            if (changed) {
              saveState(false); renderChat(); renderBucketAndAlbum(); renderHome();
              if (isLiveEvent) {
                const _o = String(m.original || '').trim();
                const _t = String(m.translated || '').trim();
                const _oIsKo = /[가-힣]/.test(_o) && !/[\u4e00-\u9fff]/.test(_o);
                const _koB = _oIsKo ? (_o || '사진이 커플앨범에도 저장됐어요 🖼️') : (_t || _o || '사진이 커플앨범에도 저장됐어요 🖼️');
                const _zhB = _oIsKo ? (_t || _o || '照片已同步存入情侣相册 🖼️') : (_o || '照片已同步存入情侣相册 🖼️');
                pushNotification('📷', `${pName}의 새 사진 도착!`, `${pName}发来新照片！`, _koB, _zhB, 'translator', 'messenger', 'post', false, pkt.myRole);
              }
            }
          } else if (pkt.kind === 'chat_video') {
            if (!Array.isArray(state.chat.messages)) state.chat.messages = [];
            const existingMsg = state.chat.messages.find(x => x && x.id === m.msgId);
            if (existingMsg) {
              if (!existingMsg.videoUrl) { existingMsg.videoUrl = localDataUrl; changed = true; }
            } else {
              state.chat.messages.push({
                id: m.msgId || `msg_${Date.now()}`, ts: pkt.ts || Date.now(),
                sender: m.sender || pkt.myRole || 'jingchan',
                time: m.time || new Date().toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' }),
                original: m.original || '동영상을 보냈어요 🎬', translated: m.translated || '',
                pronunciation: m.pronunciation || '', tone: m.tone || '', nuance: m.nuance || '',
                engine: m.engine || '', tgtLang: m.tgtLang || '',
                photoUrl: '', videoUrl: localDataUrl, photoCat: m.category || '✨ 일상 순간'
              });
              state.chat.messages = sortChatMessagesStable(state.chat.messages);
              changed = true;
            }
            if (!Array.isArray(state.albums)) state.albums = [];
            const albIdV = m.albumId || `alb_sync_${m.msgId || Date.now()}`;
            if (!delAlbSet.has(albIdV)) {
              const exAlbV = state.albums.find(a => a && a.id === albIdV);
              if (!exAlbV) {
                state.albums.unshift({
                  id: albIdV, authorRole: pkt.myRole || 'jingchan', dataUrl: localDataUrl, mediaType: 'video',
                  caption: m.original || '공유된 동영상 🎬', translated: m.translated || '',
                  date: m.date || getKstDateString(), category: m.category || '✨ 일상 순간', source: 'messenger', comments: []
                });
                changed = true;
              } else if (!exAlbV.dataUrl) { exAlbV.dataUrl = localDataUrl; exAlbV.mediaType = 'video'; changed = true; }
            }
            if (changed) {
              saveState(false); renderChat(); renderBucketAndAlbum(); renderHome();
              if (isLiveEvent) pushNotification('🎬', `${pName}의 새 동영상 도착!`, `${pName}发来新视频！`, m.original || '동영상이 커플앨범에도 저장됐어요 🎬', m.translated || m.original || '视频已同步存入情侣相册 🎬', 'translator', 'messenger', 'post', false, pkt.myRole);
            }
          } else if (pkt.kind === 'album_video') {
            if (!Array.isArray(state.albums)) state.albums = [];
            const albId = m.albumId || `alb_sync_${Date.now()}`;
            if (!delAlbSet.has(albId)) {
              const exAlb = state.albums.find(a => a && a.id === albId);
              if (!exAlb) {
                state.albums.unshift({
                  id: albId, authorRole: pkt.myRole || 'jingchan', dataUrl: localDataUrl, mediaType: 'video',
                  caption: m.caption || '우리의 소중한 영상 🎬', translated: m.translated || '',
                  date: m.date || getKstDateString(), category: m.category || '✨ 일상 순간', source: 'album', comments: []
                });
                changed = true;
                saveState(false); renderBucketAndAlbum(); renderHome();
                if (isLiveEvent) pushNotification('🎬', `${pName}이 커플앨범에 동영상을 올렸어요!`, `${pName}往情侣相册上传了新视频！`, m.caption || '지금 바로 재생해 보세요 🎬', m.translated || m.caption || '快去相册看看吧 🎬', 'diary', 'album', 'post', false, pkt.myRole);
              } else if (!exAlb.dataUrl) {
                exAlb.dataUrl = localDataUrl; exAlb.mediaType = 'video'; changed = true;
                saveState(false); renderBucketAndAlbum(); renderHome();
              }
            }
          } else if (pkt.kind === 'album_photo') {
            if (!Array.isArray(state.albums)) state.albums = [];
            const albId = m.albumId || `alb_sync_${Date.now()}`;
            const exAlb = state.albums.find(a => a && a.id === albId);
            if (!exAlb) {
              state.albums.unshift({
                id: albId, authorRole: pkt.myRole || 'jingchan', dataUrl: localDataUrl, mediaType: 'image',
                caption: m.caption || '우리의 소중한 순간', translated: m.translated || '',
                date: m.date || getKstDateString(), category: m.category || '✨ 일상 순간', source: 'album', comments: []
              });
              changed = true;
              saveState(false); renderBucketAndAlbum(); renderHome();
              if (isLiveEvent) {
                const _o = String(m.caption || '').trim();
                const _t = String(m.translated || '').trim();
                const _oIsKo = /[가-힣]/.test(_o) && !/[\u4e00-\u9fff]/.test(_o);
                const _koB = _oIsKo ? _o : (_t || _o);
                const _zhB = _oIsKo ? (_t || _o) : _o;
                pushNotification('🖼️', `${pName}이 커플앨범에 사진을 올렸어요!`, `${pName}往情侣相册上传了新照片！`, _koB, _zhB, 'diary', 'album', 'post', false, pkt.myRole);
              }
            } else if (!exAlb.dataUrl) {
              exAlb.dataUrl = localDataUrl;
              changed = true;
              saveState(false); renderBucketAndAlbum(); renderHome();
            }
          } else if (pkt.kind === 'avatar' && (m.target === 'suwan' || m.target === 'jingchan')) {
            if (!state.profile) state.profile = {};
            const prevAv = m.target === 'suwan' ? state.profile.suwanAvatar : state.profile.jingchanAvatar;
            if (prevAv !== localDataUrl) {
              if (m.target === 'suwan') state.profile.suwanAvatar = localDataUrl;
              else state.profile.jingchanAvatar = localDataUrl;
              changed = true;
              saveState(false); renderHome(); renderChat();
            }
          } else if (pkt.kind === 'custom_voice' && m.phrase) {
            if (!state.customVoices || typeof state.customVoices !== 'object') state.customVoices = {};
            state.customVoices[m.phrase] = localDataUrl; saveSuwanVoicesNow();
            changed = true;
            saveState(false); renderLearn(); renderHome();
            if (isLiveEvent) pushNotification('🎙️', `${pName}의 새 목소리 녹음 도착!`, `${pName}发来新的原声录音！`, `"${m.phrase}" — 이제 🔊로 바로 들을 수 있어요 💜`, `「${m.phrase}」— 现在点 🔊 就能听到原声啦 💜`, 'learn', 'cheat', 'post', false, pkt.myRole);
          } else if (pkt.kind === 'voice_letter') {
            if (!Array.isArray(state.voiceLetters)) state.voiceLetters = [];
            const vlId = m.id || `vl_${Date.now()}`;
            if (!state.voiceLetters.some(v => v && v.id === vlId)) {
              state.voiceLetters.unshift({
                id: vlId, sender: m.sender || pkt.myRole || 'jingchan', tag: m.tag || '🌙 굿나잇',
                note: m.note || '', translated: m.translated || '',
                date: m.date || getKstDateString(), time: m.time || new Date().toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' }),
                audioUrl: localDataUrl
              });
              changed = true;
              saveState(false);
              if (typeof renderVoiceLetters === 'function') renderVoiceLetters();
              renderHome();
              if (isLiveEvent) pushNotification('🎙️', `${pName}의 음성 편지가 도착했어요!`, `${pName}发来一封语音信！`, `${m.tag || '🎙️'} ${m.note || '지금 바로 들어보세요 💜'}`, `${m.tag || '🎙️'} ${m.translated || m.note || '快点听听吧 💜'}`, 'diary', 'voice', 'post', false, pkt.myRole);
            }
          } else if (pkt.kind === 'chat_voice') {
            if (!Array.isArray(state.chat.messages)) state.chat.messages = [];
            const existingV = state.chat.messages.find(x => x && x.id === m.msgId);
            if (existingV) {
              if (!existingV.audioUrl) { existingV.audioUrl = localDataUrl; changed = true; }
            } else {
              ((__m) => { state.chat.messages.push(__m); try { if (__m && __m.sender === (state.myRole || "suwan")) { const __who = __m.sender === "jingchan" ? "靖灿" : "수완"; sendPartnerNativePush(`💌 ${__who}님의 새 메시지`, __m.original || (__m.photoUrl ? "📷 사진을 보냈어요" : (__m.audioUrl ? "🎙️ 음성 메시지를 보냈어요" : "새 메시지가 도착했어요"))); } } catch (_) {} })({
                id: m.msgId || `msg_v_${Date.now()}`,
                ts: pkt.ts || Date.now(),
                sender: m.sender || pkt.myRole || 'jingchan',
                time: m.time || new Date().toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' }),
                original: m.original || '🎙️ 음성 메시지를 보냈어요',
                translated: m.translated || '🎙️ 发来一条语音消息',
                pronunciation: '', tone: '🎙️ 음성 메시지', nuance: '', engine: '', tgtLang: m.tgtLang || 'zh',
                audioUrl: localDataUrl, reactions: []
              });
              state.chat.messages = sortChatMessagesStable(state.chat.messages);
              changed = true;
            }
            if (!Array.isArray(state.voiceLetters)) state.voiceLetters = [];
            const vlRecvId = `vl_chat_${m.msgId || pkt.ts || Date.now()}`;
            if (!state.voiceLetters.some(v => v && v.id === vlRecvId)) {
              state.voiceLetters.unshift({
                id: vlRecvId, sender: m.sender || pkt.myRole || 'jingchan', source: 'messenger',
                tag: state.lang === 'zh' ? '💬 聊天语音' : '💬 메신저 음성',
                note: '', translated: '',
                date: getKstDateString(), time: m.time || new Date().toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' }),
                audioUrl: localDataUrl
              });
              changed = true;
            }
            if (changed) {
              saveState(false); renderChat(); renderHome();
              if (typeof renderVoiceLetters === 'function') renderVoiceLetters();
              if (isLiveEvent) pushNotification('🎙️', `${pName}의 음성 메시지!`, `${pName}发来语音消息！`, '메신저에서 눌러서 들어보세요 💜', '去聊天里点击收听吧 💜', 'translator', 'messenger', 'post', false, pkt.myRole);
            }
          }
          return changed;
        }

        function buildSyncPayload(coreObj, fullSnapshot) {
          const lim = fullSnapshot
            ? { msg: 220, qa: 40, diary: 60, memo: 60, bucket: 50, cap: 40, coup: 40, anniv: 40, sched: 50, phrase: 120, trans: 35, gif: 25 }
            : { msg: 20, qa: 10, diary: 12, memo: 15, bucket: 15, cap: 10, coup: 12, anniv: 12, sched: 15, phrase: 25, trans: 12, gif: 12 };
          return {
            v: 'pro2',
            ts: Date.now(),
            clientId: myDeviceClientId,
            myRole: state.myRole || 'suwan',
            heartCount: coreObj.heartCount || 0,
            heartResetDate: coreObj.heartResetDate || getKstDateString(),
            startDate: coreObj.startDate || '',
            startDateUpdatedAt: Number(coreObj.startDateUpdatedAt || 0),
            cities: coreObj.cities || null,
            profile: {
              suwanMood: coreObj.profile?.suwanMood,
              jingchanMood: coreObj.profile?.jingchanMood,
              suwanMoodUpdatedAt: Number(coreObj.profile?.suwanMoodUpdatedAt || 0),
              jingchanMoodUpdatedAt: Number(coreObj.profile?.jingchanMoodUpdatedAt || 0),
              suwanActivity: coreObj.profile?.suwanActivity || '',
              jingchanActivity: coreObj.profile?.jingchanActivity || '',
              suwanActivityUpdatedAt: Number(coreObj.profile?.suwanActivityUpdatedAt || 0),
              jingchanActivityUpdatedAt: Number(coreObj.profile?.jingchanActivityUpdatedAt || 0),
              suwanLastSeen: Number(coreObj.profile?.suwanLastSeen || 0),
              jingchanLastSeen: Number(coreObj.profile?.jingchanLastSeen || 0),
              suwanReadUpToTs: Number(coreObj.profile?.suwanReadUpToTs || 0),
              jingchanReadUpToTs: Number(coreObj.profile?.jingchanReadUpToTs || 0),
              suwanSleep: coreObj.profile?.suwanSleep,
              jingchanSleep: coreObj.profile?.jingchanSleep,
              suwanEnergy: coreObj.profile?.suwanEnergy,
              jingchanEnergy: coreObj.profile?.jingchanEnergy
            },
            hugs: coreObj.hugs || null,
            makerLayout: coreObj.makerLayout || null,
            tmiBook: coreObj.tmiBook || null,
            meals: coreObj.meals || null,
            lavender: coreObj.lavender || null,
            balanceGame: coreObj.balanceGame || null,
            dateStamps: coreObj.dateStamps || null,
            complimentJar: (coreObj.complimentJar || []).slice(0, 80),
            coupleQuizzes: (coreObj.coupleQuizzes || []).slice(0, 50),
            learn: coreObj.learn || {},
            chat: {
              pinnedMsg: coreObj.chat?.pinnedMsg || null,
              messages: (coreObj.chat?.messages || []).slice(-lim.msg),
              qaAnswers: (coreObj.chat?.qaAnswers || []).slice(0, lim.qa)
            },
            diaries: (coreObj.diaries || []).slice(0, lim.diary),
            memos: (coreObj.memos || []).slice(0, lim.memo),
            buckets: (coreObj.buckets || []).slice(0, lim.bucket),
            capsules: (coreObj.capsules || []).slice(0, lim.cap),
            coupons: (coreObj.coupons || []).slice(0, lim.coup),
            anniversaries: (coreObj.anniversaries || []).slice(0, lim.anniv),
            schedules: (coreObj.schedules || []).slice(0, lim.sched),
            albumFolders: (coreObj.albumFolders || []).slice(0, 25),
            albumFoldersCustomized: !!coreObj.albumFoldersCustomized,
            albumFoldersUpdatedAt: Number(coreObj.albumFoldersUpdatedAt || 0),
            customPhrases: (coreObj.customPhrases || []).slice(0, lim.phrase),
            transHistory: (coreObj.transHistory || []).slice(0, lim.trans),
            customGifs: (coreObj.customGifs || []).slice(0, lim.gif),
            deletedMsgIds: (coreObj.deletedMsgIds || []).slice(-80),
            deletedAlbumIds: (coreObj.deletedAlbumIds || []).slice(-100),
            drawQuizzes: (coreObj.drawQuizzes || []).slice(0, 12),
            rpsGame: coreObj.rpsGame || null,
            truthDare: coreObj.truthDare || null,
            customFoods: (coreObj.customFoods || []).slice(0, 40),
            albumMeta: (state.albums || []).slice(0, 250).map(a => ({ id: a.id, category: a.category || '', categoryUpdatedAt: Number(a.categoryUpdatedAt || 0), comments: Array.isArray(a.comments) ? a.comments.slice(-15) : [] }))
          };
        }

        async function executeCloudPush(coreObj, fullSnapshot) {
          const room = getSyncRoomCode();
          if (!room || !coreObj) return;
          lastCloudPushTs = Date.now();
          if (__cachedCloudLearn && coreObj.learn) {
            coreObj.learn = mergeLearnMonotonic(__cachedCloudLearn, coreObj.learn);
          }
          const payload = buildSyncPayload(coreObj, !!fullSnapshot);
          const fullSnapPayload = buildSyncPayload(coreObj, true);
          if (Number(state.learn?.xp || 0) > 0 || Number(state.learn?.solved || 0) > 0 || Number(state.learn?.resetAt || 0) > 0) {
            syncCloudLearnVault(room, false).catch(() => {});
          }
          const emqxBody = buildEmqxFastPacket(coreObj);
          const ntfyBody = buildCompactNtfyPacket(coreObj);

          // Priority #1 (China Direct): Fire EMQX immediately with full never-null fast packet!
          if (!emqxConnected) connectEmqxChinaDirect();
          const emqxOk = emqxBody ? publishEmqxBackup(room, emqxBody) : false;
          if (emqxOk) {
            lastSyncOkTs = Date.now();
            updateLiveSyncIndicators(true, room);
            markMyPendingMsgsStatus('sent');
          }

          // Safety Guard: NEVER overwrite couple_sync_state snapshot with an empty state or before initial cloud pull finishes!
          const __hasRealLocalData = (
            (Array.isArray(coreObj.chat?.messages) && coreObj.chat.messages.length > 0) ||
            (Array.isArray(coreObj.diaries) && coreObj.diaries.length > 0) ||
            (Array.isArray(coreObj.memos) && coreObj.memos.length > 0) ||
            (Array.isArray(coreObj.anniversaries) && coreObj.anniversaries.length > 0)
          );
          const __canUpsertSnap = !!window.__cwInitialPullDone && __hasRealLocalData;

          // Broadcast delta instantaneously over Seoul Supabase Realtime WebSocket (0.08s!) if subscribed
          let sbRealtimeSent = false;
          try {
            if (sbChannel && syncTransportMode === 'realtime' && typeof sbChannel.send === 'function' && emqxBody) {
              sbChannel.send({ type: 'broadcast', event: 'cw_delta', payload: JSON.parse(emqxBody) }).catch(() => {});
              sbRealtimeSent = true;
            }
          } catch (_) {}

          // Priority #2 & #3: Fire Supabase Seoul REST + ntfy simultaneously (5.5s tight timeout)
          const [sbEvRes, sbSnapRes, ntfyRes] = await Promise.allSettled([
            insertSupabaseEvent(room, 'delta', payload),
            __canUpsertSnap ? upsertSupabaseStateSnapshot(room, fullSnapPayload) : Promise.resolve(false),
            ntfyBody ? pushNtfyBackup(room, ntfyBody) : Promise.resolve(false)
          ]);

          const sbOk = sbRealtimeSent || (sbEvRes.status === 'fulfilled' && !!sbEvRes.value) || (sbSnapRes.status === 'fulfilled' && !!sbSnapRes.value);
          const ntfyOk = ntfyRes.status === 'fulfilled' && !!ntfyRes.value;
          if (sbOk) sbLastOkTs = Date.now();
          else enqueueOutboxPacket('delta', payload, 'delta');

          if (emqxOk || sbOk || ntfyOk) {
            lastSyncOkTs = Date.now();
            if (syncTransportMode === 'connecting' || syncTransportMode === 'reconnecting') syncTransportMode = 'rest';
            updateLiveSyncIndicators(true, room);
            markMyPendingMsgsStatus('sent');
          } else {
            // Auto-retry once after 1.8s (covers mobile wake-up / Wi-Fi↔LTE switch / EMQX handshake) before marking failed
            await new Promise(r => setTimeout(r, 1800));
            const retryEmqx = emqxBody ? publishEmqxBackup(room, emqxBody) : false;
            let retrySb = false, retryNtfy = false;
            if (!retryEmqx) {
              const [rSbEv, rSbSnap, rNtfy] = await Promise.allSettled([
                insertSupabaseEvent(room, 'delta', payload),
                __canUpsertSnap ? upsertSupabaseStateSnapshot(room, fullSnapPayload) : Promise.resolve(false),
                ntfyBody ? pushNtfyBackup(room, ntfyBody) : Promise.resolve(false)
              ]);
              retrySb = rSbEv.status === 'fulfilled' || rSbSnap.status === 'fulfilled';
              retryNtfy = rNtfy.status === 'fulfilled' && !!rNtfy.value;
            }
            if (retryEmqx || retrySb || retryNtfy) {
              lastSyncOkTs = Date.now();
              if (retrySb) sbLastOkTs = Date.now();
              updateLiveSyncIndicators(true, room);
              markMyPendingMsgsStatus('sent');
            } else {
              markMyPendingMsgsStatus('failed');
            }
          }
        }
        window.addEventListener('online', () => {
          try {
            connectEmqxChinaDirect();
            const hasPendingOrFailed = (state.chat?.messages || []).some(m => m && (m.deliveryStatus === 'failed' || m.deliveryStatus === 'sending'));
            if (hasPendingOrFailed) {
              pushCloudSyncDelta(extractLightweightCore(state));
            }
            if (typeof flushSyncOutbox === 'function') flushSyncOutbox();
          } catch (_) {}
        });
        window.__connectEmqxNow = connectEmqxChinaDirect;

        function markMyPendingMsgsStatus(newStatus) {
          try {
            const myR = state.myRole || 'suwan';
            let updated = false;
            (state.chat?.messages || []).forEach(m => {
              if (!m) return;
              const normS = (m.sender === 'jingchan' || String(m.sender || '').includes('靖灿')) ? 'jingchan' : 'suwan';
              if (normS === myR && (m.deliveryStatus === 'sending' || (newStatus === 'sent' && m.deliveryStatus === 'failed'))) {
                m.deliveryStatus = newStatus;
                updated = true;
              }
            });
            if (updated) {
              saveState(false);
              const trPanel = document.getElementById('tab-translator');
              if (trPanel && trPanel.classList.contains('active')) {
                if (!updateChatDeliveryBadgesInPlace()) renderChat();
              }
            }
          } catch (_) {}
        }
        window.__markMyPendingMsgsStatus = markMyPendingMsgsStatus;

        function pushCloudSyncDelta(coreObj) {
          const room = getSyncRoomCode();
          if (!room || !coreObj) return;
          pendingPushCore = coreObj;
          const now = Date.now();
          const elapsed = now - lastCloudPushTs;
          if (elapsed >= 300 && !livePushTimer) {
            const snap = pendingPushCore;
            pendingPushCore = null;
            executeCloudPush(snap, false);
          } else if (!livePushTimer) {
            livePushTimer = setTimeout(() => {
              livePushTimer = null;
              if (pendingPushCore) {
                const snap = pendingPushCore;
                pendingPushCore = null;
                executeCloudPush(snap, false);
              }
            }, Math.max(120, 340 - elapsed));
          }
        }

        async function pushFullCloudSync() {
          const coreObj = extractLightweightCore(state);
          await executeCloudPush(coreObj, true);
        }

        window.__pushCloudSyncDelta = pushCloudSyncDelta;
        window.__pushFullCloudSync = pushFullCloudSync;
        window.__flushSyncOutbox = flushSyncOutbox;

        async function processSupabaseEventRow(row, isLiveEvent, allowMediaReplay) {
          if (!row || typeof row !== 'object') return false;
          if (row.id) {
            if (!allowMediaReplay && processedEventIds.has(row.id)) return false;
            processedEventIds.add(row.id);
            if (processedEventIds.size > 600) {
              const first = processedEventIds.values().next().value;
              processedEventIds.delete(first);
            }
            const prevCursor = loadLastEventId();
            if (!isLiveEvent || prevCursor === 0 || row.id <= prevCursor + 1) {
              saveLastEventId(row.id);
            }
          }
          const isSelfRow = !!(row.client_id && row.client_id === myDeviceClientId);
          if (isSelfRow && !allowMediaReplay) return false;
          const data = await e2eeUnwrapPayload(row.payload);
          if (!data || typeof data !== 'object') return false;
          if (data.v === 'pro2' && (!isSelfRow || allowMediaReplay)) return mergeIncomingCoupleData(data, isSelfRow ? false : isLiveEvent, !!allowMediaReplay);
          if (data.v === 'pro2_media') return await handleIncomingMediaPacket(data, isSelfRow ? false : isLiveEvent, !!allowMediaReplay);
          if (data.v === 'pro2_media_chunk') return await handleIncomingMediaChunk(data, isSelfRow ? false : isLiveEvent, !!allowMediaReplay);
          if (data.v === 'pro2_signal' && !isSelfRow) { handleIncomingChatSignal(data); return false; }
          return false;
        }

        function connectLiveSyncStream() {
          const room = getSyncRoomCode();
          if (!room) return;
          // Priority #1 (China Direct): Connect EMQX Mainland China WebSocket FIRST!
          connectEmqxChinaDirect();
          // Priority #2: Connect Supabase Seoul Realtime WebSocket in parallel
          try {
            if (window.supabase && typeof window.supabase.createClient === 'function') {
              if (!sbClient) {
                sbClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_KEY, {
                  auth: { persistSession: false, autoRefreshToken: false },
                  realtime: { params: { eventsPerSecond: 10 } }
                });
              }
              if (sbChannel) {
                try { sbClient.removeChannel(sbChannel); } catch (_) {}
                sbChannel = null;
              }
              if (window.__sbPgChannel) {
                try { sbClient.removeChannel(window.__sbPgChannel); } catch (_) {}
                window.__sbPgChannel = null;
              }
              // Pure WebSocket Broadcast Channel: NEVER fails with CHANNEL_ERROR even if DB Realtime publication is off!
              sbChannel = sbClient
                .channel(`chanwan-bcast-${room}`, { config: { broadcast: { self: false } } })
                .on('broadcast', { event: 'cw_sig' }, (msg) => {
                  try {
                    sbLastOkTs = Date.now();
                    lastSyncOkTs = Date.now();
                    if (msg && msg.payload) handleIncomingChatSignal(msg.payload);
                  } catch (_) {}
                })
                .on('broadcast', { event: 'cw_delta' }, (msg) => {
                  try {
                    if (msg && msg.payload && msg.payload.clientId !== myDeviceClientId) {
                      sbLastOkTs = Date.now();
                      lastSyncOkTs = Date.now();
                      mergeIncomingCoupleData(msg.payload, true);
                      updateLiveSyncIndicators(true, room);
                    }
                  } catch (_) {}
                })
                .subscribe((status) => {
                  if (status === 'SUBSCRIBED') {
                    syncTransportMode = 'realtime';
                    liveSyncSource = { readyState: 1 };
                    sbLastOkTs = Date.now();
                    lastSyncOkTs = Date.now();
                    updateLiveSyncIndicators(true, room);
                    flushSyncOutbox();
                  } else if (status === 'CLOSED' || status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') {
                    liveSyncSource = null;
                    if (syncTransportMode === 'realtime') syncTransportMode = 'rest';
                    updateLiveSyncIndicators(sbLastOkTs > 0, room);
                  }
                });

              // Optional secondary DB change listener on couple_sync_state (isolated so it never breaks sbChannel!)
              window.__sbPgChannel = sbClient
                .channel(`chanwan-pgstate-${room}`)
                .on(
                  'postgres_changes',
                  { event: '*', schema: 'public', table: 'couple_sync_state', filter: `room_id=eq.${room}` },
                  async (payload) => {
                    try {
                      if (payload && payload.new && payload.new.payload) {
                        sbLastOkTs = Date.now();
                        lastSyncOkTs = Date.now();
                        const dec = await e2eeUnwrapPayload(payload.new.payload);
                        if (dec) mergeIncomingCoupleData(dec, true);
                        updateLiveSyncIndicators(true, room);
                      }
                    } catch (_) {}
                  }
                )
                .subscribe();
            }
          } catch (_) {}
          pullCloudSync(false);
        }
        window.__reconnectLiveSync = connectLiveSyncStream;

        async function pullCloudSync(manual) {
          if (isPullingCloud && !manual) return;
          const room = getSyncRoomCode();
          if (!room) return;
          isPullingCloud = true;
          try {
            let mergedAny = false;
            const lastId = loadLastEventId();

            window.__sbPollTick = (window.__sbPollTick || 0) + 1;
            // First poll on boot/reconnect is ALWAYS silent catch-up so old notifications NEVER replay!
            const isLivePull = (manual === 'live_push' || !manual) && lastId > 0 && window.__sbPollTick > 1;
            // Priority #1 (China Direct): Ensure EMQX China WebSocket stays alive on every 7s cycle
            if (!emqxConnected) connectEmqxChinaDirect();

            const safeFromId = Math.max(0, lastId - 15);
            const __needsDeepRecover = ((state.chat?.messages || []).length < 8 || (state.diaries || []).length === 0) && !window.__cwDeepDeltaRecovered;
            const evUrl = __needsDeepRecover
              ? `${SUPABASE_URL}/rest/v1/couple_sync_events?room_id=eq.${encodeURIComponent(room)}&kind=eq.delta&order=id.desc&limit=80`
              : (lastId > 0
                  ? `${SUPABASE_URL}/rest/v1/couple_sync_events?room_id=eq.${encodeURIComponent(room)}&id=gt.${safeFromId}&order=id.asc&limit=60`
                  : `${SUPABASE_URL}/rest/v1/couple_sync_events?room_id=eq.${encodeURIComponent(room)}&order=id.desc&limit=30`);
            const snapUrl = `${SUPABASE_URL}/rest/v1/couple_sync_state?room_id=eq.${encodeURIComponent(room)}&select=payload,updated_at`;
            const bothRealtimeHealthy = !!(emqxConnected && syncTransportMode === 'realtime' && (Date.now() - lastSyncOkTs) < 25000);
            const shouldPullSnap = !isLivePull || manual || !bothRealtimeHealthy || (window.__sbPollTick % 5 === 1);
            const shouldPullMedia = !isLivePull || manual || (window.__sbPollTick % 6 === 1);
            // Lightweight index query ONLY (id, client_id) so it NEVER times out even when videos are stored!
            const mediaIdxUrl = `${SUPABASE_URL}/rest/v1/couple_sync_events?room_id=eq.${encodeURIComponent(room)}&kind=eq.media&select=id,client_id&order=id.desc&limit=400`;

            // Fire ALL pull channels simultaneously so China mobile NEVER stalls on a single slow server!
            const [ntfyPull, snapPull, evPull, mediaPull] = await Promise.allSettled([
              (!bothRealtimeHealthy || manual || (window.__sbPollTick % 4 === 1)) ? pollNtfyBackup(room, isLivePull) : Promise.resolve(false),
              shouldPullSnap ? fetchWithTimeout(snapUrl, { headers: sbHeaders() }, SYNC_FETCH_TIMEOUT_MS).then(async r => {
                if (!r.ok) return null;
                sbLastOkTs = Date.now();
                const d = await r.json();
                try {
                  if (Array.isArray(d) && d[0] && d[0].payload) {
                    const fastDec = await e2eeUnwrapPayload(d[0].payload);
                    if (fastDec) mergeIncomingCoupleData(fastDec, false);
                  }
                } catch (_) {}
                return d;
              }) : Promise.resolve(null),
              (!__sbEventsUnavailable ? fetchSbEventsCompat(evUrl, SYNC_FETCH_TIMEOUT_MS).then(async r => {
                if (!r.ok) return null;
                const d = await r.json();
                try {
                  if (Array.isArray(d) && d.length) {
                    const fastRows = (__needsDeepRecover || lastId === 0) ? d.slice().reverse() : d;
                    const fastNew = fastRows.filter(x => Number(x && x.id || 0) > lastId);
                    if (fastNew.length > 0 && fastNew.length <= 8) {
                      const topId = Number(fastNew[fastNew.length - 1].id || 0);
                      for (const fr of fastNew) {
                        const frId = Number(fr && fr.id || 0);
                        const liveFlag = isLivePull && (Date.now() - __cwBootEpoch) > 4000 && (fastNew.length <= 2 || frId === topId);
                        if (await processSupabaseEventRow(fr, liveFlag)) mergedAny = true;
                      }
                    }
                  }
                } catch (_) {}
                return d;
              }) : Promise.resolve(null)),
              (shouldPullMedia && !__sbEventsUnavailable) ? fetchSbEventsCompat(mediaIdxUrl, 9000).then(r => r.ok ? r.json() : null) : Promise.resolve(null)
            ]);

            let anyServerOk = !!emqxConnected;
            if (ntfyPull.status === 'fulfilled' && ntfyPull.value) { mergedAny = true; anyServerOk = true; }
            if (snapPull.status === 'fulfilled' && Array.isArray(snapPull.value)) {
              sbLastOkTs = Date.now(); anyServerOk = true;
              if (snapPull.value[0] && snapPull.value[0].payload) {
                const decSnap = await e2eeUnwrapPayload(snapPull.value[0].payload);
                const snapFresh = !!(decSnap && decSnap.ts && (Date.now() - Number(decSnap.ts)) <= 60000);
                if (decSnap && mergeIncomingCoupleData(decSnap, isLivePull && snapFresh)) mergedAny = true;
              }
            }
            if (evPull.status === 'fulfilled' && Array.isArray(evPull.value)) {
              sbLastOkTs = Date.now(); anyServerOk = true;
              const rows = (__needsDeepRecover || lastId === 0) ? evPull.value.slice().reverse() : evPull.value;
              if (__needsDeepRecover) window.__cwDeepDeltaRecovered = true;
              const newRows = rows.filter(r => Number(r && r.id || 0) > lastId);
              const latestNewId = newRows.length ? Number(newRows[newRows.length - 1].id || 0) : 0;
              for (const r of rows) {
                const rid = Number(r && r.id || 0);
                // When catching up a backlog of missed events, only alert on the newest one (never flood 10+ banners!)
                const isTrulyNewRow = isLivePull && (Date.now() - __cwBootEpoch) > 4000 && rid > lastId && (newRows.length <= 2 || rid === latestNewId);
                if (await processSupabaseEventRow(r, isTrulyNewRow)) mergedAny = true;
              }
            }
            if (shouldPullMedia) {
              pullRecentMediaPack(room, false).catch(() => {});
              fetchCloudVaultManifest(room).then(async (mItems) => {
                const cnt = await restoreVaultBatchParallel(room, mItems);
                if (cnt > 0) {
                  persistMediaVaultsNow(true);
                  saveState(false);
                  try { renderBucketAndAlbum(); renderVoiceLetters(); renderChat(); renderHome(); updateVaultIndicators(); } catch (_) {}
                }
              }).catch(() => {});
              if ((state.albums || []).length === 0 || (state.voiceLetters || []).length === 0) {
                if (typeof window.__requestPartnerVaultSync === 'function') window.__requestPartnerVaultSync('poll_missing');
              }
            }
            if (mediaPull.status === 'fulfilled' && Array.isArray(mediaPull.value)) {
              sbLastOkTs = Date.now(); anyServerOk = true;
              const needSelfRecover = manual || (state.albums || []).length === 0 || (state.voiceLetters || []).length === 0 || (state.chat?.messages || []).some(x => x && !x.photoUrl && !x.videoUrl && !x.audioUrl && /사진을 보냈어요|동영상을 보냈어요|음성 메시지|发来|照片|视频/.test(String(x.original || '')));
              const idxRows = mediaPull.value.slice().reverse();
              const idsToFetch = [];
              for (const r of idxRows) {
                const rid = Number(r && r.id || 0);
                if (!rid) continue;
                const isSelfR = !!(r.client_id && r.client_id === myDeviceClientId);
                if (isSelfR && !needSelfRecover) continue;
                if (!needSelfRecover && processedEventIds.has(rid)) continue;
                idsToFetch.push(rid);
              }
              // Fetch media payloads in small 4-row batches with generous 22s timeout so videos & photos NEVER time out!
              const batchCap = needSelfRecover ? 400 : 180;
              const targetIds = idsToFetch.slice(-batchCap);
              for (let bi = 0; bi < targetIds.length; bi += 6) {
                const chunkIds = targetIds.slice(bi, bi + 6);
                try {
                  const bUrl = `${SUPABASE_URL}/rest/v1/couple_sync_events?room_id=eq.${encodeURIComponent(room)}&id=in.(${chunkIds.join(',')})&order=id.asc`;
                  const bRes = await fetchWithTimeout(bUrl, { headers: sbHeaders() }, 22000);
                  if (bRes.ok) {
                    const bRows = await bRes.json();
                    if (Array.isArray(bRows)) {
                      for (const mr of bRows) {
                        if (await processSupabaseEventRow(mr, false, true)) mergedAny = true;
                      }
                    }
                  }
                } catch (_) {}
              }
            }
            if (!anyServerOk) throw new Error('all_servers_unreachable');
            window.__cwInitialPullDone = true;
            lastSyncOkTs = Date.now();
            if (syncTransportMode !== 'realtime') syncTransportMode = 'rest';
            updateLiveSyncIndicators(true, room);
            await flushSyncOutbox();
            if (manual === true) {
              await pushFullCloudSync();
              showToast(mergedAny
                ? (state.lang === 'zh' ? '⚡ 首尔服务器同步完成 · 已更新最新记录 ✨' : '⚡ 서울 서버 동기화 완료 · 새 기록을 가져왔어요 ✨')
                : (state.lang === 'zh' ? '🟢 首尔实时服务器连接正常 · 已是最新 ✨' : '🟢 서울 실시간 서버 연결 정상 · 최신 상태예요 ✨'));
            }
          } catch (_) {
            const bkMerged = await pollNtfyBackup(room, !manual);
            if (ntfyLastOkTs && (Date.now() - ntfyLastOkTs) < 15000) {
              lastSyncOkTs = Date.now();
              if (syncTransportMode !== 'realtime') syncTransportMode = 'rest';
              updateLiveSyncIndicators(true, room);
              if (manual) showToast(bkMerged
                ? (state.lang === 'zh' ? '🟢 备用通道同步完成 ✨' : '🟢 백업 서버 동기화 완료 ✨')
                : (state.lang === 'zh' ? '🟢 备用实时通道连接正常 ✨' : '🟢 백업 실시간 서버 연결 정상 ✨'));
            } else {
              if (syncTransportMode !== 'realtime') syncTransportMode = 'reconnecting';
              updateLiveSyncIndicators(false, room);
              if (manual) showToast(state.lang === 'zh' ? '🟡 网络暂时波动，稍后会自动重连' : '🟡 잠시 네트워크가 불안정해요. 자동으로 다시 연결돼요');
            }
          } finally {
            isPullingCloud = false;
          }
        }
        window.__pullCloudSync = pullCloudSync;

        // Ultra-fast (~100ms) chat-only delta pull for notification open & foreground nudge (never waits on media scan!)
        async function pullFastChatDeltaNow(isLiveNudge) {
          try {
            const room = getSyncRoomCode();
            if (!room) return false;
            if (!emqxConnected) connectEmqxChinaDirect();
            const lastId = loadLastEventId();
            const safeFrom = Math.max(0, lastId - 10);
            const fastUrl = lastId > 0
              ? `${SUPABASE_URL}/rest/v1/couple_sync_events?room_id=eq.${encodeURIComponent(room)}&kind=eq.delta&id=gt.${safeFrom}&order=id.asc&limit=30`
              : `${SUPABASE_URL}/rest/v1/couple_sync_events?room_id=eq.${encodeURIComponent(room)}&kind=eq.delta&order=id.desc&limit=25`;
            const snapUrl = `${SUPABASE_URL}/rest/v1/couple_sync_state?room_id=eq.${encodeURIComponent(room)}&select=payload,updated_at`;
            const [evRes, snapRes] = await Promise.allSettled([
              fetchSbEventsCompat(fastUrl, 3500).then(r => r.ok ? r.json() : null),
              fetchWithTimeout(snapUrl, { headers: sbHeaders() }, 3500).then(r => r.ok ? r.json() : null)
            ]);
            let changed = false;
            if (evRes.status === 'fulfilled' && Array.isArray(evRes.value)) {
              const rows = lastId > 0 ? evRes.value : evRes.value.slice().reverse();
              const newRows = rows.filter(x => Number(x && x.id || 0) > lastId);
              const latestId = newRows.length ? Number(newRows[newRows.length - 1].id || 0) : 0;
              for (const r of rows) {
                const rid = Number(r && r.id || 0);
                const live = !!isLiveNudge && lastId > 0 && rid > lastId && (newRows.length <= 2 || rid === latestId);
                if (await processSupabaseEventRow(r, live)) changed = true;
              }
            }
            if (snapRes.status === 'fulfilled' && Array.isArray(snapRes.value) && snapRes.value[0]?.payload) {
              const dec = await e2eeUnwrapPayload(snapRes.value[0].payload);
              if (dec && mergeIncomingCoupleData(dec, false)) changed = true;
            }
            if (changed) {
              if (Array.isArray(state.chat?.messages)) {
                state.chat.messages = state.chat.messages.filter(m => m && !m.__tempPushPreview);
              }
              renderChat();
              if (typeof window.__scrollChatToBottom === 'function') window.__scrollChatToBottom(true);
              if (typeof window.__emitChatReadIfVisible === 'function') window.__emitChatReadIfVisible(false);
            }
            return changed;
          } catch (_) { return false; }
        }
        window.__pullFastChatDeltaNow = pullFastChatDeltaNow;

        // 0.0s Notification Tap Handler: wipes ALL OS notifications, switches to CW Talk, shows message immediately & syncs!
        window.__openChatFromNotification = async function(pushTitle, pushBody, pushWhenMs) {
          try {
            clearAllAppBadgesAndOsNotifs();
            switchTab('translator');
            if (typeof switchTransSubtab === 'function') switchTransSubtab('messenger');

            const cleanBody = String(pushBody || '').trim();
            const isGeneric = !cleanBody || /^(새 메시지가 도착했어요|收到一条新消息)$/.test(cleanBody);
            const isNonChat = /밸런스|게임|하트비트|커플공간|기분|상태|默契|心跳|空间|心情|状态/.test(String(pushTitle || ''));
            if (!isGeneric && !isNonChat) {
              if (!state.chat) state.chat = { messages: [] };
              if (!Array.isArray(state.chat.messages)) state.chat.messages = [];
              const myR = state.myRole || 'suwan';
              const partnerR = myR === 'suwan' ? 'jingchan' : 'suwan';
              const alreadyExists = state.chat.messages.slice(-12).some(m =>
                m && (String(m.original || '').trim() === cleanBody || String(m.translated || '').trim() === cleanBody)
              );
              if (!alreadyExists) {
                const whenEpoch = Number(pushWhenMs) > 0 ? Number(pushWhenMs) : Date.now();
                const tStr = new Date(whenEpoch).toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' });
                state.chat.messages = state.chat.messages.filter(m => m && !m.__tempPushPreview);
                state.chat.messages.push({
                  id: `msg_push_prev_${whenEpoch}`,
                  ts: whenEpoch,
                  sender: partnerR,
                  time: tStr,
                  original: cleanBody,
                  translated: cleanBody,
                  pronunciation: '',
                  tone: '',
                  nuance: '',
                  engine: '',
                  tgtLang: myR === 'suwan' ? 'ko' : 'zh',
                  __tempPushPreview: true
                });
              }
            }
            window.__cwForceScrollBottom = true;
            renderChat();
            if (typeof window.__scrollChatToBottom === 'function') window.__scrollChatToBottom(true);

            await pullFastChatDeltaNow(false);
            pullCloudSync(false).catch(() => {});
          } catch (_) {}
        };
        if (window.__pendingNotifOpen) {
          const p = window.__pendingNotifOpen;
          window.__pendingNotifOpen = null;
          setTimeout(() => window.__openChatFromNotification(p.title, p.body, p.when), 20);
        }

        let isRunningFullCloudRestore = false;
        async function runFullCloudDataRestore(silentBoot) {
          if (isRunningFullCloudRestore) return;
          const room = getSyncRoomCode();
          const isZh = state.lang === 'zh';
          if (!room) {
            showToast(isZh ? '请先在同步设置中填写房间暗号' : '동기화 방 코드가 설정되어 있지 않아요');
            return;
          }
          isRunningFullCloudRestore = true;
          const btn = document.getElementById('cloudFullRestoreBtn');
          const progWrap = document.getElementById('cloudFullRestoreProgressWrap');
          const statusEl = document.getElementById('cloudFullRestoreStatus');
          const pctEl = document.getElementById('cloudFullRestorePct');
          const barEl = document.getElementById('cloudFullRestoreBar');
          const reportEl = document.getElementById('cloudFullRestoreReport');
          const setProg = (pct, msg) => {
            const p = Math.max(0, Math.min(100, Math.round(pct)));
            if (progWrap) progWrap.classList.remove('hidden');
            if (statusEl) statusEl.textContent = msg;
            if (pctEl) pctEl.textContent = `${p}%`;
            if (barEl) barEl.style.width = `${p}%`;
          };
          const countChatMedia = () => (state.chat?.messages || []).filter(m => m && (m.photoUrl || m.videoUrl || m.audioUrl || (Array.isArray(m.photoUrls) && m.photoUrls.length))).length;
          const before = {
            msgs: (state.chat?.messages || []).length,
            chatMedia: countChatMedia(),
            albums: (state.albums || []).length,
            voices: (state.voiceLetters || []).length,
            diaries: (state.diaries || []).length,
            memos: (state.memos || []).length
          };
          if (btn) { btn.disabled = true; btn.textContent = isZh ? '⏳ 正在恢复...' : '⏳ 복구 중...'; }
          if (reportEl) reportEl.classList.add('hidden');
          try {
            // Immediately request real-time P2P vault stream from partner's browser/phone (works in 0.1s over EMQX China-Direct!)
            if (typeof window.__requestPartnerVaultSync === 'function') {
              window.__requestPartnerVaultSync(silentBoot ? 'boot_restore' : 'manual_restore');
            }

            // Phase 1: Snapshot from couple_sync_state (with allowSelfReplay=true so ALL history restores!)
            setProg(10, isZh ? '1/4 正在拉取云端快照记录...' : '1/4 서버 스냅샷 기록 불러오는 중...');
            try {
              const snapRes = await fetchWithTimeout(`${SUPABASE_URL}/rest/v1/couple_sync_state?room_id=eq.${encodeURIComponent(room)}&select=payload,updated_at`, { headers: sbHeaders() }, 15000);
              if (snapRes.ok) {
                const snapArr = await snapRes.json();
                if (Array.isArray(snapArr) && snapArr[0] && snapArr[0].payload) {
                  const decSnap = await e2eeUnwrapPayload(snapArr[0].payload);
                  if (decSnap) mergeIncomingCoupleData(decSnap, false, true);
                }
              }
            } catch (_) {}

            // Phase 1.5: Restore Dedicated Cloud Study Vault (__learn_vault_v1)
            await syncCloudLearnVault(room, false);

            // Phase 2: Permanent Cloud Media Vault inside couple_sync_state (__vault_manifest_v1)
            setProg(24, isZh ? '2/4 正在读取云端永久相册与语音信金库...' : '2/4 서버 영구 금고(앨범 사진·음성편지·프로필) 복구 중...');
            const manifestItems = await fetchCloudVaultManifest(room);
            let vaultRestored = 0;
            for (let mi = 0; mi < manifestItems.length; mi++) {
              const okV = await restoreVaultEntryFromCloudState(room, manifestItems[mi]);
              if (okV) vaultRestored++;
              const vPct = 24 + ((mi + 1) / Math.max(1, manifestItems.length)) * 36;
              setProg(vPct, isZh
                ? `2/4 正在恢复永久金库照片与语音 (${mi + 1}/${manifestItems.length})...`
                : `2/4 영구 금고 사진·음성편지 복구 중 (${mi + 1}/${manifestItems.length})...`);
            }

            // Phase 3: Universal Event Scan in couple_sync_events (if table exists)
            setProg(64, isZh ? '3/4 正在扫描历史同步事件...' : '3/4 서버 이벤트 기록 정밀 스캔 중...');
            let evCursor = null;
            const allEventIds = [];
            if (!__sbEventsUnavailable) {
              for (let page = 0; page < 4; page++) {
                const idxUrl = `${SUPABASE_URL}/rest/v1/couple_sync_events?room_id=eq.${encodeURIComponent(room)}${evCursor ? `&id=lt.${evCursor}` : ''}&select=id&order=id.desc&limit=500`;
                try {
                  const iRes = await fetchWithTimeout(idxUrl, { headers: sbHeaders() }, 10000);
                  if (!iRes.ok) break;
                  const iRows = await iRes.json();
                  if (!Array.isArray(iRows) || !iRows.length) break;
                  for (const r of iRows) { if (r && r.id) allEventIds.push(Number(r.id)); }
                  evCursor = iRows[iRows.length - 1].id;
                  if (iRows.length < 500) break;
                } catch (_) { break; }
              }
            }

            const orderedIds = allEventIds.slice().reverse();
            const totalMedia = manifestItems.length + orderedIds.length;
            let fetchedCount = 0;
            let failedBatches = 0;
            for (let bi = 0; bi < orderedIds.length; bi += 6) {
              const chunkIds = orderedIds.slice(bi, bi + 6);
              let okBatch = false;
              for (let attempt = 0; attempt < 2 && !okBatch; attempt++) {
                try {
                  const bUrl = `${SUPABASE_URL}/rest/v1/couple_sync_events?room_id=eq.${encodeURIComponent(room)}&id=in.(${chunkIds.join(',')})&order=id.asc`;
                  const bRes = await fetchWithTimeout(bUrl, { headers: sbHeaders() }, 22000);
                  if (bRes.ok) {
                    const bRows = await bRes.json();
                    if (Array.isArray(bRows)) {
                      for (const mr of bRows) {
                        await processSupabaseEventRow(mr, false, true);
                      }
                    }
                    okBatch = true;
                  }
                } catch (_) {
                  if (attempt === 0) await new Promise(r => setTimeout(r, 700));
                }
              }
              if (!okBatch) failedBatches++;
              fetchedCount = Math.min(orderedIds.length, bi + chunkIds.length);
              const pct = orderedIds.length > 0 ? (65 + (fetchedCount / orderedIds.length) * 25) : 90;
              setProg(pct, isZh
                ? `3/4 正在恢复事件媒体 (${fetchedCount}/${orderedIds.length})...`
                : `3/4 추가 이벤트 기록 복구 중 (${fetchedCount}/${orderedIds.length})...`);
            }

            // Brief window for live EMQX P2P partner stream packets to land if partner's app is currently open!
            if (!silentBoot && ((state.albums || []).length === 0 || (state.voiceLetters || []).length === 0)) {
              setProg(93, isZh ? '4/4 正在呼叫对方在线设备同步相册与语音信...' : '4/4 상대방 접속 기기(징찬 폰·이전 브라우저)에서 직통 수신 대기 중...');
              await new Promise(r => setTimeout(r, 2200));
            }

            // Phase 4: Sort messages strictly chronologically, lock into all 4 IndexedDB Vaults & Re-render
            setProg(98, isZh ? '正在写入 4 重永久金库并刷新界面...' : '4중 영구 금고에 안전 저장 중...');
            if (state.chat && Array.isArray(state.chat.messages)) {
              state.chat.messages = sortChatMessagesStable(state.chat.messages);
            }
            persistMediaVaultsNow(true);
            flushIdbStateNow();
            saveState(false);
            try { renderAll(); updateVaultIndicators(); } catch (_) {}

            const after = {
              msgs: (state.chat?.messages || []).length,
              chatMedia: countChatMedia(),
              albums: (state.albums || []).length,
              voices: (state.voiceLetters || []).length,
              diaries: (state.diaries || []).length,
              memos: (state.memos || []).length
            };
            const diffStr = (a, b) => (a > b ? ` (+${a - b})` : '');
            setProg(100, isZh ? '✅ 云端数据完整恢复完成！' : '✅ 클라우드 데이터 전체 가져오기 완료!');
            if (reportEl) {
              reportEl.innerHTML = isZh
                ? `<div class="font-bold text-gold mb-1">☁️ 已扫描云端媒体 ${totalMedia} 条 · 安全合并完成</div>
                   <div>• 聊天照片/视频/语音：<b>${after.chatMedia}</b>${diffStr(after.chatMedia, before.chatMedia)}</div>
                   <div>• 情侣相册：<b>${after.albums}</b>${diffStr(after.albums, before.albums)} · 语音信：<b>${after.voices}</b>${diffStr(after.voices, before.voices)}</div>
                   <div>• 聊天记录：<b>${after.msgs}</b>${diffStr(after.msgs, before.msgs)} · 日记/备忘：<b>${after.diaries}/${after.memos}</b></div>
                   ${failedBatches > 0 ? `<div class="text-rose-500 mt-1">⚠️ 网络波动跳过 ${failedBatches} 批，可稍后再点一次补齐</div>` : ''}`
                : `<div class="font-bold text-gold mb-1">☁️ 서버·금고 미디어 ${totalMedia}건 스캔 · 안전 복구 완료</div>
                   <div>• 메신저 사진·영상·음성: <b>${after.chatMedia}건</b>${diffStr(after.chatMedia, before.chatMedia)}</div>
                   <div>• 커플앨범: <b>${after.albums}건</b>${diffStr(after.albums, before.albums)} · 음성편지: <b>${after.voices}건</b>${diffStr(after.voices, before.voices)}</div>
                   <div>• 대화: <b>${after.msgs}건</b>${diffStr(after.msgs, before.msgs)} · 일기·메모: <b>${after.diaries}/${after.memos}건</b></div>
                   ${(after.albums === 0 && after.voices === 0) ? `<div class="mt-1.5 pt-1.5 border-t text-[11px]" style="border-color: var(--border-subtle); color: var(--accent-royal);">💡 이전 앱 삭제 전 사진·음성편지는 <b>징찬이 폰 웹앱</b>(또는 수완님 폰 삼성인터넷/크롬)이 켜지는 즉시 <b>EMQX 직통 + 서버 영구금고</b>로 자동 전송되어 채워져요!</div>` : ''}
                   ${failedBatches > 0 ? `<div class="text-rose-500 mt-1">⚠️ 네트워크 불안정으로 ${failedBatches}개 구간을 건너뛰었어요. 한 번 더 누르면 이어서 채워져요.</div>` : ''}`;
              reportEl.classList.remove('hidden');
            }
            if (!silentBoot || after.chatMedia > before.chatMedia || after.albums > before.albums || after.voices > before.voices || after.msgs > before.msgs) { showToast(isZh ? '☁️ 云端全部数据与照片/语音已恢复并锁定到永久金库 ✨' : '☁️ 클라우드 데이터와 사진·음성편지가 영구 금고에 복구됐어요 ✨'); }
          } catch (_) {
            setProg(100, isZh ? '⚠️ 连接首尔服务器失败，请检查网络后重试' : '⚠️ 서버 연결에 실패했어요. 네트워크 확인 후 다시 눌러주세요');
            showToast(isZh ? '⚠️ 云端恢复失败，请检查网络后重试' : '⚠️ 클라우드 복구 중 네트워크 오류가 발생했어요');
          } finally {
            isRunningFullCloudRestore = false;
            if (btn) {
              btn.disabled = false;
              btn.textContent = (I18N[state.lang] && I18N[state.lang].cloudFullRestoreBtn) || (isZh ? '☁️ 完整导入恢复' : '☁️ 전체 가져오기');
            }
          }
        }
        window.__runFullCloudDataRestore = runFullCloudDataRestore;
        const cloudFullRestoreBtnEl = document.getElementById('cloudFullRestoreBtn');
        if (cloudFullRestoreBtnEl) {
          cloudFullRestoreBtnEl.addEventListener('click', () => runFullCloudDataRestore());
        }

        // Smart Automatic Self-Diagnosis & Lightweight Auto-Heal (runs silently on boot + reconnect with 5-min cooldown, zero lag!)
        let __cwLastAutoHealTs = 0;
        let __cwLastAutoMediaRecoverTs = 0;
        const autoHealToggleEl = document.getElementById('autoSelfHealToggle');
        if (autoHealToggleEl) {
          try {
            const savedAuto = localStorage.getItem('cw_auto_self_heal_v1');
            autoHealToggleEl.checked = savedAuto !== '0';
          } catch (_) {}
          autoHealToggleEl.addEventListener('change', () => {
            try { localStorage.setItem('cw_auto_self_heal_v1', autoHealToggleEl.checked ? '1' : '0'); } catch (_) {}
            const isZh = state.lang === 'zh';
            showToast(autoHealToggleEl.checked
              ? (isZh ? '🤖 已开启智能自动自检（零卡顿后台守护）' : '🤖 스마트 자동 자가진단을 켰어요 (백그라운드 경량 점검)')
              : (isZh ? '⏸️ 已暂停自动自检（可随时手动点击修复）' : '⏸️ 자동 자가진단을 껐어요 (필요할 때 수동으로 누르실 수 있어요)'));
          });
        }
        async function runSilentAutoHeal(reason) {
          try {
            if (!__cwStateLoaded) return;
            if (localStorage.getItem('cw_auto_self_heal_v1') === '0') return;
            const now = Date.now();
            if ((now - __cwLastAutoHealTs) < 5 * 60 * 1000) return;
            __cwLastAutoHealTs = now;
            const fixed = [];
            const isZh = state.lang === 'zh';

            // 0) Repair state structure & dedupe corrupt entries
            const repCnt = typeof repairStateIntegrity === 'function' ? repairStateIntegrity() : 0;
            if (repCnt > 0) fixed.push(isZh ? `数据结构修复 ${repCnt} 处` : `구조 정리 ${repCnt}건`);

            // 1) Stuck 'sending' (>18s) or 'failed' messages -> auto-retry immediately when online!
            let stuckCnt = 0;
            const isOnlineNow = (typeof navigator === 'undefined' || navigator.onLine !== false);
            (state.chat?.messages || []).forEach(m => {
              if (!m) return;
              if (m.deliveryStatus === 'failed' || (m.deliveryStatus === 'sending' && m.ts && (now - Number(m.ts)) > 18000)) {
                m.deliveryStatus = isOnlineNow ? 'sending' : 'failed';
                stuckCnt++;
              }
            });
            if (stuckCnt > 0) {
              fixed.push(isZh ? `未发消息自动重发 ${stuckCnt} 条` : `미전송 ${stuckCnt}건 자동 재전송`);
              if (isOnlineNow) {
                if (typeof flushSyncOutbox === 'function') flushSyncOutbox();
                if (typeof pushCloudSyncDelta === 'function') pushCloudSyncDelta(extractLightweightCore(state));
              }
            }

            // 1b) Resolve any stuck '⏳ 번역 중...' messages & notifications
            if (typeof autoResolvePendingTranslations === 'function') autoResolvePendingTranslations();
            if (typeof renderNotifications === 'function') renderNotifications();

            // 2) Sweep deleted album/voice ghosts
            let ghostCnt = 0;
            if (Array.isArray(state.albums) && Array.isArray(state.deletedAlbumIds) && state.deletedAlbumIds.length) {
              const delA = new Set(state.deletedAlbumIds);
              const beforeA = state.albums.length;
              state.albums = state.albums.filter(a => a && !delA.has(a.id));
              ghostCnt += Math.max(0, beforeA - state.albums.length);
            }
            if (Array.isArray(state.voiceLetters) && Array.isArray(state.deletedVoiceIds) && state.deletedVoiceIds.length) {
              const delV = new Set(state.deletedVoiceIds);
              const beforeV = state.voiceLetters.length;
              state.voiceLetters = state.voiceLetters.filter(v => v && !delV.has(v.id));
              ghostCnt += Math.max(0, beforeV - state.voiceLetters.length);
            }
            if (ghostCnt > 0) fixed.push(isZh ? `清理残留 ${ghostCnt} 项` : `삭제 잔재 ${ghostCnt}건 정리`);

            // 3) Clear phantom Samsung/Android badge when unread == 0
            const unreadCnt = (state.notifications || []).filter(n => n && n.unread).length;
            if (unreadCnt === 0 && typeof clearAllAppBadgesAndOsNotifs === 'function') {
              clearAllAppBadgesAndOsNotifs();
            }

            // 4) Reconnect EMQX China Direct if dropped
            if (!emqxConnected && typeof connectEmqxChinaDirect === 'function') {
              connectEmqxChinaDirect();
              fixed.push(isZh ? 'EMQX重连' : 'EMQX 재연결');
            }

            // 5) Anomaly-only cloud media auto-recovery (max once per 15 min)
            const msgCount = (state.chat?.messages || []).length;
            const hasMissingChatMedia = (state.chat?.messages || []).slice(-30).some(x => x && !x.photoUrl && !x.videoUrl && !x.audioUrl && /사진을 보냈어요|동영상을 보냈어요|음성 메시지|分享了一张照片|分享了一段视频/.test(String(x.original || '')));
            if ((now - __cwLastAutoMediaRecoverTs) > 15 * 60 * 1000 && ((msgCount >= 3 && (state.albums || []).length === 0) || hasMissingChatMedia)) {
              __cwLastAutoMediaRecoverTs = now;
              fixed.push(isZh ? '缺失媒体自动拉取' : '누락 사진·영상 자동 복구');
              pullCloudSync(false);
            }

            if (stuckCnt > 0 || ghostCnt > 0) saveState(false);

            const tStr = new Date().toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' });
            const lineEl = document.getElementById('autoHealLastRunText');
            if (lineEl) {
              lineEl.textContent = fixed.length
                ? (isZh ? `🟢 ${tStr} 自动修复：${fixed.join(' · ')}` : `🟢 ${tStr} 자동 복구 완료: ${fixed.join(' · ')}`)
                : (isZh ? `🟢 ${tStr} 自动自检正常 · 无需修复` : `🟢 ${tStr} 자동 자가진단 정상 · 이상 없음`);
            }
          } catch (_) {}
        }
        window.__runSilentAutoHeal = runSilentAutoHeal;
        setTimeout(() => runSilentAutoHeal('boot'), 4000);
        window.addEventListener('online', () => setTimeout(() => runSilentAutoHeal('online'), 2000));
        document.addEventListener('visibilitychange', () => { if (!document.hidden) setTimeout(() => runSilentAutoHeal('resume'), 1800); });

        const saveRoomBtn = document.getElementById('saveCloudRoomBtn');
        const pullSyncBtn = document.getElementById('pullCloudSyncBtn');
        const chatSyncBtn = document.getElementById('chatQuickSyncBtn');

        if (saveRoomBtn) {
          saveRoomBtn.addEventListener('click', () => {
            if (!state.settings) state.settings = {};
            state.settings.cloudSyncRoom = getSyncRoomCode();
            saveState(false);
            connectLiveSyncStream();
            pullCloudSync(true);
            showToast(state.lang === 'zh' ? '⚡ 已重新连接 Supabase 首尔实时通道 ✨' : '⚡ Supabase 서울 실시간 채널을 다시 연결했어요 ✨');
          });
        }
        if (pullSyncBtn) pullSyncBtn.addEventListener('click', () => { connectLiveSyncStream(); pullCloudSync(true); });
        if (chatSyncBtn) chatSyncBtn.addEventListener('click', () => { connectLiveSyncStream(); pullCloudSync(true); });

        // ---- Settings E2EE UI Controller & Auto-Lock on Background Return ----
        (function setupE2eeSecurityUi() {
          const inp = document.getElementById('e2eePassInput');
          const visBtn = document.getElementById('e2eeToggleVisBtn');
          const saveBtn = document.getElementById('e2eeSaveBtn');
          const clearBtn = document.getElementById('e2eeClearBtn');
          const badge = document.getElementById('e2eeStatusBadge');
          const hint = document.getElementById('e2eeRoomHint');
          const titleEl = document.getElementById('e2eeTitleLabel');
          const descEl = document.getElementById('e2eeDescLabel');
          const refreshE2eeUi = () => {
            const isZh = state.lang === 'zh';
            const active = window.__isE2eeActive && window.__isE2eeActive();
            if (titleEl) titleEl.textContent = isZh ? '🔐 两人端到端加密 (AES-256 E2EE)' : '🔐 둘만의 종단간 암호화 (AES-256 E2EE)';
            if (descEl) descEl.textContent = isZh
              ? '在双方手机输入相同的专属密钥后，所有照片、聊天、语音和日记都会在设备端通过 AES-256 加密，并自动隔离到专属私密通道传输。'
              : '두 사람 폰에 똑같은 비밀 암호키를 입력하면 모든 사진·대화·음성·일기가 AES-256으로 암호화되어 전용 비밀 채널로만 전송돼요.';
            if (badge) {
              badge.textContent = active ? (isZh ? '🟢 AES-256 加密保护中' : '🟢 AES-256 암호화 보호 중') : (isZh ? '未开启' : '미설정');
              badge.style.background = active ? 'rgba(16,185,129,0.16)' : 'var(--surface-2)';
              badge.style.color = active ? '#059669' : 'var(--text-muted)';
            }
            if (saveBtn) saveBtn.textContent = active ? (isZh ? '更改密钥' : '키 변경') : (isZh ? '开启加密' : '암호화 켜기');
            if (clearBtn) {
              clearBtn.textContent = isZh ? '关闭' : '해제';
              clearBtn.classList.toggle('hidden', !active);
            }
            if (visBtn) visBtn.title = isZh ? '显示/隐藏' : '보기/숨기기';
            if (inp) inp.placeholder = active ? (isZh ? '已加密 · 输入新密钥可更改' : '암호화 적용 중 · 새 키 입력 시 변경') : (isZh ? '输入两人专属密钥 (6位以上)' : '둘만의 비밀 암호키 입력 (6자 이상)');
            if (hint) {
              if (active && cwE2eePrivateRoom) {
                hint.classList.remove('hidden');
                hint.textContent = isZh
                  ? `🛡️ 专属加密通道已隔离 (${cwE2eePrivateRoom.slice(0, 12)}…) · 所有聊天/照片/语音均在设备端加密后传输`
                  : `🛡️ 전용 비밀 채널 격리 중 (${cwE2eePrivateRoom.slice(0, 12)}…) · 모든 대화·사진·음성이 기기에서 암호화되어 전송돼요`;
              } else {
                hint.classList.add('hidden');
              }
            }
            const cardRoot = titleEl && titleEl.closest('.royal-subcard');
            if (cardRoot && typeof window.syncAllTabIconsToStyle === 'function') window.syncAllTabIconsToStyle(null, cardRoot);
          };
          window.__refreshE2eeUi = refreshE2eeUi;
          if (visBtn && inp) {
            visBtn.addEventListener('click', () => {
              inp.type = inp.type === 'password' ? 'text' : 'password';
            });
          }
          if (saveBtn && inp) {
            saveBtn.addEventListener('click', async () => {
              const val = (inp.value || '').trim();
              const isZh = state.lang === 'zh';
              if (val.length < 6) {
                showToast(isZh ? '🔐 请输入至少 6 位以上的专属密钥' : '🔐 보안을 위해 6자 이상의 비밀 암호키를 입력해 주세요');
                return;
              }
              const ok = await initE2eeFromPassphrase(val);
              if (!ok) {
                showToast(isZh ? '当前浏览器不支持 WebCrypto 加密' : '현재 브라우저에서 암호화 기능을 지원하지 않아요');
                return;
              }
              inp.value = '';
              inp.type = 'password';
              try { saveLastEventId(0); processedEventIds.clear(); } catch (_) {}
              try { if (sbChannel && sbClient) { sbClient.removeChannel(sbChannel); sbChannel = null; } } catch (_) {}
              try { if (emqxWs) { emqxWs.close(); emqxWs = null; emqxSubscribedRoom = ''; } } catch (_) {}
              refreshE2eeUi();
              connectLiveSyncStream();
              setTimeout(() => { pullCloudSync(false); }, 250);
              showToast(isZh ? '🔐 AES-256 端到端加密已开启！对方手机也输入相同密钥即可同步' : '🔐 AES-256 종단간 암호화가 켜졌어요! 상대방 폰에도 같은 키를 입력해 주세요');
            });
          }
          if (clearBtn) {
            clearBtn.addEventListener('click', () => {
              cwE2eeCryptoKey = null;
              cwE2eePrivateRoom = '';
              try {
                localStorage.removeItem(E2EE_PASS_STORAGE_KEY);
                localStorage.removeItem(E2EE_ROOM_STORAGE_KEY);
                saveLastEventId(0);
                processedEventIds.clear();
              } catch (_) {}
              try { if (sbChannel && sbClient) { sbClient.removeChannel(sbChannel); sbChannel = null; } } catch (_) {}
              try { if (emqxWs) { emqxWs.close(); emqxWs = null; emqxSubscribedRoom = ''; } } catch (_) {}
              refreshE2eeUi();
              connectLiveSyncStream();
              showToast(state.lang === 'zh' ? '已关闭端到端加密，恢复默认通道' : '종단간 암호화가 해제되어 기본 채널로 돌아갔어요');
            });
          }
          ensureE2eeReady().then(() => refreshE2eeUi());
          // Auto re-lock PIN if app stays in background > 30 seconds
          let cwBgHiddenAt = 0;
          document.addEventListener('visibilitychange', () => {
            if (document.hidden) {
              cwBgHiddenAt = Date.now();
            } else if (cwBgHiddenAt && (Date.now() - cwBgHiddenAt) > 30000) {
              cwBgHiddenAt = 0;
              try {
                const savedPin = localStorage.getItem('chanwan_pin_lock_v1') || (state.settings && state.settings.pinCode);
                const ov = document.getElementById('pinLockOverlay');
                if (savedPin && ov && ov.classList.contains('hidden')) {
                  ov.classList.remove('hidden');
                }
              } catch (_) {}
            }
          });
        })();

        // ---- Global Native-App Long-Press Guard (Blocks Browser Copy / Touch-to-Search Outside Inputs) ----
        document.addEventListener('contextmenu', (ev) => {
          const t = ev.target;
          if (!t || t.tagName === 'TEXTAREA' || t.tagName === 'INPUT' || t.isContentEditable) return;
          ev.preventDefault();
        });
        document.addEventListener('selectstart', (ev) => {
          const t = ev.target;
          if (!t || t.tagName === 'TEXTAREA' || t.tagName === 'INPUT' || t.isContentEditable) return;
          ev.preventDefault();
        });

        // ---- Universal App-Wide Emoji & Emoticon Quick-Insert Controller ----
        (function setupUniversalEmojiPicker() {
          const wrap = document.getElementById('cwUniversalEmojiWrap');
          const fab = document.getElementById('cwUniversalEmojiFab');
          const tray = document.getElementById('cwUniversalEmojiTray');
          const grid = document.getElementById('cwUniversalEmojiGrid');
          const closeBtn = document.getElementById('cwUniversalEmojiClose');
          if (!wrap || !fab || !tray || !grid) return;

          const EMOJIS = [
            '😀','😃','😄','😁','😆','🥹','😅','😂','🤣','😊','😇','🙂','🙃','😉','😌','😍','🥰','😘','😗','😙','😚','😋','😛','😝','😜','🤪','🤨','🧐','🤓','😎',
            '🤩','🥳','😏','😒','😞','😔','😟','😕','🙁','☹️','😣','😖','😫','😩','🥺','😢','😭','😤','😠','😡','🤬','🤯','😳','🥵','🥶','😱','😨','😰','😥','😓',
            '🤗','🤔','🫣','🤭','🫢','🫡','🤫','🫠','🤥','😶','😐','😑','😬','🙄','😯','😦','😧','😮','😲','🥱','😴','🤤','😪','😵','🤐','🥴','🤢','🤮','🤧','😷',
            '💜','🩷','❤️','🧡','💛','💚','🩵','💙','🖤','🤍','🤎','💔','❤️‍🔥','💕','💞','💓','💗','💖','💘','💝','💋','💌','🫶','👍','👎','👏','🙌','🤝','🙏','✌️',
            '🤞','🤟','🤘','👌','🤏','👋','🤚','🖐️','✋','💪','🫂','👀','🔥','✨','⭐','🌟','💫','🎉','🎊','🎁','🎈','🌸','🌷','🌹','🌺','🌻','☀️','🌙','🌈','☁️',
            '🐶','🐱','🐰','🐻','🐼','🐨','🦊','🐷','🐸','🐥','🦋','☕','🧋','🍵','🍺','🍷','🍜','🍲','🍕','🍔','🍟','🍗','🍣','🍰','🎂','🍓','🍑','🍒','📸','🎶'
          ];
          const KAOMOJIS = ['(˘³˘)♥','(つ✧ω✧)つ','(◍•ᴗ•◍)❤','(˶˃ ᵕ ˂˶)','(｡•́︿•̀｡)','(ง •̀_•́)ง','ʕ•ᴥ•ʔ','( ･ᴗ･ )','♡(˃͈ દ ˂͈ ༶ )','(⁎˃ᴗ˂⁎)','(๑•̀ㅂ•́)و✧','(っ˘̩╭╮˘̩)っ'];
          let activeTarget = null;
          let activeUTab = 'emoji';
          let hideTimer = null;

          function isEligibleField(el) {
            if (!el || (el.tagName !== 'INPUT' && el.tagName !== 'TEXTAREA')) return false;
            if (el.id === 'chatInput' || el.id === 'e2eePassInput' || el.id === 'pinInput') return false;
            if (el.tagName === 'INPUT') {
              const tp = (el.type || 'text').toLowerCase();
              if (!['text', 'search', ''].includes(tp)) return false;
            }
            if (el.readOnly || el.disabled) return false;
            return true;
          }

          function renderGrid() {
            const isZhU = state && state.lang === 'zh';
            let recentU = [];
            try { recentU = JSON.parse(localStorage.getItem('chanwan_recent_wechat_v2') || '[]'); } catch (_) {}
            if (!Array.isArray(recentU) || !recentU.length) recentU = ['💜', '🥰', '😂', '🥹', '👍', '✨', '🌸', '🔥'];
            if (activeUTab === 'kaomoji') {
              grid.className = 'grid grid-cols-3 gap-1.5 max-h-48 overflow-y-auto p-0.5';
              grid.innerHTML = KAOMOJIS.map(tok =>
                `<button type="button" class="cw-u-em-pick btn-ghost rounded-xl px-1.5 py-1.5 text-[11px] font-medium flex items-center justify-center transition active:scale-90" data-tok="${escapeHtml(tok)}">${escapeHtml(tok)}</button>`
              ).join('');
            } else {
              grid.className = 'max-h-52 overflow-y-auto space-y-2.5 px-0.5 pb-1';
              grid.innerHTML = `
                <div>
                  <div class="flex items-center justify-between px-1 mb-1">
                    <span class="text-[10.5px] font-semibold text-mut">${isZhU ? '微信经典表情' : '위챗 이모티콘'}</span>
                    <button type="button" id="cwUEmojiBackBtn" class="btn-ghost px-2 py-0.5 rounded-lg text-[11px] font-bold" title="지우기">⌫</button>
                  </div>
                  <div class="grid grid-cols-7 gap-1 text-center">
                    ${(window.__WECHAT_OFFICIAL_EMOTICONS || []).map(em => `<button type="button" class="cw-u-em-pick flex flex-col items-center justify-center gap-0.5 py-1 rounded-xl active:scale-90" data-tok="${escapeHtml(em.tag)}">${window.getWechatEmoticonSvg ? window.getWechatEmoticonSvg(em.tag, 28) : em.tag}<span class="text-[9px] text-mut truncate max-w-[40px]">${escapeHtml(isZhU ? em.zh : em.ko)}</span></button>`).join('')}
                  </div>
                </div>
              `;
              const bk = grid.querySelector('#cwUEmojiBackBtn');
              if (bk) {
                bk.addEventListener('mousedown', (e) => e.preventDefault());
                bk.addEventListener('click', (e) => {
                  e.preventDefault();
                  if (!activeTarget || !activeTarget.isConnected) return;
                  const val = activeTarget.value || '';
                  const pos = (typeof activeTarget.__cwSavedPos === 'number' && activeTarget.__cwSavedPos >= 0 && activeTarget.__cwSavedPos <= val.length)
                    ? activeTarget.__cwSavedPos
                    : val.length;
                  if (pos <= 0) return;
                  const before = Array.from(val.slice(0, pos));
                  before.pop();
                  const nextStr = before.join('');
                  activeTarget.value = nextStr + val.slice(pos);
                  activeTarget.__cwSavedPos = nextStr.length;
                  activeTarget.dispatchEvent(new Event('input', { bubbles: true }));
                });
              }
            }
            grid.querySelectorAll('.cw-u-em-pick').forEach(btn => {
              btn.addEventListener('mousedown', (e) => e.preventDefault());
              btn.addEventListener('click', (e) => {
                e.preventDefault();
                const openEd = document.querySelector('[id^="editMsgBox_"]:not(.hidden) textarea');
                const tgt = (openEd && openEd.isConnected) ? openEd : activeTarget;
                if (!tgt || !tgt.isConnected) return;
                activeTarget = tgt;
                const tok = btn.getAttribute('data-tok') || '';
                const val = activeTarget.value || '';
                const curPos = (typeof activeTarget.__cwSavedPos === 'number' && activeTarget.__cwSavedPos >= 0 && activeTarget.__cwSavedPos <= val.length)
                  ? activeTarget.__cwSavedPos
                  : val.length;
                activeTarget.value = val.slice(0, curPos) + tok + val.slice(curPos);
                activeTarget.__cwSavedPos = curPos + tok.length;
                activeTarget.dispatchEvent(new Event('input', { bubbles: true }));
                if (activeUTab !== 'kaomoji' && tok) {
                  try {
                    let rec = JSON.parse(localStorage.getItem('chanwan_recent_wechat_v2') || '[]');
                    if (!Array.isArray(rec)) rec = [];
                    rec = [tok, ...rec.filter(x => x !== tok)].slice(0, 8);
                    localStorage.setItem('chanwan_recent_wechat_v2', JSON.stringify(rec));
                  } catch (_) {}
                }
              });
            });
          }

          document.addEventListener('pointerdown', (e) => {
            if (wrap.classList.contains('hidden')) return;
            const t = e.target;
            if (t && t.closest && (t.closest('#cwUniversalEmojiWrap') || t === activeTarget)) return;
            if (!isEligibleField(t)) {
              tray.classList.add('hidden');
              wrap.classList.add('hidden');
              activeTarget = null;
              restoreMainPadding();
            }
          });
          function positionWrapAboveKeyboard() {
            try {
              const vv = window.visualViewport;
              if (vv && window.innerHeight - vv.height > 100) {
                const kbH = Math.max(0, Math.round(window.innerHeight - vv.height - vv.offsetTop));
                wrap.style.bottom = kbH + 'px';
              } else {
                wrap.style.bottom = 'calc(64px + env(safe-area-inset-bottom, 0px))';
              }
            } catch (_) {}
          }

          wrap.querySelectorAll('.cw-u-em-tab').forEach(tb => {
            tb.addEventListener('mousedown', (e) => e.preventDefault());
            tb.addEventListener('pointerdown', (e) => e.preventDefault());
            tb.addEventListener('click', () => {
              activeUTab = tb.getAttribute('data-utab') || 'emoji';
              wrap.querySelectorAll('.cw-u-em-tab').forEach(b => {
                b.className = `cw-u-em-tab w-10 h-8 rounded-xl flex items-center justify-center transition ${b === tb ? 'btn-royal' : 'btn-ghost'}`;
              });
              renderGrid();
            });
          });

          tray.addEventListener('mousedown', (e) => { if (e.target.tagName !== 'INPUT') e.preventDefault(); });
          let lastUFabTs = 0;
          const toggleUniversalTray = () => {
            if (hideTimer) { clearTimeout(hideTimer); hideTimer = null; }
            const willOpen = tray.classList.contains('hidden');
            tray.classList.toggle('hidden', !willOpen);
            if (willOpen) {
              if (activeTarget && activeTarget.isConnected) {
                activeTarget.__cwSavedPos = typeof activeTarget.selectionStart === 'number' ? activeTarget.selectionStart : (activeTarget.value || '').length;
                try { activeTarget.blur(); } catch (_) {}
              }
              renderGrid();
              wrap.style.bottom = 'calc(60px + env(safe-area-inset-bottom, 0px))';
            }
          };
          fab.addEventListener('pointerdown', (e) => {
            if (e.pointerType === 'mouse' && e.button !== 0) return;
            e.preventDefault();
            e.stopPropagation();
            lastUFabTs = Date.now();
            toggleUniversalTray();
          });
          fab.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            if (Date.now() - lastUFabTs < 450) return;
            toggleUniversalTray();
          });

          if (closeBtn) {
            closeBtn.addEventListener('mousedown', (e) => e.preventDefault());
            closeBtn.addEventListener('click', () => tray.classList.add('hidden'));
          }

          function bringFieldIntoView(field) {
            if (!field || !field.isConnected || field.id === 'chatInput') return;
            try {
              const mainEl = document.querySelector('main');
              if (mainEl && !document.body.classList.contains('cw-chat-lock')) {
                mainEl.style.setProperty('padding-bottom', '48vh', 'important');
              }
              const doCenter = () => {
                if (!field || !field.isConnected || document.activeElement !== field) return;
                try { field.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'nearest' }); } catch (_) {}
              };
              requestAnimationFrame(doCenter);
              setTimeout(doCenter, 160);
              setTimeout(doCenter, 360);
            } catch (_) {}
          }
          function restoreMainPadding() {
            try {
              const mainEl = document.querySelector('main');
              if (mainEl) mainEl.style.removeProperty('padding-bottom');
            } catch (_) {}
          }

          document.addEventListener('focusin', (e) => {
            const el = e.target;
            if (el && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') && el.id !== 'chatInput') {
              bringFieldIntoView(el);
            }
            if (isEligibleField(el)) {
              if (hideTimer) { clearTimeout(hideTimer); hideTimer = null; }
              activeTarget = el;
              wrap.classList.remove('hidden');
              positionWrapAboveKeyboard();
            } else if (!el || !el.closest || !el.closest('#cwUniversalEmojiWrap')) {
              tray.classList.add('hidden');
              wrap.classList.add('hidden');
              activeTarget = null;
            }
          });

          document.addEventListener('focusout', (e) => {
            if (e.target === activeTarget || (e.target && (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA'))) {
              hideTimer = setTimeout(() => {
                const nowAct = document.activeElement;
                if (!nowAct || (nowAct.tagName !== 'INPUT' && nowAct.tagName !== 'TEXTAREA')) {
                  restoreMainPadding();
                }
                const isDrawerOpen = !tray.classList.contains('hidden');
                if (!isDrawerOpen && !isEligibleField(nowAct) && (!nowAct || !nowAct.closest || !nowAct.closest('#cwUniversalEmojiWrap'))) {
                  tray.classList.add('hidden');
                  wrap.classList.add('hidden');
                  activeTarget = null;
                }
              }, 180);
            }
          });

          let __uVvRaf = 0;
          if (window.visualViewport) {
            window.visualViewport.addEventListener('resize', () => {
              if (wrap.classList.contains('hidden')) return;
              if (__uVvRaf) return;
              __uVvRaf = requestAnimationFrame(() => {
                __uVvRaf = 0;
                positionWrapAboveKeyboard();
              });
            }, { passive: true });
          }
          renderGrid();
        })();

        // ==================== Prime 4 v58: Bidirectional P2P + Cloud Vault Auto-Recovery & Backfill ====================
        let __lastVaultReqSentTs = 0;
        let __isStreamingVaultToPartner = false;

        function requestPartnerVaultSync(reason) {
          const now = Date.now();
          if ((now - __lastVaultReqSentTs) < 6000 && reason !== 'manual_restore') return;
          __lastVaultReqSentTs = now;
          const haveAlbums = (state.albums || []).filter(a => a && a.id && a.dataUrl).map(a => a.id).slice(0, 160);
          const haveVoices = (state.voiceLetters || []).filter(v => v && v.id && v.audioUrl).map(v => v.id).slice(0, 100);
          const haveChatMedia = (state.chat?.messages || []).filter(m => m && m.id && (m.photoUrl || m.videoUrl || m.audioUrl)).map(m => m.id).slice(-80);
          const haveAvatars = [];
          if (state.profile?.suwanAvatar) haveAvatars.push('suwan');
          if (state.profile?.jingchanAvatar) haveAvatars.push('jingchan');
          sendChatSignal('request_vault_sync', {
            reason: reason || 'auto',
            haveLearnXp: Number(state.learn?.xp || 0),
            haveLearnSolved: Number(state.learn?.solved || 0),
            haveAlbums,
            haveVoices,
            haveChatMedia,
            haveAvatars
          });
        }
        window.__requestPartnerVaultSync = requestPartnerVaultSync;

        async function respondToPartnerVaultRequest(sig) {
          if (__isStreamingVaultToPartner) return;
          const room = getSyncRoomCode();
          if (!room) return;
          const haveAlbSet = new Set(Array.isArray(sig?.haveAlbums) ? sig.haveAlbums : []);
          const haveVlSet = new Set(Array.isArray(sig?.haveVoices) ? sig.haveVoices : []);
          const haveCmSet = new Set(Array.isArray(sig?.haveChatMedia) ? sig.haveChatMedia : []);
          const haveAvSet = new Set(Array.isArray(sig?.haveAvatars) ? sig.haveAvatars : []);

          const hasPartnerStudyToShare = Number(state.learn?.xp || 0) > Number(sig?.haveLearnXp || 0) || Number(state.learn?.solved || 0) > Number(sig?.haveLearnSolved || 0);
          if (hasPartnerStudyToShare) {
            try {
              const fastEmqx = buildEmqxFastPacket(extractLightweightCore(state));
              if (fastEmqx) publishEmqxBackup(room, fastEmqx);
              await syncCloudLearnVault(room, true);
              await pushFullCloudSync();
            } catch (_) {}
          }
          const missingAlbums = (state.albums || []).filter(a => a && a.id && a.dataUrl && !haveAlbSet.has(a.id)).slice(0, 60);
          const missingVoices = (state.voiceLetters || []).filter(v => v && v.id && v.audioUrl && !haveVlSet.has(v.id)).slice(0, 40);
          const missingChatM = (state.chat?.messages || []).filter(m => m && m.id && (m.photoUrl || m.audioUrl || m.videoUrl) && !haveCmSet.has(m.id)).slice(-35);
          const missingAvs = ['suwan', 'jingchan'].filter(rk => state.profile?.[rk + 'Avatar'] && !haveAvSet.has(rk));
          const customVoiceEntries = Object.entries(state.customVoices || {}).filter(([, u]) => u && String(u).startsWith('data:'));

          if (!missingAlbums.length && !missingVoices.length && !missingChatM.length && !missingAvs.length && !customVoiceEntries.length) {
            return;
          }
          __isStreamingVaultToPartner = true;
          try {
            await pushFullCloudSync();
            for (const rk of missingAvs) {
              const avUrl = state.profile[rk + 'Avatar'];
              if (avUrl) {
                await sendEmqxMediaPaced(room, 'avatar', `av_${rk}_${Date.now()}`, { target: rk }, avUrl, Date.now());
                await saveVaultItemToCloudState(room, deriveDeterministicVaultKey('avatar', { target: rk }, rk), 'avatar', { target: rk }, avUrl);
              }
            }
            for (const alb of missingAlbums) {
              const mKind = String(alb.mediaType || '').includes('video') ? 'album_video' : 'album_photo';
              const meta = { albumId: alb.id, authorRole: alb.authorRole || state.myRole || 'jingchan', caption: alb.caption || '', translated: alb.translated || '', date: alb.date || '', category: alb.category || '' };
              await sendEmqxMediaPaced(room, mKind, `p2p_alb_${alb.id}`, meta, alb.dataUrl, Date.now());
              await saveVaultItemToCloudState(room, deriveDeterministicVaultKey(mKind, meta, alb.id), mKind, meta, alb.dataUrl);
              await new Promise(r => setTimeout(r, 140));
            }
            for (const vl of missingVoices) {
              const normAud = normalizeAudioDataUrl(vl.audioUrl);
              if (!normAud || !normAud.startsWith('data:audio/')) continue;
              const meta = { id: vl.id, sender: vl.sender || state.myRole || 'jingchan', tag: vl.tag || '🎙️', note: vl.note || '', translated: vl.translated || '', date: vl.date || '', time: vl.time || '' };
              await sendEmqxMediaPaced(room, 'voice_letter', `p2p_vl_${vl.id}`, meta, normAud, Date.now());
              await saveVaultItemToCloudState(room, deriveDeterministicVaultKey('voice_letter', meta, vl.id), 'voice_letter', meta, normAud);
              await new Promise(r => setTimeout(r, 140));
            }
            for (const [phr, cvUrl] of customVoiceEntries) {
              const normCv = normalizeAudioDataUrl(cvUrl);
              if (!normCv || !normCv.startsWith('data:audio/')) continue;
              const meta = { phrase: phr };
              await sendEmqxMediaPaced(room, 'custom_voice', `p2p_cv_${Date.now()}`, meta, normCv, Date.now());
              await saveVaultItemToCloudState(room, deriveDeterministicVaultKey('custom_voice', meta, phr), 'custom_voice', meta, normCv);
            }
            for (const cm of missingChatM) {
              if (cm.photoUrl && String(cm.photoUrl).startsWith('data:image/')) {
                const meta = { msgId: cm.id, sender: cm.sender, time: cm.time, original: cm.original, translated: cm.translated, tgtLang: cm.tgtLang, category: cm.photoCat || '✨ 일상 순간' };
                await sendEmqxMediaPaced(room, 'chat_photo', `p2p_cm_${cm.id}`, meta, cm.photoUrl, cm.ts || Date.now());
                await saveVaultItemToCloudState(room, deriveDeterministicVaultKey('chat_photo', meta, cm.id), 'chat_photo', meta, cm.photoUrl);
              } else if (cm.audioUrl) {
                const normChatAud = normalizeAudioDataUrl(cm.audioUrl);
                if (normChatAud && normChatAud.startsWith('data:audio/')) {
                  const meta = { msgId: cm.id, sender: cm.sender, time: cm.time, original: cm.original, translated: cm.translated, tgtLang: cm.tgtLang };
                  await sendEmqxMediaPaced(room, 'chat_voice', `p2p_cvmsg_${cm.id}`, meta, normChatAud, cm.ts || Date.now());