(function () {
      'use strict';

      const CW_MEDIA_SVG = {
        play: '<svg viewBox="0 0 24 24" width="15" height="15" fill="none"><path d="M8.4 6.2c0-.95 1.05-1.52 1.86-1.01l8.8 5.55c.75.47.75 1.55 0 2.02l-8.8 5.55c-.81.51-1.86-.06-1.86-1.01V6.2z" fill="currentColor"/></svg>',
        stop: '<svg viewBox="0 0 24 24" width="15" height="15" fill="none"><rect x="6.5" y="6.5" width="11" height="11" rx="3.2" fill="currentColor"/></svg>',
        stopBadge: '<svg viewBox="0 0 24 24" width="19" height="19" fill="none"><circle cx="12" cy="12" r="10" fill="#ffffff" fill-opacity="0.24" stroke="#ffffff" stroke-opacity="0.52" stroke-width="1.2"/><rect x="8.2" y="8.2" width="7.6" height="7.6" rx="2.3" fill="#ffffff"/></svg>',
        stopSttBtn: '<svg viewBox="0 0 24 24" width="17" height="17" fill="none"><line class="cw-wave-bar" x1="3.5" y1="8.5" x2="3.5" y2="15.5" stroke="#ffffff" stroke-width="2" stroke-linecap="round"/><rect x="7.8" y="7.8" width="8.4" height="8.4" rx="2.5" fill="#ffffff"/><line class="cw-wave-bar b2" x1="20.5" y1="8.5" x2="20.5" y2="15.5" stroke="#ffffff" stroke-width="2" stroke-linecap="round"/></svg>',
        recDot: '<svg viewBox="0 0 24 24" width="15" height="15" fill="none"><circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="1.8" opacity="0.45"/><circle cx="12" cy="12" r="4.8" fill="#fb7185"/></svg>',
        stopSoft: '<svg viewBox="0 0 24 24" width="15" height="15" fill="none"><circle cx="12" cy="12" r="9.2" fill="currentColor" fill-opacity="0.16" stroke="currentColor" stroke-width="1.6"/><rect x="8.5" y="8.5" width="7" height="7" rx="2" fill="currentColor"/></svg>',
        closeDrawer: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none"><circle cx="12" cy="12" r="9.2" fill="currentColor" fill-opacity="0.11" stroke="currentColor" stroke-width="1.75"/><path d="M9.3 9.3l5.4 5.4M14.7 9.3l-5.4 5.4" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"/></svg>',
        waveMini: '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round"><path d="M5 10v4M9.5 7v10M14.5 5.5v13M19 9.5v5"/></svg>'
      };
      window.__cwMediaSvg = CW_MEDIA_SVG;

      /* ============================================================
         1. I18N, FONTS, MOODS, CITIES & COUPLE ROULETTE
         ============================================================ */
      const I18N = {
        ko: {
          headerSub: '수완 ♥ 靖灿',
          sysNotifTitle: '🔔 화면 밖 배너 알림',
          allowBtn: '허용하기',
          filterAll: '전체',
          filterPost: '새글·메시지',
          filterUnread: '안읽음',
          learnSubTag: '징찬의 매일 한국어',
          coupleSubTag: '우리의 소중한 기록',
          transSubTag: '한·중 자연스러운 AI 번역',
          lvl1: '1단계 입문',
          lvl2: '2단계 초급',
          lvl3: '3단계 중급',
          lvl4: '4단계 고급',
          lvl5: '5단계 마스터',
          subGames: '🎮 미니게임',
          miniGamesTitle: '🎮 한·중 커플 미니게임',
          miniGamesDesc: '징찬이와 수완이 모두 즐기며 서로의 언어를 익혀요! 클리어하면 XP가 쌓여요.',
          gameDirLabel: '플레이 모드',
          gameDirKo: '💜 징찬 (한국어 맞추기)',
          gameDirZh: '❤️ 수완 (중국어 맞추기)',
          gameTabMem: '💘 짝맞추기',
          gameTabPuz: '🧩 문장 조립',
          gameTabSpd: '⚡ 30초 스피드',
          homeRoleLabel: '현재 접속 프로필',
          gameTabListen: '🎧 듣고 맞추기',
          gameTabChoseong: '🔤 초성 퀴즈',
          choseongGuide: '초성과 중국어 뜻을 보고 알맞은 한국어를 맞춰보세요',
          choseongHintBtn: '💡 첫 글자 힌트',
          choseongAudioBtn: '🔊 발음 듣기',
          phChoseong: '직접 한국어로 입력해서 맞출 수도 있어요...',
          choseongNext: '다음 초성 문제 →',
          listenNext: '다음 듣기 문제 →',
          memMovesLabel: '시도',
          memMatchedLabel: '맞춘 짝',
          memRestart: '새 판 ↻',
          puzHint: '💡 힌트',
          puzReset: '다시 놓기',
          puzNext: '다음 문장 →',
          secUnit: '초',
          scoreLabel: '점수',
          spdTitle: '30초 하트 스피드 챌린지',
          spdDesc: '화면에 뜨는 표현의 뜻을 빠르게 골라 콤보를 쌓아보세요!',
          spdStart: '게임 시작하기 ▶',
          spdRetry: '🔁 다시 도전하기',
          phHomeTrans: '번역할 문장 입력...',
          phChat: '',
          phMemo: '공유 메모, 할 일, 장보기, 데이트 약속 입력...',
          phBucket: '함께 하고 싶은 위시리스트 입력...',
          phCheat: '261개 실전 표현 검색 (한국어 / 中文 / 상황)...',
          notifTitle: '새 소식 알림',
          markRead: '모두 읽음',
          clearAll: '비우기',
          sendPing: '💌 보고 싶다고 알림 보내기',
          togetherDays: '함께한 날',
          heartbeatTitle: '지금 보고 싶어',
          sendHeartBtn: '마음 보내기',
          rouletteTitle: '오늘 뭐 할까? 미션 뽑기',
          rouletteBtn: '🎲 뽑기',
          customMoodBtn: '✏️ 직접',
          storageSaved: '🛡️ 안전 저장됨',
          clearNotesBtn: '노트 비우기',
          wrongNotesTitle: '📌 틀린 문제 자동 복습 노트',
          addCalBtn: '+ 일정 추가',
          addFolderBtn: '+ 폴더 추가',
          calLegendShort: '💜 일정 · 🎂 기념일',
          calTodayBtn: '오늘',
          chatVaultBtn: '모아보기',
          chatVaultTitle: '🖼️ 사진·동영상·링크 모아보기',
          iconStyleDesc: '앱 전체 버튼·탭·이모티콘 스타일을 한 번에 바꿔요.',
          iconStyleTitle: '🎨 아이콘·이모티콘 스타일',
          istyleEmoji: '😊 감성 이모지',
          istyleGold: '👑 로얄 골드',
          istyleLine: '✨ 미니멀 라인',
          istylePastel: '🎨 파스텔 그림체',
          missionTapHint: '눌러서 오늘 미션 뽑기',
          phCalSchedule: '우리의 데이트·약속 일정을 적어주세요...',
          phChatSearch: '대화 내용 검색...',
          phNewFolder: '새 앨범 폴더 이름...',
          pinLockDesc: '앱을 열거나 백그라운드에서 돌아올 때 4자리 비밀번호로 보호해요.',
          pinLockTitle: '🔐 앱 잠금 (4자리 PIN)',
          pinOffBtn: '잠금 끄기',
          pinSetBtn: 'PIN 설정',
          recModeDiary: '✏️ 일기',
          recModeMemo: '📝 메모',
          soundPickerTitle: '🔔 알림음 선택',
          soundPreviewBtn: '🔊 미리듣기',
          subCalendar: '📅 달력',
          themeBlue: '🩵 파스텔 블루',
          themeBlueDesc: '산뜻한 하늘빛 & 화이트 실크',
          themeLav: '🔮 파스텔 보라',
          themeLavDesc: '포근한 라벤더 & 소프트 펄',
          themeNavy: '🌌 미드나잇 네이비',
          themeNavyDesc: '깊은 밤바다 남색 & 달빛 블루',
          themeRoseNoir: '🥀 로즈 누아르',
          themeRoseNoirDesc: '깊은 버건디 와인 & 로즈 골드',
          themeBlack: '🖤 미드나잇 블랙 (OLED 리얼 블랙)',
          themeBlackDesc: '순수 블랙 배경 & 샴페인 실버',
          themeLightDrawerTitle: '☀️ 라이트 모드 (5종)',
          themeDarkDrawerTitle: '🌙 다크 모드 (4종)',
          autoNightDarkTitle: '🌙 밤 9시 이후 자동 랜덤 다크모드',
          autoNightDarkDesc: '각자 현지 시간 밤 9시가 되면 다크 테마 4종 중 랜덤으로 자동 전환돼요.',
          selfHealTitle: '앱 자가 복구 & 자동 오류 메모',
          selfHealDesc: '동기화·중복·배지 꼬임은 버튼 한 번으로 바로 고치고, 코드 수정이 필요한 오류는 자동으로 메모해 둬요.',
          selfHealRunBtn: '🛠️ 지금 자가 복구', makerModeTitle: '메이커 모드 (실시간 배치·간격 편집)', makerAutoSyncBadge: '🟢 자동 동기화', makerModeDesc: '재배포 없이 카드 간격·여백·글자 크기·중앙정렬·상단 상태바·홈 카드 순서를 직접 조절하면 상대방 폰에도 실시간 자동 반영돼요.', makerOpenBtn: '🎨 실시간 편집 창 열기', makerCopyBtn: '📋 복사', makerPasteBtn: '📥 붙여넣기', makerResetBtn: '🔄 기본값',
          copyErrMemoBtn: '📋 오류 메모 복사',
          clearErrMemoBtn: '🗑️ 비우기',
          transSettingsTitle: '한·중 AI 번역 설정',
          transSettingsDesc: '기본 무료 3중 병렬 번역이 자동 작동하며, 무료 Gemini API 키를 넣으면 연인체·줄임말까지 더 자연스럽게 번역돼요.',
          geminiKeyStepTitle: '🔑 Gemini 무료 키 연결 (선택)',
          geminiGetKeyLink: '🔗 무료 키 받기',
          phGeminiKey: 'AIzaSy... 키 붙여넣기',
          geminiKeySaveBtn: '💾 키 저장',
          geminiKeyTestBtn: '🧪 번역 테스트',
          geminiKeyClearBtn: '해제',
          toneBubble: '🫧 버블 팝',
          toneChime: '🎐 맑은 차임벨',
          toneHeart: '💗 두근두근 하트',
          toneMusicbox: '🎵 오르골 멜로디',
          toneSparkle: '✨ 반짝임 벨',
          uploadSoundBtn: '📂 내 알림음 올리기',
          vaultTabLinks: '🔗 링크',
          vaultTabMedia: '🖼️ 사진·영상',

          toneLover: '💜 다정한 연인체',
          toneCasual: '☀️ 자연스러운 일상',
          tonePolite: '🎩 정중한 존댓말',
          micKoBtn: '🎤 한국어 말하기',
          micZhBtn: '🎤 중국어 말하기',
          clearBtn: '지우기',
          clearHistBtn: '기록 비우기',
          lockCapsuleBtn: '🔒 타임캡슐 잠그기',
          fontSans: '깔끔 고딕',
          fontSerif: '우아한 명조·송체',
          fontCute: '동글 귀여운체',
          fontHand: '감성 손글씨체',
          fontModern: '모던 미니멀체',
          fontSansSample: '灿完时光 · 프리텐다드',
          fontSerifSample: '灿完时光 · 고운바탕',
          fontCuteSample: '灿完时光 · 주아체',
          fontHandSample: '灿完时光 · 개구 손글씨',
          fontModernSample: '灿完时光 · IBM Plex 세련된 미니멀체',
          coupleCatRecord: '📖 기록',
          coupleCatMemory: '💌 추억',
          coupleCatPromise: '✨ 약속',
          toneWechat: '💬 위챗 딩동',
          toneGuzheng: '🎋 고쟁 청음',
          toneJade: '🌸 옥피리 풍경',
          subDrawQuiz: '🎨 그림퀴즈',
          subRps: '✊ 가위바위보',
          subTruthDare: '🃏 진실·도전',
          rpsRock: '바위',
          rpsScissors: '가위',
          rpsPaper: '보',
          themePastel: '☀️ 라이트 퍼플',
          themePastelDesc: '밝은 보라 & 샴페인 펄',
          themeVelvet: '🌙 다크 퍼플',
          themeVelvetDesc: '깊은 밤 보라 & 웜 골드',
          themePearl: '펄 실크',
          themePearlDesc: '아이보리 마블 & 샴페인 골드',
          themeViolet: '🪻 라일락 블룸',
          themeCoral: '🍑 코랄 핑크',
          themeCoralDesc: '따뜻한 코랄 핑크 & 로즈 골드',
          themeVioletDesc: '화사한 라일락 보라 & 로즈 미스트',
          themeAmethyst: '로얄 퍼플',
          themeAmethystDesc: '깊은 제국 보라 & 은빛 라일락',
          homeStudyCheckTag: '징찬 한국어 공부 체크',
          goLearnBtn: '📚 공부방 가기',
          homeDailyTag: '🌷 오늘의 한국어 표현',
          citySearchApply: '검색·적용',
          cityManualApply: '이름만 직접 적용',
          cancelBtn: '취소',
          saveBtn: '저장',
          okBtn: '확인',
          editBtn: '✏️ 설정',
          reunionTitle: '다음 만남 보딩패스',
          phReunionNote: '만나면 하고 싶은 일 (예: 상하이 야경 데이트)',
          subCoupon: '🎟️ 쿠폰',
          subBalance: '⚖️ 밸런스',
          subDatemap: '🗺️ 데이트',
          coupleCatPlay: '🎲 놀이',
          subTmi: '📝 취향사전',
          subJar: '✨ 칭찬병',
          subFood: '🍜 뭐먹지',
          subFortune: '🔮 운세',
          subSleep: '🌧️ 수면음',
          subQuiz: '💌 미니퀴즈',
          toneCute: '🥰 애교·귀염',
          tonePlayful: '😄 장난·유쾌',
          toneWarm: '🌷 토닥·위로',
          chatToneCute: '🥰 애교',
          chatTonePlayful: '😄 장난',
          chatToneWarm: '🌷 위로',
          subAnniv: '💝 기념일',
          subVoice: '🎙️ 음성편지',
          phDiaryTitle: '일기 제목',
          phDiaryContent: '오늘 있었던 일이나 전하고 싶은 이야기를 적어주세요.',
          phQaAnswer: '답변을 남겨주세요. 자동 번역 및 뉘앙스가 함께 기록됩니다.',
          capsuleFormTitle: '⏳ 타임캡슐 비밀 편지',
          phCapsuleTitle: '편지 제목 (예: 다음 만남 날 열어봐)',
          capsuleUnlockLabel: '열리는 날:',
          phCapsuleBody: '지정한 날짜가 되면 봉인이 풀리는 비밀 편지를 남겨보세요 (자동 번역 포함)...',
          phAlbumCaption: '사진 설명 (자동 한·중 번역)',
          albCatFood: '🍽️ 맛집·카페',
          albCatTravel: '✈️ 여행·풍경',
          albCatSelfie: '💑 우리·셀카',
          albCatPet: '🐾 귀여운·동물',
          albCatGift: '🎁 선물·기념',
          albCatDaily: '✨ 일상 순간',
          vlTagMorning: '☀️ 굿모닝',
          vlTagNight: '🌙 굿나잇',
          vlTagMiss: '💜 보고 싶어',
          vlTagCheer: '💌 응원 한마디',
          vlFileLabelText: '🎙️ 기기 녹음·파일',
          voiceMailTitle: '🎙️ 굿모닝·굿나잇 음성 우체통',
          voiceMailDesc: '하루 시작과 끝에 짧은 목소리 편지를 녹음해 보내면 상대방 휴대폰에 실시간으로 도착하고 저장돼요.',
          phVlNote: '함께 남길 짧은 한 줄 메모 (선택 · 자동 한중 번역)',
          vlReadyText: '버튼을 눌러 목소리 편지를 녹음해 보세요 (최대 60초)',
          vlRecStart: '녹음 시작',
          vlSendBtn: '💌 음성 편지 보내기',
          customPhraseTitle: '💜 수완의 맞춤 표현 직접 추가 (회화책·퀴즈 자동 반영)',
          phCustomKo: '알려주고 싶은 한국어 표현 (필수)',
          phCustomZh: '중국어 뜻 (비워두면 자동 번역)',
          phCustomNu: '언제 쓰는지 한 줄 설명 (선택)',
          addCustomPhraseBtn: '✨ 표현 추가',
          couponTitle: '🎟️ 우리만의 애정 쿠폰북',
          couponDesc: '서로에게 특별한 쿠폰을 선물하고, 원할 때 도장을 찍어 사용해 보세요! (자동 양방향 번역)',
          phCoupon: '선물할 쿠폰 내용을 적어보세요...',
          addCouponBtn: '쿠폰 발급',
          changeCityBtn: '📍 도시 바꾸기',
          homeTransTitle: '💬 바로 쓰는 한·중 번역기',
          homeTransDesc: '한국어나 중국어를 쓰기만 하면 바로 자연스럽게 번역해 드려요.',
          transBtn: '번역하기',
          recentFeedTitle: '최근 소식',
          patchNotes: '📜 업데이트 소식 보기',
          appVersionLabel: '앱 버전',
          learnTitle: '📚 징찬의 한국어 공부방',
          rankLabel: '내 등급',
          xpLabel: '모은 XP',
          streakLabel: '연속 정답',
          resetLearnBtn: '🔄 처음부터 다시',
          subToday: '🌷 오늘의 표현',
          subQuiz: '✏️ 단계별 퀴즈',
          subChatbook: '💬 우리 대화',
          subReview: '📌 오답 노트',
          subCheat: '📖 만능 회화책',
          nextQuiz: '다른 문제 ↻',
          annivTitle: '💝 우리의 기념일',
          startDateLabel: '처음 만난 날:',
          addAnnivTitle: '✨ 기념일 직접 추가하기',
          repeatYearly: '매년 반복',
          addBtn: '추가하기',
          timelineTitle: '📅 다가오는 기념일',
          subTransStudio: '✨ 번역기',
          subMsg: '💬 커플 메신저',
          transStudioTitle: '✨ 한·중 자연스러운 번역기',
          transStudioDesc: '원하는 말투를 골라 자연스러운 번역과 발음, 뉘앙스 해설까지 한 번에 확인해 보세요.',
          transHistTitle: '🕘 최근 번역 기록',
          senderLabel: '보내는 사람:',
          msgTitle: '💬 한·중 자동번역 메신저',
          msgDesc: '메시지를 보내면 자동으로 번역되고 알림이 울려요. 보낸 메시지는 언제든 지울 수 있어요.',
          clearChat: '대화 비우기',
          chatPhotoReady: '📷 사진 첨부됨 · 앨범 자동 분류 저장',
          sendBtn: '보내기',
          coupleSpaceTitle: '💕 우리만의 커플공간',
          subDiary: '🪶 일기·메모', recModeDiary: '🪶 일기', recModeMemo: '📝 메모', subCalendar: '📅 캘린더', chatVaultBtn: '모아보기', chatVaultTitle: '📦 메신저 사진 · 링크 모아보기', vaultTabMedia: '🖼️ 사진·영상', vaultTabLinks: '🔗 링크', phChatSearch: '대화 검색...', calTodayBtn: '오늘', calLegendShort: '🟣일정 · 🩷기념일 · 🩵일기', phCalSchedule: '일정 추가 (자동 번역)...', addCalBtn: '일정 추가', pinLockTitle: '🔒 4자리 PIN 앱 잠금 (내 기기 전용)', pinLockDesc: '둘만의 대화와 기록을 안전하게 보호해요. 설정한 기기에서만 잠금 화면이 열려요.', pinSetBtn: 'PIN 설정', pinOffBtn: '잠금 해제', soundPickerTitle: '🎵 알림음 선택 (누르면 바로 미리듣기)', soundPreviewBtn: '▶️ 미리듣기', toneChime: '🔔 로맨틱 차임', toneBubble: '🫧 톡톡 물방울', toneMusicbox: '🎹 오르골', toneHeart: '💓 두근두근', toneSparkle: '✨ 스파클', uploadSoundBtn: '🎙️ 내 목소리', stTabWechat: '😊 위챗 이모지', stTabStickers: '🎀 커플 스티커', stTabGifs: '🎞️ 우리 움짤', missionTapHint: '눌러서 오늘 미션 뽑기', autoHealTitle: '🛠️ 자동 버그 픽스 & 동기화 복구', autoHealDesc: '실시간 공유가 끊기거나 화면이 멈추면 백그라운드에서 자동 복구하고, 버튼 한 번으로 즉시 점검·재연결할 수 있어요.', autoHealBtn: '🛠️ 원터치 복구', phNewFolder: '새 폴더 이름...', addFolderBtn: '📁 폴더 추가', iconStyleTitle: '앱 아이콘 그림체 모드', iconStyleDesc: '하단 탭과 메신저 아이콘을 파스텔 일러스트 그림체·미니멀 라인·클래식 이모지로 바로 바꿔보세요.', istylePastel: '파스텔 그림체', istyleLine: '미니멀 라인', istyleGold: '로얄 골드', istyleEmoji: '감성 이모지', themeBlue: '🩵 파스텔 블루', themeBlueDesc: '맑고 포근한 하늘빛 파스텔', themeLav: '🔮 파스텔 보라', themeLavDesc: '부드러운 라벤더 보라 파스텔', chatToneLover: '💜 연인체', chatToneCasual: '☀️ 일상', chatTonePolite: '🎩 존댓말',
          subQa: '💌 문답',
          subCapsule: '⏳ 타임캡슐',
          subMemo: '📝 메모',
          nextQa: '다른 질문 ↻',
          saveQaBtn: '답변 남기기',
          diaryFormTitle: '📔 오늘의 일기 쓰기',
          saveDiaryBtn: '일기 올리기',
          addMemoBtn: '메모 추가',
          subBucket: '🌟 위시',
          subAlbum: '🖼️ 앨범',
          bucketTitle: '🌟 함께 하고 싶은 버킷리스트',
          albumTitle: '🖼️ 우리 추억 사진 올리기',
          saveAlbumBtn: '사진 올리기',
          myRoleTitle: '내 프로필 모드 설정 (수완 / 징찬)',
          myRoleDesc: '내 모드를 고르면 글 작성·메신저가 내 이름으로 자동 설정되고, 상대방 알림만 울려요.',
          roleSuwanSub: '수완으로 작성 · 징찬 알림만 수신',
          roleJingchanSub: '징찬으로 작성 · 수완 알림만 수신',
          partnerOnlyNotifLabel: '🔔 내가 쓴 글은 빼고 상대방 알림만 받기',
          fontStudioTitle: '글꼴 & 글자 크기 설정',
          fsSm: '작게',
          fsMd: '보통',
          fsLg: '크게',
          fsXl: '아주 크게',
          fontPreviewTitle: '실시간 글자 크기 미리보기',
          fontPreviewSample: '너무 보고 싶어 💜',
          fontStudioDesc: '마음에 드는 서체와 글자 크기를 고르면 바로 적용돼요.',
          dockFontTitle: '📌 하단 탭 메뉴 글꼴 따로 설정',
          dockFontDesc: '아래쪽 탭 이름에 적용할 글꼴을 자유롭게 골라보세요.',
          themeStudioTitle: '화면 테마 바꾸기',
          geminiSetTitle: 'AI 번역 설정',
          geminiSetDesc: '별도 설정 없이 바로 고품질 한·중 번역이 작동해요. 본인 Gemini API 키를 넣으면 더 깊은 문맥 해설도 받을 수 있어요.',
          saveKeyBtn: '저장',
          clearKeyBtn: '해제',
          toggleNuanceLabel: '번역할 때 뜻과 뉘앙스 해설 함께 보기',
          appSuiteTitle: '알림 · 다운로드 · 중국 사용 설정',
          cloudSyncTitle: '☁️ 실시간 자동 연결 (서로 글·메신저 공유)',
          cloudSyncDesc: '별도 코드 입력 없이 수완 ↔ 靖灿이 자동으로 연결되어 메신저·일기·메모·기분·공부 기록이 실시간 공유돼요.',
          phCloudRoom: '둘만의 비밀 방 코드 (예: chanwan-2026)',
          connectSyncBtn: '다시 연결',
          syncNowBtn: '🔄 동기화',
          copyPacketBtn: '📋 위챗 공유코드 복사',
          pastePacketBtn: '📥 코드 합치기',
          settingsNotifTitle: '🔔 브라우저 알림 허용 설정',
          settingsNotifDesc: '새 메시지·하트·일기 알림을 브라우저 배너와 알림음으로 바로 받아보세요.',
          settingsNotifBtn: '🔔 알림 허용하기',
          settingsNotifTest: '테스트',
          settingsSoundLabel: '🔊 알림음 & 휴대폰 진동 켜기',
          mobilePushTitle: '📱 앱이 꺼져도 오는 휴대폰 상단·잠금화면 배너 (선택)',
          mobilePushDesc: 'iPhone·Android에 무료 「ntfy」 앱을 설치하고 아래 둘만의 비밀 채널명을 똑같이 구독하면, 앱을 닫아도 휴대폰 상단 배너와 알림음이 바로 울려요.',
          phMobilePush: '예: chanwan-love-2026 (영문·숫자)',
          appSuiteDesc: '휴대폰 알림, 앱 파일 다운로드, 중국 직통 사용을 한곳에서 관리해요.',
          dlHtmlTitle: '📥 앱 파일(.html) 원터치 다운로드',
          dlHtmlDesc: '이 파일을 내려받아 위챗·메일로 보내면 중국에서도 VPN 없이 바이두 브라우저로 바로 열 수 있어요.',
          dlHtmlBtn: '📥 HTML 다운로드',
          pwaInstallTitle: '📖 HTML 홈 화면 추가 & 매뉴얼',
          pwaInstallSub: '바로 추가가 지원되는 환경에서는 즉시 설치되고, 아니면 기기별 매뉴얼을 보여드려요.',
          pwaInstallBtn: '📲 홈 화면 추가 / 매뉴얼',
          chinaModeTitle: '🇨🇳 중국 직통 최적화 모드 (VPN 없이 사용)',
          chinaModeDesc: '중국 본토에서 차단된 구글 서버를 건너뛰고, 중국에서 바로 열리는 번역·로컬 엔진을 우선 사용해 대기 시간 없이 빨라져요.',
          autoFixTitle: '🛠️ 자동 점검 & 오류 복구',
          autoFixDesc: '앱 실행 중 오류나 데이터 꼬임을 자동 감지해 즉시 복구합니다.',
          runAutoFixBtn: '✨ 지금 진단·복구',
          backupTitle: '우리 기록 안전 보관 & 백업',
          exportBtn: '📤 기록 백업 저장',
          cloudFullRestoreTitle: '클라우드 데이터 전체 가져오기',
          cloudFullRestoreDesc: '수완·징찬 두 사람의 서버 기록·메신저 사진·동영상·커플앨범·음성편지를 누락 없이 끝까지 안전 복구해요 (기존 기록 유지).',
          cloudFullRestoreBtn: '☁️ 전체 가져오기',
          autoHealTitle: '스마트 자동 자가진단',
          autoHealOnLabel: '자동 켜짐',
          importBtn: '📥 백업 불러오기',
          navHome: 'Home',
          chatCamBtn: '사진 촬영',
          chatVideoCamBtn: '동영상 촬영',
          chatGalleryBtn: '사진·영상',
          chatVoiceBtn: '🎙️ 음성메시지',
          chatMicLabel: '🗣️ 음성인식',
          chatStickerBtn: '🎀 스티커',
          navLearn: 'Study',
          navAnniv: '기념일',
          navTrans: 'CW Talk',
          navDiary: 'Space',
          navBucket: '위시·앨범',
          navSettings: 'Setting',
          runTransBtn: '✨ 번역 & 뉘앙스 분석'
        },
        zh: {
          headerSub: '完 ♥ 灿',
          sysNotifTitle: '🔔 后台横幅提醒',
          allowBtn: '开启允许',
          filterAll: '全部',
          filterPost: '新动态·消息',
          filterUnread: '未读',
          learnSubTag: '靖灿的每日韩语',
          coupleSubTag: '我们的甜蜜记录',
          transSubTag: '韩中自然 AI 翻译',
          lvl1: '1级 入门',
          lvl2: '2级 初级',
          lvl3: '3级 中级',
          lvl4: '4级 高级',
          lvl5: '5级 大师',
          gameDirLabel: '游玩模式',
          gameDirKo: '💜 靖灿模式 (学韩语)',
          gameDirZh: '❤️ 完模式 (学中文)',
          gameTabMem: '💘 情侣配对',
          gameTabPuz: '🧩 拼句挑战',
          gameTabSpd: '⚡ 30秒速答',
          homeRoleLabel: '当前使用身份',
          gameTabListen: '🎧 听音辨词',
          gameTabChoseong: '🔤 韩语初声猜词',
          choseongGuide: '根据韩语初声辅音和中文意思，猜出正确韩语表达',
          choseongHintBtn: '💡 首字提示',
          choseongAudioBtn: '🔊 听发音提示',
          phChoseong: '也可以直接输入韩语答案哦...',
          choseongNext: '下一道初声题 →',
          listenNext: '下一道听力题 →',
          memMovesLabel: '尝试',
          memMatchedLabel: '已配对',
          memRestart: '新一局 ↻',
          puzHint: '💡 提示',
          puzReset: '重置',
          puzNext: '下一句 →',
          secUnit: '秒',
          scoreLabel: '得分',
          spdTitle: '30秒心动速答挑战',
          spdDesc: '快速选出屏幕上表达的正确意思，不断刷新连击纪录吧！',
          spdStart: '开始挑战 ▶',
          spdRetry: '🔁 再来一局',
          phHomeTrans: '输入要翻译的句子...',
          phChat: '',
          phMemo: '输入共享备忘、待办事项或约会计划...',
          phBucket: '输入想一起完成的心愿清单...',
          phCheat: '搜索261条实战表达 (韩语 / 中文 / 场景)...',
          notifTitle: '实时新动态通知',
          markRead: '全部已读',
          clearAll: '清空',
          sendPing: '💌 发送心动提醒',
          togetherDays: '在一起的日子',
          heartbeatTitle: '此刻好想你 · 心跳提醒',
          sendHeartBtn: '点一下',
          rouletteTitle: '今日情侣心动转盘',
          rouletteBtn: '🎲 抽一抽',
          customMoodBtn: '✏️ 自定义',
          storageSaved: '🛡️ 已安全保存',
          clearNotesBtn: '清空错题',
          wrongNotesTitle: '📌 错题自动复习本',
          addCalBtn: '+ 添加日程',
          addFolderBtn: '+ 新建相册',
          calLegendShort: '💜 日程 · 🎂 纪念日',
          calTodayBtn: '今天',
          chatVaultBtn: '查看全部',
          chatVaultTitle: '🖼️ 照片·视频·链接合集',
          iconStyleDesc: '一键切换全应用按钮、导航与表情图标风格。',
          iconStyleTitle: '🎨 图标与表情风格', makerModeTitle: '创客模式 (实时排版·间距编辑)', makerAutoSyncBadge: '🟢 自动同步', makerModeDesc: '无需重新部署，直接调节卡片间距、边距、字号、居中对齐、状态栏与首页卡片顺序，对方手机也会自动同步。', makerOpenBtn: '🎨 打开实时编辑窗', makerCopyBtn: '📋 复制', makerPasteBtn: '📥 粘贴', makerResetBtn: '🔄 恢复默认',
          istyleEmoji: '😊 经典表情',
          istyleGold: '👑 皇家鎏金',
          istyleLine: '✨ 极简线条',
          istylePastel: '🎨 粉彩插画',
          missionTapHint: '点击抽取今日甜蜜任务',
          phCalSchedule: '写下我们的约会或计划日程...',
          phChatSearch: '搜索聊天记录...',
          phNewFolder: '输入新相册文件夹名称...',
          pinLockDesc: '打开应用或从后台切回时，使用 4 位密码保护隐私。',
          pinLockTitle: '🔐 应用锁 (4位 PIN)',
          pinOffBtn: '关闭密码',
          pinSetBtn: '设置 PIN',
          recModeDiary: '✏️ 日记',
          recModeMemo: '📝 备忘',
          soundPickerTitle: '🔔 提示音选择',
          soundPreviewBtn: '🔊 试听',
          subCalendar: '📅 日历',
          themeBlue: '🩵 粉彩晴空蓝',
          themeBlueDesc: '清新晴空蓝与柔和白丝',
          themeLav: '🔮 粉彩薰衣草',
          themeLavDesc: '温柔薰衣草紫与珍珠光',
          themeNavy: '🌌 午夜深蓝',
          themeNavyDesc: '静谧夜海深蓝与月光天蓝',
          themeRoseNoir: '🥀 黑玫瑰酒红',
          themeRoseNoirDesc: '深邃丝绒酒红与玫瑰金',
          themeBlack: '🖤 午夜纯黑 (OLED 极夜黑)',
          themeBlackDesc: '纯粹深黑背景与香槟银点缀',
          themeLightDrawerTitle: '☀️ 浅色模式 (5款)',
          themeDarkDrawerTitle: '🌙 深色模式 (4款)',
          autoNightDarkTitle: '🌙 晚9点后自动随机深色模式',
          autoNightDarkDesc: '各自当地时间满21:00后，自动在4款深色主题中随机切换。',
          selfHealTitle: '应用自检修复 & 自动错误备忘',
          selfHealDesc: '同步卡顿、重复记录与角标异常可一键自动修复；需修改代码的异常会自动记入下方备忘录。',
          selfHealRunBtn: '🛠️ 立即一键修复',
          copyErrMemoBtn: '📋 复制错误备忘',
          clearErrMemoBtn: '🗑️ 清空',
          transSettingsTitle: '中韩 AI 翻译设置',
          transSettingsDesc: '默认自动启用免费三引擎并发翻译；填入免费 Gemini API 密钥后，恋人语气与网络用语会更自然。',
          geminiKeyStepTitle: '🔑 绑定免费 Gemini 密钥（可选）',
          geminiGetKeyLink: '🔗 免费获取密钥',
          phGeminiKey: '粘贴 AIzaSy... 密钥',
          geminiKeySaveBtn: '💾 保存密钥',
          geminiKeyTestBtn: '🧪 测试翻译',
          geminiKeyClearBtn: '清除',
          toneBubble: '🫧 气泡叮咚',
          toneChime: '🎐 清脆风铃',
          toneGuzheng: '🪕 古筝清音',
          toneHeart: '💗 心动节拍',
          toneJade: '💎 玉佩清响',
          toneMusicbox: '🎵 八音盒旋律',
          toneSparkle: '✨ 星光铃声',
          toneWechat: '💬 轻快提示',
          uploadSoundBtn: '📂 上传自定义铃声',
          vaultTabLinks: '🔗 链接',
          vaultTabMedia: '🖼️ 照片·视频',

          toneLover: '💜 甜蜜恋人',
          toneCasual: '☀️ 自然日常',
          tonePolite: '🙇 礼貌敬语',
          toneCute: '🥰 撒娇可爱',
          tonePlayful: '😄 俏皮逗趣',
          toneWarm: '🌷 暖心安慰',
          chatToneLover: '💜 甜蜜',
          chatToneCute: '🥰 撒娇',
          chatTonePlayful: '😄 俏皮',
          chatToneWarm: '🌷 暖心',
          chatToneCasual: '💬 日常',
          chatTonePolite: '🙇 敬语',
          subBalance: '⚖️ 默契测试',
          subDatemap: '🗺️ 约会印章',
          coupleCatPlay: '🎲 趣味',
          subTmi: '📝 喜好百科',
          subJar: '✨ 夸夸瓶',
          subFood: '🍜 吃什么',
          subFortune: '🔮 运势',
          subSleep: '🌧️ 助眠音',
          subQuiz: '💌 小测验',
          micKoBtn: '🎤 说韩语',
          micZhBtn: '🎤 说中文',
          clearBtn: '清空',
          clearHistBtn: '清空记录',
          lockCapsuleBtn: '🔒 封存胶囊信',
          fontSans: '现代黑体',
          fontSerif: '经典宋体',
          fontCute: '圆润可爱体',
          fontHand: '温柔手写体',
          fontModern: '现代简约体',
          fontSansSample: '灿完时光 · 现代黑体',
          fontSerifSample: '灿完时光 · 优雅宋体',
          fontCuteSample: '灿完时光 · 圆润可爱体',
          fontHandSample: '灿完时光 · 温柔手写体',
          fontModernSample: '灿完时光 · IBM Plex 极简现代体',
          coupleCatRecord: '📖 记录',
          coupleCatMemory: '💌 回忆',
          coupleCatPromise: '✨ 约定',
          subDrawQuiz: '🎨 你画我猜',
          subRps: '✊ 猜拳许愿',
          subTruthDare: '🃏 真心话大冒险',
          rpsRock: '石头',
          rpsScissors: '剪刀',
          rpsPaper: '布',
          fontKaiti: '优雅楷体',
          fontMono: '复古等宽体',
          themePastel: '☀️ 浅紫光韵',
          themePastelDesc: '明亮浅紫与香槟珍珠',
          themeVelvet: '🌙 深紫夜幕',
          themeVelvetDesc: '静谧深紫暗黑模式',
          themePearl: '珍珠丝绸',
          themePearlDesc: '象牙大理石与香槟金',
          themeViolet: '🪻 丁香花语',
          themeCoral: '🍑 珊瑚蜜桃粉',
          themeCoralDesc: '温柔珊瑚粉与玫瑰金',
          themeVioletDesc: '浪漫丁香紫与玫瑰柔雾',
          themeAmethyst: '皇家紫晶',
          themeAmethystDesc: '深邃皇室紫与星光丁香',
          homeStudyCheckTag: '靖灿韩语学习打卡',
          goLearnBtn: '📚 去学习室',
          homeDailyTag: '🌷 今日韩语表达',
          citySearchApply: '搜索并应用',
          cityManualApply: '仅应用城市名',
          cancelBtn: '取消',
          saveBtn: '保存',
          okBtn: '确定',
          editBtn: '✏️ 设置',
          reunionTitle: '下次见面登机牌',
          phReunionNote: '见面想一起做的事 (例：外滩夜景约会)',
          subCoupon: '🎟️ 甜蜜券',
          subAnniv: '💝 纪念日',
          subVoice: '🎙️ 语音信箱',
          phDiaryTitle: '日记标题',
          phDiaryContent: '写下今天发生的事，或想对对方说的话（自动中韩翻译）...',
          phQaAnswer: '写下你的回答，会自动翻译并保存语感解析...',
          capsuleFormTitle: '⏳ 时间胶囊秘密信',
          phCapsuleTitle: '信件标题（例：下次见面那天再打开）',
          capsuleUnlockLabel: '解锁日期：',
          phCapsuleBody: '写一封到指定日期才会自动解锁的秘密信（含自动双语翻译）...',
          phAlbumCaption: '照片说明（自动中韩翻译）',
          albCatFood: '🍽️ 美食·咖啡',
          albCatTravel: '✈️ 旅行·风景',
          albCatSelfie: '💑 我们·自拍',
          albCatPet: '🐾 可爱·宠物',
          albCatGift: '🎁 礼物·纪念',
          albCatDaily: '✨ 日常瞬间',
          vlTagMorning: '☀️ 早安',
          vlTagNight: '🌙 晚安',
          vlTagMiss: '💜 好想你',
          vlTagCheer: '💌 加油打气',
          vlFileLabelText: '🎙️ 手机录音·文件',
          voiceMailTitle: '🎙️ 早安·晚安语音信箱',
          voiceMailDesc: '录一段早安或晚安语音信发给对方，会实时同步并永久保存在双方手机里。',
          phVlNote: '附上一句简短留言（可选 · 自动中韩互译）',
          vlReadyText: '点击下方按钮录制语音信（最长60秒）',
          vlRecStart: '开始录音',
          vlSendBtn: '💌 发送语音信',
          customPhraseTitle: '💜 添加专属韩语表达（自动同步到秘籍与题库）',
          phCustomKo: '想教对方的韩语表达（必填）',
          phCustomZh: '中文意思（留空则自动翻译）',
          phCustomNu: '使用场景一句话说明（可选）',
          addCustomPhraseBtn: '✨ 添加表达',
          couponTitle: '🎟️ 我们的甜蜜兑换券',
          couponDesc: '送给对方一张专属心意券，想用时一键盖章兑换！(自动双向翻译)',
          phCoupon: '写下想送给TA的心意券内容...',
          addCouponBtn: '发放甜蜜券',
          changeCityBtn: '📍 城市设置',
          homeTransTitle: '💬 快捷韩中翻译',
          homeTransDesc: '输入韩语或中文即可实时自动翻译，附带准确度、拼音发音和语感说明。',
          transBtn: '超精准翻译',
          recentFeedTitle: '最新甜蜜动态',
          patchNotes: '📜 查看更新记录',
          appVersionLabel: '当前版本',
          learnTitle: '📚 靖灿的韩语学习室',
          rankLabel: '当前段位',
          xpLabel: '累计 XP',
          streakLabel: '连续答对',
          resetLearnBtn: '🔄 重置进度',
          subToday: '🌷 今日表达',
          subQuiz: '✏️ 分级测验',
          subGames: '🎮 趣味小游戏',
          miniGamesTitle: '🎮 靖灿的韩语趣味小游戏',
          miniGamesDesc: '边玩边轻松记住常用韩语，通关就能收获 XP 哦！',
          subChatbook: '💬 聊天课本',
          subReview: '📌 错题复习',
          subCheat: '📖 万能会话书',
          nextQuiz: '刷新新题 ↻',
          annivTitle: '💝 我们的纪念日',
          startDateLabel: '纪念起始日:',
          addAnnivTitle: '✨ 添加自定义纪念日 (生日 · 旅行 · 特别约定)',
          repeatYearly: '每年重复',
          addBtn: '添加',
          timelineTitle: '📅 纪念日时间轴',
          subTransStudio: '✨ 翻译器',
          subMsg: '💬 情侣聊天室',
          transStudioTitle: '✨ 韩中自然翻译器',
          transStudioDesc: '结合 Google 神经网络翻译与 Gemini 语感引擎，支持恋人/日常/敬语风格切换与深度解析。',
          transHistTitle: '🕘 最近翻译记录',
          senderLabel: '发送人:',
          msgTitle: '💬 情侣自动翻译聊天室',
          msgDesc: '发文字或照片都会自动翻译，气泡里只显示简洁译文和语气，照片还会自动存进相册。',
          clearChat: '清空聊天',
          chatPhotoReady: '📷 已选照片 · 将自动分类存入相册',
          sendBtn: '发送',
          chatCamBtn: '拍照',
          chatVideoCamBtn: '拍视频',
          chatGalleryBtn: '相册',
          chatMicLabel: '🗣️ 语音转字',
          chatVoiceBtn: '🎙️ 语音消息',
          chatStickerBtn: '🎀 贴纸',
          coupleSpaceTitle: '💕 我们的情侣空间',
          subDiary: '🪶 日记·备忘', recModeDiary: '🪶 日记', recModeMemo: '📝 备忘', subCalendar: '📅 日历', chatVaultBtn: '汇总', chatVaultTitle: '📦 聊天照片 · 链接汇总', vaultTabMedia: '🖼️ 照片·视频', vaultTabLinks: '🔗 链接', phChatSearch: '搜索聊天...', calTodayBtn: '今天', calLegendShort: '🟣日程 · 🩷纪念日 · 🩵日记', phCalSchedule: '添加日程（自动翻译）...', addCalBtn: '添加日程', pinLockTitle: '🔒 4位 PIN 应用锁（仅限本机）', pinLockDesc: '保护两人的私密聊天与回忆，仅在开启的设备上显示锁屏。', pinSetBtn: '设置 PIN', pinOffBtn: '关闭锁屏', soundPickerTitle: '🎵 提示音选择（点击即可试听）', soundPreviewBtn: '▶️ 试听', toneChime: '🔔 浪漫风铃', toneBubble: '🫧 清脆水滴', toneMusicbox: '🎹 八音盒', toneHeart: '💓 心动双响', toneSparkle: '✨ 星光闪耀', toneWechat: '💬 微信叮咚', toneGuzheng: '🎋 古筝清音', toneJade: '🌸 玉笛风铃', uploadSoundBtn: '🎙️ 我的声音', stTabWechat: '😊 微信表情', stTabStickers: '🎀 情侣贴纸', stTabGifs: '🎞️ 专属动图', missionTapHint: '点击抽取今日情侣任务', autoHealTitle: '🛠️ 自动修复与同步自检', autoHealDesc: '若实时共享断开或页面异常，后台会自动尝试修复；也可一键立即自检并重新同步。', autoHealBtn: '🛠️ 一键修复', phNewFolder: '新建文件夹名称...', addFolderBtn: '📁 新建文件夹', iconStyleTitle: '应用图标画风模式', iconStyleDesc: '一键切换底部导航与聊天栏图标：粉彩手绘插画、极简线条或经典表情。', istylePastel: '粉彩插画风', istyleLine: '极简线条风', istyleGold: '皇家鎏金风', istyleEmoji: '温柔表情风', themeBlue: '🩵 粉彩晴空蓝', themeBlueDesc: '清澈温柔的晴空粉彩蓝', themeLav: '🔮 粉彩薰衣草', themeLavDesc: '柔和梦幻的薰衣草粉彩紫', chatToneLover: '💜 恋人', chatToneCasual: '☀️ 日常', chatTonePolite: '🎩 敬语',
          subQa: '💌 问答',
          subCapsule: '⏳ 胶囊信',
          subMemo: '📝 备忘',
          nextQa: '换一题 ↻',
          saveQaBtn: '记录回答',
          diaryFormTitle: '📔 写下今天的日记',
          saveDiaryBtn: '保存并翻译日记',
          addMemoBtn: '添加备忘',
          subBucket: '🌟 心愿',
          subAlbum: '🖼️ 相册',
          bucketTitle: '🌟 想一起实现的心愿清单',
          albumTitle: '🖼️ 上传我们的回忆照片',
          saveAlbumBtn: '存入相册',
          myRoleTitle: '我的身份模式 (完 / 靖灿)',
          myRoleDesc: '选择自己的模式后，发消息和写日记会自动填入本人名字，并且只弹出对方的提醒。',
          roleSuwanSub: '以「完」身份发文 · 仅接收靖灿提醒',
          roleJingchanSub: '以「靖灿」身份发文 · 仅接收完的提醒',
          partnerOnlyNotifLabel: '🔔 屏蔽自己发出的动态，只接收对方提醒',
          fontStudioTitle: '多样字体与字号设置',
          fsSm: '小',
          fsMd: '中',
          fsLg: '大',
          fsXl: '超大',
          fontPreviewTitle: '实时字号效果预览',
          fontPreviewSample: '好想你呀 💜',
          fontStudioDesc: '选择喜欢的字体和大小，马上就能生效。',
          dockFontTitle: '📌 底部导航栏字体单独设置',
          dockFontDesc: '可以单独挑选底部菜单文字的字体风格。',
          themeStudioTitle: '粉紫皇家主题模式切换',
          geminiSetTitle: 'AI 翻译高级设置',
          geminiSetDesc: '默认启用 Google 神经网络 + 语感引擎；填写本人 Gemini API Key 后自动升级为实时 gemini-2.5-pro 深度解析。',
          saveKeyBtn: '保存密钥',
          clearKeyBtn: '清除',
          toggleNuanceLabel: '翻译结果自动显示核心含义、语感与情感语气',
          appSuiteTitle: '通知 · 下载 · 中国直连设置',
          cloudSyncTitle: '☁️ 情侣实时云同步（双方共享消息与日记）',
          cloudSyncDesc: '无需输入暗号，完 ↔ 灿已自动实时连接，聊天、日记、备忘录、心情与学习记录即时同步。',
          phCloudRoom: '输入两人专属暗号 (例：chanwan-2026)',
          connectSyncBtn: '重新连接',
          syncNowBtn: '🔄 立即同步',
          copyPacketBtn: '📋 复制微信同步码',
          pastePacketBtn: '📥 导入合并',
          settingsNotifTitle: '🔔 浏览器通知权限设置',
          settingsNotifDesc: '开启后，新消息、心动提醒与日记动态会通过浏览器横幅和提示音即时送达。',
          settingsNotifBtn: '🔔 允许通知',
          settingsNotifTest: '测试通知',
          settingsSoundLabel: '🔊 开启实时提示音与手机震动',
          mobilePushTitle: '📱 手机锁屏与顶部横幅推送（关闭网页也能收到）',
          mobilePushDesc: '在 iPhone 或安卓手机安装免费「ntfy」App 并订阅下方专属频道名，即使关闭页面也能收到原生手机横幅与提示音。',
          phMobilePush: '例：chanwan-love-2026 (英文/数字)',
          appSuiteDesc: '统一管理手机通知、应用文件下载与中国大陆直连优化。',
          dlHtmlTitle: '📥 一键下载独立版 App 文件 (.html)',
          dlHtmlDesc: '下载后通过微信或邮件发送，在中国大陆无需 VPN 用百度浏览器即可直接打开使用。',
          dlHtmlBtn: '📥 下载 HTML',
          pwaInstallTitle: '📖 HTML 添加到手机桌面 & 指南',
          pwaInstallSub: '支持的浏览器可直接一键添加，否则为您展示各机型桌面添加步骤。',
          pwaInstallBtn: '📲 添加桌面 / 指南',
          chinaModeTitle: '🇨🇳 中国大陆直连优化模式 (免 VPN)',
          chinaModeDesc: '自动跳过大陆受限节点，优先走国内可直连的翻译与本地引擎，打开和翻译都更快。',
          autoFixTitle: '🛠️ 自动体检与故障修复',
          autoFixDesc: '实时监测运行异常与数据损坏，发现问题自动修复并保护记录。',
          runAutoFixBtn: '✨ 立即体检修复',
          backupTitle: '数据安全保存与备份恢复',
          exportBtn: '📤 导出记录备份',
          cloudFullRestoreTitle: '从云端完整导入全部数据',
          cloudFullRestoreDesc: '无损合并恢复秀完与靖灿双方的聊天照片、视频、情侣相册、语音信与文字记录（绝不覆盖本机已有内容）。',
          cloudFullRestoreBtn: '☁️ 完整导入恢复',
          autoHealTitle: '智能自动自检与轻修复',
          autoHealOnLabel: '自动开启',
          importBtn: '📥 导入恢复记录',
          navHome: 'Home',
          navLearn: 'Study',
          navAnniv: '纪念日',
          navTrans: 'CW Talk',
          navDiary: 'Space',
          navBucket: '心愿·相册',
          navSettings: 'Setting',
          runTransBtn: '✨ 翻译与语感解析'
        }
      };

      const DATE_ROULETTE_IDEAS = [
        { ko: '🎬 같은 영화 동시에 틀고 통화하며 보기', zh: '🎬 同步看同一部电影并语音连麦' },
        { ko: '🌃 지금 각자 도시의 하늘·야경 사진 교환하기', zh: '🌃 拍下各自城市此刻的天空或夜景互发' },
        { ko: '🎙️ 오늘 배운 한국어 표현으로 다정한 음성 남기기', zh: '🎙️ 用今天学的韩语给对方录一段温柔语音' },
        { ko: '☕ 영상통화 켜고 같이 커피/야식 타임 갖기', zh: '☕ 开视频一起喝咖啡或吃夜宵' },
        { ko: '⏳ 다음 만남 날 열어볼 타임캡슐 비밀 편지 쓰기', zh: '⏳ 写一封下次见面时才能拆开的时光胶囊信' },
        { ko: '💌 오늘 서로에게 가장 고마웠던 점 1가지 말해주기', zh: '💌 告诉对方今天最感谢彼此的一件事' },
        { ko: '✈️ 다음 수원·상하이 여행에서 꼭 갈 맛집 1곳 정하기', zh: '✈️ 各自挑一家下次见面必去的宝藏餐厅' }
      ];

      const FONTS = [
        { id: 'sans', label: '깔끔 고딕', zhLabel: '现代黑体' },
        { id: 'serif', label: '우아한 명조·송체', zhLabel: '经典宋体' },
        { id: 'cute', label: '동글 귀여운체', zhLabel: '圆润可爱体' },
        { id: 'hand', label: '감성 손글씨체', zhLabel: '温柔手写体' },
        { id: 'modern', label: '모던 미니멀체', zhLabel: '现代简约体' }
      ];

      const MOOD_PRESETS = [
        '💜 보고 싶어 · 好想你',
        '🌸 기분 최고 · 心情超好',
        '💼 일/공부 중 · 工作学习中',
        '🍚 밥 먹는 중 · 吃饭中',
        '🚇 이동 중 · 在路上',
        '🛁 씻는 중 · 洗漱中',
        '📺 쉬는 중 · 休息中',
        '☕ 커피 타임 · 喝咖啡中',
        '💪 운동 중 · 运动中',
        '😪 피곤해 · 有点累',
        '🥺 안아줘 · 需要抱抱',
        '🌙 잘 준비 중 · 准备睡觉'
      ];

      const CITY_PRESETS = [
        { name: '수원 · Suwon', flag: '🇰🇷', lat: 37.2636, lon: 127.0286, tz: 'Asia/Seoul' },
        { name: '서울 · Seoul', flag: '🇰🇷', lat: 37.5665, lon: 126.9780, tz: 'Asia/Seoul' },
        { name: '용인 · Yongin', flag: '🇰🇷', lat: 37.2411, lon: 127.1776, tz: 'Asia/Seoul' },
        { name: '부산 · Busan', flag: '🇰🇷', lat: 35.1796, lon: 129.0756, tz: 'Asia/Seoul' },
        { name: '제주 · Jeju', flag: '🇰🇷', lat: 33.4996, lon: 126.5312, tz: 'Asia/Seoul' },
        { name: '인천 · Incheon', flag: '🇰🇷', lat: 37.4563, lon: 126.7052, tz: 'Asia/Seoul' },
        { name: '상하이 · 上海', flag: '🇨🇳', lat: 31.2304, lon: 121.4737, tz: 'Asia/Shanghai' },
        { name: '베이징 · 北京', flag: '🇨🇳', lat: 39.9042, lon: 116.4074, tz: 'Asia/Shanghai' },
        { name: '항저우 · 杭州', flag: '🇨🇳', lat: 30.2741, lon: 120.1551, tz: 'Asia/Shanghai' },
        { name: '선전 · 深圳', flag: '🇨🇳', lat: 22.5431, lon: 114.0579, tz: 'Asia/Shanghai' },
        { name: '광저우 · 广州', flag: '🇨🇳', lat: 23.1291, lon: 113.2644, tz: 'Asia/Shanghai' },
        { name: '칭다오 · 青岛', flag: '🇨🇳', lat: 36.0671, lon: 120.3826, tz: 'Asia/Shanghai' },
        { name: '청두 · 成都', flag: '🇨🇳', lat: 30.5728, lon: 104.0668, tz: 'Asia/Shanghai' },
        { name: '도쿄 · 東京', flag: '🇯🇵', lat: 35.6762, lon: 139.6503, tz: 'Asia/Tokyo' },
        { name: '파리 · Paris', flag: '🇫🇷', lat: 48.8566, lon: 2.3522, tz: 'Europe/Paris' },
        { name: '뉴욕 · New York', flag: '🇺🇸', lat: 40.7128, lon: -74.0060, tz: 'America/New_York' }
      ];

      /* ============================================================
         2. STORAGE & HELPERS
         ============================================================ */
      const STORAGE_CORE_KEY = 'chanwan_shiguang_v6_core';
      const STORAGE_PREV_CORE = 'chanwan_shiguang_v5_core';
      const STORAGE_LEGACY_KEY = 'chanwan_shiguang_v5_state';
      const IDB_NAME = 'ChanwanShiguangV5DB';
      const IDB_STORE = 'appState';

      let liveChannel = null;
      try { if ('BroadcastChannel' in window) liveChannel = new BroadcastChannel('chanwan_v6_live'); } catch (_) {}

      function escapeHtml(str) {
        if (str === null || str === undefined) return '';
        return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
      }

      let toastTimer = null;
      function showToast(msg, durationMs) {
        const box = document.getElementById('toastBox');
        const inner = document.getElementById('toastInner');
        if (!box || !inner) return;
        inner.textContent = msg;
        box.style.opacity = '1';
        box.style.transform = 'translate(-50%, 0)';
        if (toastTimer) clearTimeout(toastTimer);
        toastTimer = setTimeout(() => {
          box.style.opacity = '0';
          box.style.transform = 'translate(-50%, 8px)';
        }, Number(durationMs) > 0 ? Number(durationMs) : 2600);
      }

      const CUSTOM_SOUND_KEY = 'chanwan_custom_sound_data_v1';
      const CUSTOM_SOUND_NAME_KEY = 'chanwan_custom_sound_name_v1';
      const SOUND_TONE_KEY = 'chanwan_sound_tone_v1';

      let sharedAudioCtx = null;
      let audioUnlockedOnce = false;
      const SILENT_WAV_URI = 'data:audio/wav;base64,UklGRigAAABXQVZFZm10IBIAAAABAAEARKwAAIhYAQACABAAAABkYXRhAgAAAAEA';

      function unlockMobileAudioEngine() {
        try {
          const AudioCtx = window.AudioContext || window.webkitAudioContext;
          if (AudioCtx) {
            if (!sharedAudioCtx) sharedAudioCtx = new AudioCtx();
            if (sharedAudioCtx.state === 'suspended') sharedAudioCtx.resume().catch(() => {});
          }
        } catch (_) {}
        try {
          if (!audioUnlockedOnce) {
            audioUnlockedOnce = true;
            if (!sharedVoiceAudio) {
              sharedVoiceAudio = new Audio();
              sharedVoiceAudio.preload = 'auto';
              sharedVoiceAudio.setAttribute('playsinline', '');
              sharedVoiceAudio.setAttribute('webkit-playsinline', '');
            }
            sharedVoiceAudio.src = SILENT_WAV_URI;
            sharedVoiceAudio.volume = 0.01;
            const p = sharedVoiceAudio.play();
            if (p && typeof p.then === 'function') {
              p.then(() => { sharedVoiceAudio.pause(); sharedVoiceAudio.volume = 1.0; }).catch(() => { sharedVoiceAudio.volume = 1.0; });
            }
          }
        } catch (_) {}
      }
      ['touchstart', 'pointerdown', 'click'].forEach(evt => {
        document.addEventListener(evt, unlockMobileAudioEngine, { passive: true, once: false });
      });
      document.addEventListener('WeixinJSBridgeReady', () => {
        try {
          if (window.WeixinJSBridge && window.WeixinJSBridge.invoke) {
            window.WeixinJSBridge.invoke('getNetworkType', {}, () => unlockMobileAudioEngine());
          } else {
            unlockMobileAudioEngine();
          }
        } catch (_) { unlockMobileAudioEngine(); }
      }, false);

      function playGentleChime(previewTone) {
        const isPreview = typeof previewTone === 'string' && previewTone.length > 0;
        if (!isPreview && (!state.settings.notifSound || state.soundEnabled === false)) return;
        const tone = isPreview ? previewTone : (localStorage.getItem(SOUND_TONE_KEY) || state.settings.notifTone || 'chime');

        if (tone === 'custom') {
          try {
            const dataUrl = localStorage.getItem(CUSTOM_SOUND_KEY);
            if (dataUrl) {
              const audio = new Audio(dataUrl);
              audio.volume = 0.9;
              audio.play().catch(() => {});
              return;
            }
          } catch (_) {}
        }

        try {
          const AudioCtx = window.AudioContext || window.webkitAudioContext;
          if (!AudioCtx) return;
          if (!sharedAudioCtx) sharedAudioCtx = new AudioCtx();
          const ctx = sharedAudioCtx;
          if (ctx.state === 'suspended') ctx.resume().catch(() => {});
          const now = ctx.currentTime;

          const playNote = (type, freq, startOffset, dur, peak = 0.08, endFreq = null) => {
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.type = type;
            osc.frequency.setValueAtTime(freq, now + startOffset);
            if (endFreq) osc.frequency.exponentialRampToValueAtTime(endFreq, now + startOffset + dur * 0.85);
            gain.gain.setValueAtTime(0.001, now + startOffset);
            gain.gain.exponentialRampToValueAtTime(peak, now + startOffset + 0.018);
            gain.gain.exponentialRampToValueAtTime(0.001, now + startOffset + dur);
            osc.connect(gain); gain.connect(ctx.destination);
            osc.start(now + startOffset); osc.stop(now + startOffset + dur + 0.02);
          };

          if (tone === 'bubble') {
            playNote('sine', 440, 0, 0.13, 0.11, 980);
            playNote('sine', 760, 0.09, 0.14, 0.08, 1280);
          } else if (tone === 'musicbox') {
            [[1046.5, 0], [1318.5, 0.11], [1568.0, 0.22]].forEach(([f, t]) => playNote('triangle', f, t, 0.36, 0.075));
          } else if (tone === 'heart') {
            playNote('sine', 220, 0, 0.12, 0.13, 140);
            playNote('sine', 240, 0.14, 0.14, 0.12, 150);
            playNote('sine', 880, 0.25, 0.28, 0.06);
          } else if (tone === 'sparkle') {
            [[1318.5, 0], [1661.2, 0.07], [1975.5, 0.14], [2637.0, 0.21]].forEach(([f, t]) => playNote('sine', f, t, 0.26, 0.065));
          } else if (tone === 'wechat') {
            // Crisp WeChat-style crystalline 2-note ding-dong (100% offline Web Audio)
            playNote('sine', 987.77, 0, 0.14, 0.10);
            playNote('sine', 1318.51, 0.09, 0.24, 0.095);
          } else if (tone === 'guzheng') {
            // Delicate Chinese pentatonic Guzheng harp arpeggio (C5-E5-G5-C6)
            [[523.25, 0], [659.25, 0.06], [783.99, 0.12], [1046.5, 0.19]].forEach(([f, t]) => playNote('triangle', f, t, 0.34, 0.08));
          } else if (tone === 'jade') {
            // Warm Chinese jade wind-chime pentatonic cadence (D5-G5-D6)
            [[587.33, 0], [783.99, 0.10], [1174.66, 0.21]].forEach(([f, t]) => playNote('sine', f, t, 0.36, 0.075));
          } else {
            // Default: Romantic Chime
            playNote('sine', 587.33, 0, 0.28, 0.075);
            playNote('sine', 880.0, 0.09, 0.30, 0.075);
          }
        } catch (_) {}
      }
      function playNotifChime() { return playGentleChime(); }

      const MOBILE_NOTIF_ICON = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 192 192'%3E%3Crect width='192' height='192' rx='44' fill='%23583894'/%3E%3Ctext x='96' y='114' text-anchor='middle' font-family='Georgia,serif' font-size='56' font-weight='700' fill='%23fffaf2'%3E%E7%81%BF%E5%AE%8C%3C/text%3E%3C/svg%3E";

      function fireSystemNotification(title, body, targetTab, targetSub) {
        const isSilent = state.soundEnabled === false;
        const routeTab = targetTab || 'translator';
        const routeSub = targetSub || '';
        // 1) Tactile mobile vibration
        try { if (!isSilent && navigator.vibrate) navigator.vibrate([160, 80, 160]); } catch (_) {}

        // 2) Mobile & Desktop OS Banner (clickable to open/focus app & jump to exact tab!)
        try {
          if ('Notification' in window && Notification.permission === 'granted') {
            const openUrl = (location.protocol.startsWith('http') ? (location.origin + location.pathname) : './');
            const uniqueTag = `chanwan-live-${routeTab}`;
            const opts = {
              body,
              badge: './badge-96.png?v=23',
              vibrate: [160, 80, 160],
              tag: uniqueTag,
              renotify: true,
              silent: isSilent,
              timestamp: Date.now(),
              data: { tab: routeTab, sub: routeSub, url: openUrl }
            };
            const spawnFallback = () => {
              const n = new Notification(title, opts);
              n.onclick = () => {
                try { window.focus(); } catch (_) {}
                try { navigateToRoute(routeTab, routeSub); } catch (_) {}
                try { n.close(); } catch (_) {}
              };
            };
            if ('serviceWorker' in navigator) {
              navigator.serviceWorker.ready.then(reg => {
                if (reg && reg.showNotification) reg.showNotification(title, opts);
                else spawnFallback();
              }).catch(() => { try { spawnFallback(); } catch (_) {} });
            } else {
              spawnFallback();
            }
          }
        } catch (_) {}
      }


      // True Sender-Side Lock-Screen & Top-Bar Push (fires to PARTNER's dedicated ntfy channel when SENDING!)
      function sendPartnerNativePush(title, body) {
        try {
          const myRole = (state && state.myRole) || 'suwan';
          const partnerRole = myRole === 'suwan' ? 'jingchan' : 'suwan';
          const customCh = ((state.settings && state.settings.mobilePushChannel) || '').trim().replace(/[^a-zA-Z0-9_-]/g, '');
          const baseCh = customCh || ((typeof getSyncRoomCode === 'function' ? getSyncRoomCode() : '') || 'chanwan-suwan-jingchan-live2026').trim().replace(/[^a-zA-Z0-9_-]/g, '');
          if (!baseCh) return;
          const targetCh = `${baseCh}-${partnerRole}`;
          const clickUrl = (location.protocol.startsWith('http') ? (location.origin + location.pathname) : 'https://swans8562-sudo.github.io/chanwan/');
          const rawTitle = String(title || '');
          const isHeartbeat = /하트비트|心跳/.test(rawTitle);
          const isGame = /밸런스|게임|콕|默契|游戏|戳/.test(rawTitle);
          const isSpace = /커플공간|답글|空间/.test(rawTitle);
          const isMood = /기분|心情/.test(rawTitle);
          const isAct = /상태|状态/.test(rawTitle);
          // Pretty couple-app style title in receiver's language (Suwan gets Korean, Jingchan gets Chinese)
          const cleanTitle = partnerRole === 'suwan'
            ? (isGame ? '⚖️ 징찬 · 밸런스 게임' : (isHeartbeat ? '💓 징찬 · 하트비트' : (isMood ? '🌸 징찬 · 기분' : (isAct ? '✨ 징찬 · 상태' : (isSpace ? '💜 징찬 · 커플공간' : '💜 징찬')))))
            : (isGame ? '⚖️ 秀完 · 默契游戏' : (isHeartbeat ? '💓 秀完 · 心跳' : (isMood ? '🌸 秀完 · 心情' : (isAct ? '✨ 秀完 · 状态' : (isSpace ? '💜 秀完 · 情侣空间' : '💜 秀完')))));
          let cleanMsg = String(body || '').replace(/\s+/g, ' ').trim().slice(0, 140);
          if (!cleanMsg) cleanMsg = partnerRole === 'suwan' ? '새 메시지가 도착했어요' : '发来了一条新消息';
          // Translate boilerplate media/heartbeat captions into receiver's language cleanly
          if (partnerRole === 'jingchan') {
            if (cleanMsg === '지금 보고 싶어요 💜') cleanMsg = '现在好想你 💜';
            else if (/동영상을 보냈어요/.test(cleanMsg)) cleanMsg = '🎬 发送了一段视频';
            else if (/사진을 보냈어요/.test(cleanMsg)) cleanMsg = '📷 发送了一张照片';
            else if (/음성 메시지/.test(cleanMsg)) cleanMsg = '🎙️ 发送了一条语音';
            else if (/\[움짤\]/.test(cleanMsg)) cleanMsg = '🎞️ 发送了一张动图';
            else if (cleanMsg === '새 메시지가 도착했어요') cleanMsg = '发来了一条新消息';
          } else {
            if (cleanMsg === '🎙️ 语音消息') cleanMsg = '음성 메시지를 보냈어요';
            else if (cleanMsg === '🎞️ [动图]') cleanMsg = '움짤을 보냈어요';
            cleanMsg = cleanMsg.replace(/^[🎬📷🎙️💌💓💬]+\s*/u, '');
          }
          const appIconUrl = 'https://swans8562-sudo.github.io/chanwan/icon-192.png?v=21';
          const openBtnLabel = partnerRole === 'suwan' ? (isGame ? '⚖️ 게임 열기' : '💬 대화 열기') : (isGame ? '⚖️ 打开游戏' : '💬 打开聊天');
          const sendJson = (topic, attempt = 0) => {
            fetch('https://ntfy.sh', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                topic,
                title: cleanTitle,
                message: cleanMsg,
                priority: 5,
                icon: appIconUrl,
                click: clickUrl,
                actions: [{ action: 'view', label: openBtnLabel, url: clickUrl, clear: true }]
              }),
              keepalive: attempt === 0
            }).then((r) => {
              if (!r || !r.ok) throw new Error('ntfy_http_' + (r ? r.status : 0));
            }).catch(() => {
              if (attempt < 2) setTimeout(() => sendJson(topic, attempt + 1), attempt === 0 ? 1200 : 3500);
            });
          };
          sendJson(targetCh);
          if (customCh) sendJson(customCh);
        } catch (_) {}
      }
      window.__cwSendPartnerPush = sendPartnerNativePush;

      function updateSysNotifStatus() {
        const isZh = state.lang === 'zh';
        const box = document.getElementById('sysNotifBannerBox');
        const btn = document.getElementById('enableSysNotifBtn');
        const txt = document.getElementById('sysNotifStatusText');
        const __isNativeApk = typeof window.ChanwanNative !== 'undefined';
        if (box) box.classList.toggle('hidden', __isNativeApk || (('Notification' in window) && Notification.permission === 'granted'));
        const sBadge = document.getElementById('settingsNotifStatusBadge');
        const sDesc = document.getElementById('settingsNotifStatusDesc');
        const sBtn = document.getElementById('settingsNotifPermBtn');
        const sSoundCb = document.getElementById('settingsSoundToggle');
        const sSoundSt = document.getElementById('settingsSoundState');
        if (sSoundCb) sSoundCb.checked = state.soundEnabled !== false;
        if (sSoundSt) sSoundSt.textContent = state.soundEnabled !== false ? (isZh ? '开启' : 'ON') : (isZh ? '关闭' : 'OFF');

        if (__isNativeApk) {
          if (txt) txt.textContent = isZh ? '灿完时光专属 APP 后台爱心横幅已开启 💜' : '灿完时光 전용 앱 백그라운드 하트 배너가 작동 중이에요 💜';
          if (btn) btn.textContent = isZh ? '已开启' : '작동 중';
          if (sBadge) sBadge.textContent = isZh ? '🟢 专属APP已开启' : '🟢 전용 앱 ON';
          if (sDesc) sDesc.textContent = isZh ? '无需浏览器权限，后台实时接收中文横幅与状态栏爱心提醒 💜' : '전용 앱 백그라운드 서비스로 실시간 하트 배너가 켜져 있어요 💜';
          if (sBtn) sBtn.classList.add('hidden');
          return;
        }
        if (!('Notification' in window)) {
          if (txt) txt.textContent = isZh ? '当前浏览器不支持系统横幅通知。' : '이 브라우저는 브라우저 배너 알림을 지원하지 않아요.';
          if (btn) btn.textContent = isZh ? '不支持' : '미지원';
          if (sBadge) sBadge.textContent = isZh ? '⚪ 不支持' : '⚪ 미지원';
          if (sDesc) sDesc.textContent = isZh ? '请在 Chrome、Safari 或 Edge 浏览器中打开以接收横幅通知。' : 'Chrome·Safari·Edge 브라우저에서 열면 배너 알림을 받을 수 있어요.';
          if (sBtn) sBtn.textContent = isZh ? '不支持' : '미지원';
          return;
        }
        if (Notification.permission === 'granted') {
          if (txt) txt.textContent = isZh ? '已开启 · 切换其他页面也能收到横幅和提示音' : '허용됨 · 다른 탭을 볼 때도 배너와 알림음 수신';
          if (btn) { btn.textContent = isZh ? '已允许 ✓' : '허용됨 ✓'; btn.className = 'btn-ghost px-2.5 py-1.5 rounded-xl text-[10px] font-semibold shrink-0 whitespace-nowrap text-emerald-600'; }
          if (sBadge) { sBadge.textContent = isZh ? '🟢 已允许' : '🟢 허용됨'; sBadge.style.background = 'rgba(16,185,129,0.14)'; sBadge.style.color = '#059669'; }
          if (sDesc) sDesc.textContent = isZh ? '浏览器通知已开启！新消息和心动提醒会第一时间弹出。' : '브라우저 알림이 켜져 있어요! 새 메시지·하트 알림이 바로 울려요.';
          if (sBtn) { sBtn.textContent = isZh ? '已允许 ✓' : '허용됨 ✓'; sBtn.className = 'btn-ghost px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap text-emerald-600'; }
        } else if (Notification.permission === 'denied') {
          if (txt) txt.textContent = isZh ? '请在浏览器地址栏左侧图标中重新允许通知权限。' : '브라우저 주소창 왼쪽 자물쇠(권한)에서 알림을 허용해 주세요.';
          if (btn) { btn.textContent = isZh ? '已拦截' : '차단됨'; btn.className = 'btn-ghost px-2.5 py-1.5 rounded-xl text-[10px] font-semibold shrink-0 whitespace-nowrap text-rose-500'; }
          if (sBadge) { sBadge.textContent = isZh ? '🔴 已拦截' : '🔴 차단됨'; sBadge.style.background = 'rgba(244,63,94,0.12)'; sBadge.style.color = '#e11d48'; }
          if (sDesc) sDesc.textContent = isZh ? '通知权限被浏览器拦截，请点地址栏左侧权限设置改为「允许」。' : '알림이 차단되어 있어요. 주소창 왼쪽 권한 설정에서 「알림 허용」으로 바꿔주세요.';
          if (sBtn) { sBtn.textContent = isZh ? '重新检查' : '다시 확인'; sBtn.className = 'btn-ghost px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap text-rose-500'; }
        } else {
          if (txt) txt.textContent = isZh ? '切换到其他页面时也能接收横幅与提示音' : '다른 화면을 볼 때도 배너와 알림음 받기';
          if (btn) { btn.textContent = isZh ? '允许' : '허용하기'; btn.className = 'btn-royal px-2.5 py-1.5 rounded-xl text-[10px] font-semibold shrink-0 whitespace-nowrap'; }
          if (sBadge) { sBadge.textContent = isZh ? '🟡 未开启' : '🟡 미설정'; sBadge.style.background = 'var(--accent-royal-soft)'; sBadge.style.color = 'var(--accent-royal)'; }
          if (sDesc) sDesc.textContent = isZh ? '点击右侧按钮允许浏览器通知，不错过任何一条甜蜜消息。' : '오른쪽 버튼을 눌러 브라우저 알림을 허용하면 새 소식을 놓치지 않아요.';
          if (sBtn) { sBtn.textContent = isZh ? '🔔 允许通知' : '🔔 알림 허용하기'; sBtn.className = 'btn-royal px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap'; }
        }
      }

      function copyText(text) {
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(text).then(() => showToast(state.lang === 'zh' ? '已复制 ✨' : '복사되었습니다 ✨')).catch(() => fallbackCopy(text));
        } else { fallbackCopy(text); }
      }

      function fallbackCopy(text) {
        try {
          const ta = document.createElement('textarea');
          ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
          document.body.appendChild(ta); ta.select(); document.execCommand('copy'); document.body.removeChild(ta);
          showToast(state.lang === 'zh' ? '已复制 ✨' : '복사되었습니다 ✨');
        } catch (_) {}
      }

      let sharedVoiceAudio = null;
      let cachedSpeechVoices = [];

      function refreshSpeechVoices() {
        try {
          if ('speechSynthesis' in window && window.speechSynthesis.getVoices) {
            const list = window.speechSynthesis.getVoices();
            if (list && list.length) cachedSpeechVoices = list;
          }
        } catch (_) {}
      }
      refreshSpeechVoices();
      if ('speechSynthesis' in window) {
        try { window.speechSynthesis.onvoiceschanged = refreshSpeechVoices; } catch (_) {}
      }

      function pickBestFemaleVoice(targetLang) {
        refreshSpeechVoices();
        if (!cachedSpeechVoices || !cachedSpeechVoices.length) return null;
        const isZh = String(targetLang || '').toLowerCase().startsWith('zh');
        const langVoices = cachedSpeechVoices.filter(v => {
          const l = String(v.lang || '').toLowerCase();
          return isZh ? (l.startsWith('zh-cn') || l === 'zh' || l.startsWith('zh_cn') || l.startsWith('cmn')) : l.startsWith('ko');
        });
        if (!langVoices.length) return null;
        const maleBlockRe = /injoon|hyunsu|bongjin|minsu|yunxi|yunjian|yunyang|kangkang|male|남성|男/i;
        const preferredRe = isZh
          ? [/xiaoxiao|xiaoyi|microsoft.*online/i, /ting-?ting|tingting/i, /google.*普通话|google.*中文|google.*chinese/i, /meijia|sin-?ji|huihui|yaoyao|lili|female|女/i]
          : [/sunhi|ji-?min|microsoft.*online/i, /yuna/i, /google.*한국|google.*korean/i, /sora|heami|seoyeon|nara|female|여성|女/i];

        for (const rx of preferredRe) {
          const hit = langVoices.find(v => rx.test(v.name || '') && !maleBlockRe.test(v.name || ''));
          if (hit) return hit;
        }
        const nonMale = langVoices.find(v => !maleBlockRe.test(v.name || ''));
        return nonMale || langVoices[0];
      }

      function playNativeFemaleTts(cleanText, targetLang, slow) {
        try {
          if (!('speechSynthesis' in window)) return false;
          const bestVoice = pickBestFemaleVoice(targetLang);
          if (!bestVoice) return false;
          window.speechSynthesis.cancel();
          const utter = new SpeechSynthesisUtterance(cleanText);
          utter.voice = bestVoice;
          utter.lang = bestVoice.lang || targetLang;
          utter.rate = slow ? 0.68 : 0.94;
          utter.pitch = 1.05;
          utter.volume = 1.0;
          window.speechSynthesis.speak(utter);
          return true;
        } catch (_) {
          return false;
        }
      }

      let __ttsWatchdog = null;
      window.__cachedTtsVoices = [];
      try {
        if ('speechSynthesis' in window) {
          const loadTtsVoices = () => {
            const v = window.speechSynthesis.getVoices();
            if (v && v.length) window.__cachedTtsVoices = v;
          };
          loadTtsVoices();
          window.speechSynthesis.onvoiceschanged = loadTtsVoices;
        }
      } catch (_) {}
      function speakText(text, lang, slow) {
        const clean = String(text || '').trim();
        if (!clean) return;
        if (__ttsWatchdog) { clearTimeout(__ttsWatchdog); __ttsWatchdog = null; }
        const ensureAudioEl = () => {
          if (!sharedVoiceAudio) {
            sharedVoiceAudio = new Audio();
            sharedVoiceAudio.preload = 'auto';
            sharedVoiceAudio.setAttribute('playsinline', '');
            sharedVoiceAudio.setAttribute('webkit-playsinline', '');
          }
          sharedVoiceAudio.muted = false;
          sharedVoiceAudio.volume = 1.0;
          return sharedVoiceAudio;
        };

        // Priority 0: Play Suwan's real recorded voice if saved for this Korean phrase!
        try {
          let customUrl = state && state.customVoices && state.customVoices[clean];
          if (!customUrl && state && state.customVoices && typeof state.customVoices === 'object') {
            const normK = (s) => String(s || '').replace(/[\s?!.,~'"()「」『』]/g, '').trim();
            const targetNorm = normK(clean);
            if (targetNorm) {
              for (const [k, v] of Object.entries(state.customVoices)) {
                if (v && normK(k) === targetNorm) { customUrl = v; break; }
              }
            }
          }
          if (customUrl) {
            const el = ensureAudioEl();
            el.pause();
            el.onerror = null;
            el.onplaying = null;
            el.src = customUrl;
            el.playbackRate = slow ? 0.76 : 1.0;
            const p = el.play();
            if (p && typeof p.catch === 'function') p.catch(() => {});
            return;
          }
        } catch (_) {}

        const autoIsEn = !lang && /[a-zA-Z]{2,}/.test(clean) && !/[\uAC00-\uD7A3\u4E00-\u9FFF]/.test(clean);
        const targetLang = lang || (autoIsEn ? 'en-US' : (/[\u4E00-\u9FFF]/.test(clean) && !/[\uAC00-\uD7A3]/.test(clean) ? 'zh-CN' : 'ko-KR'));
        const isZh = targetLang.toLowerCase().startsWith('zh');
        const isEn = targetLang.toLowerCase().startsWith('en');
        const ttsNormalized = (isZh || isEn) ? clean : clean
          .replace(/ㅎ{2,}/g, ' 하하 ')
          .replace(/ㅋ{2,}/g, ' 하하 ')
          .replace(/[ㅠㅜ]{2,}/g, ' ')
          .replace(/(^|[^가-힣])ㅇㅇ(?![가-힣])/g, '$1응응')
          .replace(/(^|[^가-힣])ㅇㅋ(?![가-힣])/g, '$1오케이')
          .replace(/(^|[^가-힣])ㄱㅅ(?![가-힣])/g, '$1감사')
          .replace(/(^|[^가-힣])ㄴㄴ(?![가-힣])/g, '$1아니')
          .replace(/\s{2,}/g, ' ')
          .trim();
        const snippet = (ttsNormalized || clean).slice(0, 140);

        const uaStr = navigator.userAgent || '';
        const isChinaDevice = /Huawei|HarmonyOS|MicroMessenger|Baidu|XiaoMi|MIUI|OPPO|vivo|HONOR|Quark|UCBrowser|MQQBrowser/i.test(uaStr) || (state && (state.myRole === 'jingchan' || state.lang === 'zh'));

        try {
          if (!isChinaDevice && 'speechSynthesis' in window) {
            const allVoices = (window.__cachedTtsVoices && window.__cachedTtsVoices.length)
              ? window.__cachedTtsVoices
              : (window.speechSynthesis.getVoices() || []);
            const langPrefix = isEn ? 'en' : (isZh ? 'zh' : 'ko');
            const langVoices = allVoices.filter(v => String(v.lang || '').toLowerCase().startsWith(langPrefix));
            const neuralVoice =
              langVoices.find(v => /Natural|Neural|Online|Premium|Enhanced|SunHi|InJoon|Xiaoxiao|Yunxi|Aria|Jenny|Samantha/i.test(v.name || '')) ||
              langVoices.find(v => /Google|Siri|Yuna|Sora|Heami|Tingting|Meijia|Samsung|Alex|Daniel/i.test(v.name || '')) ||
              ((!isZh || isEn) && langVoices.length ? langVoices[0] : null);
            if (neuralVoice) {
              window.speechSynthesis.cancel();
              const utt = new SpeechSynthesisUtterance(snippet);
              utt.voice = neuralVoice;
              utt.lang = isEn ? 'en-US' : (isZh ? 'zh-CN' : 'ko-KR');
              utt.rate = slow ? 0.72 : 0.96;
              utt.pitch = 1.0;
              window.speechSynthesis.speak(utt);
              return;
            }
          }
        } catch (_) {}

        const urls = isEn
          ? [
              `https://dict.youdao.com/dictvoice?audio=${encodeURIComponent(snippet)}&le=eng&type=2`,
              `https://fanyi.baidu.com/gettts?lan=en&text=${encodeURIComponent(snippet)}&spd=${slow ? 3 : 5}&source=web`,
              `https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=en&ttsspeed=${slow ? 0.5 : 1}&q=${encodeURIComponent(snippet)}`
            ]
          : (isZh
              ? [
                  `https://dict.youdao.com/dictvoice?audio=${encodeURIComponent(snippet)}&le=zh&type=2`,
                  `https://fanyi.baidu.com/gettts?lan=zh&text=${encodeURIComponent(snippet)}&spd=${slow ? 3 : 5}&source=web`,
                  `https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=zh-CN&ttsspeed=${slow ? 0.5 : 1}&q=${encodeURIComponent(snippet)}`
                ]
              : (isChinaDevice
                  ? [
                      `https://dict.youdao.com/dictvoice?audio=${encodeURIComponent(snippet)}&le=ko&type=2`,
                      `https://fanyi.baidu.com/gettts?lan=kor&text=${encodeURIComponent(snippet)}&spd=${slow ? 3 : 5}&source=web`,
                      `https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=ko&ttsspeed=${slow ? 0.5 : 1}&q=${encodeURIComponent(snippet)}`
                    ]
                  : [
                      `https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=ko&ttsspeed=${slow ? 0.5 : 1}&q=${encodeURIComponent(snippet)}`,
                      `https://dict.youdao.com/dictvoice?audio=${encodeURIComponent(snippet)}&le=ko&type=2`,
                      `https://fanyi.baidu.com/gettts?lan=kor&text=${encodeURIComponent(snippet)}&spd=${slow ? 3 : 5}&source=web`
                    ]));

        try {
          const el = ensureAudioEl();
          el.pause();
          let idx = 0;
          const runPlay = (urlToPlay, onFail) => {
            if (__ttsWatchdog) { clearTimeout(__ttsWatchdog); __ttsWatchdog = null; }
            let settled = false;
            const failOnce = () => {
              if (settled) return;
              settled = true;
              if (__ttsWatchdog) { clearTimeout(__ttsWatchdog); __ttsWatchdog = null; }
              onFail();
            };
            el.onplaying = () => {
              settled = true;
              if (__ttsWatchdog) { clearTimeout(__ttsWatchdog); __ttsWatchdog = null; }
            };
            el.onerror = failOnce;
            el.src = urlToPlay;
            el.playbackRate = slow ? 0.78 : 1.0;
            el.load();
            const doStart = () => {
              const p = el.play();
              if (p && typeof p.catch === 'function') p.catch(failOnce);
            };
            if (window.WeixinJSBridge && window.WeixinJSBridge.invoke) {
              try { window.WeixinJSBridge.invoke('getNetworkType', {}, doStart); } catch (_) { doStart(); }
            } else {
              doStart();
            }
            __ttsWatchdog = setTimeout(failOnce, 2800);
          };

          const tryNext = () => {
            if (idx >= urls.length) {
              if (!playNativeFemaleTts(snippet, targetLang, !!slow)) {
                try {
                  if ('speechSynthesis' in window) {
                    window.speechSynthesis.cancel();
                    const u = new SpeechSynthesisUtterance(snippet);
                    u.lang = targetLang; u.rate = slow ? 0.68 : 0.94; u.pitch = 1.05; u.volume = 1.0;
                    window.speechSynthesis.speak(u);
                  }
                } catch (_) {}
              }
              return;
            }
            runPlay(urls[idx++], tryNext);
          };
          tryNext();
        } catch (_) {
          playNativeFemaleTts(snippet, targetLang, !!slow);
        }
      }

      function openConfirm(title, message, onConfirm) {
        const isZh = state && state.lang === 'zh';
        if (typeof message === 'function' && typeof onConfirm === 'undefined') {
          onConfirm = message;
          message = title;
          title = isZh ? '删除确认' : '삭제 확인';
        }
        if (typeof onConfirm !== 'function') return;
        const modal = document.getElementById('confirmModal');
        const titleEl = document.getElementById('confirmTitle');
        const msgEl = document.getElementById('confirmMessage');
        let step = 1;
        titleEl.textContent = title;
        msgEl.textContent = message;
        modal.classList.remove('hidden');
        const oldOk = document.getElementById('confirmOkBtn');
        const oldCancel = document.getElementById('confirmCancelBtn');
        const okBtn = oldOk.cloneNode(true);
        const cancelBtn = oldCancel.cloneNode(true);
        oldOk.replaceWith(okBtn);
        oldCancel.replaceWith(cancelBtn);
        const origOkStyle = okBtn.getAttribute('style') || '';
        okBtn.textContent = isZh ? '确认 (1/2)' : '1차 확인 (1/2)';
        cancelBtn.textContent = isZh ? '取消' : '취소';
        const cleanup = () => {
          modal.classList.add('hidden');
          okBtn.setAttribute('style', origOkStyle);
          okBtn.textContent = isZh ? '确认' : '확인';
          okBtn.replaceWith(okBtn.cloneNode(true));
          cancelBtn.replaceWith(cancelBtn.cloneNode(true));
        };
        okBtn.addEventListener('click', () => {
          if (step === 1) {
            step = 2;
            titleEl.textContent = isZh ? '⚠️ 最终确认 (2/2)' : '⚠️ 최종 확인 (2/2)';
            msgEl.textContent = isZh ? '确定要永久删除吗？执行后无法恢复！' : '정말 영구 삭제할까요? 삭제 후에는 되돌릴 수 없어요!';
            okBtn.textContent = isZh ? '⚠️ 确认删除' : '⚠️ 최종 삭제';
            okBtn.style.background = '#e11d48';
            okBtn.style.color = '#ffffff';
            return;
          }
          cleanup();
          onConfirm();
        });
        cancelBtn.addEventListener('click', cleanup);
      }

      function getKstTimeShort() {
        try {
          return new Date().toLocaleTimeString('ko-KR', { timeZone: 'Asia/Seoul', hour: '2-digit', minute: '2-digit' });
        } catch (_) {
          return new Date().toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' });
        }
      }

      function getKstDateString(dateObj) {
        const d = dateObj || new Date();
        const parts = new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Seoul', year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(d);
        return `${parts.find(p => p.type === 'year').value}-${parts.find(p => p.type === 'month').value}-${parts.find(p => p.type === 'day').value}`;
      }

      function parseYmd(ymd) {
        const [y, m, d] = (ymd || '2026-01-01').split('-').map(Number);
        return new Date(Date.UTC(y || 2026, (m || 1) - 1, d || 1));
      }

      function diffDays(ymdA, ymdB) {
        return Math.floor((parseYmd(ymdB).getTime() - parseYmd(ymdA).getTime()) / 86400000);
      }

      function idbPut(key, data) {
        return new Promise((resolve) => {
          try {
            if (!window.indexedDB) return resolve(false);
            const req = indexedDB.open(IDB_NAME, 1);
            req.onupgradeneeded = (e) => {
              const db = e.target.result;
              if (!db.objectStoreNames.contains(IDB_STORE)) db.createObjectStore(IDB_STORE);
            };
            req.onsuccess = (e) => {
              try {
                const tx = e.target.result.transaction(IDB_STORE, 'readwrite');
                tx.objectStore(IDB_STORE).put(data, key);
                tx.oncomplete = () => resolve(true);
                tx.onerror = () => resolve(false);
              } catch (_) { resolve(false); }
            };
            req.onerror = () => resolve(false);
          } catch (_) { resolve(false); }
        });
      }

      function idbGet(key) {
        return new Promise((resolve) => {
          let settled = false;
          const done = (val) => { if (!settled) { settled = true; clearTimeout(guard); resolve(val); } };
          const guard = setTimeout(() => done(null), 1200);
          try {
            if (!window.indexedDB) return done(null);
            const req = indexedDB.open(IDB_NAME, 1);
            req.onupgradeneeded = (e) => {
              const db = e.target.result;
              if (!db.objectStoreNames.contains(IDB_STORE)) db.createObjectStore(IDB_STORE);
            };
            req.onsuccess = (e) => {
              try {
                const tx = e.target.result.transaction(IDB_STORE, 'readonly');
                const getReq = tx.objectStore(IDB_STORE).get(key);
                getReq.onsuccess = () => done(getReq.result || null);
                getReq.onerror = () => done(null);
              } catch (_) { done(null); }
            };
            req.onerror = () => done(null);
            req.onblocked = () => done(null);
          } catch (_) { done(null); }
        });
      }

      /* ============================================================
         3. NOTIFICATION CENTER (IN-APP + OS SYSTEM BANNER)
         ============================================================ */
      let liveBannerTimer = null;
      let activeNotifFilter = 'all';
      let lastLiveRoute = { tab: 'home', sub: '' };

      function showLiveBanner(item) {
        const isZh = state.lang === 'zh';
        const hidePrev = !!(state.settings && state.settings.hideNotifPreview);
        const title = isZh ? item.titleZh : item.titleKo;
        const fullBody = isZh ? item.bodyZh : item.bodyKo;
        const osBody = hidePrev
          ? (isZh ? '收到一条新消息' : '새 메시지가 도착했어요')
          : fullBody;

        const hasNativeApk = !!(window.ChanwanNative);
        const isAppForeground = (document.visibilityState === 'visible' && !document.hidden)
          && (!hasNativeApk || typeof window.ChanwanNative.isForeground !== 'function' || window.ChanwanNative.isForeground());

        // Strict Foreground vs. Background Split:
        // - App in Foreground: ONLY play gentle chime + show in-app banner (#liveNotifBanner), ZERO phone OS banner!
        // - App in Background/Closed: fire phone OS banner (for web/PWA; Native APK handles background OS banners via ChanwanPushService).
        if (!isAppForeground) {
          if (!hasNativeApk) {
            let cleanOsTitle = String(title || '').replace(/^[\s\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]+/u, '').trim();
            cleanOsTitle = cleanOsTitle
              .replace(/의\s*새\s*메시지.*$/, '')
              .replace(/님의\s*새\s*메시지.*$/, '')
              .replace(/发来的新消息.*$/, '')
              .replace(/的新消息.*$/, '')
              .trim() || (isZh ? '秀完' : '징찬');
            const cleanOsBody = String(osBody || '').replace(/[💌💜✨]+$/u, '').replace(/\s+/g, ' ').trim();
            fireSystemNotification(cleanOsTitle, cleanOsBody, item.tab, item.sub);
          }
          return;
        }

        if (hasNativeApk && typeof window.ChanwanNative.clearNotifications === 'function') {
          try { window.ChanwanNative.clearNotifications(); } catch (_) {}
        }
        playGentleChime();

        // Inside the app itself, show the in-app notification banner with arrival time!
        const banner = document.getElementById('liveNotifBanner');
        lastLiveRoute = { tab: item.tab || 'home', sub: item.sub || '' };
        document.getElementById('liveNotifIcon').textContent = item.icon || '💜';
        document.getElementById('liveNotifTitle').textContent = title;
        document.getElementById('liveNotifBody').textContent = fullBody;
        banner.classList.remove('pointer-events-none');
        const tBadge = document.getElementById('liveNotifTimeBadge');
        if (tBadge) tBadge.textContent = item.time || (isZh ? '刚刚' : '방금 전');
        if (typeof window.syncAllTabIconsToStyle === 'function') window.syncAllTabIconsToStyle(null, banner);
        banner.style.opacity = '1';
        banner.style.transform = 'translate(-50%, 0) scale(1)';
        if (liveBannerTimer) clearTimeout(liveBannerTimer);
        liveBannerTimer = setTimeout(() => {
          banner.style.opacity = '0';
          banner.style.transform = 'translate(-50%, -140%) scale(0.96)';
          banner.classList.add('pointer-events-none');
        }, 4800);
      }

      function isPendingTransStr(s) {
        return /^(⏳\s*(번역 중|正在翻译)\.\.\.)$/.test(String(s || '').trim());
      }
      function updateChatNotifsForMsg(msgId, origTxt, trTxt) {
        try {
          if (!msgId || !trTxt || isPendingTransStr(trTxt) || !Array.isArray(state.notifications)) return;
          const o = String(origTxt || '');
          const origIsKo = /[가-힣]/.test(o) && !/[\u4e00-\u9fff]/.test(o);
          const nextKo = origIsKo ? o : trTxt;
          const nextZh = origIsKo ? trTxt : o;
          let updated = false;
          state.notifications.forEach(n => {
            if (!n) return;
            if (n.msgId === msgId || (n.tab === 'translator' && (isPendingTransStr(n.bodyKo) || isPendingTransStr(n.bodyZh)))) {
              if (n.msgId && n.msgId !== msgId) return;
              n.bodyKo = nextKo;
              n.bodyZh = nextZh;
              updated = true;
            }
          });
          if (updated) {
            saveState(false);
            renderNotifications();
          }
        } catch (_) {}
      }
      window.__updateChatNotifsForMsg = updateChatNotifsForMsg;

      function pushNotification(icon, titleKo, titleZh, bodyKo, bodyZh, targetTab, targetSub, category, silent, authorRole, msgId) {
        try {
          let _bK = String(bodyKo || '');
          let _bZ = String(bodyZh || '');
          if (isPendingTransStr(_bK) && _bZ && !isPendingTransStr(_bZ)) _bK = _bZ;
          if (isPendingTransStr(_bZ) && _bK && !isPendingTransStr(_bK)) _bZ = _bK;
          if (/[\u4e00-\u9fff]/.test(_bK) && !/[가-힣]/.test(_bK) && /[가-힣]/.test(_bZ)) { const tmp = _bK; _bK = _bZ; _bZ = tmp; }
          bodyKo = _bK; bodyZh = _bZ;
        } catch (_) {}
        // Strict Partner-Only Alert Filter: ONLY partner's incoming events ever trigger alerts!
        const myRole = state.myRole || 'suwan';
        const partnerRole = myRole === 'suwan' ? 'jingchan' : 'suwan';
        const cleanAuthor = String(authorRole || '').trim();
        // If no authorRole is given (local self action) OR authorRole is myself, skip completely!
        if (!cleanAuthor || cleanAuthor === myRole || cleanAuthor !== partnerRole) return;
        // Smart notification deduplication: 90s TTL for chat/nudges (so repeated phrases like "응"/"밥 먹었어?" always ring later!), persistent only for static posts
        try {
          const isRepeatableOrChat = (targetTab === 'translator' || targetTab === 'home' || /하트|포옹|보고 싶|마음|拥抱|想你|心动/.test(String(titleKo || '') + String(bodyKo || '')));
          const fpKey = `${cleanAuthor}|${targetTab || ''}|${targetSub || ''}|${String(titleKo || '').trim()}|${String(bodyKo || '').trim().slice(0, 70)}`;
          const nowMs = Date.now();
          let seenMap = {};
          try {
            const raw = JSON.parse(localStorage.getItem('cw_notified_fp_v2') || '{}');
            if (raw && typeof raw === 'object' && !Array.isArray(raw)) seenMap = raw;
          } catch (_) {}
          const prevTs = Number(seenMap[fpKey] || 0);
          if (isRepeatableOrChat) {
            if (prevTs && (nowMs - prevTs) < 90000) return;
          } else {
            if (prevTs && (nowMs - prevTs) < 86400000 * 7) return;
          }
          seenMap[fpKey] = nowMs;
          const keys = Object.keys(seenMap);
          if (keys.length > 250) {
            keys.sort((a, b) => (seenMap[a] || 0) - (seenMap[b] || 0)).slice(0, keys.length - 200).forEach(k => delete seenMap[k]);
          }
          localStorage.setItem('cw_notified_fp_v2', JSON.stringify(seenMap));
        } catch (_) {}
        const inferredRole = cleanAuthor;
        const isSelfEvent = false;
        const nowStr = new Date().toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' });
        const item = {
          id: `ntf_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
          icon: icon || '💜', titleKo, titleZh: titleZh || titleKo,
          bodyKo, bodyZh: bodyZh || bodyKo, time: nowStr,
          tab: targetTab || 'home', sub: targetSub || '', category: category || 'post',
          unread: true, fromRole: inferredRole || 'partner', msgId: msgId || '', createdAt: Date.now()
        };
        if (!Array.isArray(state.notifications)) state.notifications = [];
        state.notifications.unshift(item);
        if (state.notifications.length > 40) state.notifications = state.notifications.slice(0, 40);
        saveState(false);
        renderNotifications();
        // Fire live top banner + OS notification for ALL partner events (Messenger, Heartbeat, Couple Space, etc.)
        if (!silent && !isSelfEvent) {
          showLiveBanner(item);
        }
      }

      function navigateToRoute(tab, sub) {
        const panel = document.getElementById('notifPanel');
        if (panel) panel.classList.add('hidden'); document.getElementById('notifBackdrop')?.classList.add('hidden');
        switchTab(tab || 'home');
        if (tab === 'translator') switchTransSubtab(sub || 'messenger');
        if (tab === 'diary' && sub) switchDiarySubtab(sub);
        if (tab === 'learn' && sub && typeof switchLearnSubtab === 'function') switchLearnSubtab(sub);
      }

      function renderHomeLiveNotifs() {
        const card = document.getElementById('homeLiveNotifCard');
        const list = document.getElementById('homeLiveNotifList');
        const heading = document.getElementById('homeLiveNotifHeading');
        const clearBtn = document.getElementById('homeClearLiveNotifBtn');
        if (!card || !list) return;
        const isZh = state.lang === 'zh';
        const curRole = state.myRole || 'suwan';
        const unread = (state.notifications || []).filter(n => n && n.unread && n.fromRole !== curRole);
        if (!unread.length) {
          card.classList.add('hidden');
          return;
        }
        card.classList.remove('hidden');
        if (heading) heading.textContent = isZh ? `实时新消息 · ${unread.length}条` : `실시간 새 알림 · ${unread.length}건`;
        if (clearBtn) clearBtn.textContent = isZh ? '✓ 全部已读' : '✓ 모두 읽음';
        list.innerHTML = unread.slice(0, 3).map(n => `
          <div class="royal-subcard rounded-2xl px-3 py-2.5 flex items-center gap-2.5 border transition" style="border-color: var(--border-accent); background: var(--surface-elevated);">
            <button type="button" class="home-live-notif-item flex-1 min-w-0 text-left flex items-start gap-2.5" data-nid="${escapeHtml(n.id)}" data-tab="${escapeHtml(n.tab || 'home')}" data-sub="${escapeHtml(n.sub || '')}">
              <span class="w-8 h-8 rounded-xl flex items-center justify-center text-sm shrink-0" style="background: var(--accent-royal-soft);">${escapeHtml(n.icon || '💜')}</span>
              <div class="min-w-0 flex-1">
                <div class="flex items-center justify-between gap-2">
                  <span class="text-[11.5px] font-bold truncate text-gold">${escapeHtml(isZh ? (n.titleZh || n.titleKo) : (n.titleKo || n.titleZh))}</span>
                  <span class="text-[10px] text-mut shrink-0">${escapeHtml(n.time || '')}</span>
                </div>
                <div class="text-[11px] text-sec truncate mt-0.5">${escapeHtml(isZh ? (n.bodyZh || n.bodyKo) : (n.bodyKo || n.bodyZh))}</div>
              </div>
            </button>
            <div class="flex items-center gap-1 shrink-0">
              <button type="button" class="notif-unified-read btn-ghost w-6 h-6 rounded-full flex items-center justify-center text-[10px] text-emerald-600" data-nid="${escapeHtml(n.id)}" title="${isZh ? '标为已读' : '읽음 처리'}">✓</button>
              <button type="button" class="notif-unified-del btn-ghost w-6 h-6 rounded-full flex items-center justify-center text-[10px] text-mut hover:text-rose-500" data-nid="${escapeHtml(n.id)}" title="${isZh ? '删除' : '지우기'}">✕</button>
            </div>
          </div>
        `).join('');
        list.querySelectorAll('.home-live-notif-item').forEach(btn => {
          btn.addEventListener('click', () => {
            const nid = btn.getAttribute('data-nid');
            const target = (state.notifications || []).find(x => x && x.id === nid);
            if (target) target.unread = false;
            saveState(false);
            renderNotifications();
            navigateToRoute(btn.getAttribute('data-tab') || 'home', btn.getAttribute('data-sub') || '');
          });
        });
        list.querySelectorAll('.notif-unified-read').forEach(btn => {
          btn.addEventListener('click', (e) => {
            e.stopPropagation();
            const target = (state.notifications || []).find(x => x && x.id === btn.getAttribute('data-nid'));
            if (target) target.unread = false;
            saveState(false); renderNotifications();
          });
        });
        list.querySelectorAll('.notif-unified-del').forEach(btn => {
          btn.addEventListener('click', (e) => {
            e.stopPropagation();
            const nid = btn.getAttribute('data-nid');
            state.notifications = (state.notifications || []).filter(x => x && x.id !== nid);
            saveState(false); renderNotifications();
          });
        });
      }

      function clearAllAppBadgesAndOsNotifs() {
        try {
          if (window.ChanwanNative && typeof window.ChanwanNative.clearNotifications === 'function') {
            try { window.ChanwanNative.clearNotifications(); } catch (_) {}
          }
          if (typeof navigator.setAppBadge === 'function') navigator.setAppBadge(0).catch(() => {});
          if (typeof navigator.clearAppBadge === 'function') navigator.clearAppBadge().catch(() => {});
          if ('serviceWorker' in navigator) {
            if (navigator.serviceWorker.controller) {
              try { navigator.serviceWorker.controller.postMessage({ type: 'CLEAR_APP_BADGE' }); } catch (_) {}
            }
            navigator.serviceWorker.ready.then(reg => {
              if (!reg) return;
              if (reg.active) { try { reg.active.postMessage({ type: 'CLEAR_APP_BADGE' }); } catch (_) {} }
              if (typeof reg.clearAppBadge === 'function') reg.clearAppBadge().catch(() => {});
              if (typeof reg.setAppBadge === 'function') reg.setAppBadge(0).catch(() => {});
              if (reg.getNotifications) {
                reg.getNotifications().then(list => {
                  if (Array.isArray(list)) list.forEach(n => { try { n.close(); } catch (_) {} });
                }).catch(() => {});
              }
            }).catch(() => {});
          }
        } catch (_) {}
      }

      function renderNotifications() {
        // Sync Home-Screen Installed PWA Icon Red Badge Number (Android / iOS 16.4+ / Samsung One UI)
        try {
          const _myR = (state && state.myRole) || 'suwan';
          const _uCnt = (Array.isArray(state && state.notifications) ? state.notifications : []).filter(n => n && n.unread && n.fromRole !== _myR).length;
          if (_uCnt > 0 && typeof navigator.setAppBadge === 'function') {
            navigator.setAppBadge(_uCnt).catch(() => {});
          } else if (_uCnt === 0) {
            clearAllAppBadgesAndOsNotifs();
          }
        } catch (_) {}
        const curMyRole = state.myRole || 'suwan';
        if (Array.isArray(state.notifications)) {
          state.notifications = state.notifications.filter(n => !n || n.fromRole !== curMyRole);
        }
        renderHomeLiveNotifs();
        const all = state.notifications || [];
        try {
          const chatMsgs = (state.chat && Array.isArray(state.chat.messages)) ? state.chat.messages : [];
          all.forEach(n => {
            if (!n || n.tab !== 'translator') return;
            if (isPendingTransStr(n.bodyKo) || isPendingTransStr(n.bodyZh)) {
              const matched = n.msgId
                ? chatMsgs.find(m => m && m.id === n.msgId)
                : chatMsgs.slice().reverse().find(m => m && m.time === n.time && m.translated && !isPendingTransStr(m.translated));
              if (matched && matched.translated && !isPendingTransStr(matched.translated)) {
                const o = String(matched.original || '');
                const origIsKo = /[가-힣]/.test(o) && !/[\u4e00-\u9fff]/.test(o);
                n.bodyKo = origIsKo ? o : matched.translated;
                n.bodyZh = origIsKo ? matched.translated : o;
              } else if (matched && matched.original) {
                n.bodyKo = matched.original;
                n.bodyZh = matched.original;
              }
            }
          });
        } catch (_) {}
        const __notifMyRole = state.myRole || 'suwan';
        const __nowNotifTs = Date.now();
        const unreadCount = all.filter(n => n && n.unread && n.fromRole !== __notifMyRole && (!n.createdAt || (__nowNotifTs - Number(n.createdAt)) < 86400000)).length;
        const badge = document.getElementById('notifBadgeCount');
        if (badge) {
          if (unreadCount > 0) {
            badge.textContent = unreadCount > 9 ? '9+' : String(unreadCount);
            badge.classList.remove('hidden');
          } else {
            badge.classList.add('hidden');
          }
        }
        const soundBtn = document.getElementById('toggleSoundBtn');
        if (soundBtn) soundBtn.textContent = state.settings.notifSound ? (state.lang === 'zh' ? '🔔开' : '🔔ON') : (state.lang === 'zh' ? '🔕关' : '🔕OFF');
        updateSysNotifStatus();

        document.querySelectorAll('.notif-filter-btn').forEach(btn => {
          const isAct = btn.getAttribute('data-filter') === activeNotifFilter;
          btn.className = `notif-filter-btn ${isAct ? 'btn-royal' : 'btn-ghost'} px-2.5 py-1 rounded-full text-[10px] font-semibold`;
        });

        const filtered = all.filter(n => {
          if (activeNotifFilter === 'post') return n.category === 'post';
          if (activeNotifFilter === 'unread') return n.unread;
          return true;
        });

        const container = document.getElementById('notifList');
        if (!container) return;
        const isZh = state.lang === 'zh';
        if (!filtered.length) {
          container.innerHTML = `<div class="text-xs text-mut text-center py-6">${isZh ? '暂无新动态通知 ✨' : '새글 알림이 없습니다 ✨'}</div>`;
          return;
        }
        container.innerHTML = filtered.map(n => `
          <div class="royal-subcard rounded-2xl p-2.5 flex items-center gap-2.5 border transition ${n.unread ? 'shadow-xs' : 'opacity-75'}" style="border-color: ${n.unread ? 'var(--border-accent)' : 'var(--border-subtle)'}; background: ${n.unread ? 'linear-gradient(135deg, var(--accent-royal-soft), var(--surface-1))' : 'var(--surface-1)'};">
            <button type="button" class="notif-row flex-1 min-w-0 text-left flex items-start gap-2.5" data-id="${escapeHtml(n.id)}" data-tab="${escapeHtml(n.tab || 'home')}" data-sub="${escapeHtml(n.sub || '')}">
              <span class="w-8 h-8 rounded-xl flex items-center justify-center text-sm shrink-0 mt-0.5" style="background: var(--surface-elevated);">${escapeHtml(n.icon)}</span>
              <div class="min-w-0 flex-1">
                <div class="flex items-center justify-between gap-1.5">
                  <span class="text-[11px] font-bold truncate ${n.unread ? 'text-gold' : 'text-sec'}">${escapeHtml(isZh ? n.titleZh : n.titleKo)}</span>
                  <span class="text-[10px] text-mut shrink-0">${escapeHtml(n.time)}</span>
                </div>
                <div class="text-[11px] text-sec leading-snug mt-0.5 break-words">${escapeHtml(isZh ? n.bodyZh : n.bodyKo)}</div>
              </div>
            </button>
            <div class="flex flex-col items-center gap-1 shrink-0">
              ${n.unread ? `<button type="button" class="notif-panel-read btn-ghost w-6 h-6 rounded-full flex items-center justify-center text-[10px] text-emerald-600" data-id="${escapeHtml(n.id)}" title="${isZh ? '标为已读' : '읽음 처리'}">✓</button>` : ''}
              <button type="button" class="notif-panel-del btn-ghost w-6 h-6 rounded-full flex items-center justify-center text-[10px] text-mut hover:text-rose-500" data-id="${escapeHtml(n.id)}" title="${isZh ? '删除' : '지우기'}">✕</button>
            </div>
          </div>
        `).join('');

        container.querySelectorAll('.notif-row').forEach(btn => {
          btn.addEventListener('click', () => {
            const found = state.notifications.find(x => x.id === btn.getAttribute('data-id'));
            if (found) found.unread = false;
            saveState(false); renderNotifications();
            document.getElementById('notifPanel')?.classList.add('hidden'); document.getElementById('notifBackdrop')?.classList.add('hidden');
            navigateToRoute(btn.getAttribute('data-tab'), btn.getAttribute('data-sub'));
          });
        });
        container.querySelectorAll('.notif-panel-read').forEach(btn => {
          btn.addEventListener('click', (e) => {
            e.stopPropagation();
            const found = state.notifications.find(x => x.id === btn.getAttribute('data-id'));
            if (found) found.unread = false;
            saveState(false); renderNotifications();
          });
        });
        container.querySelectorAll('.notif-panel-del').forEach(btn => {
          btn.addEventListener('click', (e) => {
            e.stopPropagation();
            const nid = btn.getAttribute('data-id');
            state.notifications = (state.notifications || []).filter(x => x && x.id !== nid);
            saveState(false); renderNotifications();
          });
        });
      }

      /* ============================================================
         4. BEST-IN-CLASS MULTI-ENGINE TRANSLATOR (Gemini 2.5 + Google Neural + MyMemory)
         ============================================================ */
      let activeToneMode = 'lover'; // lover | casual | polite

      const CURATED_TRANSLATIONS = [
        { ko: '보고 싶어', zh: '好想你', pinyin: 'hǎo xiǎng nǐ', literal: '네가 너무 보고 싶어', tone: '💜 그리움 · 애정', nuance: '단순한 想你(보고 싶어)보다 好(정말/너무)를 붙여 연인 사이의 애틋하고 따뜻한 그리움을 자연스럽게 전달합니다.', alts: ['想见你 (만나고 싶어)', '超级想你 (엄청 보고 싶어)'] },
        { ko: '보고 싶어서 잠이 안 와', zh: '想你想得睡不着', pinyin: 'xiǎng nǐ xiǎng de shuì bu zháo', literal: '네가 보고 싶어서 잠들 수 없어', tone: '🌙 깊은 그리움', nuance: '중국어 연인 대화에서 자주 쓰이는 로맨틱한 표현입니다.', alts: ['太想你了，睡不着', '脑子里全是你'] },
        { ko: '오늘 하루도 정말 수고 많았어, 푹 쉬어', zh: '今天一天也辛苦了，好好休息吧', pinyin: 'jīntiān yītiān yě xīnkǔ le, hǎohǎo xiūxi ba', literal: '오늘 하루도 고생했어, 푹 쉬어', tone: '✨ 따뜻한 위로', nuance: '辛苦了와 好好休息吧를 함께 쓰면 하루를 마친 연인을 다정하게 토닥여 줍니다.', alts: ['今天辛苦啦，早点休息', '你今天真棒，好好放松一下吧'] },
        { ko: '사랑해', zh: '我爱你', pinyin: 'wǒ ài nǐ', literal: '너를 사랑해', tone: '❤️ 깊은 사랑', nuance: '진심을 담아 사랑을 고백할 때 쓰는 가장 직관적인 표현입니다.', alts: ['好爱你', '爱你哟'] },
        { ko: '잘 자, 내 꿈 꿔', zh: '晚安，祝你梦到我', pinyin: 'wǎn ān, zhù nǐ mèng dào wǒ', literal: '잘 자, 내 꿈 꾸길 바라', tone: '🌙 로맨틱 굿나잇', nuance: '晚安(완안)은 중국어에서 "我爱你爱你"의 약자로도 통하는 다정한 밤 인사입니다.', alts: ['晚安好梦', '梦里见'] },
        { ko: '我好想你，早点休息吧', zh: '我好想你，早点休息吧', koAlt: '정말 많이 보고 싶어, 일찍 푹 쉬어', pinyin: 'wǒ hǎo xiǎng nǐ, zǎodiǎn xiūxi ba', literal: '나 네가 정말 보고 싶어, 일찍 쉬어', tone: '💜 애틋함 · 배려', nuance: '그리움과 다정한 걱정이 어우러진 연인 표현입니다.', alts: ['너무 보고 싶다, 오늘은 일찍 자', '많이 그리워, 푹 쉬어'] },
        { ko: '今天天气真冷，记得多穿点衣服', zh: '今天天气真冷，记得多穿点衣服', koAlt: '오늘 날씨가 정말 춥네, 옷 따뜻하게 챙겨 입는 거 잊지 마', pinyin: 'jīntiān tiānqì zhēn lěng, jìde duō chuān diǎn yīfu', literal: '오늘 날씨 진짜 춥다, 옷 좀 더 입어', tone: '🧣 다정한 챙김', nuance: '记得(~하는 거 잊지 마)는 사랑하는 사람을 챙기는 따뜻한 당부입니다.', alts: ['오늘 많이 춥다, 따뜻하게 입어', '겉옷 든든히 챙겨'] },
        { ko: '뭐해', zh: '在干嘛呀？', pinyin: 'zài gàn ma ya', literal: '지금 뭐 하고 있어?', tone: '💬 친근한 안부', nuance: '연인이나 친한 사이에 가장 자주 쓰는 표현으로, 끝에 呀(ya)를 붙이면 훨씬 다정해져요.', alts: ['在做什么呢？', '干嘛呢？'] },
        { ko: '뭐해요', zh: '在做什么呢？', pinyin: 'zài zuò shén me ne', literal: '무엇을 하고 계세요?', tone: '☀️ 부드러운 존댓말', nuance: '정중하면서도 다정하게 근황을 묻는 표현입니다.', alts: ['在忙什么呢？', '现在在干嘛呀？'] },
        { ko: '지금 뭐해', zh: '现在在干嘛呀？', pinyin: 'xiàn zài zài gàn ma ya', literal: '지금 뭐 하고 있어?', tone: '💜 다정한 연인체', nuance: '지금 당장 상대방이 무엇을 하는지 궁금할 때 쓰는 표현입니다.', alts: ['现在忙吗？', '此刻在干嘛呢？'] },
        { ko: '밥 먹었어', zh: '吃饭了吗？', pinyin: 'chī fàn le ma', literal: '밥 먹었니?', tone: '🍚 따뜻한 챙김', nuance: '한국과 중국 모두에서 애정을 담아 건네는 대표 안부 인사입니다.', alts: ['吃过饭了吗？', '好好吃饭了吗？'] },
        { ko: '어디야', zh: '在哪里呀？', pinyin: 'zài nǎ lǐ ya', literal: '지금 어디에 있어?', tone: '📍 일상 안부', nuance: '약속 전이나 이동 중 위치를 다정하게 물을 때 씁니다.', alts: ['到哪儿啦？', '现在在哪呢？'] },
        { ko: '안녕', zh: '嗨，你好呀', pinyin: 'hāi, nǐ hǎo ya', literal: '안녕', tone: '☀️ 반가운 인사', nuance: '친근하고 밝게 건네는 기본 인사입니다.', alts: ['哈喽~', '你好呀'] },
        { ko: '안녕하세요', zh: '您好', pinyin: 'nín hǎo', literal: '안녕하세요', tone: '🎩 정중한 인사', nuance: '처음 만나는 분이나 어른께 쓰는 공손한 인사입니다.', alts: ['你好', '初次见面，您好'] },
        { ko: '고마워', zh: '谢谢你呀', pinyin: 'xiè xie nǐ ya', literal: '고마워', tone: '💐 따뜻한 감사', nuance: '친한 사이나 연인 사이에 부드럽게 고마움을 전할 때 씁니다.', alts: ['太感谢你了', '多亏了你'] },
        { ko: '미안해', zh: '对不起呀', pinyin: 'duì bu qǐ ya', literal: '미안해', tone: '🙏 진심 어린 사과', nuance: '진심을 담아 미안함을 전하는 표현입니다.', alts: ['不好意思', '我错了，别生气'] },
        { ko: '괜찮아', zh: '没关系，没事的', pinyin: 'méi guān xi, méi shì de', literal: '괜찮아, 별일 아니야', tone: '🌙 따뜻한 위로', nuance: '상대방의 걱정을 덜어줄 때 쓰는 다정한 표현입니다.', alts: ['别在意', '不要紧的'] },
        { ko: '배고파', zh: '我肚子饿啦', pinyin: 'wǒ dù zi è la', literal: '배가 고파', tone: '🍽️ 일상 표현', nuance: '귀엽게 배고픔을 표현할 때 啦(la)를 붙이면 자연스러워요.', alts: ['好饿呀', '想吃好吃的'] },
        { ko: '졸려', zh: '好困呀', pinyin: 'hǎo kùn ya', literal: '너무 졸려', tone: '😴 일상 표현', nuance: '밤늦게 연락할 때 졸리다고 귀엽게 말하는 표현입니다.', alts: ['困死了', '想睡觉了'] },
        { ko: '피곤해', zh: '好累呀', pinyin: 'hǎo lèi ya', literal: '너무 피곤해', tone: '🌙 일상 표현', nuance: '하루 일과를 마치고 지쳤을 때 쓰는 표현입니다.', alts: ['今天好辛苦', '累坏了'] },
        { ko: '심심해', zh: '好无聊呀', pinyin: 'hǎo wú liáo ya', literal: '심심해', tone: '💬 일상 표현', nuance: '할 일이 없어 상대방과 놀고 싶을 때 쓰는 말입니다.', alts: ['陪我聊聊天吧', '有点无聊呢'] },
        { ko: '귀여워', zh: '好可爱呀', pinyin: 'hǎo kě ài ya', literal: '너무 귀여워', tone: '💜 애정 칭찬', nuance: '상대방의 행동이나 사진이 귀여울 때 쓰는 칭찬입니다.', alts: ['太可爱了', '怎么这么可爱'] },
        { ko: '예뻐', zh: '好漂亮呀', pinyin: 'hǎo piào liang ya', literal: '너무 예뻐', tone: '🌸 애정 칭찬', nuance: '외모나 분위기를 칭찬할 때 가장 자연스러운 표현입니다.', alts: ['真美', '今天特别好看'] },
        { ko: '멋있어', zh: '好帅呀', pinyin: 'hǎo shuài ya', literal: '너무 멋있어', tone: '✨ 애정 칭찬', nuance: '상대방이 멋져 보일 때 쓰는 칭찬 표현입니다.', alts: ['太帅了', '超有魅力'] },
        { ko: '잘 잤어', zh: '睡得好吗？', pinyin: 'shuì de hǎo ma', literal: '잠 잘 잤어?', tone: '☀️ 아침 인사', nuance: '아침에 일어나 다정하게 건네는 안부입니다.', alts: ['早安，睡醒了吗？', '昨晚睡得香吗？'] },
        { ko: '잘 자', zh: '晚安，好梦', pinyin: 'wǎn ān, hǎo mèng', literal: '잘 자, 좋은 꿈 꿔', tone: '🌙 밤 인사', nuance: '잠들기 전 다정하게 전하는 굿나잇 인사입니다.', alts: ['早点睡哦', '做个好梦'] },
        { ko: '집에 왔어', zh: '我到家啦', pinyin: 'wǒ dào jiā la', literal: '집에 도착했어', tone: '🏠 안심 보고', nuance: '무사히 귀가했다고 알려줄 때 쓰는 표현입니다.', alts: ['安全到家了', '刚进家门'] },
        { ko: '조심해서 가', zh: '路上小心哦', pinyin: 'lù shàng xiǎo xīn o', literal: '길 조심해서 가', tone: '🌙 다정한 배려', nuance: '헤어질 때 안전을 당부하는 따뜻한 말입니다.', alts: ['注意安全', '到了发消息给我'] },
        { ko: '화이팅', zh: '加油呀！', pinyin: 'jiā yóu ya', literal: '힘내!', tone: '🔥 응원', nuance: '상대방을 응원할 때 쓰는 밝은 표현입니다.', alts: ['你可以的！', '打起精神！'] },
        { ko: '기다릴게', zh: '我等你哦', pinyin: 'wǒ děng nǐ o', literal: '너를 기다릴게', tone: '💜 다정한 약속', nuance: '편안하게 기다리겠다는 따뜻한 마음을 전합니다.', alts: ['慢慢来，我等你', '随时等你'] },
        { ko: '알겠어', zh: '好哒，知道啦', pinyin: 'hǎo da, zhī dào la', literal: '응, 알겠어', tone: '💬 다정한 대답', nuance: '딱딱하지 않고 귀엽게 수긍하는 연인체 표현입니다.', alts: ['明白啦', '好的呀'] },
        { ko: '진짜', zh: '真的吗？', pinyin: 'zhēn de ma', literal: '정말이야?', tone: '✨ 리액션', nuance: '놀라거나 되물을 때 쓰는 자연스러운 표현입니다.', alts: ['真的假的？', '不会吧'] },
        { ko: '수고했어', zh: '辛苦啦', pinyin: 'xīn kǔ la', literal: '고생했어', tone: '🌙 따뜻한 위로', nuance: '하루를 마친 상대방에게 건네는 최고의 위로입니다.', alts: ['今天辛苦你了', '好好休息吧'] },
        { ko: '고생해', zh: '辛苦啦，加油哦', pinyin: 'xīn kǔ la, jiā yóu o', literal: '고생해, 힘내', tone: '💪 다정한 응원', nuance: '일하거나 바쁜 상대방을 다정하게 응원하는 일상 표현입니다.', alts: ['辛苦你啦', '加油哦'] },
        { ko: '고생해요', zh: '辛苦啦，加油哦', pinyin: 'xīn kǔ la, jiā yóu o', literal: '고생해요', tone: '💪 다정한 응원', nuance: '부드럽게 상대를 격려하는 한국어 일상 표현입니다.', alts: ['辛苦你啦', '注意休息哦'] },
        { ko: '수고해', zh: '辛苦啦，加油哦', pinyin: 'xīn kǔ la, jiā yóu o', literal: '수고해', tone: '💪 다정한 응원', nuance: '일·공부하는 상대에게 건네는 따뜻한 응원입니다.', alts: ['辛苦啦', '慢慢来别太累'] },
        { ko: '수고해요', zh: '辛苦啦，加油哦', pinyin: 'xīn kǔ la, jiā yóu o', literal: '수고해요', tone: '💪 다정한 응원', nuance: '부드러운 존댓말로 건네는 다정한 응원입니다.', alts: ['辛苦你了', '加油呀'] },
        { ko: '고생이 많아', zh: '你辛苦啦，别太累着自己', pinyin: 'nǐ xīn kǔ la, bié tài lèi zhe zì jǐ', literal: '고생이 많아', tone: '🌙 따뜻한 위로', nuance: '상대의 노고를 알아주며 다독이는 표현입니다.', alts: ['真辛苦你了', '辛苦啦宝贝'] },
        { ko: '고생했어', zh: '辛苦啦', pinyin: 'xīn kǔ la', literal: '고생했어', tone: '🌙 따뜻한 위로', nuance: '오늘 하루 애쓴 상대에게 건네는 따뜻한 위로입니다.', alts: ['今天辛苦啦', '好好休息吧'] },
        { ko: '오늘도 화이팅', zh: '今天也要加油哦！', pinyin: 'jīn tiān yě yào jiā yóu o', literal: '오늘도 힘내!', tone: '💪 다정한 응원', nuance: '하루를 시작하며 에너지를 불어넣는 응원입니다.', alts: ['今天加油呀', '今天也要元气满满哦'] },
        { ko: '화이팅', zh: '加油哦！', pinyin: 'jiā yóu o', literal: '파이팅!', tone: '💪 다정한 응원', nuance: '짧고 힘차게 응원할 때 쓰는 표현입니다.', alts: ['加油呀', '你可以的！'] },
        { ko: '힘내', zh: '加油呀！', pinyin: 'jiā yóu ya', literal: '힘내!', tone: '💪 다정한 응원', nuance: '지친 상대를 다정하게 응원하는 말입니다.', alts: ['打起精神来哦', '加油宝贝'] },
        { ko: '출근했어', zh: '到公司上班了吗？', pinyin: 'dào gōng sī shàng bān le ma', literal: '출근했어?', tone: '☀️ 일상 안부', nuance: '아침에 무사히 출근했는지 묻는 일상 안부입니다.', alts: ['上班了吗？', '已经到公司了吗？'] },
        { ko: '퇴근했어', zh: '下班了吗？', pinyin: 'xià bān le ma', literal: '퇴근했어?', tone: '🌆 일상 안부', nuance: '일과를 마쳤는지 다정하게 묻는 표현입니다.', alts: ['忙完了吗？', '准备下班了吗？'] },
        { ko: '출근 중', zh: '正在去上班的路上', pinyin: 'zhèng zài qù shàng bān de lù shàng', literal: '출근하는 중', tone: '🚶 일상 공유', nuance: '출근길에 짧게 보내는 상태 공유입니다.', alts: ['在上班路上呢', '正去上班呢'] },
        { ko: '퇴근 중', zh: '正在下班回家路上', pinyin: 'zhèng zài xià bān huí jiā lù shàng', literal: '퇴근하는 중', tone: '🚶 일상 공유', nuance: '퇴근길에 짧게 보내는 상태 공유입니다.', alts: ['在下班路上啦', '刚下班正回家'] },
        { ko: '일하는 중', zh: '正在忙工作呢', pinyin: 'zhèng zài máng gōng zuò ne', literal: '일하는 중', tone: '💻 일상 공유', nuance: '근무 중임을 짧게 알리는 표현입니다.', alts: ['在工作呢', '正上班呢'] },
        { ko: '밥 먹는 중', zh: '正在吃饭呢', pinyin: 'zhèng zài chī fàn ne', literal: '밥 먹는 중', tone: '🍚 일상 공유', nuance: '식사 중임을 알리는 짧은 일상 표현입니다.', alts: ['在吃饭啦', '正吃着呢'] },
        { ko: '집에 왔어', zh: '我到家啦', pinyin: 'wǒ dào jiā la', literal: '집에 왔어', tone: '🏠 안심 보고', nuance: '무사히 귀가했음을 알리는 다정한 보고입니다.', alts: ['回到家啦', '到家了哦'] },
        { ko: '집 도착', zh: '到家啦', pinyin: 'dào jiā la', literal: '집 도착', tone: '🏠 안심 보고', nuance: '짧게 귀가를 알리는 카톡 표현입니다.', alts: ['我到家了', '安全到家啦'] },
        { ko: '씻고 올게', zh: '我去洗个澡就来', pinyin: 'wǒ qù xǐ gè zǎo jiù lái', literal: '씻고 올게', tone: '🛁 일상 공유', nuance: '잠깐 씻고 다시 연락하겠다는 일상 표현입니다.', alts: ['我先去洗漱一下', '去洗个澡马上回来'] },
        { ko: '이제 자려고', zh: '我准备睡觉啦', pinyin: 'wǒ zhǔn bèi shuì jiào la', literal: '이제 자려고', tone: '🌙 밤 인사', nuance: '잠들기 직전에 보내는 다정한 표현입니다.', alts: ['要睡觉啦', '准备躺下睡了'] },
        { ko: '잠깐만', zh: '等我一下哦', pinyin: 'děng wǒ yī xià o', literal: '잠깐만', tone: '💬 일상 대화', nuance: '잠시만 기다려 달라는 부드러운 표현입니다.', alts: ['稍等一下呀', '马上好'] },
        { ko: '금방 갈게', zh: '我马上就来', pinyin: 'wǒ mǎ shàng jiù lái', literal: '금방 갈게', tone: '💬 일상 대화', nuance: '곧 돌아오거나 도착하겠다는 표현입니다.', alts: ['马上就到', '等我一下马上来'] },
        { ko: '조심해서 가', zh: '路上小心哦', pinyin: 'lù shàng xiǎo xīn o', literal: '조심해서 가', tone: '💜 다정한 챙김', nuance: '상대의 안전을 챙기는 따뜻한 배려입니다.', alts: ['注意安全呀', '慢点走，到了告诉我'] },
        { ko: '조심해서 와', zh: '路上小心点过来哦', pinyin: 'lù shàng xiǎo xīn diǎn guò lái o', literal: '조심해서 와', tone: '💜 다정한 챙김', nuance: '오는 길 안전을 챙기는 다정한 인사입니다.', alts: ['过来路上注意安全呀', '慢点过来哦'] },
        { ko: '헐', zh: '天哪！', pinyin: 'tiān na', literal: '헐!', tone: '😮 리액션', nuance: '깜짝 놀랐을 때 쓰는 한국어 특유의 감탄사입니다.', alts: ['哇塞', '不是吧'] },
        { ko: '대박', zh: '太厉害了吧！', pinyin: 'tài lì hài le ba', literal: '대박!', tone: '✨ 감탄', nuance: '놀랍거나 멋질 때 쓰는 한국어 일상 감탄사입니다.', alts: ['绝了！', '太牛了吧'] },
        { ko: '어이없어', zh: '真是无语了', pinyin: 'zhēn shì wú yǔ le', literal: '어이없어', tone: '😅 일상 리액션', nuance: '황당하거나 어처구니없을 때 쓰는 구어체입니다.', alts: ['太离谱了吧', '无语死了'] },
        { ko: '웃겨', zh: '笑死我了', pinyin: 'xiào sǐ wǒ le', literal: '웃겨', tone: '😆 유쾌함', nuance: '재미있고 웃길 때 쓰는 짧은 리액션입니다.', alts: ['太搞笑啦', '好好笑哈哈'] },
        { ko: '귀여워', zh: '好可爱呀', pinyin: 'hǎo kě ài ya', literal: '귀여워', tone: '🥰 달콤한 칭찬', nuance: '상대방이 사랑스럽고 귀여울 때 쓰는 말입니다.', alts: ['太可爱了吧', '可爱死了'] },
        { ko: '오키', zh: '好哒！', pinyin: 'hǎo da', literal: '오키!', tone: '💬 가벼운 대답', nuance: '가볍고 귀엽게 OK라고 답할 때 씁니다.', alts: ['OK啦', '没问题呀'] },
        { ko: '콜', zh: '没问题，就这么定了！', pinyin: 'méi wèn tí, jiù zhè me dìng le', literal: '콜!', tone: '😆 유쾌한 수락', nuance: '상대 제안에 흔쾌히 동의할 때 쓰는 구어체입니다.', alts: ['好呀，一言为定', '成交！'] },
        { ko: '당연하지', zh: '那当然啦', pinyin: 'nà dāng rán la', literal: '당연하지', tone: '💜 다정한 대답', nuance: '확신을 담아 다정하게 답하는 표현입니다.', alts: ['当然咯', '必须的呀'] },
        { ko: '배고파', zh: '我好饿呀', pinyin: 'wǒ hǎo è ya', literal: '배고파', tone: '🍚 일상 투정', nuance: '배고프다고 귀엽게 말하는 일상 표현입니다.', alts: ['饿死了', '好想吃东西'] },
        { ko: '졸려', zh: '好困呀', pinyin: 'hǎo kùn ya', literal: '졸려', tone: '😴 일상 공유', nuance: '졸릴 때 짧게 보내는 일상 표현입니다.', alts: ['困死了', '有点困了'] },
        { ko: '심심해', zh: '好无聊呀', pinyin: 'hǎo wú liáo ya', literal: '심심해', tone: '💬 일상 투정', nuance: '심심해서 상대와 놀고 싶을 때 보내는 말입니다.', alts: ['无聊死了', '陪我聊聊天嘛'] },
        { ko: '옥수수', zh: '玉米', pinyin: 'yù mǐ', literal: '옥수수', tone: '🌽 일상 단어', nuance: '옥수수를 뜻하는 일상 단어입니다.', alts: ['甜玉米', '烤玉米'] },
        { ko: '在干嘛', zh: '在干嘛', koAlt: '뭐 하고 있어?', pinyin: 'zài gàn ma', literal: '뭐 해?', tone: '💬 친근한 안부', nuance: '중국어에서 가장 흔하게 쓰는 "뭐해?" 표현입니다.', alts: ['뭐해?', '지금 뭐 하고 있어?'] },
        { ko: '想你了', zh: '想你了', koAlt: '보고 싶어졌어', pinyin: 'xiǎng nǐ le', literal: '네가 보고 싶어', tone: '💜 그리움', nuance: '문득 상대방이 그리워졌을 때 쓰는 따뜻한 표현입니다.', alts: ['보고 싶어', '네 생각 나네'] },
        { ko: '吃饭了吗', zh: '吃饭了吗', koAlt: '밥 먹었어?', pinyin: 'chī fàn le ma', literal: '식사했니?', tone: '🍚 따뜻한 안부', nuance: '식사를 챙겨주는 다정한 안부 인사입니다.', alts: ['식사하셨어요?', '밥 챙겨 먹었어?'] },
        { ko: '晚安', zh: '晚安', koAlt: '잘 자, 좋은 꿈 꿔', pinyin: 'wǎn ān', literal: '평안한 밤', tone: '🌙 밤 인사', nuance: '중국어에서 연인에게 "我爱你(사랑해)"의 뉘앙스도 담긴 다정한 밤 인사입니다.', alts: ['잘 자요', '푹 자'] },
        { ko: '여기 너무 예쁘다', zh: '这里好漂亮呀', pinyin: 'zhè lǐ hǎo piào liang ya', literal: '여기 정말 예쁘다', tone: '🌸 감탄 · 공유', nuance: '예쁜 풍경이나 카페 사진을 보낼 때 가장 자연스러운 말투예요.', alts: ['这里太美了', '风景真好看'] },
        { ko: '오늘 하늘 예뻐', zh: '今天的天空好美呀', pinyin: 'jīn tiān de tiān kōng hǎo měi ya', literal: '오늘 하늘이 예쁘다', tone: '🌤️ 감성 공유', nuance: '하늘 사진을 공유하며 마음을 전할 때 쓰는 다정한 표현입니다.', alts: ['今天天气真好', '你看今天的天空'] },
        { ko: '지금 먹는 중', zh: '正在吃呢~', pinyin: 'zhèng zài chī ne', literal: '지금 먹고 있어', tone: '🍽️ 일상 공유', nuance: '음식 사진과 함께 보내면 딱 자연스러운 구어체입니다.', alts: ['在吃饭啦', '开动啦~'] },
        { ko: '맛있겠다', zh: '看起来好好吃呀', pinyin: 'kàn qǐ lái hǎo hǎo chī ya', literal: '정말 맛있어 보인다', tone: '🍽️ 리액션', nuance: '상대방이 보낸 음식 사진에 가장 기분 좋게 답하는 말입니다.', alts: ['好诱人呀', '我也想吃'] },
        { ko: '예쁘지', zh: '好看吧？', pinyin: 'hǎo kàn ba', literal: '예쁘지 않아?', tone: '✨ 애교 질문', nuance: '사진을 보내고 상대방의 반응을 귀엽게 물어볼 때 씁니다.', alts: ['漂亮吗？', '是不是很好看？'] },
        { ko: '귀엽지', zh: '可爱吧？', pinyin: 'kě ài ba', literal: '귀엽지 않아?', tone: '🐾 애교 질문', nuance: '귀여운 사진이나 셀카를 보낼 때 자주 쓰는 표현입니다.', alts: ['是不是很可爱？', '萌不萌？'] },
        { ko: '어때', zh: '怎么样呀？', pinyin: 'zěn me yàng ya', literal: '어떻게 생각해?', tone: '💬 일상 질문', nuance: '사진이나 옷, 장소를 보여주고 의견을 물을 때 자연스럽게 씁니다.', alts: ['你觉得怎么样？', '好看吗？'] },
        { ko: '도착했어', zh: '我到啦！', pinyin: 'wǒ dào la', literal: '도착했어', tone: '📍 안심 보고', nuance: '목적지에 무사히 도착했음을 밝게 알리는 표현입니다.', alts: ['刚到哦', '已经到了'] },
        { ko: '출발했어', zh: '我出发啦！', pinyin: 'wǒ chū fā la', literal: '출발했어', tone: '🚶 일상 보고', nuance: '약속 장소로 출발할 때 가볍게 보내는 표현입니다.', alts: ['在路上了', '刚出门'] },
        { ko: '今天天空好美', zh: '今天天空好美', koAlt: '오늘 하늘 너무 예쁘다', pinyin: 'jīn tiān tiān kōng hǎo měi', literal: '오늘 하늘이 정말 예쁘다', tone: '🌤️ 감성 공유', nuance: '하늘 사진을 찍어 보낼 때 쓰는 따뜻한 표현입니다.', alts: ['오늘 하늘 진짜 예뻐', '하늘 봐봐, 너무 예쁘지?'] },
        { ko: '好看吗', zh: '好看吗', koAlt: '예뻐? 어때?', pinyin: 'hǎo kàn ma', literal: '보기 좋아?', tone: '✨ 애교 질문', nuance: '사진이나 스타일을 보여주고 반응을 물을 때 쓰는 말입니다.', alts: ['괜찮아 보여?', '예쁘지?'] },
        { ko: '正在吃', zh: '正在吃', koAlt: '지금 먹고 있어~', pinyin: 'zhèng zài chī', literal: '먹는 중이야', tone: '🍽️ 일상 공유', nuance: '식사 사진을 보내며 자연스럽게 하는 말입니다.', alts: ['지금 먹는 중!', '맛있게 먹고 있어'] }
      ];

      function detectLanguage(text) {
        const koCount = (text.match(/[\uAC00-\uD7A3\u3131-\u318E]/g) || []).length;
        const zhCount = (text.match(/[\u4E00-\u9FFF]/g) || []).length;
        if (koCount >= zhCount && koCount > 0) return 'ko';
        if (zhCount > 0) return 'zh';
        return 'ko';
      }

      function analyzeNuanceHeuristics(original, translated, srcLang, toneMode) {
        const text = (original + ' ' + translated).toLowerCase();
        const isZh = state.lang === 'zh';
        const modeLabel = isZh
          ? (toneMode === 'polite' ? '礼貌敬语' : (toneMode === 'casual' ? '自然日常' : '甜蜜恋人语气'))
          : (toneMode === 'polite' ? '정중한 존댓말' : (toneMode === 'casual' ? '자연스러운 일상체' : '다정한 연인체'));
        let tone = `✨ ${modeLabel}`;
        let nuance = isZh
          ? (srcLang === 'ko'
              ? `保留了韩语原文的情感温度，以${modeLabel}自然译为中文。`
              : `结合中文原文的亲切语境，以${modeLabel}自然译为地道韩语。`)
          : (srcLang === 'ko'
              ? `한국어 원문의 감정을 살려 ${modeLabel} 어감의 자연스러운 중국어로 옮겼습니다.`
              : `중국어 원문의 친근하고 부드러운 뉘앙스를 살려 ${modeLabel} 한국어로 자연스럽게 번역했습니다.`);

        if (/보고\s?싶|그리워|想你|想见/.test(text)) {
          tone = isZh ? '💜 思念 · 浪漫' : '💜 그리움 · 애틋함';
          nuance = isZh ? '即使相隔两地，也能传递出满满思念与温柔爱意的浪漫表达。' : '떨어져 있어도 따뜻한 그리움이 진하게 전해지는 로맨틱한 뉘앙스입니다.';
        } else if (/사랑|좋아해|爱你|喜欢你|心动/.test(text)) {
          tone = isZh ? '❤️ 深情 · 心动' : '❤️ 깊은 애정 · 설렘';
          nuance = isZh ? '直白而真挚地表达了对彼此的喜欢与心动。' : '상대방을 향한 진심과 애정이 직접적으로 담겨 있습니다.';
        } else if (/수고|고생|쉬어|잘\s?자|辛苦|休息|晚安/.test(text)) {
          tone = isZh ? '🌙 温柔安慰 · 关心' : '🌙 따뜻한 위로 · 배려';
          nuance = isZh ? '抚慰一天的疲惫，体现细腻体贴的暖心关怀。' : '하루의 피로를 다독이고 상대방을 세심하게 챙기는 다정한 배려입니다.';
        } else if (/미안|죄송|잘못|对不起|抱歉/.test(text)) {
          tone = isZh ? '🙏 真诚致歉' : '🙏 진심 어린 사과';
          nuance = isZh ? '真诚表达歉意、先照顾对方情绪的柔和语气。' : '변명보다 마음을 먼저 전하는 부드러운 사과 어조입니다.';
        } else if (/고마|감사|谢谢|多亏/.test(text)) {
          tone = isZh ? '💐 真心感谢' : '💐 진심 어린 감사';
          nuance = isZh ? '珍惜对方的好意与体贴，表达温暖谢意。' : '상대방의 호의와 배려를 소중하게 여기는 따뜻한 감사 표현입니다.';
        }

        let alts = [];
        if (srcLang === 'ko') {
          if (/보고\s?싶|그리워|想你|想见/.test(text)) {
            alts = [
              { text: '超级想你呀', pron: 'chāo jí xiǎng nǐ ya', meaning: isZh ? '超级想你（更撒娇温柔）' : '엄청 보고 싶어 (더 다정하게)' },
              { text: '好想马上见到你', pron: 'hǎo xiǎng mǎ shàng jiàn dào nǐ', meaning: isZh ? '好想马上见到你' : '당장 네가 보고 싶어' }
            ];
          } else if (/사랑|좋아해|爱你|喜欢你|心动/.test(text)) {
            alts = [
              { text: '我最喜欢你了', pron: 'wǒ zuì xǐ huan nǐ le', meaning: isZh ? '我最喜欢你了' : '내가 너 제일 좋아해' },
              { text: '每天都更爱你一点', pron: 'měi tiān dōu gèng ài nǐ yī diǎn', meaning: isZh ? '每天都更爱你一点' : '매일 너를 더 사랑해' }
            ];
          } else if (/수고|고생|쉬어|잘\s?자|辛苦|休息|晚安/.test(text)) {
            alts = [
              { text: '今天辛苦啦，早点休息哦', pron: 'jīn tiān xīn kǔ la, zǎo diǎn xiū xi o', meaning: isZh ? '今天辛苦啦，早点休息哦' : '오늘 수고했어, 일찍 푹 쉬어' },
              { text: '晚安，祝你好梦', pron: 'wǎn ān, zhù nǐ hǎo mèng', meaning: isZh ? '晚安，祝你好梦' : '잘 자, 예쁜 꿈 꿔' }
            ];
          } else if (/미안|죄송|잘못|对不起|抱歉/.test(text)) {
            alts = [
              { text: '对不起呀，别生气哦', pron: 'duì bu qǐ ya, bié shēng qì o', meaning: isZh ? '对不起呀，别生气哦' : '미안해, 화 풀어요' },
              { text: '是我不好，原谅我吧', pron: 'shì wǒ bù hǎo, yuán liàng wǒ ba', meaning: isZh ? '是我不好，原谅我吧' : '내가 잘못했어, 용서해 줘' }
            ];
          } else if (/고마|감사|谢谢|多亏/.test(text)) {
            alts = [
              { text: '真的太谢谢你啦', pron: 'zhēn de tài xiè xie nǐ la', meaning: isZh ? '真的太谢谢你啦' : '정말 너무 고마워' },
              { text: '多亏有你在我身边', pron: 'duō kuī yǒu nǐ zài wǒ shēn biān', meaning: isZh ? '多亏有你在我身边' : '네가 내 옆에 있어 줘서 고마워' }
            ];
          } else {
            const softZh = String(translated || '').replace(/[。！？!?.]+$/, '') + '呀';
            const politeZh = '请放心，' + String(translated || '').replace(/^请/, '');
            alts = [
              { text: softZh, pron: isZh ? '句尾加「呀(ya)」更温柔亲切' : '문장 끝에 呀(ya)를 붙인 다정한 말투', meaning: isZh ? '更温柔甜蜜的恋人语气' : '더 다정하고 부드러운 연인 표현' },
              { text: politeZh, pron: isZh ? '前面加「请放心(qǐng fàng xīn)」' : 'qǐng fàng xīn + 문장 (안심·정중한 말투)', meaning: isZh ? '更贴心安抚的表达' : '상대방을 안심시키는 따뜻한 표현' }
            ];
          }
        } else {
          if (/보고\s?싶|그리워|想你|想见/.test(text)) {
            alts = [
              { text: '지금 당장 보고 싶어', pron: 'ji-geum dang-jang bo-go si-peo', meaning: isZh ? '现在立刻就想见你' : '지금 바로 만나고 싶어 (연인체)' },
              { text: '오늘따라 더 그리워요', pron: 'o-neul-tta-ra deo geu-ri-wo-yo', meaning: isZh ? '今天格外想念你（温柔敬语）' : '오늘따라 더 그리워요 (부드러운 존댓말)' }
            ];
          } else if (/사랑|좋아해|爱你|喜欢你|心动/.test(text)) {
            alts = [
              { text: '세상에서 제일 사랑해', pron: 'se-sang-e-seo je-il sa-rang-hae', meaning: isZh ? '在这世上最爱你' : '세상에서 제일 사랑해' },
              { text: '네가 있어서 정말 행복해', pron: 'ne-ga i-sseo-seo jeong-mal haeng-bo-kae', meaning: isZh ? '因为有你真的好幸福' : '네가 있어서 정말 행복해' }
            ];
          } else if (/수고|고생|쉬어|잘\s?자|辛苦|休息|晚安/.test(text)) {
            alts = [
              { text: '오늘도 고생 많았어, 푹 쉬어', pron: 'o-neul-do go-saeng ma-na-sseo, puk swi-eo', meaning: isZh ? '今天也辛苦了，好好休息吧' : '오늘도 고생 많았어, 푹 쉬어' },
              { text: '잘 자고 내일 또 연락해', pron: 'jal ja-go nae-il tto yeol-la-kae', meaning: isZh ? '晚安，明天再联系哦' : '잘 자고 내일 또 연락해' }
            ];
          } else {
            const cleanKo = String(translated || '').replace(/[.!?~]+$/, '');
            alts = [
              { text: `${cleanKo}~`, pron: typeof romanizeKoreanBasic === 'function' ? romanizeKoreanBasic(cleanKo) : '', meaning: isZh ? '自然亲密的恋人语气' : '부드럽고 다정한 연인 말투' },
              { text: `${cleanKo}요`, pron: typeof romanizeKoreanBasic === 'function' ? romanizeKoreanBasic(`${cleanKo}요`) : '', meaning: isZh ? '温柔礼貌的敬语表达' : '부드러운 존댓말 표현' }
            ];
          }
        }
        return { tone, nuance, alts };
      }

      function offlinePhraseFallback(text, srcLang) {
        const dictKoZh = [
          ['지금 뭐해', '现在在干嘛'], ['뭐해', '在干嘛'], ['보고 싶어', '好想你'], ['보고싶어', '好想你'],
          ['수고했어', '辛苦了'], ['사랑해', '我爱你'], ['고마워', '谢谢你'], ['미안해', '对不起'],
          ['잘 자', '晚安'], ['좋은 아침', '早上好'], ['밥 먹었어', '吃饭了吗'], ['일어났어', '起床啦'],
          ['징찬이 좋아', '好喜欢靖灿'], ['징찬 좋아', '喜欢靖灿'], ['수완이 좋아', '好喜欢秀完'], ['수완 좋아', '喜欢秀完'],
          ['오빠 좋아', '喜欢欧巴'], ['자기 좋아', '喜欢宝贝'], ['너무 좋아', '太喜欢啦'], ['진짜 좋아', '真的很喜欢'],
          ['좋아해', '喜欢你'], ['좋아요', '好呀'], ['좋아', '好喜欢'], ['예뻐', '真漂亮'], ['이뻐', '真漂亮'], ['귀여워', '好可爱'],
          ['자기야', '宝贝'], ['자기', '宝贝'], ['오빠', '欧巴'], ['징찬아', '靖灿呀'], ['징찬', '靖灿'], ['수완', '秀完'],
          ['칭다오', '青岛'], ['서울', '首尔'], ['상하이', '上海'], ['수원', '水原'],
          ['오늘', '今天'], ['내일', '明天'], ['우리', '我们'], ['함께', '一起'], ['여행', '旅行'],
          ['행복해', '很幸福'], ['힘내', '加油'], ['푹 쉬어', '好好休息'],
          ['하하하', '哈哈哈'], ['하하', '哈哈'], ['헤헤', '嘿嘿'], ['히히', '嘻嘻'], ['흑흑', '呜呜'], ['응응', '嗯嗯'], ['오케이', '好的']
        ];
        let out = text;
        if (srcLang === 'ko') dictKoZh.forEach(([k, z]) => { out = out.split(k).join(z); });
        else dictKoZh.forEach(([k, z]) => { out = out.split(z).join(k); });
        return out;
      }

      function prepareTextWithLockedNames(rawText, srcLang) {
        // Keep source text in its native script so MT engines never drop mixed-script names
        return String(rawText || '');
      }

      // Universal Korean Casual Chat / Cute ㅇ-받침 / Slang / Laughs / Greeting Normalizer (applied app-wide before MT!)
      const __CW_KEEP_IEUNG_WORDS = new Set([
        '사랑','안녕','걱정','인정','일정','결정','감정','표정','진정','사정','설정','예정','안정','열정','다정',
        '공부중','생각중','이동중','식사중','준비중','출근중','퇴근중','운전중','통화중','데이트중','기다리는중','일하는중','가는중','오는중','먹는중','자는중',
        '식당','성당','마당','강당','분당','담당','해당','적당','정당','부당','타당','황당','수당','배당','설탕','사탕',
        '공항','영상','가방','화장','냉장','항상','평생','인생','동생','학생','선생','병원','운동','쇼핑','결혼','사랑해','안경','풍경','구경',
        '태양','모양','영양','사양','고양','안양','분양','해양','동양','서양','교양','휴양','입양','배양','양양',
        '수영','운영','환영','촬영','경영','방영','반영','번영','진영','조영','한영','영영',
        '사용','내용','비용','이용','적용','허용','신용','전용','조용','미용','착용','고용','응용','수용','작용','실용',
        '명령','연령','요령','유령','대통령','법령','발령','수령','점령',
        '강아지','고양이','아침','점심','저녁','소세지','치킨','피자','커피','우유','라면','김치','삼겹살','떡볶이','초콜릿','아이스크림',
        '영화','드라마','노래','음악','사진','앨범','편지','선물','기념일','식빵','붕어빵','호빵','찐빵','대빵','금방','처방','가방','예방','방방'
      ]);
      function normalizeKoreanColloquialForMT(raw) {
        let s = String(raw || '').trim();
        if (!s || !/[가-힣ㄱ-ㅎㅏ-ㅣ]/.test(s)) return s;
        // 1) Greeting '안녕' protection (never let MT turn '안녕' / '안녕 내사랑' into '再见/拜拜'!)
        if (/^안녕([~!.\s,]|$)/.test(s) && !/(잘\s*가|잘가|이따\s*봐|헤어|작별|바이|안녕히\s*계|안녕히\s*가)/.test(s)) {
          s = s.replace(/^안녕(?=[~!.\s,]|$)/, '하이');
        }
        // 2) Comprehensive Korean KakaoTalk cute ㅇ-받침, phonetic spellings, 초성, laughs & couple slang
        const phraseMap = [
          // 1-syllable cute replies ('넹', '웅', '앙', '잉', '옹')
          [/(^|[\s,.!?~])넹+(?=[\s,.!?~ㅎㅋㅠㅜ]|$)/g, '$1네'],
          [/(^|[\s,.!?~])웅+(?=[\s,.!?~ㅎㅋㅠㅜ]|$)/g, '$1응'],
          [/(^|[\s,.!?~])응앙(?=[\s,.!?~ㅎㅋㅠㅜ]|$)/g, '$1응아'],
          // Cute '~잉' trailing particle (보고싶다잉 -> 보고 싶다, 사랑해잉 -> 사랑해, 잘자잉 -> 잘 자, 알았지잉 -> 알았지)
          [/보고\s*싶다잉/g, '보고 싶다'], [/사랑해잉/g, '사랑해'], [/고마워잉/g, '고마워'], [/미안해잉/g, '미안해'],
          [/잘\s*자잉/g, '잘 자'], [/뭐\s*해잉/g, '뭐 해'], [/귀여워잉/g, '귀여워'], [/이뻐잉|예뻐잉/g, '예뻐'],
          [/([가-힣]{2,})(다|지|어|아|해|자|래|네|야|워|봐|줘|와|가)잉(?=[\s,.!?~ㅎㅋㅠㅜ]|$)/g, '$1$2'],
          // Cute rounded '~옹' & '~웅' & '~쪙' & '~썽' endings (먹었옹->먹었어, 고마웅->고마워, 먹었쪙->먹었어, 잘해썽->잘했어)
          [/고마웅/g, '고마워'], [/귀여웅/g, '귀여워'], [/부러웅/g, '부러워'], [/그리웅/g, '그리워'], [/미웅/g, '미워'], [/추웅/g, '추워'], [/더웅/g, '더워'], [/무서웅/g, '무서워'],
          [/([가-힣]*)(었|았|였|했|갔|왔|봤|잤|줬|났|쳤|졌|렸|겼|켰|셨)옹(?=[\s,.!?~ㅎㅋㅠㅜ]|$)/g, '$1$2어'],
          [/([가-힣]*)(었|았|였|했|갔|왔|봤|잤|줬|났)쪙(?=[\s,.!?~ㅎㅋㅠㅜ]|$)/g, '$1$2어'],
          [/잘해썽/g, '잘했어'], [/해썽/g, '했어'], [/와썽/g, '왔어'], [/가썽/g, '갔어'], [/자썽/g, '잤어'], [/봐썽/g, '봤어'], [/먹어썽|머거썽/g, '먹었어'],
          [/해쪙/g, '했어'], [/와쪙/g, '왔어'], [/자쪙/g, '잤어'], [/이뻤쪙|예뻤쪙/g, '예뻤어'],
          // Cute '뻥/뽕/팡/빵/펑' adjective endings (이뻥->예뻐, 아팡->아파, 바빵->바빠, 슬펑->슬퍼, 보고시펑->보고 싶어)
          [/이뻥|이뽕|예뻥|예뽕|이뿨/g, '예뻐'], [/기뻥/g, '기뻐'], [/슬펑/g, '슬퍼'],
          [/보고\s*시펑|보고\s*시퍼|보고\s*싶엉|보고파|보고팡/g, '보고 싶어'],
          [/배고팡/g, '배고파'], [/아팡|아퐁/g, '아파'], [/바빵|바뽕/g, '바빠'], [/나빵/g, '나빠'],
          // Question / casual typos
          [/ㅁ+머하지/g, '뭐 하지'], [/ㅁ+머해/g, '뭐 해'],
          [/(^|[\s,.!?~])머해(?=[\s,.!?~]|$)/g, '$1뭐 해'], [/(^|[\s,.!?~])모해(?=[\s,.!?~]|$)/g, '$1뭐 해'],
          [/(^|[\s,.!?~])머하지(?=[\s,.!?~]|$)/g, '$1뭐 하지'], [/(^|[\s,.!?~])모하지(?=[\s,.!?~]|$)/g, '$1뭐 하지'],
          [/(^|[\s,.!?~])머야(?=[\s,.!?~]|$)/g, '$1뭐야'], [/(^|[\s,.!?~])모야(?=[\s,.!?~]|$)/g, '$1뭐야'],
          [/왜구래|왜구령|왜구랭/g, '왜 그래'], [/왜그래써|왜그래썽/g, '왜 그랬어'],
          [/(^|[\s,.!?~])구래(?=[\s,.!?~]|$)/g, '$1그래'], [/(^|[\s,.!?~])구랭(?=[\s,.!?~]|$)/g, '$1그래'],
          [/(^|[\s,.!?~])구럼(?=[\s,.!?~]|$)/g, '$1그럼'], [/(^|[\s,.!?~])구치(?=[\s,.!?~]|$)/g, '$1그렇지'],
          [/어케/g, '어떻게'], [/어뜩해|어뜩행/g, '어떡해'], [/시러|시렁/g, '싫어'],
          [/바부/g, '바보'], [/(^|[\s,.!?~])넘(?=[\s]|$)/g, '$1너무'], [/(^|[\s,.!?~])힝+(?=[\s,.!?~]|$)/g, '$1흑'],
          [/뭐해써|머해써|뭐해썽/g, '뭐 했어'], [/밥머거써|밥머거썽/g, '밥 먹었어'], [/머거써|머거썽/g, '먹었어'],
          [/잘자써|잘자썽/g, '잘 잤어'], [/자써/g, '잤어'], [/와써/g, '왔어'], [/가써/g, '갔어'], [/해써/g, '했어'], [/봐써/g, '봤어'],
          [/조아해용/g, '좋아해요'], [/조아행|조아해/g, '좋아해'], [/조아용/g, '좋아요'], [/조앙|조아/g, '좋아'],
          [/사랑행/g, '사랑해'], [/고마웡/g, '고마워'], [/미안행/g, '미안해'],
          [/잘자용/g, '잘 자요'], [/잘장/g, '잘 자'], [/졸령/g, '졸려'], [/심심행/g, '심심해'], [/행복행/g, '행복해'], [/귀여웡/g, '귀여워'],
          [/헤헿+|헤헤+/g, '헤헤'], [/히힇+|히히+/g, '히히'], [/푸하하+/g, '하하하'],
          [/존맛탱|존맛|JMT/gi, '정말 맛있어'], [/개졸려/g, '너무 졸려'], [/개피곤/g, '너무 피곤해'], [/개좋아/g, '너무 좋아'], [/개웃겨/g, '너무 웃겨'],
          [/꿀잼/g, '정말 재밌어'], [/핵노잼|노잼/g, '재미없어'], [/점메추/g, '점심 메뉴 추천해 줘'], [/저메추/g, '저녁 메뉴 추천해 줘'], [/오운완/g, '오늘 운동 완료'],
          [/(^|\s)ㅇㅇ(?=\s|[?!.~,]|$)/g, '$1응'], [/(^|\s)ㄴㄴ(?=\s|[?!.~,]|$)/g, '$1아니'], [/(^|\s)ㅇㅋ(?=\s|[?!.~,]|$)/g, '$1오케이'],
          [/(^|\s)ㄱㄱ(?=\s|[?!.~,]|$)/g, '$1가자'], [/(^|\s)ㄱㅅ(?=\s|[?!.~,]|$)/g, '$1고마워'], [/(^|\s)ㅈㅅ(?=\s|[?!.~,]|$)/g, '$1미안해'],
          [/(^|\s)ㅎㅇ(?=\s|[?!.~,]|$)/g, '$1하이'], [/(^|\s)ㅂㅂ(?=\s|[?!.~,]|$)/g, '$1잘 가'], [/(^|\s)ㅊㅋ(?=\s|[?!.~,]|$)/g, '$1축하해'],
          [/(^|[\s,.!?~])자기(?=[\s,.!?~]|$)/g, '$1자기야'],
          // Affectionate couple exclamations ('아이 이뻐/이뻥', '오구 잘했어', '우쭈쭈', '내새끼') -> never mistranslate '아이' as 孩子 or '오구' as 奥古!
          [/(^|[\s,.!?~])(?:오구오구|오구|어구어구|어구|아이구야|아이구|아이고야|우쭈쭈)\s*(?=잘했|이뻐|예뻐|귀여|착해|고생|수고|기특|장해|멋져|내\s*새끼|내\s*사랑|우리)/g, '$1아이고 정말 '],
          [/(^|[\s,.!?~])(?:오구오구|오구|어구|우쭈쭈)(?=[\s,.!?~]|$)/g, '$1아이고 착해라'],
          [/내\s*새끼/g, '내 소중한 자기'],
          [/(^|[\s,.!?~])아이\s*(?=(?:이뻐|예뻐|귀여|착해|잘했|좋아|멋져|고마|설레|부끄|참|진짜|정말|너무|배고|졸려|추워|더워|아파|웃겨|심심))/g, '$1아이고 정말 '],
          [/이뻐라|예뻐라/g, '예쁘네'], [/귀여워라/g, '귀엽네'], [/기특해라/g, '기특하네'],
          // Indefinite '뭐 (좀) 하고 오께/올게/오껭/올껭' -> '잠깐 볼일 좀 하고 올게'
          [/뭐\s*좀?\s*하고\s*(?:오께|올께|올게|오껭|올껭|올겡)/g, '잠깐 볼일 좀 하고 올게'],
          [/머\s*좀?\s*하고\s*(?:오께|올께|올게|오껭|올껭|올겡)/g, '잠깐 볼일 좀 하고 올게'],
          [/^(이거\s*|그거\s*)?하고\s*(?:오께|올께|오껭|올껭|올겡)(?=[\s,.!?~ㅎㅋ]|$)/g, '$1잠깐 하고 올게'],
          // Universal phonetic '~께 / ~껭 / ~겡' -> standard '~ㄹ게' across ALL Korean verbs!
          [/([가-힣])고\s*(?:오께|올께|오껭|올껭|올겡)(?=요|[\s,.!?~ㅎㅋㅠㅜ]|$)/g, '$1고 올게'],
          [/(다녀|갔다|나갔다|들어갔다|잠깐갔다)\s*(?:오께|올께|오껭|올껭|올겡)/g, '$1올게'],
          [/(금방|얼른|빨리|이따|이따가|다시)\s*(?:오께|올께|오껭|올껭|올겡)/g, '$1 올게'],
          [/([가-힣]+)(?:하께|할께|하껭|할껭|할겡)(?=요|[\s,.!?~ㅎㅋㅠㅜ]|$)/g, '$1할게'],
          [/([가-힣]+)(?:갈께|가껭|갈껭|갈겡)(?=요|[\s,.!?~ㅎㅋㅠㅜ]|$)/g, '$1갈게'],
          [/(^|[\s,.!?~])(?:가께|갈께|가껭|갈껭|갈겡)(?=요|[\s,.!?~ㅎㅋㅠㅜ]|$)/g, '$1갈게'],
          [/([가-힣]*)(?:올께|오껭|올껭|올겡)(?=요|[\s,.!?~ㅎㅋㅠㅜ]|$)/g, '$1올게'],
          [/([가-힣]+)(?:볼께|보껭|볼껭|볼겡)(?=요|[\s,.!?~ㅎㅋㅠㅜ]|$)/g, '$1볼게'],
          [/(^|[\s,.!?~]|이따\s*|나중에\s*)(?:보께|볼께|보껭|볼껭|볼겡)(?=요|[\s,.!?~ㅎㅋㅠㅜ]|$)/g, '$1볼게'],
          [/([가-힣]+)(?:줄께|주께|주껭|줄껭|줄겡)(?=요|[\s,.!?~ㅎㅋㅠㅜ]|$)/g, '$1줄게'],
          [/([가-힣]+)(?:잘께|자껭|잘껭|잘겡)(?=요|[\s,.!?~ㅎㅋㅠㅜ]|$)/g, '$1잘게'],
          [/(^|[\s,.!?~]|먼저\s*)(?:자께|잘께|자껭|잘껭|잘겡)(?=요|[\s,.!?~ㅎㅋㅠㅜ]|$)/g, '$1잘게'],
          [/먹을께|먹을껭|먹을겡/g, '먹을게'], [/보낼께|보내께|보낼껭|보내껭/g, '보낼게'],
          [/기다릴께|기다리께|기다릴껭|기다리껭/g, '기다릴게'], [/살께|살껭/g, '살게'],
          // Korean location + copula ('아직 가게에요??' -> '아직 가게에 있어요??', never '店里还在吗'!)
          [/(아직도?|지금도?|여전히)\s*(가게|매장|회사|집|학교|밖|식당|카페|일터|사무실|숙소|방|병원|헬스장|공항|역)(?:에요|예요|이요|야|이야|인가요|니|냐)(?=[?!.~,\sㅋㅎㅠㅜ]|$)/g, '$1 $2에 있어요'],
          [/(^|[\s,.!?~])(가게|매장|회사|사무실|일터|숙소)(?:에요|예요|야|인가요)(?=\s*\?)/g, '$1지금 $2에 있어요']
        ];
        for (const [rx, rep] of phraseMap) s = s.replace(rx, rep);
        // 3) Smart Unicode Hangul cute ㅇ-받침 stripper (zero false positives on Sino-Korean nouns like 태양/수영/내용/식당!)
        const SAFE_CUTE_IEUNG = new Set(['엉','앙','행','랭','징','웡','냥','넹','뎅','젱','겡','꿩','뀽','씅','맹','팽','탱','캉','챵','썅','뻥','펑']);
        const GRAMMATICAL_IEUNG_RX = /(해용|세용|에용|예용|네용|구용|지용|나용|어용|아용|워용|려용|가용|와용|봐용|줘용|자용|주용|마용|래용|대용|거양|꺼양|자기양|오빠양|뭐양|어디양|누구양|이쁘당|예쁘당|귀엽당|좋당|싫당|밉당|고맙당|미안하당|배고프당|졸리당|피곤하당|행복하당|신난당|간당|온당|잔당|먹는당|본당|한당|된당|준당|산당|운당|웃는당)$/;
        s = s.replace(/([가-힣]{2,})(?=[?!.~,\sㅋㅎㅠㅜ]|$)/g, (word) => {
          if (__CW_KEEP_IEUNG_WORDS.has(word) || word.endsWith('중') || word.endsWith('님') || word.endsWith('장') || word.endsWith('상') || word.endsWith('방')) return word;
          const last = word[word.length - 1];
          const code = last.charCodeAt(0);
          if (code >= 0xAC00 && code <= 0xD7A3 && (code - 0xAC00) % 28 === 21) {
            if (SAFE_CUTE_IEUNG.has(last) || GRAMMATICAL_IEUNG_RX.test(word)) {
              return word.slice(0, -1) + String.fromCharCode(code - 21);
            }
          }
          return word;
        });
        return s;
      }
      window.__normalizeKoreanColloquialForMT = normalizeKoreanColloquialForMT;

      function enforceCoupleNameGlossary(outText, tgtLang, origText) {
        let s = String(outText || '').trim();
        if (!s) return s;
        const orig = String(origText || '');
        if (tgtLang === 'zh') {
          if (/징찬|장찬|정찬|진찬|靖灿|jing\s*chan/i.test(orig) || /징찬|장찬|jing\s*chan|[靖静晶京景精正青清金敬竞净贞郑俊军君张章长陈真珍][灿赞禅蝉璨粲婵参]/i.test(s)) {
            s = s
              .replace(/징찬아/g, '靖灿呀')
              .replace(/징찬이랑|징찬하고/g, '和靖灿')
              .replace(/징찬이?(?:한테|에게)/g, '给靖灿')
              .replace(/징찬이?(?:는|은|가|를|을|도|의|만|님|씨)?/g, '靖灿')
              .replace(/(?:[靖静晶京景精正青清金敬竞净贞郑俊军君张章长陈真珍][灿赞禅蝉璨粲婵参]|静灿伊|靖灿伊)/g, '靖灿')
              .replace(/^靖灿[,，、\s]+(?=.*靖灿)/, '')
              .replace(/靖灿(?:이|아|가|는|를|도|의)/g, '靖灿')
              .replace(/jing\s*chan(?:\s*i|a)?/gi, '靖灿');
          }
          if (/수완|秀完|su\s*wan/i.test(orig) || /수완|su\s*wan|[秀水素寿修施守手首][完婉莞万丸腕湾]/i.test(s)) {
            s = s
              .replace(/수완아/g, '秀完呀')
              .replace(/수완이랑|수완하고/g, '和秀完')
              .replace(/수완이?(?:한테|에게)/g, '给秀完')
              .replace(/수완이?(?:는|은|가|를|을|도|의|만|님|씨)?/g, '秀完')
              .replace(/(?:[秀水素寿修施守手首][完婉莞万丸腕湾]|足智多谋)/g, '秀完')
              .replace(/秀完(?:이|아|가|는|를|도|의)/g, '秀完')
              .replace(/su\s*wan(?:\s*i|a)?/gi, '秀完');
          }
          if (/오빠/.test(orig)) {
            s = s
              .replace(/我弟弟/g, '哥哥')
              .replace(/弟弟/g, '哥哥')
              .replace(/兄弟/g, '哥哥')
              .replace(/老兄/g, '哥哥');
          }
          if (/징찬/.test(orig) && !/靖灿/.test(s)) {
            s = /^好想你/.test(s) ? s.replace(/^好想你/, '好想靖灿') : `靖灿，${s}`;
          }
          if (/수완/.test(orig) && !/秀完/.test(s)) {
            s = /^好想你/.test(s) ? s.replace(/^好想你/, '好想秀完') : `秀完，${s}`;
          }
          // Vocative '자기' -> '宝贝' (never '自己'!)
          if (/(^|[\s,.!?~])자기(?=[\s,.!?~]|$)/.test(orig) && !/자기\s*(자신|전|소개|관리|개발|계발)/.test(orig)) {
            s = s.replace(/自己(?=[\s,.!?~。！？]|$)/g, '宝贝');
          }
          // Deduplicate accidental '秀完，秀完' or '靖灿，靖灿'
          s = s.replace(/秀完[\s,，]*秀完/g, '秀完').replace(/靖灿[\s,，]*靖灿/g, '靖灿');
          s = s.replace(/呵呵呵?/g, '哈哈').replace(/祝您/g, '祝你');
        } else if (tgtLang === 'ko') {
          if (/靖灿|징찬|jing\s*chan/i.test(orig) || /靖灿|jing\s*chan/i.test(s)) {
            s = s
              .replace(/靖灿/g, '징찬')
              .replace(/(?:정찬|징천|경찬|청찬|진찬)/g, '징찬')
              .replace(/jing\s*chan/gi, '징찬');
          }
          if (/^\s*秀完\s*(?:欧巴|哥哥)[\s\uD800-\uDBFF\uDC00-\uDFFF❤️💕💗💜✨~!.,。！？]*$/.test(orig)) {
            const emTail = (orig.match(/[\uD800-\uDBFF\uDC00-\uDFFF❤️💕💗💜✨~!]+/g) || []).join('');
            return `수완 오빠${emTail}`;
          }
          if (/秀完|수완|su\s*wan/i.test(orig) || /秀完|수완|su\s*wan/i.test(s)) {
            s = s
              .replace(/秀完/g, '수완')
              .replace(/su\s*wan/gi, '수완');
          }
          if (/哥哥|欧巴/.test(orig)) {
            s = s
              .replace(/형님/g, '오빠')
              .replace(/형아/g, '오빠')
              .replace(/(^|[\s,"'“‘(])형(이|은|는|을|를|한테|에게|이랑|도|의|만)?(?=[\s,!?.~"”’)]|$)/g, (_, pre, josa) => {
                const jMap = { '이': '가', '은': '는', '을': '를', '이랑': '랑' };
                return pre + '오빠' + (josa ? (jMap[josa] || josa) : '');
              });
          }
        }
        return s;
      }

      function polishNaturalTranslation(outText, tgtLang, toneMode, origText) {
        let __pOut = String(outText || '');
        const __pOrig = String(origText || '');
        if (tgtLang === 'zh') {
          // Eliminate duplicated Jingchan homophones (e.g. '靖灿，靖禅你在做什么？' -> '靖灿，在干嘛呀？')
          __pOut = __pOut.replace(/靖灿[\s,，、]*(?:[靖静晶京景精正青清金敬竞净贞郑俊军君张章长陈真珍][灿赞禅蝉璨粲婵参])/g, '靖灿');
          __pOut = __pOut.replace(/[靖静晶京景精正青清金敬竞净贞郑俊军君张章长陈真珍][灿赞禅蝉璨粲婵参]/g, (m) => (/징찬/.test(__pOrig) ? '靖灿' : m));
          if (/가게|매장/.test(__pOrig) && /店里还在吗/.test(__pOut)) {
            __pOut = __pOut.replace(/店里还在吗/g, '还在店里吗');
          }
          // Never translate greeting '안녕' as '再见/拜拜' unless farewell context
          if (/^안녕([~!.\s,]|$)/.test(__pOrig.trim()) && !/(잘\s*가|잘가|이따\s*봐|헤어|작별|바이)/.test(__pOrig)) {
            __pOut = __pOut.replace(/^(再见了?|拜拜了?)/, '嗨，').replace(/嗨，[\s,，]+/, '嗨，');
          }
          if (/(^|[\s,.!?~])아이\s*(이뻐|예뻐|귀여|착해|잘했)/.test(__pOrig) && !/(아기|어린이|애기들|아이들)/.test(__pOrig)) {
            __pOut = __pOut.replace(/孩子们?/g, '哎呀').replace(/小孩/g, '哎呀');
          }
          if (/(오구|우쭈쭈)/.test(__pOrig)) {
            __pOut = __pOut.replace(/奥古|五九|乌鸦/g, '哎哟');
          }
          // Cute laughs & leftover Korean jamo KO -> ZH (preserve single ㅠ/ㅜ as 呜呜 too!)
          __pOut = __pOut
            .replace(/ㅎ{3,}/g, '哈哈哈')
            .replace(/ㅎ{2}/g, '嘿嘿')
            .replace(/ㅋ{3,}/g, '哈哈哈')
            .replace(/ㅋ{2}/g, '哈哈')
            .replace(/(^|[^가-힣])[ㅠㅜ]+(?![가-힣])/g, '$1呜呜')
            .replace(/[ㅠㅜ]{2,}/g, '呜呜')
            .replace(/(^|[^가-힣])[ㅎㅋ]+(?![가-힣])/g, '$1');
          if (/^(헤헤헤+|헤헿+)$/.test(__pOrig.trim())) __pOut = '嘿嘿嘿';
          else if (/^헤헤$/.test(__pOrig.trim())) __pOut = '嘿嘿';
          else if (/헤헿|헤헤/.test(__pOrig) && !/嘿嘿/.test(__pOut)) __pOut = __pOut.replace(/呵呵|哈哈|嗯哼/g, '嘿嘿');
          if (/히힇|히히/.test(__pOrig) && !/嘻嘻/.test(__pOut)) __pOut = __pOut.replace(/呵呵/g, '嘻嘻');
          outText = __pOut;
        } else if (tgtLang === 'ko') {
          // Never translate boyfriend '哥/哥哥' as '형님/형/동생' in couple chat!
          if (/哥|欧巴/.test(__pOrig)) {
            __pOut = __pOut.replace(/형님|형아/g, '오빠').replace(/(^|[\s,])형(?=[은는이가의를도와,.\s?!]|$)/g, '$1오빠');
          }
          outText = __pOut;
        }
        let s = String(outText || '').trim();
        if (!s) return s;
        if (tgtLang === 'ko') {
          const origStrKo = String(origText || '');
          if (/想你|好想你|我也想你/.test(origStrKo)) {
            s = s
              .replace(/^나도\s*당신이\s*그리워요\.?$/, '나도 보고 싶어')
              .replace(/^나도\s*네가\s*그리워\.?$/, '나도 보고 싶어')
              .replace(/^당신이\s*그리워요\.?$/, '보고 싶어')
              .replace(/^나는\s*네가\s*그리워\.?$/, '보고 싶어');
          }
          if (toneMode === 'lover' || toneMode === 'cute' || toneMode === 'warm' || toneMode === 'playful') {
            s = s
              .replace(/^나는\s+너를\s+사랑한다\.?$/, '사랑해')
              .replace(/^나는\s+네가\s+그립다\.?$/, '보고 싶어')
              .replace(/^너는\s+무엇을\s+하고\s+있니\??$/, '뭐 하고 있어?')
              .replace(/^너는\s+밥을\s+먹었니\??$/, '밥 먹었어?')
              .replace(/좋은\s*밤\s*되세요\.?$/g, '잘 자, 좋은 꿈 꿔')
              .replace(/수고하셨습니다\.?$/g, '오늘도 수고했어');
          }
          if (toneMode === 'cute') {
            s = s.replace(/보고 싶어[.!]?$/, '보고 시퍼잉~ 🥰').replace(/사랑해[.!]?$/, '사랑행~ 💕').replace(/뭐 하고 있어\?$/, '뭐 하고 이써~?');
            if (!/[~?!💕🥰💜✨]$/.test(s) && s.length < 40) s = s.replace(/\.$/, '') + '~';
          } else if (toneMode === 'playful') {
            if (!/[ㅋㅎ?!😄😆]$/.test(s) && s.length < 45) s = s.replace(/\.$/, '') + ' ㅎㅎ';
          } else if (toneMode === 'warm') {
            s = s.replace(/수고했어[.!]?$/, '오늘도 정말 수고 많았어 🌷').replace(/괜찮아[.!]?$/, '괜찮아, 내가 항상 옆에 있어 🌷');
          }
        } else if (tgtLang === 'zh') {
          const origStr = String(origText || '');
          // Fix literal "我要见你/我想见你" when Korean couple context means "I miss you (보고 싶어)"
          if (/보고\s*싶/.test(origStr) && !/(만나|보러|영화|사진|영상|책|메뉴|공연)/.test(origStr)) {
            s = s
              .replace(/我要见你/g, '好想你')
              .replace(/我想见你/g, '好想你')
              .replace(/想见你/g, '好想你')
              .replace(/我想见(靖灿|秀完)/g, '好想$1')
              .replace(/我要见(靖灿|秀完)/g, '好想$1');
          }
          if (toneMode === 'lover' || toneMode === 'cute' || toneMode === 'warm' || toneMode === 'playful') {
            s = s
              .replace(/^(靖灿[，,\s]*)?你在(?:做什么|干什么)[？?]*$/, '$1在干嘛呀？')
              .replace(/你在干什么([？?]*)$/g, '在干嘛呀$1')
              .replace(/你在做什么([？?]*)$/g, '在干嘛呀$1')
              .replace(/^你吃饭了吗？?$/, '吃饭了吗？')
              .replace(/^我很想你。?$/, '好想你呀')
              .replace(/^我爱你。?$/, '我爱你呀')
              .replace(/^辛苦了。?$/, '辛苦啦')
              .replace(/^这是什么原因[？?]*$/, '为什么呀？');
          }
          if (/(?:^|\s)[ㅠㅜ]+(?:\s|[?!.~]|$)|[ㅠㅜ]{2,}/.test(origStr) && !/呜呜/.test(s)) {
            s = /[？?]+$/.test(s) ? s.replace(/[？?]+$/, '呜呜') : (s + ' 呜呜');
          }
          if (toneMode === 'cute') {
            s = s.replace(/好想你呀?。?$/, '超级想你嘛~ 🥰').replace(/我爱你呀?。?$/, '最爱你啦~ 💕');
            if (!/[呀啦嘛呢~？！?!💕🥰💜✨]$/.test(s) && s.length < 36) s = s.replace(/。$/, '') + '嘛~';
          } else if (toneMode === 'playful') {
            if (!/[哈嘿？！?!😄😆]$/.test(s) && s.length < 36) s = s.replace(/。$/, '') + ' 哈哈';
          } else if (toneMode === 'warm') {
            s = s.replace(/辛苦啦?。?$/, '今天也辛苦啦，抱抱你 🌷').replace(/没关系。?$/, '没关系的，我一直都在 🌷');
          }
        }
        return enforceCoupleNameGlossary(s, tgtLang, origText);
      }

      const DEFAULT_ALBUM_FOLDERS = [
        '💑 우리·셀카', '🍽️ 맛집·카페', '✈️ 여행·풍경', '🐾 귀여운·동물', '🎁 선물·기념', '📱 캡처·기록', '✨ 일상 순간'
      ];
      function ensureEditableAlbumFolders() {
        if (!state.albumFoldersCustomized) {
          const custom = Array.isArray(state.albumFolders) ? state.albumFolders : [];
          state.albumFolders = [...DEFAULT_ALBUM_FOLDERS, ...custom.filter(f => f && !DEFAULT_ALBUM_FOLDERS.includes(f))];
          state.albumFoldersCustomized = true;
        }
        if (!Array.isArray(state.albumFolders) || !state.albumFolders.length) {
          state.albumFolders = ['✨ 일상 순간'];
        }
      }
      function getAllAlbumFolders() {
        if (state.albumFoldersCustomized && Array.isArray(state.albumFolders) && state.albumFolders.length) {
          return state.albumFolders.filter(Boolean);
        }
        const custom = Array.isArray(state.albumFolders) ? state.albumFolders : [];
        return [...DEFAULT_ALBUM_FOLDERS, ...custom.filter(f => f && !DEFAULT_ALBUM_FOLDERS.includes(f))];
      }
      function detectPhotoCategory(text, fileName) {
        const t = (String(text || '') + ' ' + String(fileName || '')).toLowerCase();
        // 1) Check user-created custom folders first!
        const custom = Array.isArray(state.albumFolders) ? state.albumFolders : [];
        for (const f of custom) {
          const cleanName = String(f).replace(/^[^a-zA-Z0-9가-힣一-鿿]+/, '').trim().toLowerCase();
          if (cleanName && t.includes(cleanName)) return f;
        }
        // 2) Precision built-in bilingual classification
        if (/screenshot|스크린샷|캡처|화면|예약|티켓|항공권|영수증|주문|截图|机票|订单|车票|攻略|地图/.test(t)) return '📱 캡처·기록';
        if (/밥|먹|맛|카페|커피|디저트|치킨|고기|라면|빵|케이크|야식|음식|술|맥주|와인|밀크티|브런치|초밥|삼겹|마라|훠궈|吃|饭|咖啡|奶茶|甜品|好吃|美食|火锅|烧烤|蛋糕|面|酒|餐厅|早餐|晚餐|宵夜/.test(t)) return '🍽️ 맛집·카페';
        if (/여행|바다|하늘|노을|야경|산|공항|비행기|호텔|상하이|수원|칭다오|제주|도쿄|풍경|꽃|벚꽃|거리|공원|관광|산책|旅游|旅行|海|天空|夜景|风景|机场|酒店|上海|水原|青岛|夕阳|公园|散步/.test(t)) return '✈️ 여행·풍경';
        if (/셀카|우리|커플|사랑|보고|데이트|손|뽀뽀|안아|함께|거울|오빠|자기|여보|남친|여친|사진찍|自拍|我们|情侣|约会|合照|想你|爱你|牵手|抱|欧巴|宝贝|亲亲/.test(t)) return '💑 우리·셀카';
        if (/강아지|고양이|멍멍|냥|동물|인형|귀여|댕댕|토끼|곰|小狗|小猫|宠物|可爱|玩偶|猫|狗|兔/.test(t)) return '🐾 귀여운·동물';
        if (/선물|꽃다발|반지|생일|기념일|편지|쿠폰|케익|서프라이즈|택배|도착|礼物|戒指|生日|纪念日|惊喜|花束|快递/.test(t)) return '🎁 선물·기념';
        return '✨ 일상 순간';
      }

      async function _coreTranslate(rawText, toneOverride, opts) {
        const skipEngine = (opts && opts.skipEngine) || '';
        const isRetryPass = !!(opts && opts._isRetry);
        const origRawText = (rawText || '').trim();
        if (!origRawText) return null;
        // Pure Korean jamo slang instant natural translation (ㅎㅎㅎ / ㅋㅋㅋ / ㅠㅠ / ㅇㅇ / ㄱㅅ / ㅇㅋ)
        if (/^[ㅎㅋㅠㅜㅇㄱㅅㄴㄷ\s~!.?]+$/.test(origRawText) && /[ㅎㅋㅠㅜㅇㄱㅅㄴㄷ]/.test(origRawText)) {
          let zhOut = '哈哈';
          let pronOut = 'hā hā';
          if (/^[ㅠㅜ\s~!.?]+$/.test(origRawText)) { zhOut = '呜呜'; pronOut = 'wū wū'; }
          else if (/^[ㅋ\s~!.?]+$/.test(origRawText)) { zhOut = origRawText.length >= 3 ? '哈哈哈' : '哈哈'; pronOut = 'hā hā hā'; }
          else if (/^[ㅎ\s~!.?]+$/.test(origRawText)) { zhOut = origRawText.length >= 3 ? '哈哈哈' : '哈哈'; pronOut = 'hā hā'; }
          else if (/ㅇㅇ/.test(origRawText)) { zhOut = '嗯嗯'; pronOut = 'èn èn'; }
          else if (/ㅇㅋ/.test(origRawText)) { zhOut = '好的'; pronOut = 'hǎo de'; }
          else if (/ㄱㅅ/.test(origRawText)) { zhOut = '谢谢'; pronOut = 'xiè xie'; }
          else if (/ㄴㄴ/.test(origRawText)) { zhOut = '不不'; pronOut = 'bù bù'; }
          return { original: origRawText, translated: zhOut, srcLang: 'ko', tgtLang: 'zh', pronunciation: pronOut, literal: zhOut, tone: '😄 자연스러운 표현', nuance: '', alts: [], accuracy: 99, engine: '한중 커플 사전' };
        }
        const srcLang = detectLanguage(origRawText);
        const tgtLang = srcLang === 'ko' ? 'zh' : 'ko';
        const text = srcLang === 'ko'
          ? origRawText
              .replace(/ㅎ{2,}/g, ' 하하')
              .replace(/ㅋ{2,}/g, ' 하하하')
              .replace(/(^|[^가-힣])[ㅠㅜ]+(?![가-힣])/g, '$1 흑흑')
              .replace(/[ㅠㅜ]{2,}/g, ' 흑흑')
              .replace(/(^|[^가-힣])ㅇㅇ(?![가-힣])/g, '$1응응')
              .replace(/(^|[^가-힣])ㅇㅋ(?![가-힣])/g, '$1오케이')
              .replace(/(^|[^가-힣])ㄱㅅ(?![가-힣])/g, '$1고마워')
              .replace(/\s{2,}/g, ' ')
              .trim()
          : origRawText;
        const toneMode = toneOverride || activeToneMode || 'lover';

        const isChinaMode = !!(state.settings && state.settings.chinaMode);

        // 1) Flagship Gemini 2.5 Pro Live (with automatic Gemini 2.5 Pro fallback, skipped in China Direct Mode)
        const apiKey = (state.settings && state.settings.geminiApiKey || '').trim();
        if (apiKey && !isChinaMode) {
          const styleMap = {
            lover: 'warm affectionate romantic couple tone (다정한 연인체 / 甜蜜恋人语气)',
            cute: 'cute playful aegyo sweetheart tone (귀여운 애교체 / 可爱撒娇语气)',
            playful: 'fun teasing witty lighthearted couple tone (유쾌한 장난체 / 俏皮逗趣语气)',
            warm: 'gentle comforting empathetic healing tone (따뜻한 위로체 / 温柔暖心安慰语气)',
            casual: 'natural casual everyday tone (자연스러운 일상 반말 / 自然日常口语)',
            polite: 'polite respectful formal tone (정중한 존댓말 / 礼貌敬语)'
          };
          const styleDesc = styleMap[toneMode] || styleMap.lover;
          const prompt = `You are the highest-tier Korean-Chinese bilingual translator and cultural nuance specialist. Translate into natural, native-level ${tgtLang === 'zh' ? 'Simplified Chinese' : 'Korean'} using a ${styleDesc}. Return ONLY JSON with keys: "translated", "pronunciation" (Pinyin if Chinese, Hangul/romanization guide if Korean), "literal" (meaning in ${state.lang === 'zh' ? 'Simplified Chinese' : 'Korean'}), "tone" (short tone tag in ${state.lang === 'zh' ? 'Simplified Chinese' : 'Korean'}), "nuance" (1-2 clear sentences in ${state.lang === 'zh' ? 'Simplified Chinese' : 'Korean'} explaining subtle feeling and context), "alts" (array of 2 natural alternative expressions), "accuracy" (integer 90-99 estimating translation precision). Text: ${text}`;
          const models = [
            { id: 'gemini-3.5-flash-lite', label: 'Gemini 3.5 Flash-Lite ⚡', minAcc: 95, maxAcc: 99, timeout: 8000 },
            { id: 'gemini-3.8-flash', label: 'Gemini 3.8 Flash 👑', minAcc: 96, maxAcc: 99, timeout: 10000 },
            { id: 'gemini-2.5-flash-lite', label: 'Gemini 2.5 Flash-Lite ✨', minAcc: 93, maxAcc: 97, timeout: 7000 }
          ];
          for (const m of models) {
            try {
              const ctrl = new AbortController();
              const timer = setTimeout(() => ctrl.abort(), m.timeout);
              const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${m.id}:generateContent?key=${encodeURIComponent(apiKey)}`, {
                method: 'POST', headers: { 'Content-Type': 'application/json' }, signal: ctrl.signal,
                body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }], generationConfig: { responseMimeType: 'application/json' } })
              });
              clearTimeout(timer);
              if (res.ok) {
                const parsed = JSON.parse((await res.json())?.candidates?.[0]?.content?.parts?.[0]?.text || '{}');
                if (parsed && parsed.translated) {
                  const rawAcc = Number(parsed.accuracy);
                  const acc = Number.isFinite(rawAcc) ? Math.max(m.minAcc, Math.min(m.maxAcc, Math.round(rawAcc))) : (m.maxAcc - 1);
                  return { original: origRawText, translated: enforceCoupleNameGlossary(parsed.translated, tgtLang, origRawText), srcLang, tgtLang, pronunciation: parsed.pronunciation || '', literal: parsed.literal || text, tone: parsed.tone || '✨ Gemini 정밀 분석', nuance: parsed.nuance || '', alts: Array.isArray(parsed.alts) ? parsed.alts.slice(0, 2) : [], accuracy: acc, engine: m.label };
                }
              }
            } catch (_) {}
          }
        }

        function isValidTranslatedScript(outText, targetLang, origText) {
          if (!outText) return false;
          const cleanOut = String(outText).trim();
          if (!cleanOut || cleanOut === origText) return false;
          if (/MYMEMORY WARNING|INVALID|PLEASE SELECT|QUERY LENGTH/i.test(cleanOut)) return false;
          const hasKo = /[\uAC00-\uD7A3]/.test(cleanOut);
          const hasZh = /[\u4E00-\u9FFF]/.test(cleanOut);
          if (targetLang === 'zh') return hasZh && !hasKo;
          if (targetLang === 'ko') return hasKo && !hasZh;
          return true;
        }

        // 1.5) Fixed Couple Name Glossary (징찬 <-> 靖灿 always locked across entire app!)
        const normalized = text.replace(/[.!?~。！？\s]+$/g, '');
        if (/^(징찬아|징찬이|징찬이가|징찬)?\s*보고\s*싶어[!.~♥♡💜]*$/.test(normalized) && /징찬/.test(normalized)) {
          return { original: origRawText, translated: '好想靖灿呀 💜', srcLang: 'ko', tgtLang: 'zh', pronunciation: 'Hǎo xiǎng Jìngcàn ya', literal: '징찬이가 너무 보고 싶어', tone: '💗 깊은 애정 · 설렘', nuance: '연인에게 그리운 마음을 다정하게 전하는 자연스러운 표현이에요.', alts: ['靖灿，好想你呀', '好想马上见到靖灿'], accuracy: 99, engine: '한중 커플 정밀 사전 💜' };
        }
        if (/^(수완아|수완이|수완이가|수완)?\s*보고\s*싶어[!.~♥♡💜]*$/.test(normalized) && /수완/.test(normalized)) {
          return { original: origRawText, translated: '好想秀完呀 💜', srcLang: 'ko', tgtLang: 'zh', pronunciation: 'Hǎo xiǎng Xiùwán ya', literal: '수완이가 너무 보고 싶어', tone: '💗 깊은 애정 · 설렘', nuance: '연인에게 그리운 마음을 다정하게 전하는 자연스러운 표현이에요.', alts: ['秀完，好想你呀', '好想马上见到秀完'], accuracy: 99, engine: '한중 커플 정밀 사전 💜' };
        }
        const rawNorm = origRawText.replace(/[.!?~。！？\s]+$/g, '').trim();
        const COLLOQUIAL_COUPLE_EXACT = [
          { rx: /^(?:아이|아이고|아이고\s*정말|어이구|오구|오구오구|우쭈쭈)\s*(?:이뻐|예뻐|이뻐라|예뻐라|예쁘네|이쁘다|예쁘다)$/, zh: '哎呀，真漂亮呀', py: 'Āiyā, zhēn piàoliang ya', alt: '好乖好漂亮呀', tone: '🥰 꿀 떨어지는 칭찬' },
          { rx: /^(?:아이|아이고|아이고\s*정말|오구|오구오구|우쭈쭈)\s*(?:귀여워|귀여워라|귀엽네|귀엽다|귀여웡)$/, zh: '哎呀，太可爱啦', py: 'Āiyā, tài kě\'ài la', alt: '怎么这么可爱呀', tone: '🥰 꿀 떨어지는 칭찬' },
          { rx: /^(?:오구|오구오구|어구|어구어구|우쭈쭈|아이구|아이고|아이고\s*정말|아이)\s*(?:잘했어|잘했네|잘해써|잘했엉|기특해|기특하네|장하다)$/, zh: '哎哟，真棒呀！', py: 'Āiyō, zhēn bàng ya!', alt: '乖乖真厉害呀！', tone: '🥰 다정한 칭찬 · 우쭈쭈' },
          { rx: /^(?:오구|오구오구|우쭈쭈|아이고\s*정말)\s*(?:착해|착해라|내\s*새끼|내\s*소중한\s*자기야?|내\s*사랑|우리\s*애기)$/, zh: '哎哟，我家宝贝真乖呀', py: 'Āiyō, wǒ jiā bǎobèi zhēn guāi ya', alt: '乖乖宝贝真棒', tone: '🥰 다정한 칭찬 · 우쭈쭈' },
          { rx: /^(?:오빠\s*|나\s*)?(?:뭐\s*좀?\s*|머\s*좀?\s*|잠깐\s*볼일\s*좀\s*)하고\s*(?:오께|올께|올게|오껭|올껭)요?$/, zh: '我去忙点事马上回来呀', py: 'Wǒ qù máng diǎn shì mǎshàng huílái ya', alt: '我去弄点事情就回来', tone: '💬 다정한 일상 공유' },
          { rx: /^(?:오빠\s*|나\s*|이거\s*|잠깐\s*)?하고\s*(?:오께|올께|올게|오껭|올껭)요?$/, zh: '我去弄一下马上回来呀', py: 'Wǒ qù nòng yīxià mǎshàng huílái ya', alt: '我先忙完就回来', tone: '💬 다정한 일상 공유' },
          { rx: /^(?:나\s*|얼른\s*|잠깐\s*)?(?:씻고|샤워하고)\s*(?:오께|올께|올게|오껭)요?$/, zh: '我去洗漱一下马上回来呀', py: 'Wǒ qù xǐshù yīxià mǎshàng huílái ya', alt: '我去洗个澡就回来', tone: '💬 다정한 일상 공유' },
          { rx: /^(?:나\s*|얼른\s*)?(?:밥\s*먹고|먹고)\s*(?:오께|올께|올게|오껭)요?$/, zh: '我去吃个饭马上回来呀', py: 'Wǒ qù chī gè fàn mǎshàng huílái ya', alt: '我先去吃饭，吃完就来', tone: '💬 다정한 일상 공유' },
          { rx: /^(?:나\s*|잠깐\s*|얼른\s*)?(?:다녀|갔다|나갔다)\s*(?:오께|올께|올게|오껭)요?$/, zh: '我去去就回呀', py: 'Wǒ qù qù jiù huí ya', alt: '我出去一下马上回来', tone: '💬 다정한 일상 공유' },
          { rx: /^(?:뭐|머|모)\s*(?:해|하고\s*있어|해요|하구\s*있어|하니)[,\s]*징찬(?:아|이)?$/, zh: '靖灿，在干嘛呀？', py: 'Jìngcàn, zài gànmá ya?', alt: '靖灿，你在忙什么呢？', tone: '💬 다정한 안부' },
          { rx: /^징찬(?:아|이)?[,\s]*(?:뭐|머|모)\s*(?:해|하고\s*있어|해요|하구\s*있어|하니)$/, zh: '靖灿，在干嘛呀？', py: 'Jìngcàn, zài gànmá ya?', alt: '靖灿，你在忙什么呢？', tone: '💬 다정한 안부' },
          { rx: /^(?:뭐|머|모)\s*(?:해|하고\s*있어|해요)\s*[ㅠㅜ]+$/, zh: '在干嘛呀呜呜', py: 'Zài gànmá ya wūwū', alt: '你在忙什么呀呜呜', tone: '🥺 보고 싶은 애교 · 안부' },
          { rx: /^(?:뭐|머|모)\s*(?:해|해요|하구\s*있어|하고\s*있어)$/, zh: '在干嘛呀？', py: 'Zài gànmá ya?', alt: '你在忙什么呢？', tone: '💬 다정한 안부' },
          { rx: /^아직도?\s*(?:가게|매장)(?:에\s*있어요|에\s*있어|에요|예요|이요|야|인가요)$/, zh: '还在店里吗？', py: 'Hái zài diàn lǐ ma?', alt: '还在店里忙吗？', tone: '💬 다정한 안부 · 걱정' }
        ];
        for (const cc of COLLOQUIAL_COUPLE_EXACT) {
          if (cc.rx.test(rawNorm)) {
            const zhWithQ = (/\?{2,}$/.test(origRawText.trim()) && /[？?]$/.test(cc.zh)) ? cc.zh.replace(/[？?]$/, '？？') : cc.zh;
            return {
              original: origRawText, translated: zhWithQ, altTranslated: cc.alt, srcLang: 'ko', tgtLang: 'zh',
              pronunciation: cc.py, literal: cc.zh, tone: cc.tone, toneKo: cc.tone, toneZh: '🥰 宠溺夸奖 · 日常',
              nuance: '연인 사이에서 다정하게 예뻐하거나 잠시 다녀온다고 말할 때 쓰는 자연스러운 표현이에요.',
              nuanceKo: '연인 사이에서 다정하게 예뻐하거나 잠시 다녀온다고 말할 때 쓰는 자연스러운 표현이에요.',
              nuanceZh: '恋人之间宠溺夸奖或温柔告知去忙一下马上回来的自然口语。',
              alts: [cc.alt], accuracy: 99, engine: '한중 커플 정밀 사전 💜'
            };
          }
        }
        if (/^(징찬아|징찬이|징찬님|징찬)$/.test(normalized)) {
          const zOut = normalized === '징찬아' ? '靖灿呀' : '靖灿';
          return { original: text, translated: zOut, srcLang: 'ko', tgtLang: 'zh', pronunciation: 'Jìngcàn', literal: '靖灿', tone: '💜 커플 이름 고정 번역', nuance: '징찬 이름은 앱 전체에서 항상 「靖灿」으로 고정 번역돼요.', alts: ['靖灿'], accuracy: 100, engine: '커플 이름 고정 사전 💜' };
        }
        if (/^(靖灿呀|靖灿)$/.test(normalized)) {
          const kOut = normalized === '靖灿呀' ? '징찬아' : '징찬';
          return { original: text, translated: kOut, srcLang: 'zh', tgtLang: 'ko', pronunciation: 'Jingchan', literal: '징찬', tone: '💜 情侣专属固定翻译', nuance: '「靖灿」在应用内始终固定翻译为「징찬」。', alts: ['징찬'], accuracy: 100, engine: '커플 이름 고정 사전 💜' };
        }
        const apiQueryText = prepareTextWithLockedNames(text, srcLang);

        // 2) Curated Native Precision Match + Cheat-Sheet Exact Match (Instant, 99% Verified!)
        const compactNorm = normalized.replace(/\s+/g, '');
        for (const item of CURATED_TRANSLATIONS) {
          const koNorm = item.ko.replace(/[.!?~。！？\s]+$/g, '');
          const zhNorm = item.zh.replace(/[.!?~。！？\s]+$/g, '');
          if (srcLang === 'ko' && !item.koAlt && (koNorm === normalized || koNorm.replace(/\s+/g, '') === compactNorm)) {
            const h1 = state.lang === 'zh' ? analyzeNuanceHeuristics(text, item.zh, srcLang, toneMode) : null;
            return { original: text, translated: item.zh, srcLang, tgtLang, pronunciation: item.pinyin, literal: state.lang === 'zh' ? item.zh : item.literal, tone: h1 ? h1.tone : item.tone, nuance: h1 ? h1.nuance : item.nuance, alts: item.alts, accuracy: 99, engine: 'Gemini 초정밀 큐레이션 👑' };
          }
          if (srcLang === 'zh' && (zhNorm === normalized || zhNorm.replace(/\s+/g, '') === compactNorm)) {
            const h2 = state.lang === 'zh' ? analyzeNuanceHeuristics(text, item.koAlt || item.ko, srcLang, toneMode) : null;
            return { original: text, translated: item.koAlt || item.ko, srcLang, tgtLang, pronunciation: item.pinyin, literal: state.lang === 'zh' ? item.zh : item.literal, tone: h2 ? h2.tone : item.tone, nuance: h2 ? h2.nuance : item.nuance, alts: item.alts, accuracy: 99, engine: 'Gemini 초정밀 큐레이션 👑' };
          }
        }
        if (typeof CHEAT_SHEET_72 !== 'undefined') {
          const catZhMap = {
            '연애·애정': '恋爱甜蜜', '일상·인사': '日常问候', '맛집·카페': '餐厅咖啡',
            '여행·교통': '旅行交通', '감정·위로': '情绪安慰', '쇼핑·긴급': '购物应急',
            '카톡·전화': '聊天通话', '식당·배달': '点餐外卖', '올영·편의점': '美妆便利店',
            '가족·예절': '长辈礼仪', '택시·길찾기': '打车指路', '리액션·화해': '地道反应与和好',
            '병원·약국': '医院药店应急', '데이트·사진': '约会拍照美发', '일상·스몰토크': '职场天气闲聊'
          };
          for (const ch of CHEAT_SHEET_72) {
            const koC = ch.ko.replace(/[.!?~。！？\s]+$/g, '');
            const zhC = ch.zh.replace(/[.!?~。！？\s]+$/g, '');
            if (srcLang === 'ko' && (koC === normalized || koC.replace(/\s+/g, '') === compactNorm)) {
              const isZhUi = state.lang === 'zh';
              const h = isZhUi ? analyzeNuanceHeuristics(text, ch.zh, srcLang, toneMode) : null;
              const cz = catZhMap[ch.cat] || ch.cat;
              return {
                original: text, translated: ch.zh, srcLang, tgtLang,
                pronunciation: isZhUi ? '🔊 支持地道中文发音' : '🔊 원어민 중국어 발음 지원',
                literal: isZhUi ? ch.zh : ch.ko,
                tone: isZhUi ? `💜 ${cz}` : `💜 ${ch.cat}`,
                nuance: isZhUi ? `「${cz}」场景中的高频地道表达。${h.nuance}` : ch.nu,
                alts: isZhUi ? h.alts : [], accuracy: 99, engine: '실전 치트키 정밀 사전 👑'
              };
            }
            if (srcLang === 'zh' && (zhC === normalized || zhC.replace(/\s+/g, '') === compactNorm)) {
              const isZhUi = state.lang === 'zh';
              const h = isZhUi ? analyzeNuanceHeuristics(text, ch.ko, srcLang, toneMode) : null;
              const cz = catZhMap[ch.cat] || ch.cat;
              return {
                original: text, translated: ch.ko, srcLang, tgtLang,
                pronunciation: isZhUi ? '🔊 支持地道韩语发音' : '🔊 원어민 한국어 발음 지원',
                literal: isZhUi ? ch.zh : ch.ko,
                tone: isZhUi ? `💜 ${cz}` : `💜 ${ch.cat}`,
                nuance: isZhUi ? `「${cz}」场景中的高频地道韩语表达。${h.nuance}` : ch.nu,
                alts: isZhUi ? h.alts : [], accuracy: 99, engine: '실전 치트키 정밀 사전 👑'
              };
            }
          }
        }

        // 3) China-First Fast Route or Google Neural GTX (fast 2.5s timeout so China never hangs!)
        if (!isChinaMode && skipEngine !== 'google') {
        try {
          const ctrl = new AbortController();
          const timer = setTimeout(() => ctrl.abort(), 2800);
          const tl = tgtLang === 'zh' ? 'zh-CN' : 'ko';
          const sl = srcLang === 'ko' ? 'ko' : 'zh-CN';
          const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${sl}&tl=${tl}&dt=t&dt=rm&q=${encodeURIComponent(apiQueryText)}`;
          const res = await fetch(url, { signal: ctrl.signal });
          clearTimeout(timer);
          if (res.ok) {
            const data = await res.json();
            const segs = Array.isArray(data?.[0]) ? data[0] : [];
            const translated = segs.map(s => s?.[0] || '').join('').trim();
            const roman = segs.map(s => s?.[2] || '').filter(Boolean).join(' ').trim();
            if (isValidTranslatedScript(translated, tgtLang, text)) {
              const naturalTrans = polishNaturalTranslation(translated, tgtLang, toneMode, text);
              const analysis = analyzeNuanceHeuristics(text, naturalTrans, srcLang, toneMode);
              return {
                original: text, translated: naturalTrans, srcLang, tgtLang,
                pronunciation: roman || (tgtLang === 'zh' ? '🔊 원어민 중국어 발음 지원' : '🔊 원어민 한국어 발음 지원'),
                literal: state.lang === 'zh' ? (srcLang === 'zh' ? text : translated) : (srcLang === 'ko' ? text : translated),
                tone: analysis.tone, nuance: analysis.nuance, alts: analysis.alts,
                accuracy: Math.max(88, Math.min(95, 94 - Math.floor(text.length / 45) + (roman ? 1 : 0))), engine: 'Google Neural + 뉘앙스 엔진'
              };
            }
          }
        } catch (_) {}

        }

        // 3.5) China-Friendly High-Accuracy Neural Engine: SimplyTranslate AI (Free, CORS-enabled, No Key Required)
        if (skipEngine !== 'simply') try {
          const ctrl = new AbortController();
          const timer = setTimeout(() => ctrl.abort(), 3500);
          const res = await fetch('https://api.simplytranslate.ai/translate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            signal: ctrl.signal,
            body: JSON.stringify({
              text: apiQueryText,
              from: srcLang === 'ko' ? 'ko' : 'zh-cn',
              to: tgtLang === 'zh' ? 'zh-cn' : 'ko'
            })
          });
          clearTimeout(timer);
          if (res.ok) {
            const stJson = await res.json();
            const stRaw = (stJson && stJson.result ? String(stJson.result) : '').trim();
            if (isValidTranslatedScript(stRaw, tgtLang, text)) {
              const naturalSt = polishNaturalTranslation(stRaw, tgtLang, toneMode, text);
              const analysis = analyzeNuanceHeuristics(text, naturalSt, srcLang, toneMode);
              const conf = Number(stJson?.confidence);
              const acc = Number.isFinite(conf) ? Math.max(88, Math.min(97, Math.round(conf * 100))) : 93;
              return {
                original: text, translated: naturalSt, srcLang, tgtLang,
                pronunciation: tgtLang === 'zh' ? '🔊 원어민 중국어 발음 지원' : '🔊 원어민 한국어 발음 지원',
                literal: state.lang === 'zh' ? (srcLang === 'zh' ? text : stRaw) : (srcLang === 'ko' ? text : stRaw),
                tone: analysis.tone, nuance: analysis.nuance, alts: analysis.alts,
                accuracy: acc, engine: 'SimplyTranslate AI 신경망 ✨'
              };
            }
          }
        } catch (_) {}

        // 4) China-Accessible Neural Engine: MyMemory API (works directly in Mainland China without VPN)
        if (skipEngine !== 'mymemory') try {
          const ctrl = new AbortController();
          const timer = setTimeout(() => ctrl.abort(), 5000);
          const langpair = srcLang === 'ko' ? 'ko|zh-CN' : 'zh-CN|ko';
          const res = await fetch(`https://api.mymemory.translated.net/get?q=${encodeURIComponent(apiQueryText)}&langpair=${encodeURIComponent(langpair)}`, { signal: ctrl.signal });
          clearTimeout(timer);
          if (res.ok) {
            const mmJson = await res.json(); const translated = (mmJson?.responseData?.translatedText || '').trim(); const mmMatch = Number(mmJson?.responseData?.match);
            const isSaneLen = (outS) => {
              const oL = Math.max(1, text.length);
              const tL = String(outS || '').trim().length;
              return tL > 0 && tL <= Math.max(40, oL * 4.5 + 12);
            };
            const mtEntry = Array.isArray(mmJson?.matches) ? mmJson.matches.find(x => String(x?.['created-by'] || '').toLowerCase().includes('mt') && isValidTranslatedScript(x?.translation, tgtLang, text) && isSaneLen(x?.translation)) : null;
            const bestMm = mtEntry ? String(mtEntry.translation).trim() : (isValidTranslatedScript(translated, tgtLang, text) && isSaneLen(translated) && (!Number.isFinite(mmMatch) || mmMatch >= 0.72) ? translated : '');
            if (bestMm) {
              const naturalMm = polishNaturalTranslation(bestMm, tgtLang, toneMode, text);
              const analysis = analyzeNuanceHeuristics(text, naturalMm, srcLang, toneMode);
              return { original: text, translated: naturalMm, srcLang, tgtLang, pronunciation: '', literal: state.lang === 'zh' ? (srcLang === 'zh' ? text : bestMm) : (srcLang === 'ko' ? text : bestMm), tone: analysis.tone, nuance: analysis.nuance, alts: analysis.alts, accuracy: Number.isFinite(mmMatch) ? Math.max(82, Math.min(93, Math.round(78 + mmMatch * 15))) : 88, engine: '하이브리드 AI 번역' };
            }
          }
        } catch (_) {}

        // 5) Guaranteed Offline Fallback
        const fallbackTrans = enforceCoupleNameGlossary(offlinePhraseFallback(apiQueryText, srcLang), tgtLang, text);
        const analysis = analyzeNuanceHeuristics(text, fallbackTrans, srcLang, toneMode);
        return { original: text, translated: fallbackTrans === text ? (tgtLang === 'zh' ? `[中文] ${text}` : `[한국어] ${text}`) : fallbackTrans, srcLang, tgtLang, pronunciation: '', literal: state.lang === 'zh' ? (srcLang === 'zh' ? text : fallbackTrans) : (srcLang === 'ko' ? text : fallbackTrans), tone: analysis.tone, nuance: analysis.nuance, alts: analysis.alts, accuracy: fallbackTrans === text ? 70 : 84, engine: '로컬 안전 번역 엔진' };
      }

      // 0ms Local Phrase Cache + Gemini 2.5 Flash Priority #1 + 0.3s 1st-Arrival Fast Free Race!
      const __cwTransCacheKey = 'cw_trans_fast_cache_v1';
      let __cwTransCacheMem = null;
      function __getTransCache() {
        if (__cwTransCacheMem) return __cwTransCacheMem;
        try { __cwTransCacheMem = JSON.parse(localStorage.getItem(__cwTransCacheKey) || '{}') || {}; } catch (_) { __cwTransCacheMem = {}; }
        return __cwTransCacheMem;
      }
      function __saveTransCache(k, val) {
        try {
          const c = __getTransCache();
          c[k] = val;
          const keys = Object.keys(c);
          if (keys.length > 260) {
            for (let i = 0; i < keys.length - 220; i++) delete c[keys[i]];
          }
          localStorage.setItem(__cwTransCacheKey, JSON.stringify(c));
        } catch (_) {}
      }
      const __cwEngineSkipUntil = {};
      function __getActiveGeminiKey() {
        try {
          const kState = (state && state.settings && state.settings.geminiApiKey || '').trim();
          const kLs = (localStorage.getItem('cw_gemini_api_key_v1') || '').trim();
          const k = kState || kLs;
          if (k && k !== kLs) localStorage.setItem('cw_gemini_api_key_v1', k);
          return k;
        } catch (_) { return ''; }
      }
      window.__getActiveGeminiKey = __getActiveGeminiKey;
      async function __callGeminiCoupleTranslate(rawText, toneOverride) {
        const gKey = __getActiveGeminiKey();
        if (!gKey) return null;
        if (__cwEngineSkipUntil.gemini && Date.now() < __cwEngineSkipUntil.gemini) return null;
        const isOrigZh = /[一-鿿]/.test(rawText) && !/[가-힣]/.test(rawText);
        const tgtLang = isOrigZh ? 'ko' : 'zh';
        const prompt = isOrigZh
          ? `한국인 남자친구(수완/秀完)와 중국인 여자친구(징찬/靖灿)의 실제 카톡 대화입니다. 중국어 원문을 과장 없이 원문 길이와 뜻에 딱 맞는 가장 자연스러운 한국어 연인 구어체(반말)로 번역하세요. 규칙: 원문에 없는 애칭(우리 애기 등)이나 문장을 억지로 덧붙이지 말 것(예: 早上好->좋은 아침!). 哥/哥哥/欧巴는 무조건 '오빠'로 번역. 嘿嘿->헤헤, 嘻嘻->히히. JSON만 반환: {"translated":"가장 자연스러운 번역문","altTranslated":"조금 다른 느낌의 자연스러운 대안 번역 1개","pronunciation":"","toneKo":"짧은 한국어 감정 태그(예: 다정한 챙김)","toneZh":"简短中文语气标签(例: 暖心照顾)","nuanceKo":"반드시 한국어로 작성한 1문장 말투·뉘앙스 설명","nuanceZh":"必须用中文写的1句语气解析"}. 원문: ${rawText}`
          : `한국인 남자친구(수완/秀完)와 중국인 여자친구(징찬/靖灿)의 실제 위챗 대화입니다. 한국어 카톡 애교체·구어체(ㅇ받침, 줄임말, 감탄사 '아이 이뻐/예뻐'는 절대 孩子로 오역하지 말고 '哎呀真漂亮呀/真好看呀', '오구/오구오구/우쭈쭈 잘했어'는 '哎哟真棒呀/乖乖真厉害', '~하고오께/~올께/~하께/~가께'는 '~하고 올게/할게/갈게(马上回来/我去...就回来)', '뭐하고오께'는 의문문이 아니라 '我去忙点事马上回来呀', 오타 장찬/정찬->징찬, 헤헤/헤헿->嘿嘿)를 정확히 이해해 실제 중국 연인이 쓰는 자연스러운 구어체로 번역하세요. 규칙: 원문에 없는 말 덧붙이지 말 것, 원문에 [捂脸][亲亲] 같은 위챗 이모티콘 태그가 있으면 그대로 유지할 것, 중국어 번역문에 절대 한글 자모(ㅎㅎ,ㅋㅋ,ㅠㅠ) 남기지 말고 嘿嘿/哈哈/呜呜로 번역할 것. 수완->秀完, 징찬/장찬->靖灿(절대 张灿/俊灿/静蝉 등 오역·중복 금지), 인사 '안녕'은 嗨/你好呀 사용. JSON만 반환: {"translated":"가장 자연스러운 중국어 번역","altTranslated":"조금 다른 느낌의 자연스러운 중국어 대안 번역 1개","pronunciation":"병음","toneKo":"짧은 한국어 감정 태그(예: 다정한 연인체)","toneZh":"简短中文语气标签(例: 甜蜜恋人语气)","nuanceKo":"반드시 한국어로 작성한 1문장 말투·뉘앙스 설명","nuanceZh":"必须用中文写的1句语气解析"}. 원문: ${rawText}`;
        window.__cwLastGeminiErr = '';
        const __gemStartTs = Date.now();
        const tryModel = async (modelName, disableThinking, timeoutMs = 2800) => {
          const ctrl = new AbortController();
          const tm = setTimeout(() => ctrl.abort(), timeoutMs);
          try {
            const genCfg = { responseMimeType: 'application/json', maxOutputTokens: 280 };
            if (/gemini-3\.5-flash-lite/i.test(modelName)) genCfg.thinkingConfig = { thinkingLevel: 'minimal' };
            else if (/gemini-3\.[68]-flash/i.test(modelName)) genCfg.thinkingConfig = { thinkingLevel: 'low' };
            else if (disableThinking || /gemini-2\.5/i.test(modelName)) genCfg.thinkingConfig = { thinkingBudget: 0 };
            const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${modelName}:generateContent?key=${encodeURIComponent(gKey)}`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              signal: ctrl.signal,
              body: JSON.stringify({
                contents: [{ parts: [{ text: prompt }] }],
                generationConfig: genCfg
              })
            });
            clearTimeout(tm);
            if (!r.ok) {
              window.__cwLastGeminiErr = `${modelName} HTTP ${r.status}`;
              return { ok: false, status: r.status, json: null };
            }
            return { ok: true, status: 200, json: await r.json() };
          } catch (err) {
            clearTimeout(tm);
            window.__cwLastGeminiErr = `${modelName} ${err && err.name === 'AbortError' ? 'timeout' : 'network'}`;
            return { ok: false, status: 0, json: null };
          }
        };
        try {
          const cachedDisc = (() => { try { return (localStorage.getItem('cw_gemini_active_model_v1') || '').trim(); } catch (_) { return ''; } })();
          const modelChain = [];
          if (cachedDisc) modelChain.push([cachedDisc, false]);
          ['gemini-3.5-flash-lite', 'gemini-3.8-flash', 'gemini-3.6-flash', 'gemini-2.5-flash-lite'].forEach(m => {
            if (!modelChain.some(x => x[0] === m)) modelChain.push([m, false]);
          });
          let resp = { ok: false, status: 0, json: null };
          let usedModel = cachedDisc || 'gemini-3.5-flash-lite';
          for (let __mi = 0; __mi < modelChain.length; __mi++) {
            if (__mi > 0 && (Date.now() - __gemStartTs) > 4200) break;
            const [mName, noThink] = modelChain[__mi];
            resp = await tryModel(mName, noThink, __mi === 0 ? 2800 : 2000);
            if (resp.ok && resp.json) {
              usedModel = mName;
              window.__cwGemToCnt = 0; try { localStorage.setItem('cw_gemini_active_model_v1', mName); } catch (_) {}
              break;
            }
            if (resp.status === 403 || resp.status === 401 || resp.status === 0) break;
          }
          // Future-proof auto-discovery: if all known model names 404, query /v1beta/models to pick the live Flash model automatically!
          if (!resp.ok && resp.status === 404) {
            try {
              const lr = await fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${encodeURIComponent(gKey)}`);
              if (lr.ok) {
                const lj = await lr.json();
                const list = Array.isArray(lj.models) ? lj.models : [];
                const pick = list.find(m => m && Array.isArray(m.supportedGenerationMethods) && m.supportedGenerationMethods.includes('generateContent') && /flash/i.test(m.name || '') && !/tts|image|audio|live|embedding/i.test(m.name || ''));
                if (pick && pick.name) {
                  const cleanM = String(pick.name).replace(/^models\//, '');
                  resp = await tryModel(cleanM, false);
                  if (resp.ok && resp.json) {
                    usedModel = cleanM;
                    try { localStorage.setItem('cw_gemini_active_model_v1', cleanM); } catch (_) {}
                  }
                }
              }
            } catch (_) {}
          }
          if (!resp.ok || !resp.json) {
            if (resp.status === 0) { window.__cwGemToCnt = (window.__cwGemToCnt || 0) + 1; if (window.__cwGemToCnt >= 2) __cwEngineSkipUntil.gemini = Date.now() + 5 * 60 * 1000; } else if (resp.status === 403 || resp.status === 429) __cwEngineSkipUntil.gemini = Date.now() + 60000;
            return null;
          }
          const j = resp.json;
          const txt = j?.candidates?.[0]?.content?.parts?.[0]?.text || '';
          const m = txt.match(/\{[\s\S]*\}/);
          if (!m) return null;
          const p = JSON.parse(m[0]);
          if (!p || !p.translated) return null;
          return {
            original: rawText,
            translated: String(p.translated).trim(),
            altTranslated: (p.altTranslated && String(p.altTranslated).trim() !== String(p.translated).trim()) ? String(p.altTranslated).trim() : '',
            pronunciation: String(p.pronunciation || '').trim(),
            tone: String(p.toneKo || p.tone || '').trim(),
            toneZh: String(p.toneZh || '').trim(),
            nuance: String(p.nuanceKo || p.nuance || '').trim(),
            nuanceZh: String(p.nuanceZh || '').trim(),
            engine: `Gemini (${usedModel})`,
            tgtLang,
            accuracy: 99
          };
        } catch (_) {
          __cwEngineSkipUntil.gemini = Date.now() + 180000;
          return null;
        }
      }

      async function translateWithAutoRetry(rawText, toneOverride, prevEngineLabel) {
        const fullRaw = String(rawText || '').trim();
        if (!fullRaw) return null;
        const wcTagRx = /\[(捂脸|旺柴|破涕为笑|笑哭|呲牙|偷笑|亲亲|害羞|愉快|奸笑|机智|吃瓜|让我看看|裂开|委屈|可怜|拥抱|抱抱|色|微笑|调皮|憨笑|坏笑|嘿哈|哇|666|加油|好的|耶|Emm|天啊|打脸|翻白眼|叹气|苦涩|皱眉|汗|发呆|流泪|大哭|发怒|惊讶|困|睡|疑问|嘘|晕|再见|鼓掌|哈欠|玫瑰|爱心|心碎|嘴唇|猪头|强|合十|红包)\]/g;
        const wcTagsFound = fullRaw.match(wcTagRx) || [];
        const cleanRaw = wcTagsFound.length ? fullRaw.replace(wcTagRx, ' ').replace(/\s{2,}/g, ' ').trim() : fullRaw;
        if (!cleanRaw) {
          return { original: fullRaw, translated: wcTagsFound.join(''), altTranslated: '', pronunciation: '', tone: '😊 위챗 이모티콘', toneKo: '😊 위챗 이모티콘', toneZh: '😊 微信表情', nuance: '', nuanceKo: '', nuanceZh: '', accuracy: 100, engine: 'WeChat Emoticon' };
        }
        const reattachWcTags = (resObj) => {
          if (!resObj || !wcTagsFound.length) return resObj;
          const suffix = ' ' + wcTagsFound.join('');
          if (resObj.translated && !wcTagRx.test(resObj.translated)) resObj.translated = String(resObj.translated).trim() + suffix;
          wcTagRx.lastIndex = 0;
          if (resObj.altTranslated && !wcTagRx.test(resObj.altTranslated)) resObj.altTranslated = String(resObj.altTranslated).trim() + suffix;
          resObj.original = fullRaw;
          return resObj;
        };
        const isManualRetry = !!prevEngineLabel;
        // 0) 0ms instant hit from local couple phrase cache (unless manual retranslate)
        const cacheKey = `${toneOverride || 'lover'}|${cleanRaw}`;
        if (!isManualRetry) {
          const hit = __getTransCache()[cacheKey];
          const hitOk = hit && hit.translated && (hit.tgtLang === 'zh' ? !/[가-힣]/.test(hit.translated) : !/[\u4e00-\u9fff]/.test(hit.translated));
          if (hitOk) return reattachWcTags({ ...hit, original: cleanRaw });
        }
        // 1) Priority #1: Saved Gemini 2.5 Flash API Key (natural couple slang, ㅇ-받침, names, zero mistranslation!)
        if (!isManualRetry || !String(prevEngineLabel || '').includes('Gemini')) {
          const gemRes = await __callGeminiCoupleTranslate(cleanRaw, toneOverride);
          if (gemRes && gemRes.translated) {
            gemRes.translated = enforceCoupleNameGlossary(gemRes.translated, gemRes.tgtLang, cleanRaw);
            gemRes.translated = polishNaturalTranslation(gemRes.translated, gemRes.tgtLang, toneOverride || 'lover', cleanRaw);
            if (gemRes.altTranslated) {
              gemRes.altTranslated = enforceCoupleNameGlossary(gemRes.altTranslated, gemRes.tgtLang, cleanRaw);
              gemRes.altTranslated = polishNaturalTranslation(gemRes.altTranslated, gemRes.tgtLang, toneOverride || 'lover', cleanRaw);
            }
            __saveTransCache(cacheKey, gemRes);
            return reattachWcTags({ ...gemRes });
          }
        }
        // 2) Normalize Korean colloquial/cute endings/typos before free MT engines
        const mtInput = normalizeKoreanColloquialForMT(cleanRaw);
        const engineIdOf = (lbl) => {
          const s = String(lbl || '');
          if (s.includes('Google')) return 'google';
          if (s.includes('Simply')) return 'simply';
          if (s.includes('하이브리드') || s.includes('MyMemory')) return 'mymemory';
          return '';
        };
        const firstSkip = isManualRetry ? (engineIdOf(prevEngineLabel) || 'google') : '';
        const raceWithCap = (prom, ms) => Promise.race([prom.catch(() => null), new Promise(r => setTimeout(() => r(null), ms))]);
        const isPureTarget = (r) => {
          if (!r || !r.translated) return false;
          const s = String(r.translated).trim();
          if (!s || /^\[(中文|한국어)\]/.test(s) || r.engine === '로컬 안전 번역 엔진') return false;
          return r.tgtLang === 'zh'
            ? (/[\u4e00-\u9fff]/.test(s) && !/[가-힣]/.test(s))
            : (/[가-힣]/.test(s) && !/[\u4e00-\u9fff]/.test(s));
        };
        const isValidRes = (r) => isPureTarget(r);
        // 3) Fast 1st-Arrival Free Race (never lets 5ms partial dictionary cut off real neural MT!)
        const nowTs = Date.now();
        const jobs = [];
        if (firstSkip !== 'google' && !(__cwEngineSkipUntil.google && nowTs < __cwEngineSkipUntil.google)) {
          jobs.push(raceWithCap(_coreTranslate(mtInput, toneOverride, { skipEngine: 'mymemory', _isRetry: true }), 2600).then(r => { if (!isValidRes(r)) __cwEngineSkipUntil.google = Date.now() + 12000; return r; }));
        }
        if (firstSkip !== 'mymemory') {
          jobs.push(raceWithCap(_coreTranslate(mtInput, toneOverride, { skipEngine: 'google', _isRetry: true }), 2800));
        }
        if (!jobs.length) jobs.push(raceWithCap(_coreTranslate(mtInput, toneOverride), 2800));
        const collected = [];
        await new Promise((resolve) => {
          let done = false;
          let pending = jobs.length;
          let graceTimer = null;
          const finish = () => { if (!done) { done = true; if (graceTimer) clearTimeout(graceTimer); resolve(); } };
          jobs.forEach(p => p.then(r => {
            if (isValidRes(r)) {
              collected.push(r);
              if (collected.length >= 2) return finish();
              // 1st valid translation arrived fast! Give 2nd engine max 450ms to provide '다른 번역(altTranslated)'
              if (!graceTimer) graceTimer = setTimeout(finish, 200);
            }
            pending--;
            if (pending <= 0) finish();
          }).catch(() => { pending--; if (pending <= 0) finish(); }));
        });
        const triResults = collected.length ? collected : await Promise.all(jobs);
        const candidates = [];
        triResults.forEach(r => {
          if (r && r.translated && !/^\[(中文|한국어)\]/.test(String(r.translated))) candidates.push(r);
        });
        if (!candidates.length) {
          const fallbackOne = await _coreTranslate(rawText, toneOverride).catch(() => null);
          if (!fallbackOne) return null;
          candidates.push(fallbackOne);
        }

        const normKey = (str) => String(str || '').replace(/[\s,.!?~。，！？、'"`()（）]/g, '').toLowerCase();
        const isTargetOk = (s, tl) => tl === 'zh'
          ? (/[\u4e00-\u9fff]/.test(s) && !/[가-힣]/.test(s))
          : (/[가-힣]/.test(s) && !/[\u4e00-\u9fff]/.test(s));
        const freqMap = new Map();
        candidates.forEach(c => {
          c.translated = enforceCoupleNameGlossary(c.translated, c.tgtLang, rawText);
          if (typeof polishNaturalTranslation === 'function') {
            c.translated = polishNaturalTranslation(c.translated, c.tgtLang, toneOverride || 'lover', rawText);
          }
          const nk = normKey(c.translated);
          if (nk) freqMap.set(nk, (freqMap.get(nk) || 0) + 1);
        });
        candidates.forEach(c => {
          const nk = normKey(c.translated);
          const agrees = freqMap.get(nk) || 1;
          const okScript = isTargetOk(c.translated, c.tgtLang);
          let score = Number(c.accuracy || 88);
          if (okScript) score = Math.max(score, 93);
          if (agrees >= 2 && okScript) score = Math.max(score, 98);
          if (agrees >= 3 && okScript) score = 100;
          else if (isManualRetry && okScript && agrees >= 2) score = 100;
          c.accuracy = Math.min(100, score);
        });
        candidates.sort((a, b) => (b.accuracy || 0) - (a.accuracy || 0));
        let best = { ...candidates[0], original: cleanRaw, autoRetried: !isManualRetry };
        if (best && best.translated && isTargetOk(best.translated, best.tgtLang)) __saveTransCache(cacheKey, best);
        if (best && best.translated) {
          best.translated = enforceCoupleNameGlossary(best.translated, best.tgtLang, rawText);
          const bestNorm = normKey(best.translated);
          const maxAltLen = Math.max(36, rawText.length * 4 + 14);
          const distinctAlt = candidates.find(c =>
            c && c.translated && isTargetOk(c.translated, best.tgtLang) &&
            c.translated.length <= maxAltLen &&
            normKey(c.translated) && normKey(c.translated) !== bestNorm
          );
          best.altTranslated = distinctAlt ? distinctAlt.translated : '';
          // Replace generic boilerplate with smart, context-aware tone & nuance analysis
          try {
            const smart = analyzeSmartCoupleTone(rawText, best.translated);
            if (smart) {
              best.tone = smart.toneKo;
              best.toneKo = smart.toneKo;
              best.toneZh = smart.toneZh;
              best.nuance = smart.nuanceKo;
              best.nuanceKo = smart.nuanceKo;
              best.nuanceZh = smart.nuanceZh;
            }
          } catch (_) {}
        }
        return reattachWcTags(best);
      }

      function analyzeSmartCoupleTone(origText, transText) {
        const raw = String(origText || '').trim();
        const combined = (raw + ' ' + String(transText || '')).trim();
        if (!raw) return null;
        const isPolite = /(요[.!?~]*$|습니다|니다[.!?~]*$|세요|셨어요|해요|에요|예요|이에요|您|请)/.test(raw);
        const isQuestion = /[?？]|(뭐해|어디|언제|어때|고파|먹었|잤어|했어|나요|을까|吗|呢|什么|哪|几点)/.test(raw);
        const isPlayful = /(ㅋㅋ|ㅎㅎ|하하|히히|헤헤|헤헿|장난|바보|바부|놀리|웃겨|哈哈|嘿嘿|嘻嘻|笨蛋|调皮)/.test(raw);
        const isCute = /(~|♡|♥|잉|웅|앙|넹|쪼|뿌|그랭|구랭|가야징|알았엉|좋앙|보고파|왜구래|헤헿|히힇|嘛|哦|啦|呀|么么|宝宝|欧巴|[가-힣][엉앙행랭징웡령양용당냥])/.test(raw);
        const styleKo = isPolite ? '부드러운 존댓말' : '친밀한 반말';
        const styleZh = isPolite ? '礼貌温柔敬语' : '亲密自然平语';

        if (/(사랑|좋아해|보고 싶|보고싶|그리워|뽀뽀|안아|설레|내꺼|爱你|喜欢你|想你|亲亲|抱抱|心动)/.test(combined)) {
          return {
            toneKo: '💗 깊은 애정 · 설렘', toneZh: '💗 深情 · 心动',
            nuanceKo: `솔직하고 달달한 마음을 담아 전하는 ${styleKo} 애정 표현이에요.`,
            nuanceZh: `用${styleZh}直率传达甜蜜爱意与想念的表达。`
          };
        }
        if (/(밥|먹었|고파|배고|배불|식사|점심|저녁|아침|배달|커피|물|吃饭|饿|饱|外卖|早饭|午饭|晚饭)/.test(combined)) {
          return {
            toneKo: '🥰 다정한 챙김', toneZh: '🥰 暖心照顾',
            nuanceKo: isQuestion
              ? `상대방의 끼니와 상태를 살뜰히 챙기는 ${styleKo} 질문이에요.`
              : `식사나 일상을 다정하게 나누는 ${styleKo} 표현이에요.`,
            nuanceZh: isQuestion
              ? `用${styleZh}贴心关心对方饮食起居的温柔询问。`
              : `用${styleZh}自然分享用餐与日常的暖心表达。`
          };
        }
        if (/(피곤|힘들|아프|아파|졸려|졸리|지쳐|우울|속상|걱정|괜찮|쉬어|累|辛苦|生病|难受|困|担心|休息|没事)/.test(combined)) {
          return {
            toneKo: '🫧 위로 · 배려', toneZh: '🫧 关心 · 安慰',
            nuanceKo: isQuestion
              ? `상대방의 컨디션을 걱정하며 살피는 따뜻한 ${styleKo}이에요.`
              : `지치거나 힘든 마음을 솔직히 털어놓거나 다정히 다독이는 ${styleKo}이에요.`,
            nuanceZh: isQuestion
              ? `用${styleZh}关切询问对方身体与心情的温暖语气。`
              : `坦诚倾诉疲惫或温柔安慰陪伴对方的${styleZh}。`
          };
        }
        if (/(늦었|잘 자|잘자|굿나잇|꿈|밤|자야|취침|晚安|睡|太晚|好梦|早点睡)/.test(combined)) {
          return {
            toneKo: '🌙 밤 인사 · 배려', toneZh: '🌙 晚安 · 贴心',
            nuanceKo: `늦은 시간 상대방이 편히 쉬길 바라는 포근한 ${styleKo}이에요.`,
            nuanceZh: `夜深时希望对方安心休息的温柔${styleZh}。`
          };
        }
        if (/(좋은 아침|잘 잤|일어났|굿모닝|출근|早安|起床|睡得好)/.test(combined)) {
          return {
            toneKo: '☀️ 아침 인사', toneZh: '☀️ 早安问候',
            nuanceKo: `하루를 기분 좋게 시작하며 건네는 상쾌한 ${styleKo} 인사예요.`,
            nuanceZh: `开启美好一天时轻松温暖的${styleZh}早安问候。`
          };
        }
        if (/(고마워|고마웡|감사|고생했|수고했|谢谢|感谢|辛苦了)/.test(combined)) {
          return {
            toneKo: '🌷 따뜻한 고마움', toneZh: '🌷 暖心感谢',
            nuanceKo: `상대방에게 고마운 마음을 진심으로 전하는 따뜻한 ${styleKo}이에요.`,
            nuanceZh: `向对方真诚表达谢意与心疼的温暖${styleZh}。`
          };
        }