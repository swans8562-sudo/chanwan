          });
        });
        document.querySelectorAll('.learn-subtab').forEach(btn => {
          btn.addEventListener('click', () => {
            const sub = btn.getAttribute('data-subtab');
            document.querySelectorAll('.learn-subtab').forEach(b => {
              b.className = `learn-subtab ${b === btn ? 'btn-royal' : 'btn-ghost'} py-2 px-2 rounded-xl text-xs font-semibold whitespace-nowrap truncate`;
            });
            ['quiz', 'games', 'today', 'review', 'cheat', 'chatbook'].forEach(id => {
              const el = document.getElementById(`learn-sub-${id}`);
              if (el) el.classList.toggle('hidden', id !== sub);
            });
            if (sub === 'chatbook' && typeof renderChatLearnBook === 'function') renderChatLearnBook(); if (sub === 'games') initMiniGamesIfNeeded();
          });
        });
        document.querySelectorAll('.quiz-level-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            const targetLvl = btn.getAttribute('data-level');
            const reqLv = QUIZ_LEVEL_UNLOCK[targetLvl] || 1;
            const curLv = getRankInfo(state.learn.xp || 0).level || 1;
            if (curLv < reqLv) {
              if (state.myRole === 'jingchan') {
                showToast(state.lang === 'zh'
                  ? `🔒 达到 Lv.${reqLv} 后解锁！(当前 Lv.${curLv})`
                  : `🔒 Lv.${reqLv} 달성 시 열려요! (현재 Lv.${curLv})`);
                return;
              } else {
                showToast(state.lang === 'zh'
                  ? `👑 完测试预览 · 靖灿需达到 Lv.${reqLv} 解锁`
                  : `👑 수완 테스트 미리보기 · 징찬은 Lv.${reqLv} 달성 시 해금돼요`);
              }
            }
            if (window.__quizAutoNextTimer) clearTimeout(window.__quizAutoNextTimer);
            state.learn.currentLevel = targetLvl;
            state.learn.quizIdx = (state.learn.quizIdx || 0) + 1;
            saveState();
            renderQuiz();
          });
        });

        // ==================== SPEECH RECOGNITION PRONUNCIATION CHECKER (Plus 1.3) ====================
        let activeSpeechTarget = null;
        let speechPracticeRec = null;

        function evaluateSpeechAttempt(spokenText) {
          if (!activeSpeechTarget) return;
          const isZh = state.lang === 'zh';
          const sim = calcKoreanSpeechSimilarity(activeSpeechTarget.ko, spokenText);
          const resEl = document.getElementById('speechResultBanner');
          const heardEl = document.getElementById('speechHeardBox');
          if (heardEl) {
            heardEl.classList.remove('hidden');
            heardEl.textContent = isZh ? `识别结果：「${spokenText}」(相似度 ${sim}%)` : `인식된 말: "${spokenText}" (일치율 ${sim}%)`;
          }
          if (resEl) resEl.classList.remove('hidden');

          if (sim >= 65) {
            playNotifChime();
            const todayK = getKstDateString();
            if (state.learn.spokenDoneDate !== todayK) {
              state.learn.spokenDoneDate = todayK;
              state.learn.spokenDoneList = [];
            }
            if (!Array.isArray(state.learn.spokenDoneList)) state.learn.spokenDoneList = [];
            const alreadyDoneToday = state.learn.spokenDoneList.includes(activeSpeechTarget.ko);
            if (canEarnJingchanXp()) {
              if (!alreadyDoneToday) {
                state.learn.spokenDoneList.push(activeSpeechTarget.ko);
                const r = recordJingchanStudyProgress(15);
                saveState(true); renderLearn(); renderHome();
                if (resEl) {
                  resEl.className = 'rounded-2xl p-3 text-xs font-semibold text-center bg-emerald-100/80 text-emerald-800';
                  resEl.textContent = r.actualGain > 0
                    ? (isZh ? `🎉 发音通过 (${sim}%)！获得 +${r.actualGain} XP！` : `🎉 발음 성공 (${sim}%)! +${r.actualGain} XP 획득!`)
                    : (isZh ? `🎉 发音通过 (${sim}%)！(今日经验已达上限 ${DAILY_XP_CAP} XP)` : `🎉 발음 성공 (${sim}%)! (오늘 최대 경험치 ${DAILY_XP_CAP} XP 달성 완료)`);
                }
              } else {
                if (resEl) {
                  resEl.className = 'rounded-2xl p-3 text-xs font-semibold text-center bg-emerald-100/80 text-emerald-800';
                  resEl.textContent = isZh ? `🎉 发音很棒 (${sim}%)！(本句今日已领取过 XP)` : `🎉 발음 아주 좋아요 (${sim}%)! (이 문장은 오늘 이미 XP를 받았어요)`;
                }
              }
            } else {
              if (resEl) {
                resEl.className = 'rounded-2xl p-3 text-xs font-semibold text-center bg-emerald-100/80 text-emerald-800';
                resEl.textContent = isZh ? `❤️ 发音成功 (${sim}%)！(完测试模式 · 不计入靖灿 XP)` : `❤️ 발음 성공 (${sim}%)! (수완 테스트 모드 · 징찬 XP 미반영)`;
              }
            }
          } else {
            if (resEl) {
              resEl.className = 'rounded-2xl p-3 text-xs font-semibold text-center bg-rose-100/80 text-rose-700';
              resEl.textContent = isZh
                ? `还差一点点 (${sim}%)！先听一遍原声再试一次吧 (65% 以上通过)`
                : `조금만 더 또박또박 말해 볼까요? (${sim}% · 65% 이상 성공!)`;
            }
          }
        }

        function openSpeechPracticeModal(ko, zh, pron) {
          activeSpeechTarget = { ko, zh, pron };
          const modal = document.getElementById('speechPracticeModal');
          if (!modal) return;
          const isZh = state.lang === 'zh';
          document.getElementById('speechModalTitle').textContent = isZh ? '🎤 跟读语音打卡 (+15 XP)' : '🎤 따라 말하기 발음 체크 (+15 XP)';
          document.getElementById('speechTargetKo').textContent = ko;
          document.getElementById('speechTargetZh').textContent = zh || '';
          document.getElementById('speechTargetPron').textContent = pron ? `[${isZh ? '发音' : '발음'}] ${pron}` : '';
          document.getElementById('speechHeardBox').classList.add('hidden');
          document.getElementById('speechResultBanner').classList.add('hidden');
          document.getElementById('speechFallbackInput').value = '';

          const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;
          const micBtn = document.getElementById('speechStartMicBtn');
          const fbBox = document.getElementById('speechTypeFallback');
          if (SpeechRec) {
            micBtn.classList.remove('hidden');
            micBtn.textContent = isZh ? '🎤 点击开始跟读韩语' : '🎤 눌러서 따라 말하기';
            fbBox.classList.remove('hidden');
            document.getElementById('speechFallbackHint').textContent = isZh
              ? '麦克风不方便时，也可以直接输入韩语句子打卡 (+15 XP)'
              : '마이크 사용이 어려운 환경이면 아래에 따라 입력해도 +15 XP 인정!';
          } else {
            micBtn.classList.add('hidden');
            fbBox.classList.remove('hidden');
            document.getElementById('speechFallbackHint').textContent = isZh
              ? '当前浏览器暂不支持语音识别，请在下方跟着输入韩语句子完成打卡 (+15 XP) 💜'
              : '현재 브라우저는 음성인식을 지원하지 않아요. 아래에 한국어를 따라 입력해도 +15 XP를 드려요 💜';
          }
          modal.classList.remove('hidden');
        }

        document.addEventListener('click', (e) => {
          const btn = e.target.closest('.speech-check-btn');
          if (!btn) return;
          openSpeechPracticeModal(
            btn.getAttribute('data-ko') || '',
            btn.getAttribute('data-zh') || '',
            btn.getAttribute('data-pron') || ''
          );
        });

        const closeSpBtn = document.getElementById('closeSpeechModalBtn');
        if (closeSpBtn) closeSpBtn.addEventListener('click', () => {
          try { if (speechPracticeRec) speechPracticeRec.stop(); } catch (_) {}
          document.getElementById('speechPracticeModal').classList.add('hidden');
        });
        const listenRefBtn = document.getElementById('speechListenRefBtn');
        if (listenRefBtn) listenRefBtn.addEventListener('click', () => { if (activeSpeechTarget) speakText(activeSpeechTarget.ko, 'ko-KR', false); });
        const listenSlowBtn = document.getElementById('speechListenSlowBtn');
        if (listenSlowBtn) listenSlowBtn.addEventListener('click', () => { if (activeSpeechTarget) speakText(activeSpeechTarget.ko, 'ko-KR', true); });

        const startMicBtn = document.getElementById('speechStartMicBtn');
        if (startMicBtn) startMicBtn.addEventListener('click', () => {
          const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;
          if (!SpeechRec || !activeSpeechTarget) return;
          const isZh = state.lang === 'zh';
          try { if (speechPracticeRec) speechPracticeRec.stop(); } catch (_) {}
          const rec = new SpeechRec();
          speechPracticeRec = rec;
          rec.lang = 'ko-KR';
          rec.interimResults = false;
          rec.maxAlternatives = 2;
          startMicBtn.textContent = isZh ? '🎙️ 正在聆听... 请大声说出韩语' : '🎙️ 듣는 중... 한국어로 말해 보세요!';
          rec.onresult = (ev) => {
            const transcript = ev.results && ev.results[0] && ev.results[0][0] ? ev.results[0][0].transcript : '';
            startMicBtn.textContent = isZh ? '🎤 再试一次' : '🎤 다시 말해 보기';
            if (transcript) evaluateSpeechAttempt(transcript);
          };
          rec.onerror = () => {
            startMicBtn.textContent = isZh ? '🎤 点击重新跟读' : '🎤 다시 눌러서 말하기';
            showToast(isZh ? '未识别到声音，请靠近麦克风或用下方输入打卡' : '목소리가 잘 안 들렸어요. 다시 말하거나 아래 입력을 이용해 보세요!');
          };
          rec.onend = () => {
            if (startMicBtn.textContent.includes('듣는 중') || startMicBtn.textContent.includes('聆听')) {
              startMicBtn.textContent = isZh ? '🎤 点击开始跟读韩语' : '🎤 눌러서 따라 말하기';
            }
          };
          try { rec.start(); } catch (_) {}
        });

        const fbSubmitBtn = document.getElementById('speechFallbackSubmitBtn');
        if (fbSubmitBtn) fbSubmitBtn.addEventListener('click', () => {
          const val = (document.getElementById('speechFallbackInput').value || '').trim();
          if (!val) return;
          evaluateSpeechAttempt(val);
        });
        document.getElementById('nextQuizBtn').addEventListener('click', () => { if (window.__quizAutoNextTimer) clearTimeout(window.__quizAutoNextTimer); state.learn.quizIdx = (state.learn.quizIdx || 0) + 1; saveState(); renderQuiz(); });
        document.getElementById('clearWrongNotesBtn').addEventListener('click', () => { state.learn.wrongNotes = []; saveState(); renderWrongNotes(); showToast(state.lang === 'zh' ? '已清空错题复习本' : '복습 노트를 비웠습니다.'); });
        document.getElementById('cheatSearchInput').addEventListener('input', renderCheatSheet);
        document.getElementById('cheatCategorySelect').addEventListener('change', renderCheatSheet);


        // ==================== BILINGUAL COUPLE MINI-GAMES (KO & ZH) ====================
        const MEMORY_PAIRS = [
          { ko: '보고 싶어', zh: '好想你', koPron: 'bo-go si-peo', zhPron: 'hǎo xiǎng nǐ' },
          { ko: '사랑해', zh: '我爱你', koPron: 'sa-rang-hae', zhPron: 'wǒ ài nǐ' },
          { ko: '밥 먹었어?', zh: '吃饭了吗？', koPron: 'bap meo-geo-sseo', zhPron: 'chī fàn le ma' },
          { ko: '조심해서 가', zh: '路上小心', koPron: 'jo-sim-hae-seo ga', zhPron: 'lù shàng xiǎo xīn' },
          { ko: '잘 자', zh: '晚安', koPron: 'jal ja', zhPron: 'wǎn ān' },
          { ko: '고마워', zh: '谢谢你', koPron: 'go-ma-wo', zhPron: 'xiè xie nǐ' },
          { ko: '귀여워', zh: '好可爱', koPron: 'gwi-yeo-wo', zhPron: 'hǎo kě ài' },
          { ko: '수고했어', zh: '辛苦了', koPron: 'su-go-hae-sseo', zhPron: 'xīn kǔ le' },
          { ko: '화이팅!', zh: '加油！', koPron: 'hwa-i-ting', zhPron: 'jiā yóu' },
          { ko: '기다릴게', zh: '我等你', koPron: 'gi-da-ril-ge', zhPron: 'wǒ děng nǐ' },
          { ko: '맛있게 먹어', zh: '吃香点', koPron: 'ma-sit-ge meo-geo', zhPron: 'chī xiāng diǎn' },
          { ko: '설레', zh: '心动', koPron: 'seol-le', zhPron: 'xīn dòng' },
          { ko: '행복해', zh: '好幸福', koPron: 'haeng-bo-kae', zhPron: 'hǎo xìng fú' },
          { ko: '미안해', zh: '对不起', koPron: 'mi-an-hae', zhPron: 'duì bu qǐ' },
          { ko: '괜찮아', zh: '没关系', koPron: 'gwaen-cha-na', zhPron: 'méi guān xi' },
          { ko: '진짜?', zh: '真的吗？', koPron: 'jin-jja', zhPron: 'zhēn de ma' },
          { ko: '최고야', zh: '最棒了', koPron: 'choe-go-ya', zhPron: 'zuì bàng le' },
          { ko: '천천히 와', zh: '慢慢来', koPron: 'cheon-cheon-hi wa', zhPron: 'màn màn lái' },
          { ko: '안아줘', zh: '抱抱我', koPron: 'a-na-jwo', zhPron: 'bào bao wǒ' },
          { ko: '약속해', zh: '拉钩约定', koPron: 'yak-so-kae', zhPron: 'lā gōu yuē dìng' },
          { ko: '완전 좋아', zh: '超级喜欢', koPron: 'wan-jeon jo-a', zhPron: 'chāo jí xǐ huan' },
          { ko: '배고파', zh: '肚子饿了', koPron: 'bae-go-pa', zhPron: 'dù zi è le' },
          { ko: '내일 봐', zh: '明天见', koPron: 'nae-il bwa', zhPron: 'míng tiān jiàn' },
          { ko: '오늘 어땠어?', zh: '今天过得怎样？', koPron: 'o-neul eo-ttae-sseo', zhPron: 'jīn tiān guò de zěn yàng' }
        ];

        const PUZZLE_SENTENCES = [
          { zh: '今天也辛苦了，好好睡吧', zhPron: 'jīn tiān yě xīn kǔ le, hǎo hǎo shuì ba', koWords: ['오늘도', '수고했어', '푹', '자'], zhWords: ['今天也', '辛苦了，', '好好', '睡吧'], koFull: '오늘도 수고했어 푹 자' },
          { zh: '不管什么时候，我都在你身边', zhPron: 'bù guǎn shén me shí hou, wǒ dōu zài nǐ shēn biān', koWords: ['언제나', '내가', '네', '옆에', '있을게'], zhWords: ['不管', '什么时候，', '我都在', '你身边'], koFull: '언제나 내가 네 옆에 있을게' },
          { zh: '见面了我们去吃好吃的吧', zhPron: 'jiàn miàn le wǒ men qù chī hǎo chī de ba', koWords: ['만나면', '맛있는', '거', '먹으러', '가자'], zhWords: ['见面了', '我们去吃', '好吃的', '吧'], koFull: '만나면 맛있는 거 먹으러 가자' },
          { zh: '天气变冷了，穿暖和点', zhPron: 'tiān qì biàn lěng le, chuān nuǎn huo diǎn', koWords: ['날씨가', '추워졌으니까', '따뜻하게', '입어'], zhWords: ['天气', '变冷了，', '穿暖和', '点'], koFull: '날씨가 추워졌으니까 따뜻하게 입어' },
          { zh: '一想到你，心情就变好了', zhPron: 'yī xiǎng dào nǐ, xīn qíng jiù biàn hǎo le', koWords: ['너', '생각하면', '기분이', '좋아져'], zhWords: ['一想到你，', '心情就', '变好了'], koFull: '너 생각하면 기분이 좋아져' },
          { zh: '到了记得给我发消息哦', zhPron: 'dào le jì de gěi wǒ fā xiāo xi o', koWords: ['도착하면', '꼭', '연락해', '줘'], zhWords: ['到了', '记得给我', '发消息', '哦'], koFull: '도착하면 꼭 연락해 줘' },
          { zh: '虽然离得远，但心在一起', zhPron: 'suī rán lí de yuǎn, dàn xīn zài yī qǐ', koWords: ['멀리', '있어도', '마음은', '함께야'], zhWords: ['虽然', '离得远，', '但心', '在一起'], koFull: '멀리 있어도 마음은 함께야' },
          { zh: '谢谢你一直对我这么好', zhPron: 'xiè xie nǐ yī zhí duì wǒ zhè me hǎo', koWords: ['항상', '잘해', '줘서', '고마워'], zhWords: ['谢谢你', '一直对我', '这么好'], koFull: '항상 잘해 줘서 고마워' },
          { zh: '今天也超级超级想你', zhPron: 'jīn tiān yě chāo jí chāo jí xiǎng nǐ', koWords: ['오늘도', '정말', '많이', '보고', '싶어'], zhWords: ['今天也', '超级', '超级', '想你'], koFull: '오늘도 정말 많이 보고 싶어' },
          { zh: '别太累了，记得按时吃饭', zhPron: 'bié tài lèi le, jì de àn shí chī fàn', koWords: ['무리하지', '말고', '밥', '꼭', '챙겨', '먹어'], zhWords: ['别太累了，', '记得', '按时', '吃饭'], koFull: '무리하지 말고 밥 꼭 챙겨 먹어' },
          { zh: '下一次旅行想去哪里？', zhPron: 'xià yī cì lǚ xíng xiǎng qù nǎ lǐ', koWords: ['다음', '여행은', '어디로', '가고', '싶어?'], zhWords: ['下一次', '旅行', '想去', '哪里？'], koFull: '다음 여행은 어디로 가고 싶어?' },
          { zh: '你的笑容最治愈我了', zhPron: 'nǐ de xiào róng zuì zhì yù wǒ le', koWords: ['네가', '웃는', '모습이', '제일', '예뻐'], zhWords: ['你的', '笑容', '最治愈', '我了'], koFull: '네가 웃는 모습이 제일 예뻐' }
        ];

        let miniGamesBooted = false;
        let gameDirection = 'learn-ko'; // 'learn-ko' (징찬: 한국어 맞추기) or 'learn-zh' (수완: 중국어 맞추기)
        let gameDifficulty = 'starter'; // 'starter' | 'beginner' | 'intermediate' | 'advanced'
        let memCards = [], memFlipped = [], memLock = false, memMovesCount = 0, memMatchedCount = 0;
        let puzzleIdx = 0, puzzleSelected = [], puzzlePoolOrder = [];
        let speedTimerId = null, speedLeft = 30, speedPts = 0, speedCmb = 0, speedCurrent = null;

        // Build 500+ phrase pool from MEMORY_PAIRS + CHEAT_SHEET_72 partitioned into 4 difficulty tiers!
        const EXPANDED_GAME_POOL = (() => {
          const seen = new Set();
          const all = [];
          MEMORY_PAIRS.forEach(p => {
            const k = p.ko.trim();
            if (!seen.has(k)) { seen.add(k); all.push({ ko: k, zh: p.zh, koPron: p.koPron, zhPron: p.zhPron || '' }); }
          });
          (typeof CHEAT_SHEET_72 !== 'undefined' ? CHEAT_SHEET_72 : []).forEach(c => {
            const k = String(c.ko || '').trim();
            const z = String(c.zh || '').trim();
            if (k && z && !seen.has(k)) {
              seen.add(k);
              all.push({ ko: k, zh: z, koPron: romanizeKoreanBasic(k), zhPron: c.nu || '' });
            }
          });
          all.sort((a, b) => a.ko.length - b.ko.length);
          const q = Math.ceil(all.length / 4);
          return {
            all,
            starter: all.slice(0, q),
            beginner: all.slice(q, q * 2),
            intermediate: all.slice(q * 2, q * 3),
            advanced: all.slice(q * 3)
          };
        })();

        function getActiveGamePool() {
          const p = EXPANDED_GAME_POOL[gameDifficulty];
          return (p && p.length >= 6) ? p : EXPANDED_GAME_POOL.all;
        }

        function splitZhChunks(zhStr) {
          const s = String(zhStr || '').trim();
          const byPunct = s.split(/([，,。！？!?])/).filter(Boolean);
          const chunks = [];
          byPunct.forEach(seg => {
            if (/^[，,。！？!?]$/.test(seg) && chunks.length) {
              chunks[chunks.length - 1] += seg;
            } else if (seg.length <= 3) {
              chunks.push(seg);
            } else {
              const step = seg.length >= 8 ? 3 : 2;
              for (let i = 0; i < seg.length; i += step) chunks.push(seg.slice(i, i + step));
            }
          });
          return chunks.length >= 2 ? chunks : [s.slice(0, Math.ceil(s.length / 2)), s.slice(Math.ceil(s.length / 2))].filter(Boolean);
        }

        function getActivePuzzlePool() {
          const tierPool = getActiveGamePool();
          const built = [];
          if (gameDifficulty === 'starter') {
            PUZZLE_SENTENCES.forEach(p => built.push(p));
          }
          tierPool.forEach(item => {
            const koWords = item.ko.trim().split(/\s+/).filter(Boolean);
            if (koWords.length >= 2 && koWords.length <= 7) {
              built.push({
                zh: item.zh,
                zhPron: item.zhPron || item.koPron || '',
                koWords,
                zhWords: splitZhChunks(item.zh),
                koFull: item.ko
              });
            }
          });
          return built.length ? built : PUZZLE_SENTENCES;
        }

        function getActiveChoseongPool() {
          const tierPool = getActiveGamePool();
          const built = [];
          if (gameDifficulty === 'starter') {
            CHOSEONG_LIST.forEach(c => built.push(c));
          }
          tierPool.forEach(item => {
            const ch = getKoreanChoseong(item.ko);
            if (ch && ch.length >= 3) {
              built.push({ ch, ko: item.ko, zh: item.zh });
            }
          });
          return built.length ? built : CHOSEONG_LIST;
        }

        const poolBadgeEl = document.getElementById('gamePoolCountBadge');
        if (poolBadgeEl) poolBadgeEl.textContent = `📚 ${EXPANDED_GAME_POOL.all.length}문장 수록`;

        function shuffleArr(arr) {
          const a = arr.slice();
          for (let i = a.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [a[i], a[j]] = [a[j], a[i]];
          }
          return a;
        }

        function updateGameBestBadge() {
          const el = document.getElementById('gameBestBadge');
          if (!el) return;
          if (gameDirection === 'learn-zh') {
            const sBest = state.learn.suwanGameBest || 0;
            el.textContent = state.lang === 'zh' ? `❤️ 完练习模式 · 最高 ${sBest}分` : `❤️ 수완 연습(XP 미반영) · 최고 ${sBest}점`;
          } else {
            const best = state.learn.gameBest || 0;
            el.textContent = state.lang === 'zh' ? `🏆 靖灿速答最高 ${best}分` : `🏆 징찬 스피드 최고 ${best}점`;
          }
        }

        function startMemoryGame() {
          const picks = shuffleArr(getActiveGamePool()).slice(0, 6);
          memCards = shuffleArr(picks.flatMap((p, idx) => [
            { uid: `k_${idx}`, pairId: idx, side: 'ko', text: p.ko, sub: p.koPron, matched: false },
            { uid: `z_${idx}`, pairId: idx, side: 'zh', text: p.zh, sub: p.zhPron, matched: false }
          ]));
          memFlipped = []; memLock = false; memMovesCount = 0; memMatchedCount = 0;
          renderMemoryGrid();
        }

        function renderMemoryGrid() {
          document.getElementById('memMoves').textContent = String(memMovesCount);
          document.getElementById('memMatched').textContent = `${memMatchedCount}/6`;
          const tapText = state.lang === 'zh' ? '翻开' : '터치';
          const grid = document.getElementById('memGrid');
          grid.innerHTML = memCards.map((c, idx) => {
            const isOpen = c.matched || memFlipped.includes(idx);
            const cls = c.matched ? 'game-card-tile matched' : (isOpen ? 'game-card-tile flipped' : 'game-card-tile');
            if (!isOpen) {
              return `<button type="button" class="${cls}" data-mem-idx="${idx}"><span class="text-lg">💜</span><span class="text-[10px] text-mut mt-0.5">${tapText}</span></button>`;
            }
            return `<button type="button" class="${cls}" data-mem-idx="${idx}"><span class="text-xs sm:text-sm font-bold leading-snug">${escapeHtml(c.text)}</span><span class="text-[9.5px] text-mut mt-0.5 leading-tight">${escapeHtml(c.sub)}</span></button>`;
          }).join('');
          grid.querySelectorAll('[data-mem-idx]').forEach(btn => {
            btn.addEventListener('click', () => handleMemoryFlip(Number(btn.getAttribute('data-mem-idx'))));
          });
        }

        function handleMemoryFlip(idx) {
          if (memLock) return;
          const card = memCards[idx];
          if (!card || card.matched || memFlipped.includes(idx)) return;
          memFlipped.push(idx);
          if (card.side === 'ko') speakKorean(card.text); else speakChinese(card.text);
          renderMemoryGrid();
          if (memFlipped.length === 2) {
            memMovesCount += 1;
            const [i1, i2] = memFlipped;
            if (memCards[i1].pairId === memCards[i2].pairId) {
              memCards[i1].matched = true;
              memCards[i2].matched = true;
              memMatchedCount += 1;
              memFlipped = [];
              playNotifChime();
              renderMemoryGrid();
              if (memMatchedCount === 6) {
                if (gameDirection === 'learn-ko' && canEarnJingchanXp()) {
                  recordJingchanStudyProgress(25);
                  saveState(true); renderLearn(); renderHome();
                  showToast(state.lang === 'zh' ? '🎉 靖灿配对通关！获得 +25 XP！' : '🎉 징찬 짝맞추기 클리어! +25 XP 획득!');
                } else {
                  showToast(state.lang === 'zh' ? '❤️ 完练习通关！(不影响靖灿的 XP 进度)' : '❤️ 수완 테스트 클리어! (징찬의 XP·진행도에는 반영되지 않아요)');
                }
              }
            } else {
              memLock = true;
              setTimeout(() => { memFlipped = []; memLock = false; renderMemoryGrid(); }, 650);
            }
          }
        }

        function loadPuzzleRound() {
          const pPool = getActivePuzzlePool();
          const item = pPool[puzzleIdx % pPool.length];
          const targetWords = gameDirection === 'learn-ko' ? item.koWords : item.zhWords;
          puzzleSelected = [];
          puzzlePoolOrder = shuffleArr(targetWords.map((w, i) => ({ id: i, text: w })));
          document.getElementById('puzzleCounter').textContent = `#${(puzzleIdx % pPool.length) + 1} / ${pPool.length}`;
          const guideEl = document.getElementById('puzzleGuideLabel');
          const promptEl = document.getElementById('puzzlePromptZh');
          const subEl = document.getElementById('puzzlePromptSub');
          if (gameDirection === 'learn-ko') {
            guideEl.textContent = state.lang === 'zh' ? '看中文意思，按顺序拼出韩语句子' : '중국어 문장을 보고 알맞은 한국어 순서대로 눌러보세요';
            promptEl.textContent = item.zh;
            subEl.textContent = `발음(병음): ${item.zhPron}`;
          } else {
            guideEl.textContent = state.lang === 'zh' ? '看韩语意思，按顺序拼出中文句子' : '한국어 문장을 보고 알맞은 중국어 순서대로 눌러보세요';
            promptEl.textContent = item.koFull;
            subEl.textContent = state.lang === 'zh' ? '点击下方中文词块组成句子' : '아래 중국어 조각을 순서대로 눌러 문장을 완성해 보세요';
          }
          const hintBox = document.getElementById('puzzleHintBox');
          hintBox.classList.add('hidden'); hintBox.textContent = '';
          const fb = document.getElementById('puzzleFeedback');
          fb.classList.add('hidden'); fb.textContent = '';
          renderPuzzleBoard();
        }

        function renderPuzzleBoard() {
          const pPool = getActivePuzzlePool();
          const item = pPool[puzzleIdx % pPool.length];
          const targetWords = gameDirection === 'learn-ko' ? item.koWords : item.zhWords;
          const fullAnswer = gameDirection === 'learn-ko' ? item.koFull : item.zh;
          const slots = document.getElementById('puzzleAnswerSlots');
          const pool = document.getElementById('puzzleWordPool');
          const emptyGuide = state.lang === 'zh' ? '按顺序点击下方词块拼成完整句子 ✨' : '아래 단어 조각을 순서대로 눌러 문장을 완성해 보세요 ✨';
          if (!puzzleSelected.length) {
            slots.innerHTML = `<span class="text-xs text-mut">${emptyGuide}</span>`;
          } else {
            slots.innerHTML = puzzleSelected.map((tok, pos) => `<button type="button" class="word-chip" data-remove-pos="${pos}">${escapeHtml(tok.text)}</button>`).join('');
            slots.querySelectorAll('[data-remove-pos]').forEach(btn => {
              btn.addEventListener('click', () => {
                puzzleSelected.splice(Number(btn.getAttribute('data-remove-pos')), 1);
                document.getElementById('puzzleFeedback').classList.add('hidden');
                renderPuzzleBoard();
              });
            });
          }
          const usedIds = new Set(puzzleSelected.map(t => t.id));
          pool.innerHTML = puzzlePoolOrder.map(tok => `<button type="button" class="word-chip ${usedIds.has(tok.id) ? 'used' : ''}" data-pick-id="${tok.id}">${escapeHtml(tok.text)}</button>`).join('');
          pool.querySelectorAll('[data-pick-id]').forEach(btn => {
            btn.addEventListener('click', () => {
              const id = Number(btn.getAttribute('data-pick-id'));
              const tok = puzzlePoolOrder.find(t => t.id === id);
              if (!tok || usedIds.has(id)) return;
              puzzleSelected.push(tok);
              renderPuzzleBoard();
              if (puzzleSelected.length === targetWords.length) {
                const attempt = puzzleSelected.map(t => t.text).join(' ');
                const fb = document.getElementById('puzzleFeedback');
                fb.classList.remove('hidden');
                if (attempt === targetWords.join(' ')) {
                  fb.className = 'rounded-2xl p-3 text-xs font-semibold bg-emerald-100/80 text-emerald-800';
                  playNotifChime();
                  if (gameDirection === 'learn-ko' && canEarnJingchanXp()) {
                    fb.textContent = state.lang === 'zh' ? `🎉 答对了！"${fullAnswer}" (+20 XP)` : `🎉 정답! "${fullAnswer}" (+20 XP)`;
                    speakKorean(item.koFull);
                    recordJingchanStudyProgress(20);
                    state.learn.streak = (state.learn.streak || 0) + 1;
                    saveState(true); renderLearn(); renderHome();
                  } else {
                    fb.textContent = state.lang === 'zh' ? `❤️ 答对了！"${fullAnswer}" (完练习模式 · 不计入靖灿进度)` : `❤️ 정답! "${fullAnswer}" (수완 테스트 모드 · 징찬 XP 미반영)`;
                    if (gameDirection === 'learn-ko') speakKorean(item.koFull); else speakChinese(item.zh);
                  }
                } else {
                  fb.className = 'rounded-2xl p-3 text-xs font-semibold bg-rose-100/80 text-rose-700';
                  fb.textContent = state.lang === 'zh' ? '顺序还差一点哦！点击上面的词块可以撤回，也可以点提示 💡' : '순서가 조금 달라요! 위 단어를 눌러 빼고 다시 맞춰볼까요? 💡 힌트도 써보세요!';
                }
              }
            });
          });
        }

        function stopSpeedTimer() {
          if (speedTimerId) { clearInterval(speedTimerId); speedTimerId = null; }
        }

        function nextSpeedQuestion() {
          const pool = shuffleArr(getActiveGamePool());
          speedCurrent = pool[0];
          const choices = shuffleArr([pool[0], pool[1], pool[2], pool[3]]);
          const isKoTarget = gameDirection === 'learn-ko';
          document.getElementById('speedWordKo').textContent = isKoTarget ? speedCurrent.ko : speedCurrent.zh;
          document.getElementById('speedWordPron').textContent = isKoTarget ? speedCurrent.koPron : speedCurrent.zhPron;
          const grid = document.getElementById('speedOptionsGrid');
          grid.innerHTML = choices.map(c => {
            const label = isKoTarget ? c.zh : c.ko;
            return `<button type="button" class="btn-ghost py-3 px-3 rounded-2xl text-sm font-semibold text-center" data-speed-ans="${escapeHtml(label)}">${escapeHtml(label)}</button>`;
          }).join('');
          grid.querySelectorAll('[data-speed-ans]').forEach(btn => {
            btn.addEventListener('click', () => {
              if (!speedCurrent || speedLeft <= 0) return;
              const expected = isKoTarget ? speedCurrent.zh : speedCurrent.ko;
              if (btn.getAttribute('data-speed-ans') === expected) {
                speedCmb += 1;
                speedPts += 10 + Math.min(20, (speedCmb - 1) * 5);
                playNotifChime();
              } else {
                speedCmb = 0;
              }
              document.getElementById('speedScore').textContent = String(speedPts);
              document.getElementById('speedCombo').textContent = `${speedCmb}🔥`;
              nextSpeedQuestion();
            });
          });
        }

        function startSpeedGame() {
          stopSpeedTimer();
          speedLeft = 30; speedPts = 0; speedCmb = 0;
          document.getElementById('speedTimeLeft').textContent = '30';
          document.getElementById('speedScore').textContent = '0';
          document.getElementById('speedCombo').textContent = '0🔥';
          document.getElementById('speedTimerBar').style.width = '100%';
          document.getElementById('speedStartView').classList.add('hidden');
          document.getElementById('speedResultView').classList.add('hidden');
          document.getElementById('speedPlayView').classList.remove('hidden');
          nextSpeedQuestion();
          speedTimerId = setInterval(() => {
            speedLeft -= 1;
            document.getElementById('speedTimeLeft').textContent = String(Math.max(0, speedLeft));
            document.getElementById('speedTimerBar').style.width = `${Math.max(0, (speedLeft / 30) * 100)}%`;
            if (speedLeft <= 0) {
              stopSpeedTimer();
              document.getElementById('speedPlayView').classList.add('hidden');
              document.getElementById('speedResultView').classList.remove('hidden');
              if (gameDirection === 'learn-ko' && canEarnJingchanXp()) {
                const isNewBest = speedPts > (state.learn.gameBest || 0);
                if (isNewBest) state.learn.gameBest = speedPts;
                const xpGain = Math.min(40, Math.max(5, Math.floor(speedPts / 10)));
                recordJingchanStudyProgress(xpGain);
                saveState(true); renderLearn(); renderHome(); updateGameBestBadge();
                if (state.lang === 'zh') {
                  document.getElementById('speedResultTitle').textContent = isNewBest ? `🏆 靖灿新纪录！${speedPts}分！` : `挑战完成：${speedPts}分！`;
                  document.getElementById('speedResultDesc').textContent = `获得奖励 +${xpGain} XP，太棒啦 💜`;
                } else {
                  document.getElementById('speedResultTitle').textContent = isNewBest ? `🏆 징찬 신기록! ${speedPts}점 달성!` : `${speedPts}점 완료!`;
                  document.getElementById('speedResultDesc').textContent = `징찬 보너스 +${xpGain} XP가 누적되었어요 💜`;
                }
              } else {
                const isNewSuwanBest = speedPts > (state.learn.suwanGameBest || 0);
                if (isNewSuwanBest) { state.learn.suwanGameBest = speedPts; saveState(true); }
                updateGameBestBadge();
                if (state.lang === 'zh') {
                  document.getElementById('speedResultTitle').textContent = isNewSuwanBest ? `❤️ 完新纪录！${speedPts}分！` : `完练习完成：${speedPts}分！`;
                  document.getElementById('speedResultDesc').textContent = `已记录完的个人练习分数（不影响靖灿的学习 XP 与进度）`;
                } else {
                  document.getElementById('speedResultTitle').textContent = isNewSuwanBest ? `❤️ 수완 신기록! ${speedPts}점!` : `수완 연습 완료: ${speedPts}점!`;
                  document.getElementById('speedResultDesc').textContent = `수완 전용 연습 기록만 저장되며, 징찬의 XP·등급·연속 정답에는 영향을 주지 않아요.`;
                }
              }
            }
          }, 1000);
        }

        function refreshMiniGamesLanguage() {
          updateGameBestBadge();
          if (!miniGamesBooted) return;
          renderMemoryGrid();
          loadPuzzleRound();
        }

        function initMiniGamesIfNeeded() {
          updateGameBestBadge();
          if (miniGamesBooted) return;
          miniGamesBooted = true;
          startMemoryGame();
          loadPuzzleRound();
        }

        document.querySelectorAll('.game-diff-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            gameDifficulty = btn.getAttribute('data-diff') || 'starter';
            document.querySelectorAll('.game-diff-btn').forEach(b => {
              b.className = `game-diff-btn ${b === btn ? 'btn-royal' : 'btn-ghost'} py-1.5 px-1.5 rounded-xl text-[11px] font-semibold text-center whitespace-nowrap`;
            });
            puzzleIdx = 0;
            choseongIdx = 0;
            startMemoryGame();
            loadPuzzleRound();
            loadListenQuestion(false);
            loadChoseongQuestion();
            if (speedTimerId) startSpeedGame();
            const tierCount = getActiveGamePool().length;
            showToast(state.lang === 'zh'
              ? `已切换难度：${btn.textContent.trim()} (${tierCount}句题库)`
              : `난이도 변경: ${btn.textContent.trim()} (${tierCount}문장 출제)`);
          });
        });

        document.querySelectorAll('.game-dir-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            gameDirection = btn.getAttribute('data-dir');
            stopSpeedTimer();
            document.getElementById('speedPlayView').classList.add('hidden');
            document.getElementById('speedResultView').classList.add('hidden');
            document.getElementById('speedStartView').classList.remove('hidden');
            document.querySelectorAll('.game-dir-btn').forEach(b => {
              b.className = `game-dir-btn ${b === btn ? 'btn-royal' : 'btn-ghost'} px-3 py-1 rounded-full text-[11px] font-semibold whitespace-nowrap`;
            });
            updateGameBestBadge();
            if (miniGamesBooted) loadPuzzleRound();
          });
        });

        document.querySelectorAll('.minigame-mode-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            const g = btn.getAttribute('data-game');
            if (g !== 'speed') stopSpeedTimer();
            document.querySelectorAll('.minigame-mode-btn').forEach(b => {
              b.className = `minigame-mode-btn ${b === btn ? 'btn-royal' : 'btn-ghost'} flex-1 min-w-[92px] py-2 px-2 rounded-2xl text-xs font-semibold text-center whitespace-nowrap`;
            });
            ['memory', 'puzzle', 'speed', 'listen', 'choseong'].forEach(id => document.getElementById(`game-panel-${id}`).classList.toggle('hidden', id !== g)); if (g === 'listen') loadListenQuestion(true); if (g === 'choseong') loadChoseongQuestion();
            initMiniGamesIfNeeded();
          });
        });
        document.getElementById('memRestartBtn').addEventListener('click', startMemoryGame);
        document.getElementById('puzzleHintBtn').addEventListener('click', () => {
          const pPool = getActivePuzzlePool(); const item = pPool[puzzleIdx % pPool.length];
          const targetWords = gameDirection === 'learn-ko' ? item.koWords : item.zhWords;
          const fullAnswer = gameDirection === 'learn-ko' ? item.koFull : item.zh;
          const nextIdx = puzzleSelected.length;
          const hintBox = document.getElementById('puzzleHintBox');
          hintBox.classList.remove('hidden');
          if (state.lang === 'zh') {
            hintBox.textContent = nextIdx < targetWords.length ? `💡 下一个词提示：「${targetWords[nextIdx]}」` : `💡 完整答案：${fullAnswer}`;
          } else {
            hintBox.textContent = nextIdx < targetWords.length ? `💡 다음 단어 힌트: "${targetWords[nextIdx]}" (뜻: ${item.koFull})` : `💡 정답: ${fullAnswer}`;
          }
        });
        document.getElementById('puzzleResetBtn').addEventListener('click', () => { puzzleSelected = []; document.getElementById('puzzleFeedback').classList.add('hidden'); renderPuzzleBoard(); });
        document.getElementById('puzzleNextBtn').addEventListener('click', () => { puzzleIdx += 1; loadPuzzleRound(); });
        document.getElementById('speedStartBtn').addEventListener('click', startSpeedGame);
        document.getElementById('speedRetryBtn').addEventListener('click', startSpeedGame);

        // Mini-game 4: Listening Quiz (China-direct audio + Jingchan XP / Suwan practice isolation)
        let listenCurrent = null, listenAnswered = false;
        function loadListenQuestion(autoPlay) {
          const pool = shuffleArr(getActiveGamePool());
          listenCurrent = pool[0];
          listenAnswered = false;
          const choices = shuffleArr([pool[0], pool[1], pool[2], pool[3]]);
          const isKoTarget = gameDirection === 'learn-ko';
          const hintEl = document.getElementById('listenPromptHint');
          const revEl = document.getElementById('listenRevealText');
          const fbEl = document.getElementById('listenFeedback');
          const grid = document.getElementById('listenOptionsGrid');
          if (hintEl) hintEl.textContent = state.lang === 'zh'
            ? (isKoTarget ? '听韩语发音，选出正确的中文意思 🎧' : '听中文发音，选出正确的韩语表达 🎧')
            : (isKoTarget ? '한국어 발음을 듣고 알맞은 중국어 뜻을 골라보세요 🎧' : '중국어 발음을 듣고 알맞은 한국어 뜻을 골라보세요 🎧');
          if (revEl) { revEl.classList.add('hidden'); revEl.textContent = ''; }
          if (fbEl) { fbEl.classList.add('hidden'); fbEl.textContent = ''; }
          if (grid) {
            grid.innerHTML = choices.map(c => {
              const lbl = isKoTarget ? c.zh : c.ko;
              return `<button type="button" class="btn-ghost py-3 px-3 rounded-2xl text-sm font-semibold text-center" data-listen-ans="${escapeHtml(lbl)}">${escapeHtml(lbl)}</button>`;
            }).join('');
            grid.querySelectorAll('[data-listen-ans]').forEach(btn => {
              btn.addEventListener('click', () => {
                if (listenAnswered || !listenCurrent) return;
                listenAnswered = true;
                const expected = isKoTarget ? listenCurrent.zh : listenCurrent.ko;
                const ok = btn.getAttribute('data-listen-ans') === expected;
                if (revEl) {
                  revEl.classList.remove('hidden');
                  revEl.textContent = `${listenCurrent.ko}  ·  ${listenCurrent.zh}`;
                }
                if (fbEl) {
                  fbEl.classList.remove('hidden');
                  if (ok) {
                    playNotifChime();
                    fbEl.className = 'rounded-2xl p-3 text-xs font-semibold text-center bg-emerald-100/80 text-emerald-800';
                    if (isKoTarget && canEarnJingchanXp()) {
                      recordJingchanStudyProgress(15);
                      saveState(true); renderLearn(); renderHome();
                      fbEl.textContent = state.lang === 'zh' ? '🎉 听对啦！获得 +15 XP！' : '🎉 정확히 들었어요! +15 XP 획득!';
                    } else {
                      fbEl.textContent = state.lang === 'zh' ? '❤️ 听对啦！(完练习模式 · 不计入靖灿进度)' : '❤️ 정답! (수완 연습 모드 · 징찬 XP 미반영)';
                    }
                  } else {
                    fbEl.className = 'rounded-2xl p-3 text-xs font-semibold text-center bg-rose-100/80 text-rose-700';
                    fbEl.textContent = state.lang === 'zh' ? `差一点点！正确答案是「${expected}」` : `아쉬워요! 정답은 "${expected}"예요.`;
                  }
                  if (window.__listenAutoTimer) clearTimeout(window.__listenAutoTimer);
                  window.__listenAutoTimer = setTimeout(() => loadListenQuestion(true), 2200);
                }
              });
            });
          }
          if (autoPlay && listenCurrent) {
            speakText(isKoTarget ? listenCurrent.ko : listenCurrent.zh, isKoTarget ? 'ko-KR' : 'zh-CN', false);
          }
        }
        const lPlayBtn = document.getElementById('listenPlayBtn');
        const lSlowBtn = document.getElementById('listenSlowBtn');
        const lNextBtn = document.getElementById('listenNextBtn');
        if (lPlayBtn) lPlayBtn.addEventListener('click', () => { if (listenCurrent) speakText(gameDirection === 'learn-ko' ? listenCurrent.ko : listenCurrent.zh, gameDirection === 'learn-ko' ? 'ko-KR' : 'zh-CN', false); });
        if (lSlowBtn) lSlowBtn.addEventListener('click', () => { if (listenCurrent) speakText(gameDirection === 'learn-ko' ? listenCurrent.ko : listenCurrent.zh, gameDirection === 'learn-ko' ? 'ko-KR' : 'zh-CN', true); });
        if (lNextBtn) lNextBtn.addEventListener('click', () => loadListenQuestion(true));

        // Mini-game 5: Korean Choseong (Initial Consonants) Quiz
        const CHOSEONG_LIST = [
          { ch: 'ㅂ ㄱ ㅅ ㅇ', ko: '보고 싶어', zh: '好想你' },
          { ch: 'ㅅ ㄹ ㅎ', ko: '사랑해', zh: '我爱你' },
          { ch: 'ㅂ ㅁ ㅇ ㅇ', ko: '밥 먹었어', zh: '吃饭了吗' },
          { ch: 'ㅈ ㅅ ㅎ ㅅ ㄱ', ko: '조심해서 가', zh: '路上小心' },
          { ch: 'ㅅ ㄱ ㅎ ㅇ', ko: '수고했어', zh: '辛苦了' },
          { ch: 'ㄱ ㅇ ㅇ', ko: '귀여워', zh: '好可爱' },
          { ch: 'ㄱ ㅁ ㅇ', ko: '고마워', zh: '谢谢你' },
          { ch: 'ㅁ ㅇ ㅎ', ko: '미안해', zh: '对不起' },
          { ch: 'ㄱ ㅊ ㅇ', ko: '괜찮아', zh: '没关系' },
          { ch: 'ㅎ ㅂ ㅎ', ko: '행복해', zh: '好幸福' },
          { ch: 'ㅂ ㄱ ㅍ', ko: '배고파', zh: '肚子饿了' },
          { ch: 'ㄴ ㅇ ㅂ', ko: '내일 봐', zh: '明天见' },
          { ch: 'ㅇ ㄷ ㅇ', ko: '어디야', zh: '在哪里呀' },
          { ch: 'ㅁ ㅎ', ko: '뭐해', zh: '在干嘛呀' },
          { ch: 'ㅈ ㅈ', ko: '잘 자', zh: '晚安' },
          { ch: 'ㄱ ㄷ ㄹ ㄱ', ko: '기다릴게', zh: '我等你' },
          { ch: 'ㅇ ㅇ ㅈ', ko: '안아줘', zh: '抱抱我' },
          { ch: 'ㅇ ㅅ ㅎ', ko: '약속해', zh: '拉钩约定' },
          { ch: 'ㅊ ㄱ ㅇ', ko: '최고야', zh: '最棒了' },
          { ch: 'ㅇ ㅈ ㅈ ㅇ', ko: '완전 좋아', zh: '超级喜欢' }
        ];
        let choseongIdx = 0, choseongAnswered = false;
        function checkChoseongAnswer(userStr) {
          if (choseongAnswered) return;
          const cPool = getActiveChoseongPool();
          const item = cPool[choseongIdx % cPool.length];
          const norm = (s) => String(s || '').replace(/[\s.!?~]/g, '');
          const ok = norm(userStr) === norm(item.ko);
          const fb = document.getElementById('choseongFeedback');
          if (!fb) return;
          fb.classList.remove('hidden');
          if (ok) {
            choseongAnswered = true;
            playNotifChime();
            speakKorean(item.ko);
            fb.className = 'rounded-2xl p-3 text-xs font-semibold text-center bg-emerald-100/80 text-emerald-800';
            if (gameDirection === 'learn-ko' && canEarnJingchanXp()) {
              recordJingchanStudyProgress(20);
              state.learn.streak = (state.learn.streak || 0) + 1;
              saveState(true); renderLearn(); renderHome();
              fb.textContent = state.lang === 'zh' ? `🎉 猜对啦！「${item.ko}」 (+20 XP)` : `🎉 정답! "${item.ko}" (+20 XP)`;
            } else {
              fb.textContent = state.lang === 'zh' ? `❤️ 猜对啦！「${item.ko}」(完练习模式 · 不计入靖灿进度)` : `❤️ 정답! "${item.ko}" (수완 연습 모드 · 징찬 XP 미반영)`;
            }
            if (window.__choseongAutoTimer) clearTimeout(window.__choseongAutoTimer);
            window.__choseongAutoTimer = setTimeout(() => { choseongIdx += 1; loadChoseongQuestion(); }, 2000);
          } else {
            fb.className = 'rounded-2xl p-3 text-xs font-semibold text-center bg-rose-100/80 text-rose-700';
            fb.textContent = state.lang === 'zh' ? '还差一点点，试试看首字提示或听发音吧 💡' : '조금 달라요! 첫 글자 힌트나 발음 듣기를 눌러보세요 💡';
          }
        }
        function loadChoseongQuestion() {
          const cPool = getActiveChoseongPool();
          const item = cPool[choseongIdx % cPool.length];
          choseongAnswered = false;
          document.getElementById('choseongCounter').textContent = `#${(choseongIdx % cPool.length) + 1} / ${cPool.length}`;
          document.getElementById('choseongPrompt').textContent = item.ch;
          document.getElementById('choseongMeaningZh').textContent = state.lang === 'zh' ? `中文意思：${item.zh}` : `뜻: ${item.zh}`;
          const hintEl = document.getElementById('choseongHintText');
          const fbEl = document.getElementById('choseongFeedback');
          const inpEl = document.getElementById('choseongAnswerInput');
          if (hintEl) { hintEl.classList.add('hidden'); hintEl.textContent = ''; }
          if (fbEl) { fbEl.classList.add('hidden'); fbEl.textContent = ''; }
          if (inpEl) inpEl.value = '';
          const others = shuffleArr(CHOSEONG_LIST.filter(x => x.ko !== item.ko)).slice(0, 3);
          const opts = shuffleArr([item, ...others]);
          const grid = document.getElementById('choseongOptionsGrid');
          if (grid) {
            grid.innerHTML = opts.map(o => `<button type="button" class="btn-ghost py-2.5 px-3 rounded-2xl text-sm font-semibold text-center" data-ch-opt="${escapeHtml(o.ko)}">${escapeHtml(o.ko)}</button>`).join('');
            grid.querySelectorAll('[data-ch-opt]').forEach(btn => {
              btn.addEventListener('click', () => checkChoseongAnswer(btn.getAttribute('data-ch-opt')));
            });
          }
        }
        const chHintBtn = document.getElementById('choseongHintBtn');
        const chAudioBtn = document.getElementById('choseongAudioBtn');
        const chNextBtn = document.getElementById('choseongNextBtn');
        const chForm = document.getElementById('choseongInputForm');
        if (chHintBtn) chHintBtn.addEventListener('click', () => {
          const cPool = getActiveChoseongPool(); const item = cPool[choseongIdx % cPool.length];
          const h = document.getElementById('choseongHintText');
          if (h) { h.classList.remove('hidden'); h.textContent = `💡 ${item.ko[0]} ${'_ '.repeat(Math.max(1, item.ko.replace(/\s/g, '').length - 1)).trim()}`; }
        });
        if (chAudioBtn) chAudioBtn.addEventListener('click', () => {
          const cPool = getActiveChoseongPool(); const item = cPool[choseongIdx % cPool.length];
          speakKorean(item.ko);
        });
        if (chNextBtn) chNextBtn.addEventListener('click', () => { choseongIdx += 1; loadChoseongQuestion(); });
        if (chForm) chForm.addEventListener('submit', (e) => {
          e.preventDefault();
          const val = document.getElementById('choseongAnswerInput').value.trim();
          if (val) checkChoseongAnswer(val);
        });

        // Anniversary
        document.getElementById('coupleStartDateInput').addEventListener('change', (e) => {
          if (!e.target.value) return;
          state.startDate = e.target.value; state.startDateUpdatedAt = Date.now(); saveState(true); renderAnniversary(); renderHome();
          showToast(state.lang === 'zh' ? '相恋纪念日已安全保存 💜' : '시작일이 안전하게 저장되었습니다 💜');
        });
        document.getElementById('addAnnivBtn').addEventListener('click', () => {
          const title = document.getElementById('customAnnivTitle').value.trim();
          const date = document.getElementById('customAnnivDate').value;
          const repeat = document.getElementById('customAnnivRepeat').checked;
          if (!title || !date) { showToast(state.lang === 'zh' ? '请填写纪念日名称和日期' : '기념일 이름과 날짜를 모두 입력해 주세요.'); return; }
          state.anniversaries.unshift({ id: `ann_${Date.now()}`, title, date, repeat });
          document.getElementById('customAnnivTitle').value = '';
          saveState(true); renderAnniversary();
          pushNotification('💍', '새 기념일 등록', '新增纪念日', `${title} (${date})`, `${title} (${date})`, 'anniversary', '', 'post', false);
        });

        // Custom Couple Phrase Adder (Syncs to Cheat Sheet & Quiz Bank Live!)
        const customPhraseForm = document.getElementById('customPhraseForm');
        if (customPhraseForm) {
          customPhraseForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const koInp = document.getElementById('customPhraseKo');
            const zhInp = document.getElementById('customPhraseZh');
            const nuInp = document.getElementById('customPhraseNu');
            const btn = document.getElementById('addCustomPhraseBtn');
            const ko = (koInp && koInp.value || '').trim();
            if (!ko) { showToast(state.lang === 'zh' ? '请输入要添加的韩语表达' : '추가할 한국어 표현을 입력해 주세요.'); return; }
            let zh = (zhInp && zhInp.value || '').trim();
            const nu = (nuInp && nuInp.value || '').trim() || (state.lang === 'zh' ? '完为靖灿专属添加的实用表达' : '수완이 직접 추가한 맞춤 표현');
            if (btn) { btn.disabled = true; btn.textContent = '...'; }
            if (!zh) {
              try {
                const tr = await geminiTranslate(ko, 'lover');
                zh = (tr && tr.translated) ? tr.translated : ko;
              } catch (_) { zh = ko; }
            }
            if (!Array.isArray(state.customPhrases)) state.customPhrases = [];
            let nuZh = '完为你专属添加的实用韩语表达！';
            if (nu && /[가-힣]/.test(nu) && nu !== '수완이 직접 추가한 맞춤 표현') {
              try { const trNu = await geminiTranslate(nu, 'casual'); if (trNu && trNu.translated) nuZh = trNu.translated; } catch (_) {}
            } else if (nu && !/[가-힣]/.test(nu)) { nuZh = nu; }
            state.customPhrases.unshift({ id: `cp_${Date.now()}`, cat: '💜 수완 맞춤', ko, zh, nu, nuZh, isCustom: true });
            if (koInp) koInp.value = '';
            if (zhInp) zhInp.value = '';
            if (nuInp) nuInp.value = '';
            if (btn) { btn.disabled = false; btn.textContent = I18N[state.lang].addCustomPhraseBtn || '✨ 표현 추가'; }
            saveState(true);
            renderLearn();
            showToast(state.lang === 'zh' ? '💜 已加入专属词库和题库，并实时同步给对方！' : '💜 맞춤 단어장과 퀴즈에 추가되었고 상대방에게도 실시간 공유됐어요!');
            const pName = (state.myRole || 'suwan') === 'suwan' ? '수완(完)' : '靖灿(灿)';
            pushNotification('📚', `${pName}이 새 맞춤 한국어 표현을 추가했어요!`, `${pName}添加了新的专属韩语表达！`, `${ko} (${zh})`, `${ko} (${zh})`, 'learn', 'cheat', 'post', false, state.myRole || 'suwan');
          });
        }
        document.body.addEventListener('click', (e) => {
          const delCp = e.target.closest('.del-custom-phrase-btn');
          if (delCp) {
            const cid = delCp.getAttribute('data-id');
            openConfirm(
              state.lang === 'zh' ? '删除专属表达' : '맞춤 표현 삭제',
              state.lang === 'zh' ? '确定要删除这条专属表达吗？' : '이 맞춤 표현을 삭제할까요?',
              () => {
                state.customPhrases = (state.customPhrases || []).filter(x => x.id !== cid);
                saveState(true);
                renderLearn();
                showToast(state.lang === 'zh' ? '已删除该专属表达' : '맞춤 표현을 삭제했어요.');
              }
            );
          }
        });

        // Good Morning / Good Night Voice Letter Mailbox
        let vlSelectedTag = '☀️ 굿모닝';
        let vlPendingAudioUrl = '';
        let vlRecorder = null, vlStream = null, vlTimer = null, vlMaxTimer = null, vlStartTs = 0, vlIsRec = false, vlConnecting = false;
        let vlPcmCtx = null, vlPcmProc = null, vlPcmBufs = [];

        function renderVoiceLetters() {
          const list = document.getElementById('voiceLetterList');
          if (!list) return;
          const isZh = state.lang === 'zh';
          const allItems = Array.isArray(state.voiceLetters) ? state.voiceLetters : [];
          const letterItems = allItems.filter(v => v && v.source !== 'messenger');
          const chatItems = allItems.filter(v => v && v.source === 'messenger');
          const activeF = window.__vlFilter || 'all';
          const items = activeF === 'letter' ? letterItems : (activeF === 'messenger' ? chatItems : allItems);

          const filterHtml = `
            <div class="flex flex-wrap gap-1.5 pb-1">
              <button type="button" class="vl-filter-btn ${activeF === 'all' ? 'btn-royal' : 'btn-ghost'} px-3 py-1 rounded-full text-[11px] font-bold" data-vlf="all">${isZh ? '全部' : '전체'} ${allItems.length}</button>
              <button type="button" class="vl-filter-btn ${activeF === 'letter' ? 'btn-royal' : 'btn-ghost'} px-3 py-1 rounded-full text-[11px] font-bold" data-vlf="letter">💌 ${isZh ? '语音信' : '음성편지'} ${letterItems.length}</button>
              <button type="button" class="vl-filter-btn ${activeF === 'messenger' ? 'btn-royal' : 'btn-ghost'} px-3 py-1 rounded-full text-[11px] font-bold" data-vlf="messenger">💬 ${isZh ? '聊天语音' : '메신저 음성'} ${chatItems.length}</button>
            </div>`;

          if (!items.length) {
            list.innerHTML = filterHtml + `<div class="royal-card rounded-2xl p-7 text-center text-xs text-mut space-y-3">
              <div>${isZh ? '还没有收藏的语音哦 🎙️' : '아직 보관된 음성이 없어요 🎙️'}</div>
              ${allItems.length === 0 ? `<div class="pt-1 space-y-1.5">
                <button type="button" class="cw-inline-vault-restore-btn btn-royal px-4 py-2 rounded-full text-xs font-bold shadow-sm">${isZh ? '☁️ 从云端 · 对方手机一键恢复语音信与相册' : '☁️ 서버 · 상대방 폰에서 음성편지·사진 복구하기'}</button>
                <div class="text-[10.5px] text-mut">${isZh ? '对方打开网页时点击即可实时同步找回所有录音与照片' : '징찬이 웹앱(또는 이전 브라우저)이 켜지면 영구 금고로 자동 복구돼요'}</div>
              </div>` : ''}
            </div>`;
            list.querySelectorAll('.vl-filter-btn').forEach(b => b.addEventListener('click', () => { window.__vlFilter = b.getAttribute('data-vlf') || 'all'; renderVoiceLetters(); }));
            list.querySelectorAll('.cw-inline-vault-restore-btn').forEach(b => b.addEventListener('click', () => { if (typeof window.__runFullCloudDataRestore === 'function') window.__runFullCloudDataRestore(false); }));
            return;
          }
          list.innerHTML = filterHtml + items.map(v => `
            <article class="royal-card rounded-3xl p-4 space-y-2.5">
              <div class="flex items-center justify-between gap-2 text-xs">
                <div class="flex items-center gap-1.5 flex-wrap">
                  <span class="font-bold text-gold">${v.sender === 'suwan' ? '❤️ 수완(完)' : '💜 靖灿(灿)'}</span>
                  <span class="px-2 py-0.5 rounded-full text-[10px] font-semibold" style="background: var(--accent-royal-soft); color: var(--accent-royal);">${escapeHtml(v.tag || '🎙️')}</span>
                  <span class="text-[11px] text-mut">${escapeHtml(v.date || '')} ${escapeHtml(v.time || '')}</span>
                </div>
                <button type="button" class="del-vl-btn text-xs text-mut hover:text-rose-400" data-id="${escapeHtml(v.id)}">✕</button>
              </div>
              ${v.audioUrl ? `<audio controls preload="metadata" src="${__cwMediaUrl(normalizeAudioDataUrl(v.audioUrl), 'audio/mp4')}" class="w-full h-10"></audio>` : ''}
              ${v.note ? renderBilingualCard(v.note, v.translated || '', '', true) : ''}
            </article>
          `).join('');
          list.querySelectorAll('.vl-filter-btn').forEach(b => b.addEventListener('click', () => { window.__vlFilter = b.getAttribute('data-vlf') || 'all'; renderVoiceLetters(); }));
          list.querySelectorAll('.del-vl-btn').forEach(btn => {
            btn.addEventListener('click', () => {
              const vid = btn.getAttribute('data-id');
              openConfirm(
                state.lang === 'zh' ? '删除语音信件' : '음성편지 삭제',
                state.lang === 'zh' ? '确定要删除这条语音信件吗？' : '이 음성편지를 삭제할까요?',
                () => {
                  if (!Array.isArray(state.deletedVoiceIds)) state.deletedVoiceIds = [];
                if (!state.deletedVoiceIds.includes(vid)) state.deletedVoiceIds.push(vid);
                state.voiceLetters = (state.voiceLetters || []).filter(x => x.id !== vid);
                try { idbPut('voice_letters_vault_v1', state.voiceLetters); idbPut('deleted_voices_vault_v1', state.deletedVoiceIds); } catch (_) {}
                  saveState(true); renderVoiceLetters();
                }
              );
            });
          });
        }
        window.renderVoiceLetters = renderVoiceLetters;

        function vlCleanup() {
          if (vlTimer) { clearInterval(vlTimer); vlTimer = null; }
          if (vlMaxTimer) { clearTimeout(vlMaxTimer); vlMaxTimer = null; }
          if (vlPcmProc) { try { vlPcmProc.disconnect(); } catch (_) {} vlPcmProc = null; }
          if (vlPcmCtx) { try { vlPcmCtx.close(); } catch (_) {} vlPcmCtx = null; }
          if (vlStream) { try { vlStream.getTracks().forEach(t => t.stop()); } catch (_) {} vlStream = null; }
          vlRecorder = null; vlIsRec = false; vlConnecting = false;
        }

        function vlSetPreview(url) {
          vlPendingAudioUrl = normalizeAudioDataUrl(url || '');
          const wrap = document.getElementById('vlPreviewWrap');
          const aud = document.getElementById('vlPreviewAudio');
          const sendBtn = document.getElementById('vlSendBtn');
          if (vlPendingAudioUrl && wrap && aud) {
            aud.src = vlPendingAudioUrl; wrap.classList.remove('hidden');
            if (sendBtn) sendBtn.classList.remove('opacity-50', 'pointer-events-none');
          } else {
            if (wrap) wrap.classList.add('hidden');
            if (aud) { aud.pause(); aud.removeAttribute('src'); }
            if (sendBtn) sendBtn.classList.add('opacity-50', 'pointer-events-none');
          }
        }

        function vlStopRec() {
          if (!vlIsRec) return;
          const isZh = state.lang === 'zh';
          const btn = document.getElementById('vlRecordBtn');
          const dot = document.getElementById('vlStatusDot');
          const st = document.getElementById('vlStatusText');
          if (btn) { btn.innerHTML = `<span class="inline-flex items-center gap-1.5">${CW_MEDIA_SVG.recDot}<span data-i18n="vlRecStart">${isZh ? '开始录音' : '녹음 시작'}</span></span>`; btn.classList.remove('badge-pulse'); }
          if (dot) dot.style.background = '#a855f7';
          if (vlTimer) { clearInterval(vlTimer); vlTimer = null; }
          if (vlMaxTimer) { clearTimeout(vlMaxTimer); vlMaxTimer = null; }
          if (vlRecorder && vlRecorder.state !== 'inactive') {
            try { vlRecorder.requestData && vlRecorder.requestData(); } catch (_) {}
            try { vlRecorder.stop(); } catch (_) { vlCleanup(); }
            return;
          }
          if (vlPcmBufs.length) {
            const sr = vlPcmCtx ? vlPcmCtx.sampleRate : 16000;
            const wav = encodePcmToWavDataUrl(vlPcmBufs, sr);
            vlPcmBufs = []; vlCleanup(); vlSetPreview(wav);
            if (st) st.textContent = isZh ? '录音完成！试听后点发送 💌' : '녹음 완료! 미리듣기 후 보내기를 눌러주세요 💌';
            return;
          }
          vlCleanup();
        }

        document.querySelectorAll('.vl-tag-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            vlSelectedTag = btn.getAttribute('data-tag') || '☀️ 굿모닝';
            document.querySelectorAll('.vl-tag-btn').forEach(b => {
              const act = b === btn;
              b.className = `vl-tag-btn ${act ? 'btn-royal' : 'btn-ghost'} px-2.5 py-1 rounded-full text-[11px] font-semibold`;
            });
          });
        });

        const vlRecBtn = document.getElementById('vlRecordBtn');
        if (vlRecBtn) {
          vlRecBtn.addEventListener('click', async () => {
            const isZh = state.lang === 'zh';
            if (vlIsRec) { vlStopRec(); return; }
            if (vlConnecting) return;
            const st = document.getElementById('vlStatusText');
            const dot = document.getElementById('vlStatusDot');
            const isLocal = window.location && window.location.protocol === 'file:';
            const isEmb = (() => { try { return window.self !== window.top; } catch (_) { return true; } })();
            if (isLocal || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
              const fi = document.getElementById('vlFileInput');
              if (fi) { fi.click(); return; }
              return;
            }
            vlConnecting = true;
            vlRecBtn.textContent = isZh ? '⏳ 连接麦克风...' : '⏳ 마이크 연결 중...';
            if (st) st.textContent = isZh ? '正在请求麦克风权限...' : '마이크 권한을 기다리는 중이에요...';
            if (dot) dot.style.background = '#f59e0b';
            try {
              const waitMs = isEmb ? 2500 : 25000;
              const stream = await Promise.race([
                requestSafeAudioStream(),
                new Promise((_, rej) => setTimeout(() => rej(new Error('MIC_TIMEOUT')), waitMs))
              ]);
              vlConnecting = false; vlStream = stream; vlIsRec = true; vlStartTs = Date.now();
              vlRecBtn.innerHTML = `<span class="inline-flex items-center gap-1.5">${CW_MEDIA_SVG.stopBadge}<span>${isZh ? '停止录音' : '녹음 중지'}</span></span>`;
              vlRecBtn.classList.add('badge-pulse');
              if (dot) dot.style.background = '#e11d48';
              if (st) st.textContent = isZh ? '正在录制语音信... 说完点停止' : '음성 편지 녹음 중! 다 말하면 중지를 눌러주세요';
              const tEl = document.getElementById('vlTimerText');
              if (tEl) tEl.textContent = '00:00';
              vlTimer = setInterval(() => {
                const sec = Math.floor((Date.now() - vlStartTs) / 1000);
                if (tEl) tEl.textContent = `${String(Math.floor(sec / 60)).padStart(2, '0')}:${String(sec % 60).padStart(2, '0')}`;
              }, 250);
              let okRec = false;
              if (typeof MediaRecorder !== 'undefined') {
                try {
                  const mime = ['audio/mp4', 'audio/webm;codecs=opus', 'audio/webm', 'audio/ogg'].find(m => MediaRecorder.isTypeSupported && MediaRecorder.isTypeSupported(m)) || '';
                  const rec = mime ? new MediaRecorder(stream, { mimeType: mime }) : new MediaRecorder(stream);
                  const chunks = [];
                  vlRecorder = rec;
                  rec.ondataavailable = (ev) => { if (ev.data && ev.data.size > 0) chunks.push(ev.data); };
                  rec.onstop = () => {
                    try {
                      const blob = new Blob(chunks, { type: mime || (chunks[0] && chunks[0].type) || 'audio/webm' });
                      if (blob.size > 100) {
                        const r = new FileReader();
                        r.onloadend = () => {
                          vlSetPreview(String(r.result || ''));
                          if (st) st.textContent = isZh ? '录音完成！试听后点发送 💌' : '녹음 완료! 미리듣기 후 보내기를 눌러주세요 💌';
                        };
                        r.readAsDataURL(blob);
                      }
                    } catch (_) {}
                    vlCleanup();
                  };
                  rec.start(250); okRec = true;
                } catch (_) { vlRecorder = null; }
              }
              if (!okRec) {
                const AC = window.AudioContext || window.webkitAudioContext;
                vlPcmCtx = new AC();
                const src = vlPcmCtx.createMediaStreamSource(stream);
                vlPcmProc = vlPcmCtx.createScriptProcessor(4096, 1, 1);
                vlPcmBufs = [];
                vlPcmProc.onaudioprocess = (e) => { if (vlIsRec) vlPcmBufs.push(new Float32Array(e.inputBuffer.getChannelData(0))); };
                src.connect(vlPcmProc); vlPcmProc.connect(vlPcmCtx.destination);
              }
              vlMaxTimer = setTimeout(() => { if (vlIsRec) vlStopRec(); }, 60000);
            } catch (_) {
              vlCleanup();
              vlRecBtn.innerHTML = `<span class="inline-flex items-center gap-1.5">${CW_MEDIA_SVG.recDot}<span data-i18n="vlRecStart">${isZh ? '开始录音' : '녹음 시작'}</span></span>`;
              if (dot) dot.style.background = '#f59e0b';
              if (st) st.textContent = isZh ? '请允许麦克风权限或点「🎙️ 手机录音·文件」' : '마이크 권한을 허용하거나 「🎙️ 기기 녹음·파일」을 눌러 주세요';
            }
          });
        }

        const vlFileInp = document.getElementById('vlFileInput');
        if (vlFileInp) {
          vlFileInp.addEventListener('change', (e) => {
            const f = e.target.files && e.target.files[0];
            if (!f) return;
            if (f.size > 8 * 1024 * 1024) { showToast(state.lang === 'zh' ? '语音文件需小于 8MB 才能发送哦' : '음성 파일은 8MB 이하만 보낼 수 있어요.'); return; }
            const r = new FileReader();
            r.onloadend = () => {
              vlSetPreview(String(r.result || ''));
              const st = document.getElementById('vlStatusText');
              if (st) st.textContent = state.lang === 'zh' ? '语音已载入！试听后点发送 💌' : '음성 파일이 준비됐어요! 미리듣기 후 보내주세요 💌';
            };
            r.readAsDataURL(f); e.target.value = '';
          });
        }

        const vlSendBtn = document.getElementById('vlSendBtn');
        if (vlSendBtn) {
          vlSendBtn.addEventListener('click', async () => {
            if (!vlPendingAudioUrl) return;
            vlSendBtn.disabled = true; vlSendBtn.textContent = '...';
            const noteEl = document.getElementById('vlNoteInput');
            const note = (noteEl && noteEl.value || '').trim();
            let translated = '';
            if (note) {
              try { const tr = await geminiTranslate(note, 'lover'); translated = (tr && tr.translated) || ''; } catch (_) {}
            }
            const sender = state.myRole || 'suwan';
            const pName = sender === 'suwan' ? '수완(完)' : '靖灿(灿)';
            const vlObj = {
              id: `vl_${Date.now()}`, sender, tag: vlSelectedTag, note, translated,
              date: getKstDateString(),
              time: new Date().toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' }),
              audioUrl: vlPendingAudioUrl
            };
            if (!Array.isArray(state.voiceLetters)) state.voiceLetters = [];
            state.voiceLetters.unshift(vlObj);
            const audioCopy = vlPendingAudioUrl;
            if (noteEl) noteEl.value = '';
            vlSetPreview('');
            const tEl = document.getElementById('vlTimerText');
            if (tEl) tEl.textContent = '00:00';
            vlSendBtn.disabled = false;
            vlSendBtn.textContent = I18N[state.lang].vlSendBtn || '💌 음성 편지 보내기';
            saveState(true);
            renderVoiceLetters();
            if (typeof window.__pushMediaSyncPacket === 'function') {
              const ext = audioCopy.includes('audio/wav') ? 'wav' : (audioCopy.includes('audio/mp4') ? 'mp4' : 'webm');
              window.__pushMediaSyncPacket('voice_letter', { id: vlObj.id, sender, tag: vlObj.tag, note, translated, date: vlObj.date, time: vlObj.time }, audioCopy, `letter.${ext}`);
            }
            showToast(state.lang === 'zh' ? '💌 语音信已发送并实时同步给对方！' : '💌 음성 편지가 저장되고 상대방에게 실시간 전송됐어요!');
            pushNotification('🎙️', `${pName}의 새 음성 편지!`, `${pName}发来新语音信！`, `${vlObj.tag} ${note || ''}`, `${vlObj.tag} ${translated || note || ''}`, 'diary', 'voice', 'post', false, sender);
          });
        }
        renderVoiceLetters();

        // Tab 5: 기록·일기 (Diary + Q&A + Time Capsule + Memo)
        document.querySelectorAll('.diary-subtab').forEach(btn => btn.addEventListener('click', () => switchDiarySubtab(btn.getAttribute('data-subtab'))));
        document.querySelectorAll('.couple-cat-btn').forEach(btn => btn.addEventListener('click', () => switchDiarySubtab(COUPLE_CAT_DEFAULT[btn.getAttribute('data-couple-cat')] || 'diary')));
        window.__coupleRecordMode = 'diary';
        window.__coupleRecordFilter = 'all';
        function syncRecordModeUI() {
          const isMemo = window.__coupleRecordMode === 'memo';
          const isZh = state.lang === 'zh';
          document.querySelectorAll('.record-mode-btn').forEach(b => {
            const act = b.getAttribute('data-rec-mode') === window.__coupleRecordMode;
            b.className = `record-mode-btn ${act ? 'btn-royal' : 'btn-ghost'} px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap`;
          });
          const titleEl = document.getElementById('diaryTitle');
          const moodEl = document.getElementById('diaryMood');
          const contentEl = document.getElementById('diaryContent');
          const submitBtn = document.getElementById('diarySubmitBtn');
          if (titleEl) titleEl.classList.toggle('hidden', isMemo);
          if (moodEl) moodEl.classList.toggle('hidden', isMemo);
          if (contentEl) {
            contentEl.rows = isMemo ? 2 : 3;
            contentEl.placeholder = isMemo
              ? (isZh ? '输入共享备忘、待办事项或约会安排...（自动翻译）' : '공유 메모, 할 일, 데이트 약속을 적어주세요... (자동 번역)')
              : (isZh ? '写下今天的故事或想说的话（自动中韩翻译）' : '오늘의 일기나 전하고 싶은 이야기를 적어주세요 (자동 한·중 번역)');
          }
          if (submitBtn) {
            submitBtn.textContent = isMemo
              ? (isZh ? '保存备忘 & 翻译' : '메모 저장 & 번역')
              : (isZh ? '保存日记 & 翻译' : '일기 저장 & 번역');
          }
        }
        document.querySelectorAll('.record-mode-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            window.__coupleRecordMode = btn.getAttribute('data-rec-mode') || 'diary';
            syncRecordModeUI();
          });
        });
        document.querySelectorAll('.record-filter-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            window.__coupleRecordFilter = btn.getAttribute('data-rec-filter') || 'all';
            document.querySelectorAll('.record-filter-btn').forEach(b => {
              const act = b.getAttribute('data-rec-filter') === window.__coupleRecordFilter;
              b.className = `record-filter-btn ${act ? 'btn-royal' : 'btn-ghost'} px-3 py-1 rounded-full text-[11px] font-semibold whitespace-nowrap`;
            });
            renderDiaryQaMemos();
          });
        });
        syncRecordModeUI();

        document.getElementById('diaryForm').addEventListener('submit', async (e) => {
          e.preventDefault();
          const isMemo = window.__coupleRecordMode === 'memo';
          const author = document.getElementById('diaryAuthor').value || (state.myRole === 'jingchan' ? '靖灿(灿)' : '수완(完)');
          const content = document.getElementById('diaryContent').value.trim();
          if (!content) { showToast(state.lang === 'zh' ? '请输入内容' : '내용을 입력해 주세요.'); return; }
          if (isMemo) {
            document.getElementById('diaryContent').value = '';
            const res = await geminiTranslate(content, 'casual');
            state.memos.unshift({ id: `memo_${Date.now()}`, authorRole: state.myRole || 'suwan', author, text: content, translated: res.translated, pronunciation: res.pronunciation, done: false, comments: [] });
            saveState(true); renderDiaryQaMemos(); renderHome();
            pushNotification('📝', `${author}의 새 메모`, `${author}新增了备忘录`, content, res.translated, 'diary', 'diary', 'post', false);
            return;
          }
          const rawTitle = document.getElementById('diaryTitle').value.trim();
          const title = rawTitle || (content.length > 22 ? content.slice(0, 22) + '…' : content);
          const [titleRes, res] = await Promise.all([geminiTranslate(title, 'lover'), geminiTranslate(content, 'lover')]);
          state.diaries.unshift({ id: `diary_${Date.now()}`, authorRole: state.myRole || 'suwan', author, mood: document.getElementById('diaryMood').value, date: getKstDateString(), title, titleTranslated: titleRes.translated, content, translated: res.translated, pronunciation: res.pronunciation, nuance: res.nuance, tone: res.tone, comments: [] });
          document.getElementById('diaryTitle').value = '';
          document.getElementById('diaryContent').value = '';
          saveState(true); renderDiaryQaMemos(); renderHome();
          pushNotification('🪶', `${author}의 새 일기`, `${author}发布了新日记`, title, `${title} · ${res.translated}`, 'diary', 'diary', 'post', false);
        });

        document.getElementById('rotateQaBtn').addEventListener('click', () => { state.chat.qaIdx = ((state.chat.qaIdx || 0) + 1) % QA_QUESTIONS.length; saveState(); renderDiaryQaMemos(); });
        document.getElementById('qaForm').addEventListener('submit', async (e) => {
          e.preventDefault();
          const ta = document.getElementById('qaAnswerInput');
          const text = ta.value.trim();
          if (!text) return;
          ta.value = '';
          const sender = document.getElementById('qaAuthorSelect').value || 'suwan';
          const q = QA_QUESTIONS[(state.chat.qaIdx || 0) % QA_QUESTIONS.length];
          const res = await geminiTranslate(text, 'lover');
          state.chat.qaAnswers.unshift({ id: `qa_${Date.now()}`, sender, date: getKstDateString(), questionKo: q.ko, questionZh: q.zh, original: text, translated: res.translated, pronunciation: res.pronunciation, nuance: res.nuance });
          saveState(true); renderDiaryQaMemos();
          pushNotification('💌', '새 커플 문답 등록', '新增情侣问答', text, res.translated, 'diary', 'qa', 'post', false);
        });

        document.getElementById('capsuleForm').addEventListener('submit', async (e) => {
          e.preventDefault();
          const title = document.getElementById('capsuleTitle').value.trim();
          const unlockDate = document.getElementById('capsuleUnlockDate').value;
          const body = document.getElementById('capsuleBody').value.trim();
          if (!title || !unlockDate || !body) { showToast(state.lang === 'zh' ? '请填写标题、开启日期和信件内容' : '제목, 열리는 날, 편지 내용을 모두 입력해 주세요.'); return; }
          const [titleRes, res] = await Promise.all([geminiTranslate(title, 'lover'), geminiTranslate(body, 'lover')]);
          const author = document.getElementById('capsuleAuthor').value;
          if (!Array.isArray(state.capsules)) state.capsules = [];
          state.capsules.unshift({ id: `cap_${Date.now()}`, author, title, titleTranslated: titleRes.translated, unlockDate, body, translated: res.translated, pronunciation: res.pronunciation, forceOpened: false });
          document.getElementById('capsuleTitle').value = '';
          document.getElementById('capsuleBody').value = '';
          saveState(true); renderDiaryQaMemos(); renderHome();
          pushNotification('⏳', '새 타임캡슐 편지 봉인됨', '新时光胶囊信已封存', `${title} (${unlockDate} 열림)`, `${title} (${unlockDate} 开启)`, 'diary', 'capsule', 'post', false);
        });



        // Bucket & Album (inside 커플공간)
        document.getElementById('bucketForm').addEventListener('submit', async (e) => {
          e.preventDefault();
          const inp = document.getElementById('bucketInput');
          const text = inp.value.trim();
          if (!text) return;
          inp.value = '';
          const res = await geminiTranslate(text, 'casual');
          state.buckets.unshift({ id: `bkt_${Date.now()}`, cat: document.getElementById('bucketCategory').value, text, translated: res.translated, pronunciation: res.pronunciation, done: false });
          saveState(true); renderBucketAndAlbum(); renderHome();
          pushNotification('🦋', '새 위시리스트', '新增心愿清单', text, res.translated, 'diary', 'bucket', 'post', false);
        });
        const albumFileEl = document.getElementById('albumFileInput');
        const albumPreviewEl = document.getElementById('albumUploadPreview');
        const albumHintEl = document.getElementById('albumUploadHint');
        let pendingAlbumFiles = []; // Stores { name, size, lastModified, dataUrl } immediately so mobile OS never revokes File handles!
        let albumReadingPromise = Promise.resolve();

        function renderPendingAlbumPreviews() {
          const isZh = state.lang === 'zh';
          if (!albumPreviewEl) return;
          if (!pendingAlbumFiles.length) {
            albumPreviewEl.innerHTML = '';
            albumPreviewEl.classList.add('hidden');
            if (albumHintEl) albumHintEl.textContent = isZh ? '一次最多可选择 20 张照片批量上传 ✨' : '최대 20장까지 한 번에 여러 장 올릴 수 있어요 ✨';
            return;
          }
          albumPreviewEl.innerHTML = '';
          albumPreviewEl.classList.remove('hidden');
          if (albumHintEl) albumHintEl.textContent = isZh ? `已准备好 ${pendingAlbumFiles.length} 张（可继续添加，最多20张）` : `사진 ${pendingAlbumFiles.length}장 준비 완료! (추가 선택 가능 · 최대 20장)`;
          pendingAlbumFiles.forEach((item, idx) => {
            const wrap = document.createElement('div');
            wrap.className = 'relative w-14 h-14 shrink-0';
            if (item && item.dataUrl) {
              if (item.mediaType === 'video') {
                const vid = document.createElement('video');
                vid.src = item.dataUrl;
                vid.muted = true;
                vid.playsInline = true;
                vid.className = 'w-14 h-14 rounded-xl object-cover border';
                vid.style.borderColor = 'var(--border-accent)';
                wrap.appendChild(vid);
              } else {
                const img = document.createElement('img');
                img.src = item.dataUrl;
                img.alt = item.name || 'preview';
                img.className = 'w-14 h-14 rounded-xl object-cover border';
                img.style.borderColor = 'var(--border-accent)';
                wrap.appendChild(img);
              }
            }
            const rmBtn = document.createElement('button');
            rmBtn.type = 'button';
            rmBtn.textContent = '✕';
            rmBtn.className = 'absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full text-[10px] font-bold text-white flex items-center justify-center shadow';
            rmBtn.style.background = 'rgba(225,29,72,0.9)';
            rmBtn.addEventListener('click', () => {
              pendingAlbumFiles.splice(idx, 1);
              renderPendingAlbumPreviews();
            });
            wrap.appendChild(rmBtn);
            albumPreviewEl.appendChild(wrap);
          });
        }

        if (albumFileEl && albumPreviewEl) {
          albumFileEl.addEventListener('change', () => {
            const picked = Array.from(albumFileEl.files || []);
            if (!picked.length) return;
            const isZh = state.lang === 'zh';
            if (albumHintEl) albumHintEl.textContent = isZh ? `正在读取 ${picked.length} 张照片...` : `사진 ${picked.length}장 불러오는 중...`;
            albumReadingPromise = (async () => {
              let loadedNow = 0;
              for (const f of picked) {
                if (pendingAlbumFiles.length >= 20) break;
                const dup = pendingAlbumFiles.some(x => x.name === f.name && x.size === f.size && x.lastModified === f.lastModified);
                if (dup) continue;
                try {
                  const isVidFile = String(f.type || '').startsWith('video/') || /\.(mp4|mov|webm|m4v)$/i.test(f.name || '');
                  if (isVidFile) {
                    // Unlimited video size allowed (chunked parallel transfer)
                    const vUrl = await (typeof window.__prepareVideoDataUrl === 'function'
                      ? window.__prepareVideoDataUrl(f)
                      : new Promise((res, rej) => {
                          const r = new FileReader();
                          r.onload = () => res(String(r.result || ''));
                          r.onerror = rej;
                          r.readAsDataURL(f);
                        }));
                    if (vUrl && vUrl.startsWith('data:')) {
                      pendingAlbumFiles.push({ name: f.name || '', size: f.size || 0, lastModified: f.lastModified || 0, dataUrl: vUrl, mediaType: 'video' });
                      loadedNow++;
                    }
                  } else {
                    const dataUrl = await compressImageToDataUrl(f, 720);
                    if (dataUrl && dataUrl.startsWith('data:')) {
                      pendingAlbumFiles.push({ name: f.name || '', size: f.size || 0, lastModified: f.lastModified || 0, dataUrl, mediaType: 'image' });
                      loadedNow++;
                    }
                  }
                } catch (_) {}
              }
              try { albumFileEl.value = ''; } catch (_) {}
              renderPendingAlbumPreviews();
              if (!loadedNow && !pendingAlbumFiles.length) {
                showToast(isZh ? '无法读取该照片格式，请换一张重试 📷' : '사진을 읽지 못했어요. 다른 사진으로 다시 시도해 주세요 📷');
              }
            })();
          });
        }

        document.getElementById('albumForm').addEventListener('submit', async (e) => {
          e.preventDefault();
          const isZh = state.lang === 'zh';
          const fileInput = document.getElementById('albumFileInput');
          const capInput = document.getElementById('albumCaptionInput');
          const subBtn = document.getElementById('albumSubmitBtn');
          try { await albumReadingPromise; } catch (_) {}
          const rawFiles = (!pendingAlbumFiles.length && fileInput && fileInput.files && fileInput.files.length)
            ? Array.from(fileInput.files).slice(0, 20)
            : [];
          const readyItems = pendingAlbumFiles.slice(0, 20);
          const totalCount = readyItems.length || rawFiles.length;
          if (!totalCount) { showToast(isZh ? '请先选择要上传的照片 📷' : '사진 파일을 먼저 선택해 주세요 📷'); return; }
          const origBtnTxt = subBtn ? subBtn.textContent : '';
          if (subBtn) { subBtn.disabled = true; subBtn.textContent = isZh ? `保存中 (0/${totalCount})...` : `저장 중 (0/${totalCount})...`; }
          try {
            if (!Array.isArray(state.albums)) state.albums = [];
            const caption = capInput.value.trim() || (isZh ? '我们的珍贵瞬间' : '우리의 소중한 순간');
            let translated = '';
            try {
              const res = await geminiTranslate(caption, 'lover');
              if (res && res.translated) translated = res.translated;
            } catch (_) {}
            const activeCat = window.__activeAlbumCat && window.__activeAlbumCat !== 'all' ? window.__activeAlbumCat : '';
            const albCat = activeCat || detectPhotoCategory(caption);
            const todayStr = getKstDateString();
            const syncQueue = [];
            let addedCount = 0;
            const listToSave = readyItems.length ? readyItems : rawFiles;
            for (let i = 0; i < listToSave.length; i++) {
              if (subBtn) subBtn.textContent = isZh ? `保存中 (${i + 1}/${listToSave.length})...` : `저장 중 (${i + 1}/${listToSave.length})...`;
              const entry = listToSave[i];
              const entryIsVid = (entry && entry.mediaType === 'video') || (entry instanceof File && String(entry.type || '').startsWith('video/'));
              let dataUrl = '';
              if (entry && entry.dataUrl) dataUrl = entry.dataUrl;
              else if (entryIsVid) {
                dataUrl = await new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result || '')); r.onerror = rej; r.readAsDataURL(entry); });
              } else {
                dataUrl = await compressImageToDataUrl(entry, 720);
              }
              if (!dataUrl || !dataUrl.startsWith('data:')) continue;
              const newAlbId = `alb_${Date.now()}_${i}`;
              state.albums.unshift({
                id: newAlbId, authorRole: state.myRole || 'suwan', dataUrl, mediaType: entryIsVid ? 'video' : 'image',
                caption, translated, date: todayStr, category: albCat, source: 'album', comments: []
              });
              addedCount++;
              syncQueue.push({ albumId: newAlbId, dataUrl, idx: i, isVid: entryIsVid });
            }
            if (!addedCount) throw new Error('no_valid_image');
            pendingAlbumFiles = [];
            fileInput.value = '';
            capInput.value = '';
            renderPendingAlbumPreviews();
            saveState(true);
            renderBucketAndAlbum();
            renderHome();
            showToast(isZh ? `🖼️ 已成功保存 ${addedCount} 张照片到相册！` : `🖼️ 사진 ${addedCount}장이 앨범에 한 번에 올라갔어요!`);
            pushNotification('🖼️', `새 추억 사진 ${addedCount}장 등록`, `相册新增 ${addedCount} 张回忆照片`, caption, translated || caption, 'diary', 'album', 'post', false, state.myRole || 'suwan');
            // Space out cross-border media sync uploads so ntfy.sh doesn't rate-limit bursts
            if (typeof window.__pushMediaSyncPacket === 'function') {
              (async () => {
                for (const item of syncQueue) {
                  try {
                    await window.__pushMediaSyncPacket(item.isVid ? 'album_video' : 'album_photo', {
                      albumId: item.albumId, caption, translated, category: albCat, date: todayStr
                    }, item.dataUrl, item.isVid ? `album_${item.idx}.mp4` : `album_${item.idx}.jpg`);
                  } catch (_) {}
                  await new Promise(r => setTimeout(r, 320));
                }
              })();
            }
          } catch (_) {
            showToast(isZh ? '照片上传失败，请换一张照片重试' : '사진을 읽지 못했어요. 다른 사진으로 다시 시도해 주세요.');
          } finally {
            if (subBtn) { subBtn.disabled = false; subBtn.textContent = origBtnTxt || (isZh ? '保存到相册' : '앨범에 보관'); }
          }
        });

        // Settings & Backup (Custom Filename + Full Media/Voice + Auto AES-256 Encrypted when E2EE is enabled)
        document.getElementById('exportBackupBtn').addEventListener('click', async () => {
          const isZh = state.lang === 'zh';
          const isEnc = typeof window.__isE2eeActive === 'function' && window.__isE2eeActive();
          const defaultBase = isEnc
            ? `chanwan_shiguang_encrypted_backup_${getKstDateString()}`
            : `chanwan_shiguang_backup_${getKstDateString()}`;
          const entered = window.prompt(
            isZh ? '请输入要保存的备份文件名（无需输入 .json）：' : '저장할 백업 파일 이름을 입력해 주세요 (.json은 자동 추가돼요):',
            defaultBase
          );
          if (entered === null) return;
          const safeBase = String(entered || '').trim().replace(/[\\/:*?"<>|]+/g, '_').replace(/\.json$/i, '') || defaultBase;
          const fileName = `${safeBase}.json`;
          const outObj = isEnc && typeof window.__e2eeWrapPayload === 'function' ? await window.__e2eeWrapPayload(state) : state;
          const blob = new Blob([JSON.stringify(outObj, null, 2)], { type: 'application/json' });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url; a.download = fileName;
          document.body.appendChild(a); a.click(); document.body.removeChild(a); URL.revokeObjectURL(url);
          const albCnt = Array.isArray(state.albums) ? state.albums.length : 0;
          const vlCnt = Array.isArray(state.voiceLetters) ? state.voiceLetters.length : 0;
          showToast(isEnc
            ? (isZh ? `🔐 已保存加密备份「${fileName}」（照片 ${albCnt} · 语音信 ${vlCnt}）` : `🔐 「${fileName}」 암호화 저장 완료 (사진 ${albCnt}장 · 음성편지 ${vlCnt}건)`)
            : (isZh ? `📤 已保存「${fileName}」（照片 ${albCnt} · 语音信 ${vlCnt}）` : `📤 「${fileName}」 저장 완료 (사진 ${albCnt}장 · 음성편지 ${vlCnt}건)`));
        });
        document.getElementById('importBackupInput').addEventListener('change', (e) => {
          const file = e.target.files && e.target.files[0];
          if (!file) return;
          const reader = new FileReader();
          reader.onload = async () => {
            try {
              let parsed = JSON.parse(reader.result);
              if (!parsed || typeof parsed !== 'object') throw new Error('bad');
              if (parsed.__e2ee === 1) {
                if (typeof window.__e2eeUnwrapPayload !== 'function' || !window.__isE2eeActive()) {
                  showToast(state.lang === 'zh' ? '🔐 请先在设置中输入你们的加密密钥再恢复备份' : '🔐 암호화된 백업이에요! 먼저 설정에서 둘만의 비밀 암호키를 입력해 주세요');
                  return;
                }
                parsed = await window.__e2eeUnwrapPayload(parsed);
                if (!parsed || typeof parsed !== 'object') {
                  showToast(state.lang === 'zh' ? '❌ 密钥不匹配，无法解密此备份' : '❌ 암호키가 달라 백업을 복호화할 수 없어요');
                  return;
                }
              }
              // Prime 4 v60: 100% Non-Destructive Smart Union-Merge Backup Restore!
              // Keeps ALL newer messages/diaries/anniversaries/media on the phone while restoring ALL older messages, Korean Study XP/history, customVoices, TMI, quizzes & albums!
              const curSnap = state;
              const impSnap = mergeWithDefaults(parsed, parsed);

              const unionById = (curArr, impArr) => {
                const map = new Map();
                const out = [];
                for (const item of [...(Array.isArray(curArr) ? curArr : []), ...(Array.isArray(impArr) ? impArr : [])]) {
                  if (!item || !item.id || DUMMY_IDS.has(item.id)) continue;
                  if (!map.has(item.id)) {
                    const copy = { ...item };
                    map.set(item.id, copy);
                    out.push(copy);
                  } else {
                    const ex = map.get(item.id);
                    if (!ex.photoUrl && item.photoUrl) ex.photoUrl = item.photoUrl;
                    if (!ex.videoUrl && item.videoUrl) ex.videoUrl = item.videoUrl;
                    if (!ex.audioUrl && item.audioUrl) ex.audioUrl = item.audioUrl;
                    if ((!Array.isArray(ex.photoUrls) || !ex.photoUrls.length) && Array.isArray(item.photoUrls) && item.photoUrls.length) ex.photoUrls = item.photoUrls;
                    if ((!ex.translated || /^(⏳|\[)/.test(String(ex.translated))) && item.translated) ex.translated = item.translated;
                    if (Array.isArray(item.replies) && item.replies.length) {
                      const rMap = new Map((ex.replies || []).map(r => [r && r.id, r]));
                      item.replies.forEach(r => { if (r && r.id && !rMap.has(r.id)) { ex.replies = ex.replies || []; ex.replies.push(r); } });
                    }
                    if (Array.isArray(item.comments) && item.comments.length) {
                      const cMap = new Map((ex.comments || []).map(c => [c && c.id, c]));
                      item.comments.forEach(c => { if (c && c.id && !cMap.has(c.id)) { ex.comments = ex.comments || []; ex.comments.push(c); } });
                    }
                  }
                }
                return out;
              };

              const delMsgSet = new Set([...(curSnap.deletedMsgIds || []), ...(impSnap.deletedMsgIds || [])]);
              const delAlbSet = new Set([...(curSnap.deletedAlbumIds || []), ...(impSnap.deletedAlbumIds || [])]);
              const delVlSet = new Set([...(curSnap.deletedVoiceIds || []), ...(impSnap.deletedVoiceIds || [])]);

              const mergedMsgs = unionById(curSnap.chat?.messages, impSnap.chat?.messages)
                .filter(m => m && !delMsgSet.has(m.id))
                .sort((a, b) => (Number(a.ts || 0) || 0) - (Number(b.ts || 0) || 0));

              const mergedLearn = mergeLearnMonotonic(curSnap.learn, impSnap.learn);

              const __impAlbMap = new Map();
              [...(curSnap.albums || []), ...(impSnap.albums || [])].forEach(a => {
                if (!a || !a.id || delAlbSet.has(a.id)) return;
                const ex = __impAlbMap.get(a.id);
                if (!ex || (!ex.dataUrl && a.dataUrl)) __impAlbMap.set(a.id, ex ? { ...ex, ...a, dataUrl: a.dataUrl || ex.dataUrl } : a);
              });
              const mergedAlbums = Array.from(__impAlbMap.values()).sort((a, b) => Number(b.createdAt || 0) - Number(a.createdAt || 0));

              const __impVlMap = new Map();
              [...(curSnap.voiceLetters || []), ...(impSnap.voiceLetters || [])].forEach(v => {
                if (!v || !v.id || delVlSet.has(v.id)) return;
                const ex = __impVlMap.get(v.id);
                if (!ex || (!ex.audioUrl && v.audioUrl)) __impVlMap.set(v.id, ex ? { ...ex, ...v, audioUrl: v.audioUrl || ex.audioUrl } : v);
              });
              const mergedVoiceLetters = Array.from(__impVlMap.values()).sort((a, b) => Number(b.createdAt || 0) - Number(a.createdAt || 0));

              const mergedCustomVoices = { ...(impSnap.customVoices || {}), ...(curSnap.customVoices || {}) };
              const pickTmi = (rk) => {
                const cT = curSnap.tmiBook?.[rk] || {};
                const iT = impSnap.tmiBook?.[rk] || {};
                return Number(iT.updatedAt || 0) > Number(cT.updatedAt || 0) ? { ...cT, ...iT } : { ...iT, ...cT };
              };

              state = {
                ...impSnap,
                ...curSnap,
                myRole: curSnap.myRole || impSnap.myRole || 'suwan',
                startDate: (curSnap.startDate && curSnap.startDate !== '2026-01-01') ? curSnap.startDate : (impSnap.startDate || '2026-01-01'),
                startDateUpdatedAt: Math.max(Number(curSnap.startDateUpdatedAt || 0), Number(impSnap.startDateUpdatedAt || 0)),
                heartCount: Math.max(Number(curSnap.heartCount || 0), Number(impSnap.heartCount || 0)),
                learn: mergedLearn,
                chat: {
                  ...(impSnap.chat || {}),
                  ...(curSnap.chat || {}),
                  messages: mergedMsgs,
                  qaAnswers: unionById(curSnap.chat?.qaAnswers, impSnap.chat?.qaAnswers)
                },
                diaries: unionById(curSnap.diaries, impSnap.diaries),
                memos: unionById(curSnap.memos, impSnap.memos),
                anniversaries: unionById(curSnap.anniversaries, impSnap.anniversaries),
                buckets: unionById(curSnap.buckets, impSnap.buckets),
                capsules: unionById(curSnap.capsules, impSnap.capsules),
                coupons: unionById(curSnap.coupons, impSnap.coupons),
                schedules: unionById(curSnap.schedules, impSnap.schedules),
                complimentJar: unionById(curSnap.complimentJar, impSnap.complimentJar),
                coupleQuizzes: unionById(curSnap.coupleQuizzes, impSnap.coupleQuizzes),
                drawQuizzes: unionById(curSnap.drawQuizzes, impSnap.drawQuizzes),
                customPhrases: unionById(curSnap.customPhrases, impSnap.customPhrases),
                customGifs: unionById(curSnap.customGifs, impSnap.customGifs),
                tmiBook: { suwan: pickTmi('suwan'), jingchan: pickTmi('jingchan') },
                lavender: {
                  ...(impSnap.lavender || {}),
                  ...(curSnap.lavender || {}),
                  xp: Math.max(Number(curSnap.lavender?.xp || 0), Number(impSnap.lavender?.xp || 0)),
                  totalWaters: Math.max(Number(curSnap.lavender?.totalWaters || 0), Number(impSnap.lavender?.totalWaters || 0))
                },
                profile: {
                  ...(impSnap.profile || {}),
                  ...(curSnap.profile || {}),
                  suwanAvatar: curSnap.profile?.suwanAvatar || impSnap.profile?.suwanAvatar || '',
                  jingchanAvatar: curSnap.profile?.jingchanAvatar || impSnap.profile?.jingchanAvatar || ''
                },
                albums: mergedAlbums,
                voiceLetters: mergedVoiceLetters,
                customVoices: mergedCustomVoices,
                deletedMsgIds: Array.from(delMsgSet),
                deletedAlbumIds: Array.from(delAlbSet),
                deletedVoiceIds: Array.from(delVlSet)
              };

              if (typeof saveSuwanVoicesNow === 'function') saveSuwanVoicesNow();
              persistMediaVaultsNow(true);
              flushIdbStateNow(true);
              saveState(true);
              renderAll();
              refreshBothCityWeathers();
              if (typeof window.__syncCloudLearnVaultNow === 'function') window.__syncCloudLearnVaultNow();
              if (typeof window.__pushFullCloudSync === 'function') window.__pushFullCloudSync();
              const isZhImp = state.lang === 'zh';
              showToast(isZhImp
                ? `✅ 备份已无损合并！学习 ${state.learn.xp || 0} XP · 聊天 ${state.chat.messages.length} 条 ✨`
                : `✅ 기존 기록 유지 + 백업 합치기 완료! (학습 ${state.learn.xp || 0} XP · 대화 ${state.chat.messages.length}건) ✨`);
            } catch (_) { showToast(state.lang === 'zh' ? '不是有效的备份文件' : '올바른 백업 JSON 파일이 아닙니다.'); }
          };
          reader.readAsText(file); e.target.value = '';
        });
      }

      function renderAll() {
        // ==================== PWA MANIFEST + CHINA DIRECT MODE + AUTO BUG-FIX WATCHDOG ====================
        (function setupPwaManifest() {
          if (location.protocol !== 'file:' && document.querySelector('link[rel="manifest"][href*="manifest_clean.json"]')) return;
          try {
            const svgIcon = "data:image/svg+xml," + encodeURIComponent("<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 512 512'><defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'><stop offset='0%' stop-color='#583894'/><stop offset='55%' stop-color='#7c59bd'/><stop offset='100%' stop-color='#c8a56e'/></linearGradient></defs><rect width='512' height='512' rx='118' fill='url(#g)'/><text x='256' y='292' text-anchor='middle' font-family='Georgia,serif' font-size='150' font-weight='700' fill='#fffaf2'>灿完</text><text x='256' y='388' text-anchor='middle' font-family='sans-serif' font-size='48' fill='#f5e4c3'>✦ 时光 ✦</text></svg>");
            const pwaBgMap = { 'pastel-royal': '#fdfbff', 'violet-bloom': '#fdf8ff', 'velvet-dusk': '#120d1f', 'coral-pink': '#fffaf9', 'pastel-blue': '#f8fbff', 'pastel-lavender': '#fbf9ff' };
            const pwaThemeCol = pwaBgMap[state.theme] || '#fdfbff';
            const manifest = {
              name: '灿完时光 · 우리 둘만의 공간',
              short_name: '灿完时光',
              start_url: '.',
              display: 'standalone',
              background_color: pwaThemeCol,
              theme_color: pwaThemeCol,
              icons: [{ src: svgIcon, sizes: '512x512', type: 'image/svg+xml', purpose: 'any maskable' }]
            };
            const blob = new Blob([JSON.stringify(manifest)], { type: 'application/manifest+json' });
            const link = document.createElement('link');
            link.rel = 'manifest';
            link.href = URL.createObjectURL(blob);
            document.head.appendChild(link);
          } catch (_) {}
        })();

        let deferredInstallPrompt = null;
        window.addEventListener('beforeinstallprompt', (e) => {
          e.preventDefault();
          deferredInstallPrompt = e;
          const btn = document.getElementById('installAppBtn');
          if (btn) btn.textContent = state.lang === 'zh' ? '📲 一键安装 App' : '📲 원터치 앱 설치';
        });

        const dlHtmlBtn = document.getElementById('downloadHtmlAppBtn');
        if (dlHtmlBtn) {
          dlHtmlBtn.addEventListener('click', () => {
            try {
              const clone = document.documentElement.cloneNode(true);
              // Reset to Home tab cleanly so downloaded file ALWAYS opens on Home (never Settings!)
              clone.querySelectorAll('.tab-panel').forEach(p => p.classList.toggle('active', p.id === 'tab-home'));
              clone.querySelectorAll('.dock-item').forEach(b => b.classList.toggle('active', b.getAttribute('data-tab') === 'home'));
              ['notifPanel', 'cityModal', 'customMoodModal', 'patchNotesModal', 'confirmModal', 'pwaInstallGuide'].forEach(id => {
                const el = clone.querySelector('#' + id);
                if (el) el.classList.add('hidden');
              });
              const toastClone = clone.querySelector('#toastBox');
              if (toastClone) { toastClone.textContent = ''; toastClone.classList.add('opacity-0', 'pointer-events-none'); }
              const bannerClone = clone.querySelector('#liveNotifBanner');
              if (bannerClone) { bannerClone.classList.add('opacity-0', 'pointer-events-none'); }
              clone.querySelectorAll('.tab-panel').forEach(p => p.classList.toggle('active', p.id === 'tab-home'));
              clone.querySelectorAll('.dock-item').forEach(b => b.classList.toggle('active', b.getAttribute('data-tab') === 'home'));
              const manifestLink = clone.querySelector('link[rel="manifest"]');
              if (manifestLink && String(manifestLink.getAttribute('href') || '').startsWith('blob:')) manifestLink.remove();
              const fullHtml = '<!DOCTYPE html>\n' + clone.outerHTML;
              const blob = new Blob([fullHtml], { type: 'text/html;charset=utf-8' });
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = 'chanwan_shiguang_plus1_0.html';
              document.body.appendChild(a);
              a.click();
              document.body.removeChild(a);
              setTimeout(() => URL.revokeObjectURL(url), 1500);
              showToast(state.lang === 'zh' ? '📥 已开始下载 chanwan_shiguang_plus1_0.html！可直接微信发给对方 ✨' : '📥 chanwan_shiguang_plus1_0.html 다운로드가 시작되었어요! 위챗으로 바로 보내보세요 ✨');
            } catch (_) {
              showToast(state.lang === 'zh' ? '下载失败，请尝试在系统浏览器中打开后再下载' : '다운로드가 차단되었어요. 일반 브라우저에서 열어 다시 눌러주세요.');
            }
          });
        }

        const installBtn = document.getElementById('installAppBtn');
        if (installBtn) {
          installBtn.addEventListener('click', async () => {
            if (deferredInstallPrompt) {
              try {
                deferredInstallPrompt.prompt();
                await deferredInstallPrompt.userChoice;
                deferredInstallPrompt = null;
                return;
              } catch (_) {}
            }
            const guide = document.getElementById('pwaInstallGuide');
            if (guide) guide.classList.toggle('hidden');
          });
        }

        const chinaCb = document.getElementById('toggleChinaMode');
        const chinaLbl = document.getElementById('chinaModeStateLabel');
        function syncChinaModeUi() {
          const on = !!(state.settings && state.settings.chinaMode);
          if (chinaCb) chinaCb.checked = on;
          if (chinaLbl) chinaLbl.textContent = on ? (state.lang === 'zh' ? '直连开启' : '직통 ON') : (state.lang === 'zh' ? '智能自动' : '자동');
        }
        if (chinaCb) {
          chinaCb.addEventListener('change', () => {
            if (!state.settings) state.settings = {};
            state.settings.chinaMode = chinaCb.checked;
            saveState();
            // Auto-detect Mainland China / Baidu / WeChat / QQ Browser -> automatically enable China Direct Mode (No VPN needed!)
        try {
          const tz = Intl.DateTimeFormat().resolvedOptions().timeZone || '';
          const ua = navigator.userAgent || '';
          const isChinaEnv = (/Asia\/(Shanghai|Chongqing|Harbin|Urumqi|Beijing)/i.test(tz) || /baiduboxapp|Baidu|BIDUBrowser/i.test(ua)) && !/Asia\/Seoul/i.test(tz);
          if (isChinaEnv && state.settings && typeof state.settings.chinaMode === 'undefined') {
            state.settings.chinaMode = true;
            saveState();
          }
        } catch (_) {}
        syncChinaModeUi();
            showToast(chinaCb.checked
              ? (state.lang === 'zh' ? '🇨🇳 已开启中国大陆直连优化模式' : '🇨🇳 중국 직통 최적화 모드가 켜졌어요')
              : (state.lang === 'zh' ? '🌐 已切换为智能多线路模式' : '🌐 자동 다중 경로 모드로 전환됐어요'));
          });
        }
        syncChinaModeUi();

        const autoFixLogs = [];
        function runAutoBugFixer(manual) {
          let fixedCount = 0;
          const notes = [];
          try {
            // 1. Validate & repair core state structure
            if (!state || typeof state !== 'object') { state = JSON.parse(JSON.stringify(DEFAULT_STATE)); fixedCount++; notes.push('기본 상태 복원'); }
            ['anniversaries', 'diaries', 'memos', 'buckets', 'albums', 'capsules', 'coupons', 'notifications', 'transHistory'].forEach(k => {
              if (!Array.isArray(state[k])) { state[k] = []; fixedCount++; notes.push(`${k} 배열 복구`); }
              else {
                const before = state[k].length;
                const seen = new Set();
                state[k] = state[k].filter(item => {
                  if (!item || typeof item !== 'object') return false;
                  if (item.id && seen.has(item.id)) return false;
                  if (item.id) seen.add(item.id);
                  return true;
                });
                if (state[k].length !== before) { fixedCount++; notes.push(`${k} 중복/손상 정리`); }
              }
            });
            if (!state.learn || typeof state.learn !== 'object') { state.learn = { xp: 0, solved: 0, streak: 0, currentLevel: 'starter', quizIdx: 0, wrongNotes: [], gameBest: 0 , resetAt: Date.now() }; fixedCount++; }
            if (!Array.isArray(state.learn.wrongNotes)) { state.learn.wrongNotes = []; fixedCount++; }
            if (!Array.isArray(state.learn.bookmarks)) { state.learn.bookmarks = []; fixedCount++; }
            if (!state.chat || !Array.isArray(state.chat.messages)) { state.chat = { activeSender: 'suwan', messages: [], qaIdx: 0, qaAnswers: [] }; fixedCount++; }
            if (!Array.isArray(state.chat.qaAnswers)) { state.chat.qaAnswers = []; fixedCount++; }
            if (!['sm', 'md', 'lg', 'xl'].includes(state.fontSize)) { state.fontSize = 'md'; fixedCount++; }
            if (!['pastel-royal', 'violet-bloom', 'velvet-dusk', 'coral-pink', 'pastel-blue', 'pastel-lavender', 'midnight-black', 'midnight-navy', 'rose-noir', 'pearl-silk', 'royal-amethyst'].includes(state.theme)) { state.theme = 'pastel-royal'; fixedCount++; }
            if (!state.settings || typeof state.settings !== 'object') { state.settings = { geminiApiKey: '', autoNuance: true, chinaMode: false }; fixedCount++; }

            // 2. Verify storage health
            try { localStorage.setItem('__chanwan_health__', 'ok'); localStorage.removeItem('__chanwan_health__'); } catch (_) { notes.push('브라우저 저장소 보호 모드'); }

            // 3. Re-sync UI safely if repairs happened or manually triggered
            if (fixedCount > 0) saveState(true);
            const nowStr = new Date().toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
            const pill = document.getElementById('autoFixStatusPill');
            const box = document.getElementById('autoFixReportBox');
            if (pill) pill.textContent = fixedCount > 0 ? `🔧 ${fixedCount}건 자동 복구됨` : (state.lang === 'zh' ? '🟢 系统健康 7/7' : '🟢 시스템 정상 7/7');
            if (box) {
              const summary = fixedCount > 0
                ? (state.lang === 'zh' ? `🔧 已自动修复 ${fixedCount} 项异常 (${notes.join(', ')}) · ${nowStr}` : `🔧 ${fixedCount}건 자동 복구 완료 (${notes.join(', ')}) · ${nowStr}`)
                : (state.lang === 'zh' ? `🟢 7/7 项体检全部通过（数据·存储·翻译·字体·中国直连均正常） · ${nowStr}` : `🟢 7/7 항목 점검 완료 (데이터·저장소·번역·폰트·중국 호환 모두 정상) · ${nowStr}`);
              box.textContent = summary;
            }
            if (manual) {
              applyTheme(state.theme, true);
              applyFont(state.font, true);
              applyDockFont(state.dockFont, true);
              applyFontSize(state.fontSize, true);
              showToast(fixedCount > 0 ? `🛠️ ${fixedCount}건의 오류를 자동으로 복구했어요!` : (state.lang === 'zh' ? '🟢 体检完成，一切正常！' : '🟢 자동 진단 완료! 모든 기능이 정상이에요.'));
            }
          } catch (_) {}
        }

        window.addEventListener('error', (ev) => {
          autoFixLogs.push(String(ev && ev.message || 'runtime_error'));
          if (autoFixLogs.length > 20) autoFixLogs.shift();
          runAutoBugFixer(false);
        });
        window.addEventListener('unhandledrejection', () => {
          runAutoBugFixer(false);
        });
        const runAutoFixBtn = document.getElementById('runAutoFixBtn');
        if (runAutoFixBtn) runAutoFixBtn.addEventListener('click', () => runAutoBugFixer(true));
        runAutoBugFixer(false);

        // ==================== v8.0 NEW FEATURES: REUNION BOARDING PASS & LOVE COUPONS ====================
        if (!Array.isArray(state.coupons)) state.coupons = [];

        function renderCoupons() {
          const list = document.getElementById('couponListContainer');
          const badge = document.getElementById('couponCountBadge');
          if (!list) return;
          const items = Array.isArray(state.coupons) ? state.coupons : [];
          const activeCount = items.filter(c => !c.used).length;
          if (badge) badge.textContent = state.lang === 'zh' ? `可用 ${activeCount} / 共 ${items.length}` : `사용 가능 ${activeCount} / 총 ${items.length}`;
          if (!items.length) {
            list.innerHTML = `<div class="royal-card rounded-2xl p-8 text-center text-xs text-mut">${state.lang === 'zh' ? '还没有甜蜜兑换券，点上方快捷券送给TA吧 🎟️' : '발급된 쿠폰이 없어요. 위 추천 칩을 눌러 첫 쿠폰을 선물해 보세요 🎟️'}</div>`;
            return;
          }
          list.innerHTML = items.map(c => `
            <div class="royal-card rounded-2xl p-4 space-y-2.5 ${c.used ? 'opacity-70' : ''}">
              <div class="flex items-center justify-between gap-2 text-[11px]">
                <span class="font-bold text-gold">${escapeHtml(c.issuer)}</span>
                <div class="flex items-center gap-2">
                  <span class="px-2 py-0.5 rounded-full text-[10px] font-semibold" style="background: ${c.used ? 'rgba(16,185,129,0.14)' : 'var(--accent-royal-soft)'}; color: ${c.used ? '#059669' : 'var(--accent-royal)'};">
                    ${c.used ? (state.lang === 'zh' ? `✅ 已兑换 (${escapeHtml(c.usedDate || '')})` : `✅ 사용 완료 (${escapeHtml(c.usedDate || '')})`) : (state.lang === 'zh' ? '🎟️ 可使用' : '🎟️ 사용 가능')}
                  </span>
                  <button type="button" class="del-coupon-btn text-mut hover:text-rose-400" data-id="${escapeHtml(c.id)}">✕</button>
                </div>
              </div>
              ${renderBilingualCard(c.text, c.translated, '', true)}
              ${!c.used ? `<div class="flex justify-end"><button type="button" class="use-coupon-btn btn-gold px-3.5 py-1.5 rounded-full text-xs font-semibold" data-id="${escapeHtml(c.id)}">${state.lang === 'zh' ? '🎟️ 立即盖章使用' : '🎟️ 지금 도장 찍고 사용하기'}</button></div>` : ''}
            </div>
          `).join('');
          list.querySelectorAll('.use-coupon-btn').forEach(btn => {
            btn.addEventListener('click', () => {
              const item = state.coupons.find(x => x.id === btn.getAttribute('data-id'));
              if (!item || item.used) return;
              item.used = true;
              item.usedDate = getKstDateString();
              playNotifChime();
              saveState(true); renderCoupons();
              showToast(state.lang === 'zh' ? '🎉 甜蜜券已盖章兑换！' : '🎉 애정 쿠폰 사용 도장이 쾅 찍혔어요!');
              pushNotification('🎟️', '애정 쿠폰 사용됨!', '甜蜜券已兑换使用！', `${item.text}`, `${item.translated || item.text}`, 'diary', 'coupon', 'post', false);
            });
          });
          list.querySelectorAll('.del-coupon-btn').forEach(btn => {
            btn.addEventListener('click', () => {
              const cpid = btn.getAttribute('data-id');
              openConfirm(
                state.lang === 'zh' ? '删除甜蜜券' : '애정 쿠폰 삭제',
                state.lang === 'zh' ? '确定要删除这张甜蜜券吗？' : '이 애정 쿠폰을 삭제할까요?',
                () => {
                  state.coupons = state.coupons.filter(x => x.id !== cpid);
                  saveState(true); renderCoupons();
                }
              );
            });
          });
        }

        document.querySelectorAll('.coupon-preset-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            const inp = document.getElementById('couponInput');
            if (inp) inp.value = btn.getAttribute(state.lang === 'zh' ? 'data-zh' : 'data-ko') || btn.textContent;
          });
        });

        const couponFormEl = document.getElementById('couponForm');
        if (couponFormEl) {
          couponFormEl.addEventListener('submit', async (e) => {
            e.preventDefault();
            const inp = document.getElementById('couponInput');
            const text = inp.value.trim();
            if (!text) return;
            inp.value = '';
            const issuer = document.getElementById('couponIssuer').value;
            const res = await geminiTranslate(text, 'lover');
            if (!Array.isArray(state.coupons)) state.coupons = [];
            state.coupons.unshift({ id: `cpn_${Date.now()}`, issuer, text, translated: res ? res.translated : '', used: false, usedDate: '' });
            saveState(true); renderCoupons();
            pushNotification('🎟️', '새 애정 쿠폰 도착!', '收到一张新甜蜜券！', `${issuer}: ${text}`, `${issuer}: ${res ? res.translated : text}`, 'diary', 'coupon', 'post', false);
          });
        }

        renderCoupons();

        if (!window.__cwBootedTab) { window.__cwBootedTab = true; const __urlTab = new URLSearchParams(location.search).get('tab'); switchTab(__urlTab && document.getElementById('tab-' + __urlTab) ? __urlTab : 'home'); }
        // ==================== v12.0 MY ROLE MODE (SUWAN / JINGCHAN) & AUTO NOTIFICATION PROMPT ====================
        if (!state.myRole) {
          try {
            const tz = Intl.DateTimeFormat().resolvedOptions().timeZone || '';
            state.myRole = /Asia\/(Shanghai|Chongqing|Harbin|Urumqi|Beijing)/i.test(tz) ? 'jingchan' : 'suwan';
          } catch (_) { state.myRole = 'suwan'; }
        }
        function applyMyRole(role, silent) {
          state.myRole = role === 'jingchan' ? 'jingchan' : 'suwan';
          try { localStorage.setItem('cw_my_role', state.myRole); } catch (_) {}
          try {
            if (window.ChanwanNative && typeof window.ChanwanNative.setRole === 'function') {
              window.ChanwanNative.setRole(state.myRole);
            }
          } catch (_) {}
          const isJc = state.myRole === 'jingchan';
          // Auto-sync all writing author & messenger sender selectors to my identity!
          if (state.chat) state.chat.activeSender = state.myRole;
          const diarySel = document.getElementById('diaryAuthor');
          if (diarySel) diarySel.value = isJc ? '靖灿(灿)' : '수완(完)';
          const qaSel = document.getElementById('qaAuthorSelect');
          if (qaSel) qaSel.value = state.myRole;
          const capSel = document.getElementById('capsuleAuthor');
          if (capSel) capSel.value = isJc ? '靖灿(灿)' : '수완(完)';
          const cpnSel = document.getElementById('couponIssuer');
          if (cpnSel) cpnSel.value = isJc ? '靖灿(灿) → 수완(完)' : '수완(完) → 靖灿(灿)';

          // Sync mini-game default mode so Suwan's practice never affects Jingchan's XP
          const targetDirBtn = document.getElementById(isJc ? 'gameDirKoBtn' : 'gameDirZhBtn');
          if (targetDirBtn && typeof gameDirection !== 'undefined' && gameDirection !== (isJc ? 'learn-ko' : 'learn-zh')) {
            targetDirBtn.click();
          }

          const badge = document.getElementById('myRoleActiveBadge');
          if (badge) {
            badge.textContent = isJc
              ? (state.lang === 'zh' ? '💜 靖灿(灿) 模式' : '💜 靖灿(灿) 모드')
              : (state.lang === 'zh' ? '❤️ 完(수완) 模式' : '❤️ 수완(完) 모드');
          }
          document.querySelectorAll('.role-choice-btn').forEach(btn => {
            const act = btn.getAttribute('data-role') === state.myRole;
            btn.style.borderColor = act ? 'var(--accent-royal)' : 'var(--border-subtle)';
            btn.style.boxShadow = act ? '0 0 0 2px var(--accent-royal-soft)' : 'none';
          });
          document.querySelectorAll('.home-role-btn').forEach(btn => {
            const act = btn.getAttribute('data-role') === state.myRole;
            btn.className = `home-role-btn ${act ? 'btn-royal' : 'btn-ghost'} px-3 py-1 rounded-full text-[11px] font-semibold whitespace-nowrap`;
          });
          if (typeof window.__renderPresenceBadges === 'function') window.__renderPresenceBadges();
          if (!silent && typeof window.__broadcastPresenceNow === 'function') window.__broadcastPresenceNow(true, true);
          // Toggle Suwan-only controls (Korean study reset & Praise Sticker award bar)
          const resetWrap = document.getElementById('suwanOnlyLearnResetWrap');
          if (resetWrap) resetWrap.classList.toggle('hidden', state.myRole !== 'suwan');
          const praiseBarEl = document.getElementById('suwanPraiseBar');
          if (praiseBarEl) praiseBarEl.classList.toggle('hidden', state.myRole !== 'suwan');
          const sCard = document.getElementById('suwanMoodCard');
          const jCard = document.getElementById('jingchanMoodCard');
          if (sCard) { sCard.style.borderColor = !isJc ? 'var(--accent-royal)' : 'var(--border-subtle)'; sCard.style.boxShadow = !isJc ? '0 0 0 2px var(--accent-royal-soft)' : 'none'; }
          if (jCard) { jCard.style.borderColor = isJc ? 'var(--accent-royal)' : 'var(--border-subtle)'; jCard.style.boxShadow = isJc ? '0 0 0 2px var(--accent-royal-soft)' : 'none'; }
          const pCb = document.getElementById('togglePartnerOnlyNotif');
          const pLbl = document.getElementById('partnerOnlyStateLabel');
          const pOn = !(state.settings && state.settings.partnerOnlyNotif === false);
          if (pCb) pCb.checked = pOn;
          if (pLbl) pLbl.textContent = pOn ? (state.lang === 'zh' ? '开启' : 'ON') : (state.lang === 'zh' ? '关闭' : 'OFF');

          if (typeof renderChat === 'function') renderChat();
          if (typeof renderHome === 'function') renderHome();
          if (typeof renderBalanceGame === 'function') renderBalanceGame();
          if (!silent) {
            saveState(true);
            showToast(isJc
              ? (state.lang === 'zh' ? '💜 已切换为「靖灿(灿)」模式 · 仅接收完的提醒' : '💜 징찬(灿) 모드로 전환됐어요 · 수완 알림만 받아요')
              : (state.lang === 'zh' ? '❤️ 已切换为「完」模式 · 仅接收靖灿的提醒' : '❤️ 수완(完) 모드로 전환됐어요 · 징찬 알림만 받아요'));
          }
        }

        document.querySelectorAll('.role-choice-btn, .home-role-btn').forEach(btn => {
          btn.addEventListener('click', () => applyMyRole(btn.getAttribute('data-role'), false));
        });
        const pOnlyCb = document.getElementById('togglePartnerOnlyNotif');
        if (pOnlyCb) {
          pOnlyCb.addEventListener('change', () => {
            if (!state.settings) state.settings = {};
            state.settings.partnerOnlyNotif = pOnlyCb.checked;
            const pLbl = document.getElementById('partnerOnlyStateLabel');
            if (pLbl) pLbl.textContent = pOnlyCb.checked ? (state.lang === 'zh' ? '开启' : 'ON') : (state.lang === 'zh' ? '关闭' : 'OFF');
            saveState(false);
          });
        }

        // ==================== Plus 1.5: SUPABASE SEOUL REALTIME + POSTGRES REST COUPLE SYNC ENGINE ====================
        const DEFAULT_COUPLE_ROOM = 'chanwan-suwan-jingchan-live2026';
        const SUPABASE_URL = 'https://zdqkyftqogfgbfcxdmfh.supabase.co';
        const SUPABASE_KEY = 'sb_publishable_iwXcMp6Fee8bJofcYC19bg_AvOMJewt';
        const SYNC_DEVICE_KEY = 'chanwan_device_id_v15';
        const SYNC_CURSOR_KEY = 'chanwan_sb_cursor_v15';
        const SYNC_OUTBOX_KEY = 'chanwan_sb_outbox_v15';
        const SYNC_FETCH_TIMEOUT_MS = 5500;

        let sbClient = null;
        let sbChannel = null;
        let liveSyncSource = null; // compatibility flag for watchdog
        let livePollTimer = null;
        let livePushTimer = null;
        let lastCloudPushTs = 0;
        let pendingPushCore = null;
        let lastSyncOkTs = 0;
        let sbLastOkTs = 0;
        let syncTransportMode = 'connecting'; // 'realtime' | 'rest' | 'reconnecting' | 'offline'
        let isPullingCloud = false;
        let isFlushingOutbox = false;
        const processedEventIds = new Set();
        const processedMediaIds = new Set();

        function getOrCreateDeviceId() {
          try {
            let id = localStorage.getItem(SYNC_DEVICE_KEY);
            if (!id) {
              id = 'dev_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 8);
              localStorage.setItem(SYNC_DEVICE_KEY, id);
            }
            return id;
          } catch (_) {
            return 'dev_' + Math.random().toString(36).slice(2, 10);
          }
        }
        const myDeviceClientId = getOrCreateDeviceId();

        function loadLastEventId() {
          try {
            return Number(localStorage.getItem(SYNC_CURSOR_KEY) || 0) || 0;
          } catch (_) {
            return 0;
          }
        }

        function saveLastEventId(idNum) {
          const n = Number(idNum) || 0;
          if (n <= 0) return;
          try {
            const cur = loadLastEventId();
            if (n > cur) localStorage.setItem(SYNC_CURSOR_KEY, String(n));
          } catch (_) {}
        }

        function loadSyncOutbox() {
          try {
            const raw = localStorage.getItem(SYNC_OUTBOX_KEY);
            const arr = raw ? JSON.parse(raw) : [];
            if (!Array.isArray(arr)) return [];
            const cleaned = arr.filter(x => x && x.kind !== 'signal' && (x.tries || 0) < (x.kind === 'media' ? 4 : 2));
            if (cleaned.length !== arr.length) {
              try { localStorage.setItem(SYNC_OUTBOX_KEY, JSON.stringify(cleaned)); } catch (_) {}
            }
            return cleaned;
          } catch (_) {
            return [];
          }
        }

        function saveSyncOutbox(list) {
          try {
            const trimmed = Array.isArray(list) ? list.slice(-15) : [];
            localStorage.setItem(SYNC_OUTBOX_KEY, JSON.stringify(trimmed));
          } catch (_) {}
        }

        function enqueueOutboxPacket(kind, payloadObj, dedupeKind) {
          const list = loadSyncOutbox();
          if (dedupeKind === 'delta') {
            const filtered = list.filter(x => x && x.dedupeKind !== 'delta');
            filtered.push({ id: 'ob_' + Date.now(), kind, payloadObj, dedupeKind, ts: Date.now(), tries: 0 });
            saveSyncOutbox(filtered);
          } else {
            list.push({ id: 'ob_' + Date.now() + '_' + Math.random().toString(36).slice(2, 5), kind, payloadObj, dedupeKind: dedupeKind || 'event', ts: Date.now(), tries: 0 });
            saveSyncOutbox(list);
          }
          updateLiveSyncIndicators(syncTransportMode === 'realtime' || syncTransportMode === 'rest', getSyncRoomCode());
        }

        // ==================== AES-256-GCM END-TO-END ENCRYPTION (E2EE) & PRIVATE CHANNEL SHIELD ====================
        const E2EE_PASS_STORAGE_KEY = 'cw_e2ee_passphrase_v1';
        const E2EE_ROOM_STORAGE_KEY = 'cw_e2ee_room_v1';
        let cwE2eeCryptoKey = null;
        let cwE2eeReadyPromise = null;
        let cwE2eePrivateRoom = '';
        try { cwE2eePrivateRoom = localStorage.getItem(E2EE_ROOM_STORAGE_KEY) || ''; } catch (_) {}

        function cwBytesToB64(bytes) {
          let bin = '';
          const chunk = 0x8000;
          for (let i = 0; i < bytes.length; i += chunk) {
            bin += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
          }
          return btoa(bin);
        }
        function cwB64ToBytes(b64) {
          const bin = atob(b64);
          const out = new Uint8Array(bin.length);
          for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
          return out;
        }

        async function initE2eeFromPassphrase(passphrase) {
          const clean = String(passphrase || '').trim();
          if (!clean || !window.crypto || !window.crypto.subtle) {
            cwE2eeCryptoKey = null;
            cwE2eePrivateRoom = '';
            return false;
          }
          const enc = new TextEncoder();
          const keyMat = await window.crypto.subtle.importKey('raw', enc.encode(clean), { name: 'PBKDF2' }, false, ['deriveKey']);
          cwE2eeCryptoKey = await window.crypto.subtle.deriveKey(
            { name: 'PBKDF2', salt: enc.encode('chanwan-shiguang-e2ee-salt-v2-2026'), iterations: 120000, hash: 'SHA-256' },
            keyMat,
            { name: 'AES-GCM', length: 256 },
            false,
            ['encrypt', 'decrypt']
          );
          const roomHashBuf = await window.crypto.subtle.digest('SHA-256', enc.encode('cw-private-room-v2:' + clean));
          const hex = Array.from(new Uint8Array(roomHashBuf)).map(b => b.toString(16).padStart(2, '0')).join('');
          cwE2eePrivateRoom = 'cwe2e_' + hex.slice(0, 24);
          try {
            localStorage.setItem(E2EE_PASS_STORAGE_KEY, clean);
            localStorage.setItem(E2EE_ROOM_STORAGE_KEY, cwE2eePrivateRoom);
          } catch (_) {}
          return true;
        }

        function ensureE2eeReady() {
          if (cwE2eeCryptoKey) return Promise.resolve(true);
          if (cwE2eeReadyPromise) return cwE2eeReadyPromise;
          let saved = '';
          try { saved = localStorage.getItem(E2EE_PASS_STORAGE_KEY) || ''; } catch (_) {}
          if (!saved) return Promise.resolve(false);
          cwE2eeReadyPromise = initE2eeFromPassphrase(saved).catch(() => false).finally(() => { cwE2eeReadyPromise = null; });
          return cwE2eeReadyPromise;
        }
        ensureE2eeReady();

        async function e2eeWrapPayload(obj) {
          await ensureE2eeReady();
          if (!cwE2eeCryptoKey || !obj) return obj;
          try {
            const iv = window.crypto.getRandomValues(new Uint8Array(12));
            const plain = new TextEncoder().encode(JSON.stringify(obj));
            const cipherBuf = await window.crypto.subtle.encrypt({ name: 'AES-GCM', iv }, cwE2eeCryptoKey, plain);
            return { __e2ee: 1, v: 2, iv: cwBytesToB64(iv), ct: cwBytesToB64(new Uint8Array(cipherBuf)) };
          } catch (_) {
            return obj;
          }
        }

        async function e2eeUnwrapPayload(obj) {
          if (!obj || typeof obj !== 'object') return obj;
          if (obj.__e2ee !== 1) return obj;
          await ensureE2eeReady();
          if (!cwE2eeCryptoKey || !obj.iv || !obj.ct) return null;
          try {
            const iv = cwB64ToBytes(obj.iv);
            const ct = cwB64ToBytes(obj.ct);
            const plainBuf = await window.crypto.subtle.decrypt({ name: 'AES-GCM', iv }, cwE2eeCryptoKey, ct);
            return JSON.parse(new TextDecoder().decode(plainBuf));
          } catch (_) {
            return null;
          }
        }

        async function e2eeWrapString(jsonStr) {
          await ensureE2eeReady();
          if (!cwE2eeCryptoKey || !jsonStr) return jsonStr;
          try {
            const iv = window.crypto.getRandomValues(new Uint8Array(12));
            const plain = new TextEncoder().encode(jsonStr);
            const cipherBuf = await window.crypto.subtle.encrypt({ name: 'AES-GCM', iv }, cwE2eeCryptoKey, plain);
            return JSON.stringify({ __e2ee: 1, v: 2, iv: cwBytesToB64(iv), ct: cwBytesToB64(new Uint8Array(cipherBuf)) });
          } catch (_) {
            return jsonStr;
          }
        }

        async function e2eeUnwrapString(rawStr) {
          if (!rawStr) return null;
          try {
            const parsed = JSON.parse(rawStr);
            if (!parsed || typeof parsed !== 'object') return null;
            if (parsed.__e2ee === 1) return await e2eeUnwrapPayload(parsed);
            return parsed;
          } catch (_) {
            return null;
          }
        }

        window.__isE2eeActive = () => !!(cwE2eeCryptoKey || (localStorage.getItem(E2EE_PASS_STORAGE_KEY) || '').trim());
        window.__e2eeWrapPayload = e2eeWrapPayload;
        window.__e2eeUnwrapPayload = e2eeUnwrapPayload;

        function getSyncRoomCode() {
          if (cwE2eePrivateRoom) return cwE2eePrivateRoom;
          if (!state.settings) state.settings = {};
          if (!state.settings.cloudSyncRoom) state.settings.cloudSyncRoom = DEFAULT_COUPLE_ROOM;
          const rCode = String(state.settings.cloudSyncRoom).trim().replace(/[^a-zA-Z0-9_-]/g, '') || DEFAULT_COUPLE_ROOM;
          if (window.ChanwanNative && typeof window.ChanwanNative.setRoom === 'function' && window.__lastSyncedNatRoom !== rCode) {
            window.__lastSyncedNatRoom = rCode;
            try { window.ChanwanNative.setRoom(rCode); } catch (_) {}
          }
          return rCode;
        }

        function updateLiveSyncIndicators(connected, room) {
          const badge = document.getElementById('cloudSyncBadge');
          const statusEl = document.getElementById('cloudSyncStatusText');
          const chatBtn = document.getElementById('chatQuickSyncBtn');
          const isZh = state.lang === 'zh';
          const outboxLen = loadSyncOutbox().length;
          const tStr = lastSyncOkTs
            ? new Date(lastSyncOkTs).toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
            : new Date().toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
          const isOffline = (typeof navigator !== 'undefined' && navigator.onLine === false);
          const modeLabelKo = isOffline
            ? '🔴 오프라인'
            : (syncTransportMode === 'realtime' ? '🟢 서울 실시간' : (syncTransportMode === 'rest' ? '🟢 서울 고속연결' : '🟡 연결 중'));
          const modeLabelZh = isOffline
            ? '🔴 离线待传'
            : (syncTransportMode === 'realtime' ? '🟢 首尔实时直连' : (syncTransportMode === 'rest' ? '🟢 首尔高速同步' : '🟡 连接中'));
          const isOk = !isOffline && (connected || emqxConnected || syncTransportMode === 'realtime' || syncTransportMode === 'rest');
          const queueTag = outboxLen > 0 ? (isZh ? ` · 待发 ${outboxLen} 条` : ` · 대기전송 ${outboxLen}건`) : '';

          if (badge) {
            badge.textContent = isZh ? modeLabelZh : modeLabelKo;
            badge.style.background = isOffline ? 'rgba(244,63,94,0.16)' : (isOk ? 'rgba(16,185,129,0.16)' : 'var(--accent-royal-soft)');
            badge.style.color = isOffline ? '#e11d48' : (isOk ? '#059669' : 'var(--accent-royal)');
          }
          if (statusEl) {
            statusEl.textContent = isOffline
              ? (isZh ? `🔴 当前离线 · 内容已安全暂存，联网后自动同步${queueTag}` : `🔴 오프라인 상태 · 내용이 안전 보관 중이며 연결되면 자동 전송돼요${queueTag}`)
              : isOk
                ? (isZh ? `${modeLabelZh} · 首尔主服 + ntfy + EMQX 中国直连三线守护 (${tStr})${queueTag}` : `${modeLabelKo} · 서울 메인 + ntfy + EMQX 중국직통 3중 동기화 정상 (${tStr})${queueTag}`)
                : (isZh ? `🟡 正在连接 Supabase 首尔服务器...${queueTag}` : `🟡 Supabase 서울 실시간 서버에 연결 중...${queueTag}`);
          }
          if (chatBtn) {
            chatBtn.textContent = isZh ? modeLabelZh : modeLabelKo;
          }
          const hdrLiveBtn = document.getElementById('headerLiveSyncBtn');
          const liveStateKey = isOffline ? 'offline' : (isOk ? 'ok' : 'reconnecting');
          window.__lastLiveHeartStatus = liveStateKey;
          if (typeof window.__renderHeaderLiveHeart === 'function') window.__renderHeaderLiveHeart(liveStateKey);
          if (hdrLiveBtn) {
            hdrLiveBtn.title = isOffline
              ? (isZh ? '离线状态 · 联网后自动同步' : '오프라인 · 연결되면 자동 동기화')
              : (isOk ? (isZh ? '实时三线已连接 · 点击立即同步' : '실시간 3중 서버 연결됨 · 눌러서 즉시 동기화') : (isZh ? '正在重连服务器...' : '서버 재연결 중...'));
          }
          const sbPill = document.getElementById('sbServerPill');
          const ntfyPill = document.getElementById('ntfyServerPill');
          const nowTs = Date.now();
          const sbAlive = !isOffline && (syncTransportMode === 'realtime' || syncTransportMode === 'rest' || (sbLastOkTs > 0 && (nowTs - sbLastOkTs) < 90000));
          const ntfyAlive = !isOffline && (ntfyLastOkTs > 0 && (nowTs - ntfyLastOkTs) < 90000);
          if (sbPill) {
            if (isOffline) { sbPill.textContent = isZh ? '🔴 离线' : '🔴 오프라인'; sbPill.style.color = '#e11d48'; }
            else if (syncTransportMode === 'realtime') { sbPill.textContent = isZh ? '🟢 实时' : '🟢 실시간'; sbPill.style.color = '#059669'; }
            else if (sbAlive) { sbPill.textContent = isZh ? '🟢 正常' : '🟢 고속'; sbPill.style.color = '#059669'; }
            else { sbPill.textContent = isZh ? '🟡 连接中' : '🟡 대기'; sbPill.style.color = '#d97706'; }
          }
          if (ntfyPill) {
            if (isOffline) { ntfyPill.textContent = isZh ? '🔴 离线' : '🔴 오프라인'; ntfyPill.style.color = '#e11d48'; }
            else if (ntfyAlive) { ntfyPill.textContent = isZh ? '🟢 正常' : '🟢 정상'; ntfyPill.style.color = '#059669'; }
            else { ntfyPill.textContent = isZh ? '🟡 待命' : '🟡 대기'; ntfyPill.style.color = '#d97706'; }
          }
          const emqxPill = document.getElementById('emqxServerPill');
          const emqxAlive = !isOffline && (emqxConnected || (emqxLastOkTs > 0 && (nowTs - emqxLastOkTs) < 40000));
          if (emqxPill) {
            if (isOffline) { emqxPill.textContent = isZh ? '🔴 离线' : '🔴 오프라인'; emqxPill.style.color = '#e11d48'; }
            else if (emqxAlive) { emqxPill.textContent = isZh ? '🟢 直连' : '🟢 직통'; emqxPill.style.color = '#059669'; }
            else { emqxPill.textContent = isZh ? '🟡 连接中' : '🟡 대기'; emqxPill.style.color = '#d97706'; }
          }
        }

        function extractMsgTimestamp(m) {
          if (!m) return 0;
          const direct = Number(m.ts || m.createdAt);
          if (Number.isFinite(direct) && direct > 1000000000000) return direct;
          const idStr = String(m.id || '');
          const match = idStr.match(/(\d{13})/);
          if (match) return Number(match[1]);
          return 0;
        }

        function sortChatMessagesStable(msgs) {
          if (!Array.isArray(msgs)) return [];
          return msgs
            .map((m, idx) => ({ m, idx, ts: extractMsgTimestamp(m) }))
            .sort((a, b) => {
              if (a.ts && b.ts && a.ts !== b.ts) return a.ts - b.ts;
              if (a.ts && !b.ts) return 1;
              if (!a.ts && b.ts) return -1;
              return a.idx - b.idx;
            })
            .map(x => x.m);
        }

        function mergeIncomingCoupleData(inc, isLiveEvent, allowSelfReplay) {
          if (!inc || typeof inc !== 'object') return false;
          if (inc.clientId && inc.clientId === myDeviceClientId && !allowSelfReplay) return false;
          if (isLiveEvent && ((Date.now() - __cwBootEpoch) < 3500 || (inc.ts && (Date.now() - Number(inc.ts)) > 90000))) { isLiveEvent = false; }
          let changed = false;
          let chatChanged = false;
          let newestPartnerMsg = null;
          let newestPraise = null;

          const mergeById = (curArr, incArr, prepend, trackMsg) => {
            if (!Array.isArray(incArr)) return curArr || [];
            const base = Array.isArray(curArr) ? curArr.slice() : [];
            const byId = new Map();
            base.forEach(x => { if (x && x.id) byId.set(x.id, x); });
            for (const item of incArr) {
              if (!item || !item.id) continue;
              const ex = byId.get(item.id);
              if (!ex) {
                byId.set(item.id, item);
                if (prepend) base.unshift(item); else base.push(item);
                changed = true;
                if (trackMsg) { chatChanged = true; const _ns = (item.sender === 'jingchan' || String(item.sender || '').includes('靖灿')) ? 'jingchan' : 'suwan'; if (_ns !== (state.myRole || 'suwan')) newestPartnerMsg = item; }
              } else {
                // Merge nested replies (Truth/Dare, Compliment Jar, etc.) & updated translations on existing items!
                if (Array.isArray(item.replies) && item.replies.length) {
                  if (!Array.isArray(ex.replies)) ex.replies = [];
                  const rMap = new Map(ex.replies.map(r => [r && r.id, r]));
                  item.replies.forEach(ir => {
                    if (!ir || !ir.id) return;
                    const er = rMap.get(ir.id);
                    if (!er) {
                      ex.replies.push(ir);
                      rMap.set(ir.id, ir);
                      changed = true;
                      if (isLiveEvent && ir.authorRole && ir.authorRole !== (state.myRole || 'suwan')) {
                        const rNameKo = ir.authorRole === 'jingchan' ? '靖灿(灿)' : '수완(完)';
                        const rNameZh = ir.authorRole === 'jingchan' ? '靖灿' : '完';
                        pushNotification('💬', `${rNameKo}이 커플공간에 답글을 남겼어요`, `${rNameZh}在情侣空间留了回复`, ir.translated || ir.text || '새 답글을 확인해 보세요', ir.text || ir.translated || '点击查看新回复', 'diary', '', 'post', false, ir.authorRole);
                      }
                    } else if (ir.translated && !er.translated) {
                      er.translated = ir.translated;
                      changed = true;
                    }
                  });
                }
                if (item.translated && item.translated !== ex.translated && (!ex.translated || /^\[(中文|한국어)\]/.test(String(ex.translated)))) {
                  ex.translated = item.translated;
                  changed = true;
                }
              }
            }
            return base;
          };

          if (Array.isArray(inc.deletedMsgIds) && inc.deletedMsgIds.length) {
            if (!Array.isArray(state.deletedMsgIds)) state.deletedMsgIds = [];
            inc.deletedMsgIds.forEach(did => {
              if (did && !state.deletedMsgIds.includes(did)) {
                state.deletedMsgIds.push(did);
                changed = true;
              }
            });
            if (state.deletedMsgIds.length > 150) state.deletedMsgIds = state.deletedMsgIds.slice(-150);
          }
          if (Array.isArray(inc.deletedAlbumIds) && inc.deletedAlbumIds.length) {
            if (!Array.isArray(state.deletedAlbumIds)) state.deletedAlbumIds = [];
            inc.deletedAlbumIds.forEach(aid => {
              if (aid && !state.deletedAlbumIds.includes(aid)) {
                state.deletedAlbumIds.push(aid);
                changed = true;
              }
            });
            if (state.deletedAlbumIds.length > 150) state.deletedAlbumIds = state.deletedAlbumIds.slice(-150);
          }
          const delAlbSet = new Set(Array.isArray(state.deletedAlbumIds) ? state.deletedAlbumIds : []);
          if (delAlbSet.size && Array.isArray(state.albums)) {
            const prevAlbLen = state.albums.length;
            state.albums = state.albums.filter(a => a && !delAlbSet.has(a.id));
            if (state.albums.length !== prevAlbLen) changed = true;
          }
          const delSet = new Set(Array.isArray(state.deletedMsgIds) ? state.deletedMsgIds : []);
          if (inc.chat && Array.isArray(inc.chat.messages)) {
            const cleanIncomingMsgs = inc.chat.messages.filter(m => {
              if (!m || !m.id || delSet.has(m.id)) return false;
              const isGhostVoice = (m.tone === '🎙️ 보이스 챗' || m.tone === '🎙️ 음성 메시지' || m.original === '🎙️ 음성 메시지' || m.original === '🎙️ 语音消息') && (!m.audioUrl || !String(m.audioUrl).startsWith('data:audio/'));
              return !isGhostVoice;
            });
            const existingMap = new Map((state.chat.messages || []).map(x => [x && x.id, x]));
            for (const cm of cleanIncomingMsgs) {
              const ex = existingMap.get(cm.id);
              if (!ex) continue;
              const __cmIsPending = /^(⏳ 번역 중\.\.\.|⏳ 正在翻译\.\.\.)$/.test(String(cm.translated || '').trim());
              const __exIsPending = /^(⏳ 번역 중\.\.\.|⏳ 正在翻译\.\.\.)$/.test(String(ex.translated || '').trim());
              if (cm.readByPartner && !ex.readByPartner) {
                ex.readByPartner = true;
                ex.deliveryStatus = 'sent';
                changed = true;
                chatChanged = true;
              }
              if (Array.isArray(cm.reactions) && cm.reactions.length > (Array.isArray(ex.reactions) ? ex.reactions.length : 0)) {
                ex.reactions = cm.reactions.slice(0, 12);
                changed = true;
                chatChanged = true;
              }
              if (cm.translated && !__cmIsPending && (!ex.translated || __exIsPending || Number(cm.accuracy || 0) >= Number(ex.accuracy || 0) || (cm.editedAt && cm.editedAt > (ex.editedAt || 0)))) {
                ex.original = cm.original || ex.original;
                ex.translated = cm.translated;
                if (cm.altTranslated) ex.altTranslated = cm.altTranslated;
                ex.pronunciation = cm.pronunciation || '';
                ex.accuracy = cm.accuracy;
                ex.engine = cm.engine || ex.engine || '';
                if (cm.tone) ex.tone = cm.tone;
                if (cm.toneZh) ex.toneZh = cm.toneZh;
                if (cm.nuance) ex.nuance = cm.nuance;
                if (cm.nuanceZh) ex.nuanceZh = cm.nuanceZh;
                if (cm.editedAt) ex.editedAt = cm.editedAt;
                if (typeof updateChatNotifsForMsg === 'function') updateChatNotifsForMsg(ex.id, ex.original, ex.translated);
                changed = true;
                chatChanged = true;
              }
            }
            const beforeCount = (state.chat.messages || []).length;
            const filteredCur = (state.chat.messages || []).filter(m => m && m.id && !delSet.has(m.id));
            state.chat.messages = sortChatMessagesStable(mergeById(filteredCur, cleanIncomingMsgs, false, true));
            if (state.chat.messages.length !== beforeCount) { changed = true; chatChanged = true; }
            setTimeout(() => { if (typeof autoResolvePendingTranslations === 'function') autoResolvePendingTranslations();
              try { if ('serviceWorker' in navigator) navigator.serviceWorker.getRegistrations().then(rs => rs.forEach(r => r.update().catch(() => {}))); } catch (_) {} }, 600);
          }
          const __incPartnerRole = inc.myRole || '';
          const __isFromPartner = !!(__incPartnerRole && __incPartnerRole !== (state.myRole || 'suwan'));
          const __pDispKo = __incPartnerRole === 'suwan' ? '수완' : '징찬';
          const __pDispZh = __incPartnerRole === 'suwan' ? '秀完' : '靖灿';
          if (inc.chat && inc.chat.pinnedMsg && Number(inc.chat.pinnedMsg.updatedAt || 0) > Number(state.chat?.pinnedMsg?.updatedAt || 0)) {
            state.chat.pinnedMsg = { ...inc.chat.pinnedMsg };
            changed = true;
            if (typeof window.__renderChatPinnedBanner === 'function') window.__renderChatPinnedBanner();
          }
          if (inc.chat && Array.isArray(inc.chat.qaAnswers)) {
            const prevQaIds = new Set((state.chat.qaAnswers || []).map(x => x && x.id));
            const newPartnerQa = isLiveEvent && __isFromPartner ? inc.chat.qaAnswers.find(x => x && x.id && !prevQaIds.has(x.id)) : null;
            state.chat.qaAnswers = mergeById(state.chat.qaAnswers, inc.chat.qaAnswers, true, false);
            if (newPartnerQa) {
              const bKo = String(newPartnerQa.answer || newPartnerQa.translated || '오늘의 문답을 확인해 보세요 💜').slice(0, 60);
              const bZh = String(newPartnerQa.translated || newPartnerQa.answer || '快来查看今日问答吧 💜').slice(0, 60);
              pushNotification('💌', `${__pDispKo}이 커플 문답에 답했어요!`, `${__pDispZh}回答了情侣问答！`, bKo, bZh, 'diary', 'qa', 'post', false, __incPartnerRole);
            }
          }
          ['diaries', 'memos', 'buckets', 'capsules', 'coupons', 'anniversaries', 'schedules', 'customPhrases', 'transHistory', 'customGifs'].forEach(k => {
            if (Array.isArray(inc[k])) {
              const __notifyKeys = ['diaries', 'memos', 'buckets', 'capsules', 'coupons', 'anniversaries', 'schedules'];
              const prevIdsK = (isLiveEvent && __isFromPartner && __notifyKeys.includes(k)) ? new Set((state[k] || []).map(x => x && x.id)) : null;
              const newSpaceItem = prevIdsK ? inc[k].find(x => x && x.id && !prevIdsK.has(x.id)) : null;
              state[k] = mergeById(state[k], inc[k], true, false);
              if (newSpaceItem) {
                if (k === 'diaries') {
                  const bKo = String(newSpaceItem.title || newSpaceItem.content || '새 일기가 올라왔어요 🪶').slice(0, 60);
                  const bZh = String(newSpaceItem.translatedTitle || newSpaceItem.translated || bKo).slice(0, 60);
                  pushNotification('🪶', `${__pDispKo}이 새 일기를 썼어요`, `${__pDispZh}写了新日记`, bKo, bZh, 'diary', 'diary', 'post', false, __incPartnerRole);
                } else if (k === 'memos') {
                  const bKo = String(newSpaceItem.content || newSpaceItem.text || '새 메모가 올라왔어요 📝').slice(0, 60);
                  const bZh = String(newSpaceItem.translated || bKo).slice(0, 60);
                  pushNotification('📝', `${__pDispKo}이 새 메모를 남겼어요`, `${__pDispZh}留了新备忘`, bKo, bZh, 'diary', 'diary', 'post', false, __incPartnerRole);
                } else if (k === 'buckets') {
                  const bKo = String(newSpaceItem.title || newSpaceItem.text || '새 버킷리스트가 추가되었어요 ✨').slice(0, 60);
                  const bZh = String(newSpaceItem.translated || bKo).slice(0, 60);
                  pushNotification('🌟', `${__pDispKo}이 버킷리스트를 추가했어요`, `${__pDispZh}添加了新的心愿清单`, bKo, bZh, 'diary', 'bucket', 'post', false, __incPartnerRole);
                } else if (k === 'capsules') {
                  const bKo = String(newSpaceItem.title || '새 타임캡슐 편지가 봉인되었어요 💌').slice(0, 60);
                  const bZh = String(newSpaceItem.translatedTitle || bKo).slice(0, 60);
                  pushNotification('💌', `${__pDispKo}이 타임캡슐을 봉인했어요`, `${__pDispZh}封存了一封时间胶囊`, bKo, bZh, 'diary', 'capsule', 'post', false, __incPartnerRole);
                } else if (k === 'coupons') {
                  const bKo = String(newSpaceItem.title || newSpaceItem.text || '새 애정 쿠폰이 도착했어요 🎟️').slice(0, 60);
                  const bZh = String(newSpaceItem.translated || bKo).slice(0, 60);
                  pushNotification('🎟️', `${__pDispKo}이 애정 쿠폰을 보냈어요`, `${__pDispZh}送来了一张爱心券`, bKo, bZh, 'diary', 'coupon', 'post', false, __incPartnerRole);
                } else if (k === 'anniversaries') {
                  const bKo = String(newSpaceItem.title || '새 기념일이 등록되었어요 🎂').slice(0, 60);
                  const bZh = String(newSpaceItem.translated || bKo).slice(0, 60);
                  pushNotification('🎂', `${__pDispKo}이 새 기념일을 등록했어요`, `${__pDispZh}添加了新的纪念日`, bKo, bZh, 'diary', 'anniversary', 'post', false, __incPartnerRole);
                } else if (k === 'schedules') {
                  const bKo = String(newSpaceItem.title || newSpaceItem.text || '새 일정이 등록되었어요 📅').slice(0, 60);
                  const bZh = String(newSpaceItem.translated || bKo).slice(0, 60);
                  pushNotification('📅', `${__pDispKo}이 캘린더 일정을 추가했어요`, `${__pDispZh}添加了新的日历日程`, bKo, bZh, 'diary', 'calendar', 'post', false, __incPartnerRole);
                }
              }
              if (k === 'diaries' || k === 'memos') {
                const curMap = new Map((state[k] || []).map(x => [x && x.id, x]));
                inc[k].forEach(incItem => {
                  const curItem = incItem && curMap.get(incItem.id);
                  if (curItem && Array.isArray(incItem.comments) && incItem.comments.length) {
                    if (!Array.isArray(curItem.comments)) curItem.comments = [];
                    const seenC = new Set(curItem.comments.map(c => c && c.id).filter(Boolean));
                    incItem.comments.forEach(c => {
                      if (c && c.id && !seenC.has(c.id)) { seenC.add(c.id); curItem.comments.push(c); changed = true; }
                    });
                  }
                });
              }
            }
          });
          if (Array.isArray(inc.albumFolders) && inc.albumFolders.length) {
            const incAfTs = Number(inc.albumFoldersUpdatedAt || 0);
            const curAfTs = Number(state.albumFoldersUpdatedAt || 0);
            if (incAfTs > curAfTs) {
              state.albumFolders = inc.albumFolders.filter(Boolean).slice(0, 25);
              state.albumFoldersCustomized = true;
              state.albumFoldersUpdatedAt = incAfTs;
              changed = true;
            } else if (!state.albumFoldersCustomized && curAfTs === 0) {
              if (!Array.isArray(state.albumFolders)) state.albumFolders = [];
              inc.albumFolders.forEach(f => {
                if (f && !state.albumFolders.includes(f)) { state.albumFolders.push(f); changed = true; }
              });
            }
          }
          if (inc.heartResetDate && (!state.heartResetDate || inc.heartResetDate > state.heartResetDate)) {
            state.heartResetDate = inc.heartResetDate;
            state.heartCount = inc.heartCount || 0;
            changed = true;
          } else if (inc.heartCount && inc.heartCount > (state.heartCount || 0) && (!inc.heartResetDate || !state.heartResetDate || inc.heartResetDate === state.heartResetDate)) {
            state.heartCount = inc.heartCount;
            changed = true;
            if (isLiveEvent && inc.myRole && inc.myRole !== (state.myRole || 'suwan')) {
              const pName = inc.myRole === 'suwan' ? '수완(完)' : '靖灿(灿)';
              pushNotification('💓', `${pName}의 보고 싶어 하트!`, `${pName}发来想你的心跳！`, `누적 ${state.heartCount}번째 마음을 보냈어 💜`, `已发送第 ${state.heartCount} 次心动 💜`, 'home', '', 'post', false, inc.myRole);
            }
          }
          if (inc.learn && typeof inc.learn === 'object') {
            const prevSolved = Number(state.learn?.solved || 0);
            const prevPraiseIds = new Set((state.learn?.praiseStickers || []).map(p => p && p.id).filter(Boolean));
            const incPraises = Array.isArray(inc.learn.praiseStickers) ? inc.learn.praiseStickers : [];
            const foundNewPraise = incPraises.find(p => p && p.id && !prevPraiseIds.has(p.id)) || null;
            const beforeSig = JSON.stringify(state.learn || {});
            const nextLearn = mergeLearnMonotonic(state.learn, inc.learn);
            if (JSON.stringify(nextLearn) !== beforeSig) {
              state.learn = nextLearn;
              if (foundNewPraise) newestPraise = foundNewPraise;
              changed = true;
              try { idbPut('learn_vault_v1', state.learn); } catch (_) {}
              if (isLiveEvent && Number(state.learn.solved || 0) > prevSolved && (state.myRole || 'suwan') === 'suwan' && inc.myRole === 'jingchan') {
                pushNotification('📚', '靖灿(灿)이 한국어 공부를 했어요!', '靖灿完成了韩语练习！', `오늘 ${state.learn.todaySolvedCount || 1}문제 완료 · 누적 ${state.learn.xp || 0} XP 💜`, `今日已完成 ${state.learn.todaySolvedCount || 1} 题 · 累计 ${state.learn.xp || 0} XP 💜`, 'home', '', 'post', false, 'jingchan');
              }
              if (isLiveEvent && newestPraise && (state.myRole || 'suwan') === 'jingchan' && inc.myRole === 'suwan') {
                pushNotification(newestPraise.icon || '⭐', '수완(完)의 칭찬 스티커 도착!', '收到完送来的表扬贴纸！', `${newestPraise.icon || '⭐'} ${newestPraise.ko || '최고야'} (+20 XP) 💜`, `${newestPraise.icon || '⭐'} ${newestPraise.zh || '最棒啦'} (+20 XP) 💜`, 'home', '', 'post', false, 'suwan');
              }
            }
          }
          if (inc.profile) {
            const __incSwActTs = Number(inc.profile.suwanActivityUpdatedAt || 0);
            const __curSwActTs = Number(state.profile.suwanActivityUpdatedAt || 0);
            if (inc.profile.suwanActivity && inc.profile.suwanActivity !== state.profile.suwanActivity && (__incSwActTs >= __curSwActTs || __curSwActTs === 0)) {
              state.profile.suwanActivity = inc.profile.suwanActivity;
              if (__incSwActTs > 0) state.profile.suwanActivityUpdatedAt = __incSwActTs;
              changed = true;
              if (isLiveEvent && (state.myRole || 'suwan') !== 'suwan') {
                const __am = { working:['💻 일하는 중','💻 工作中'], eating:['🍜 밥 먹는 중','🍜 吃饭中'], workout:['🏃 운동 중','🏃 运动中'], missing:['💜 보고 싶은 중','💜 想你中'], sleeping:['🌙 자는 중','🌙 睡觉中'], chilling:['✨ 여유로운 중','✨ 悠闲中'] }[inc.profile.suwanActivity] || [inc.profile.suwanActivity, inc.profile.suwanActivity];
                pushNotification('✨', '수완 · 상태', '秀完 · 状态', __am[0], __am[1], 'translator', 'messenger', 'mood', false, 'suwan');
              }
            }
            const __incJcActTs = Number(inc.profile.jingchanActivityUpdatedAt || 0);
            const __curJcActTs = Number(state.profile.jingchanActivityUpdatedAt || 0);
            if (inc.profile.jingchanActivity && inc.profile.jingchanActivity !== state.profile.jingchanActivity && (__incJcActTs >= __curJcActTs || __curJcActTs === 0)) {
              state.profile.jingchanActivity = inc.profile.jingchanActivity;
              if (__incJcActTs > 0) state.profile.jingchanActivityUpdatedAt = __incJcActTs;
              changed = true;
              if (isLiveEvent && (state.myRole || 'suwan') !== 'jingchan') {
                const __am = { working:['💻 일하는 중','💻 工作中'], eating:['🍜 밥 먹는 중','🍜 吃饭中'], workout:['🏃 운동 중','🏃 运动中'], missing:['💜 보고 싶은 중','💜 想你中'], sleeping:['🌙 자는 중','🌙 睡觉中'], chilling:['✨ 여유로운 중','✨ 悠闲中'] }[inc.profile.jingchanActivity] || [inc.profile.jingchanActivity, inc.profile.jingchanActivity];
                pushNotification('✨', '징찬 · 상태', '靖灿 · 状态', __am[0], __am[1], 'translator', 'messenger', 'mood', false, 'jingchan');
              }
            }
            const __incSwMoodTs = Number(inc.profile.suwanMoodUpdatedAt || inc.updatedAt || 0);
            const __curSwMoodTs = Number(state.profile.suwanMoodUpdatedAt || 0);
            const __allowSwMood = inc.profile.suwanMood && inc.profile.suwanMood !== state.profile.suwanMood && (
              ((state.myRole || 'suwan') !== 'suwan' && inc.myRole === 'suwan' && (__incSwMoodTs >= __curSwMoodTs || __curSwMoodTs === 0)) ||
              ((state.myRole || 'suwan') === 'suwan' && __incSwMoodTs > __curSwMoodTs)
            );
            if (__allowSwMood) {
              state.profile.suwanMood = inc.profile.suwanMood;
              state.profile.suwanMoodUpdatedAt = Math.max(__incSwMoodTs, __curSwMoodTs);
              changed = true;
              if (isLiveEvent && (state.myRole || 'suwan') !== 'suwan') {
                const mDisp = String(inc.profile.suwanMood || '').split('·')[0].trim();
                pushNotification('✨', '수완(完)의 지금 상태가 바뀌었어요', '完更新了当前状态', `지금 [${mDisp}] 중이에요 💜`, `现在正在 [${inc.profile.suwanMood}] 💜`, 'home', '', 'mood', false, 'suwan');
              }
            }
            const __incJcMoodTs = Number(inc.profile.jingchanMoodUpdatedAt || inc.updatedAt || 0);
            const __curJcMoodTs = Number(state.profile.jingchanMoodUpdatedAt || 0);
            const __allowJcMood = inc.profile.jingchanMood && inc.profile.jingchanMood !== state.profile.jingchanMood && (
              ((state.myRole || 'suwan') !== 'jingchan' && inc.myRole === 'jingchan' && (__incJcMoodTs >= __curJcMoodTs || __curJcMoodTs === 0)) ||
              ((state.myRole || 'suwan') === 'jingchan' && __incJcMoodTs > __curJcMoodTs)
            );
            if (__allowJcMood) {
              state.profile.jingchanMood = inc.profile.jingchanMood;
              state.profile.jingchanMoodUpdatedAt = Math.max(__incJcMoodTs, __curJcMoodTs);
              changed = true;
              if (isLiveEvent && (state.myRole || 'suwan') !== 'jingchan') {
                const mDisp = String(inc.profile.jingchanMood || '').split('·')[0].trim();
                pushNotification('✨', '靖灿(灿)의 지금 상태가 바뀌었어요', '靖灿更新了当前状态', `지금 [${mDisp}] 중이에요 💜`, `现在正在 [${inc.profile.jingchanMood}] 💜`, 'home', '', 'mood', false, 'jingchan');
              }
            }
            // Wake/Sleep check-in sync
            if (inc.profile.suwanSleep && Number(inc.profile.suwanSleep.updatedAt || 0) > Number(state.profile.suwanSleep?.updatedAt || 0)) {
              state.profile.suwanSleep = { ...inc.profile.suwanSleep };
              changed = true;
              if (isLiveEvent && (state.myRole || 'suwan') !== 'suwan') {
                const isWake = inc.profile.suwanSleep.status === 'wake';
                pushNotification(isWake ? '☀️' : '🌙', isWake ? '수완(完)이 일어났어요!' : '수완(完)이 자러 갔어요!', isWake ? '完起床啦！早安 ☀️' : '完准备睡觉啦！晚安 🌙', `${inc.profile.suwanSleep.time || ''} ${isWake ? '좋은 하루 보내 💜' : '잘 자, 좋은 꿈 꿔 💜'}`, `${inc.profile.suwanSleep.time || ''} ${isWake ? '今天也要开心哦 💜' : '晚安好梦 💜'}`, 'home', '', 'post', false, 'suwan');
              }
            }
            ['suwan', 'jingchan'].forEach(rk => {
              const lk = rk + 'LastSeen';
              const incLs = Number(inc.profile[lk] || 0);
              const curLs = Number(state.profile[lk] || 0);
              if (incLs > curLs) {
                state.profile[lk] = incLs;
                if (typeof window.__savePartnerLastSeen === 'function') window.__savePartnerLastSeen(rk, incLs);
                if (window.__cwPartnerPresence && window.__cwPartnerPresence[rk]) {
                  window.__cwPartnerPresence[rk].lastSeen = Math.max(Number(window.__cwPartnerPresence[rk].lastSeen || 0), incLs);
                }
                if (typeof window.__renderPresenceBadges === 'function') window.__renderPresenceBadges();
                changed = true;
              }
              const rkRead = rk + 'ReadUpToTs';
              const incRd = Number(inc.profile[rkRead] || 0);
              const curRd = Number(state.profile[rkRead] || 0);
              if (incRd > curRd) {
                state.profile[rkRead] = incRd;
                changed = true;
              }
            });
            const __myRoleNow = state.myRole || 'suwan';
            const __partnerRoleNow = __myRoleNow === 'suwan' ? 'jingchan' : 'suwan';
            const __partnerReadWatermark = Number(state.profile[__partnerRoleNow + 'ReadUpToTs'] || 0);
            if (__partnerReadWatermark > 0 && Array.isArray(state.chat?.messages)) {
              state.chat.messages.forEach(m => {
                if (!m || m.readByPartner) return;
                const _ns = (m.sender === 'jingchan' || String(m.sender || '').includes('靖灿')) ? 'jingchan' : 'suwan';
                if (_ns === __myRoleNow && Number(m.ts || 0) > 0 && Number(m.ts || 0) <= __partnerReadWatermark) {
                  m.readByPartner = true;
                  m.deliveryStatus = 'sent';
                  changed = true;
                  chatChanged = true;
                }
              });
            }
            if (inc.profile.jingchanSleep && Number(inc.profile.jingchanSleep.updatedAt || 0) > Number(state.profile.jingchanSleep?.updatedAt || 0)) {
              state.profile.jingchanSleep = { ...inc.profile.jingchanSleep };
              changed = true;
              if (isLiveEvent && (state.myRole || 'suwan') !== 'jingchan') {
                const isWake = inc.profile.jingchanSleep.status === 'wake';
                pushNotification(isWake ? '☀️' : '🌙', isWake ? '靖灿(灿)이 일어났어요!' : '靖灿(灿)이 자러 갔어요!', isWake ? '靖灿起床啦！早安 ☀️' : '靖灿准备睡觉啦！晚安 🌙', `${inc.profile.jingchanSleep.time || ''} ${isWake ? '좋은 하루 보내 💜' : '잘 자, 좋은 꿈 꿔 💜'}`, `${inc.profile.jingchanSleep.time || ''} ${isWake ? '今天也要开心哦 💜' : '晚安好梦 💜'}`, 'home', '', 'post', false, 'jingchan');
              }
            }
          }
          // Start Date (D-Day) sync (always syncs customized couple start date across both phones!)
          if (inc.startDate && /^\d{4}-\d{2}-\d{2}$/.test(String(inc.startDate))) {
            const incSdTs = Number(inc.startDateUpdatedAt || 0);
            const curSdTs = Number(state.startDateUpdatedAt || 0);
            const curIsDefault = (!state.startDate || state.startDate === '2026-01-01') && curSdTs === 0;
            const incIsCustom = inc.startDate !== '2026-01-01';
            if (inc.startDate !== state.startDate && (incSdTs > curSdTs || (curIsDefault && incIsCustom))) {
              state.startDate = inc.startDate;
              state.startDateUpdatedAt = Math.max(incSdTs, Date.now());
              changed = true;
              try { renderHome(); renderAnniversary(); } catch (_) {}
            }
          }
          // Cities sync (handles both newer timestamps AND legacy custom cities without updatedAt!)
          if (inc.cities && typeof inc.cities === 'object') {
            if (!state.cities) state.cities = JSON.parse(JSON.stringify(DEFAULT_STATE.cities));
            let cityUpdated = false;
            const defaultCityNames = { suwan: '수원 · Suwon', jingchan: '상하이 · 上海' };
            ['suwan', 'jingchan'].forEach(ck => {
              const incC = inc.cities[ck];
              const curC = state.cities[ck] || {};
              if (!incC || !incC.name) return;
              const incTs = Number(incC.updatedAt || 0);
              const curTs = Number(curC.updatedAt || 0);
              const curIsDef = (!curC.name || curC.name === defaultCityNames[ck]) && curTs === 0;
              const incIsCustom = incC.name !== defaultCityNames[ck];
              const fromOwner = inc.myRole === ck && incC.name !== curC.name && curTs === 0;
              if (incTs > curTs || (curIsDef && incIsCustom) || (fromOwner && incIsCustom)) {
                state.cities[ck] = { ...incC, updatedAt: Math.max(incTs, Date.now()) };
                cityUpdated = true;
                changed = true;
              }
            });
            if (cityUpdated) { try { renderHome(); updateClocks(); refreshBothCityWeathers(); } catch (_) {} }
          }
          // Energy & Activity sync
          if (inc.profile) {
            ['suwan', 'jingchan'].forEach(rk => {
              const ek = rk + 'Energy';
              if (inc.profile[ek] && Number(inc.profile[ek].updatedAt || 0) > Number(state.profile[ek]?.updatedAt || 0)) {
                state.profile[ek] = { ...inc.profile[ek] };
                changed = true;
                if (isLiveEvent && (state.myRole || 'suwan') !== rk && Number(inc.profile[ek].level) <= 30) {
                  const nm = rk === 'suwan' ? '수완(完)' : '靖灿(灿)';
                  pushNotification('🪫', `${nm} 에너지 ${inc.profile[ek].level}%! 위로가 필요해요`, `${nm}能量只剩 ${inc.profile[ek].level}%，求抱抱！`, '지금 따뜻한 한마디나 포옹을 보내주세요 💜', '快发一句暖心话或抱抱安慰一下吧 💜', 'home', '', 'post', false, rk);
                }
              }
            });
          }
          // Maker Mode Layout Auto-Sync (Prime 3 v34)
          if (inc.makerLayout && typeof inc.makerLayout === 'object' && Number(inc.makerLayout.updatedAt || 0) > Number(state.makerLayout?.updatedAt || 0)) {
            state.makerLayout = { ...inc.makerLayout };
            changed = true;
            if (typeof window.__applyMakerLayout === 'function') {
              try { window.__applyMakerLayout(state.makerLayout, true); } catch (_) {}
            }
          }
          // Hold-to-Hug sync
          if (inc.hugs && typeof inc.hugs === 'object' && Number(inc.hugs.updatedAt || 0) > Number(state.hugs?.updatedAt || 0)) {
            const kstH = getKstDateString();
            const prevCount = (state.hugs && state.hugs.date === kstH) ? Number(state.hugs.count || 0) : 0;
            state.hugs = { ...inc.hugs };
            changed = true;
            if (isLiveEvent && inc.hugs.lastBy && inc.hugs.lastBy !== (state.myRole || 'suwan') && Number(inc.hugs.count || 0) > prevCount) {
              const nm = inc.hugs.lastBy === 'suwan' ? '수완(完)' : '靖灿(灿)';
              pushNotification('🫂', `${nm}이 지금 꼭 안아주는 중!`, `${nm}正在紧紧抱住你！`, '따뜻한 포옹이 도착했어요 💜 (오늘 ' + inc.hugs.count + '회)', '收到一个温暖的抱抱 💜 (今日第 ' + inc.hugs.count + ' 次)', 'home', '', 'post', false, inc.hugs.lastBy);
            }
          }
          // TMI Book sync
          if (inc.tmiBook && typeof inc.tmiBook === 'object') {
            if (!state.tmiBook) state.tmiBook = JSON.parse(JSON.stringify(DEFAULT_STATE.tmiBook));
            ['suwan', 'jingchan'].forEach(rk => {
              const incT = inc.tmiBook[rk];
              const curT = state.tmiBook[rk] || {};
              if (incT && Number(incT.updatedAt || 0) > Number(curT.updatedAt || 0)) {
                state.tmiBook[rk] = { ...curT, ...incT };
                changed = true;
                if (isLiveEvent && __isFromPartner && rk === __incPartnerRole) {
                  pushNotification('📖', `${__pDispKo}이 TMI 수첩을 업데이트했어요`, `${__pDispZh}更新了 TMI 小本本`, '새로운 취향과 소소한 기록을 확인해 보세요 💜', '快去看看最新记录的小喜好吧 💜', 'diary', 'tmi', 'post', false, __incPartnerRole);
                }
              }
            });
          }
          // Compliment Jar sync
          if (Array.isArray(inc.complimentJar) && inc.complimentJar.length) {
            const prevJarIds = new Set((state.complimentJar || []).map(x => x && x.id));
            const newJar = isLiveEvent && __isFromPartner ? inc.complimentJar.find(x => x && x.id && !prevJarIds.has(x.id)) : null;
            state.complimentJar = mergeById(state.complimentJar || [], inc.complimentJar, true, false);
            if (state.complimentJar.length > 100) state.complimentJar.length = 100;
            if (newJar) {
              const bKo = String(newJar.text || newJar.content || '새 칭찬 쪽지가 도착했어요 ✨').slice(0, 60);
              const bZh = String(newJar.translated || bKo).slice(0, 60);
              pushNotification('✨', `${__pDispKo}이 칭찬 유리병에 쪽지를 넣었어요`, `${__pDispZh}往夸夸瓶放了新纸条`, bKo, bZh, 'diary', 'jar', 'post', false, __incPartnerRole);
            }
          }
          // Couple Mini Quiz sync (merges both new quizzes and partner answers)
          if (Array.isArray(inc.coupleQuizzes) && inc.coupleQuizzes.length) {
            if (!Array.isArray(state.coupleQuizzes)) state.coupleQuizzes = [];
            const qMap = new Map(state.coupleQuizzes.map(q => [q && q.id, q]));
            inc.coupleQuizzes.forEach(iq => {
              if (!iq || !iq.id) return;
              const ex = qMap.get(iq.id);
              if (!ex) {
                state.coupleQuizzes.unshift(iq);
                qMap.set(iq.id, iq);
                changed = true;
                if (isLiveEvent && __isFromPartner) {
                  pushNotification('💌', `${__pDispKo}이 새 커플 퀴즈를 냈어요!`, `${__pDispZh}出了新情侣问答！`, '눌러서 바로 퀴즈 풀러 가기 ✨', '点击马上去答题互动 ✨', 'diary', 'quiz', 'post', false, __incPartnerRole);
                }
              } else {
                if (iq.answeredAt && (!ex.answeredAt || iq.answeredAt > ex.answeredAt)) {
                  ex.pickedIdx = iq.pickedIdx;
                  ex.answeredBy = iq.answeredBy;
                  ex.answeredAt = iq.answeredAt;
                  changed = true;
                  if (isLiveEvent && __isFromPartner) {
                    pushNotification('💌', `${__pDispKo}이 커플 퀴즈를 풀었어요!`, `${__pDispZh}完成了情侣小测验！`, '눌러서 정답 결과를 확인해 보세요 ✨', '点击查看答题结果吧 ✨', 'diary', 'quiz', 'post', false, __incPartnerRole);
                  }
                }
                if (Array.isArray(iq.replies) && iq.replies.length) {
                  if (!Array.isArray(ex.replies)) ex.replies = [];
                  const rMap = new Map(ex.replies.map(r => [r && r.id, r]));
                  iq.replies.forEach(ir => {
                    if (!ir || !ir.id) return;
                    const er = rMap.get(ir.id);
                    if (!er) { ex.replies.push(ir); rMap.set(ir.id, ir); changed = true; }
                    else if (ir.translated && !er.translated) { er.translated = ir.translated; changed = true; }
                  });
                }
              }
            });
            if (state.coupleQuizzes.length > 60) state.coupleQuizzes.length = 60;
          }
          // Meal Check-in sync (partner's row merges safely for today)
          if (inc.meals && typeof inc.meals === 'object') {
            const kstNowM = getKstDateString();
            if (!state.meals || state.meals.date !== kstNowM) {
              state.meals = JSON.parse(JSON.stringify(DEFAULT_STATE.meals));
              state.meals.date = kstNowM;
            }
            if (inc.meals.date === kstNowM) {
              const pKey = inc.myRole === 'jingchan' ? 'jingchan' : 'suwan';
              if (inc.meals[pKey] && JSON.stringify(inc.meals[pKey]) !== JSON.stringify(state.meals[pKey])) {
                state.meals[pKey] = JSON.parse(JSON.stringify(inc.meals[pKey]));
                state.meals.updatedAt = Math.max(Number(state.meals.updatedAt || 0), Number(inc.meals.updatedAt || 0));
                changed = true;
              }
            }
          }
          // Lavender Pot sync
          if (inc.lavender && typeof inc.lavender === 'object') {
            if (!state.lavender) state.lavender = JSON.parse(JSON.stringify(DEFAULT_STATE.lavender));
            const maxXp = Math.max(Number(state.lavender.xp || 0), Number(inc.lavender.xp || 0));
            const maxWaters = Math.max(Number(state.lavender.totalWaters || 0), Number(inc.lavender.totalWaters || 0));
            const lwS = (inc.lavender.lastWaterSuwan || '') > (state.lavender.lastWaterSuwan || '') ? inc.lavender.lastWaterSuwan : (state.lavender.lastWaterSuwan || '');
            const lwJ = (inc.lavender.lastWaterJingchan || '') > (state.lavender.lastWaterJingchan || '') ? inc.lavender.lastWaterJingchan : (state.lavender.lastWaterJingchan || '');
            const __prevWaters = Number(state.lavender.totalWaters || 0);
            if (maxXp !== state.lavender.xp || maxWaters !== state.lavender.totalWaters || lwS !== state.lavender.lastWaterSuwan || lwJ !== state.lavender.lastWaterJingchan) {
              state.lavender.xp = maxXp;
              state.lavender.totalWaters = maxWaters;
              state.lavender.lastWaterSuwan = lwS;
              state.lavender.lastWaterJingchan = lwJ;
              state.lavender.updatedAt = Math.max(Number(state.lavender.updatedAt || 0), Number(inc.lavender.updatedAt || 0));
              changed = true;
              if (isLiveEvent && __isFromPartner && maxWaters > __prevWaters) {
                pushNotification('🪻', `${__pDispKo}이 라벤더에 물을 줬어요!`, `${__pDispZh}给薰衣草浇水啦！`, `누적 ${maxWaters}회 물주기 · ${maxXp} XP 💜`, `累计浇水 ${maxWaters} 次 · ${maxXp} XP 💜`, 'home', '', 'post', false, __incPartnerRole);
              }
            }
          }
          // Custom Food Roulette items sync
          if (Array.isArray(inc.customFoods) && inc.customFoods.length) {
            if (!Array.isArray(state.customFoods)) state.customFoods = [];
            inc.customFoods.forEach(cf => {
              if (cf && !state.customFoods.includes(cf)) { state.customFoods.push(cf); changed = true; }
            });
          }
          // Album lightweight metadata sync (folder moves & photo comments!)
          if (Array.isArray(inc.albumMeta) && inc.albumMeta.length && Array.isArray(state.albums)) {
            const albMap = new Map(state.albums.map(a => [a && a.id, a]));
            inc.albumMeta.forEach(am => {
              if (!am || !am.id) return;
              const curA = albMap.get(am.id);
              if (!curA) return;
              const incCatTs = Number(am.categoryUpdatedAt || 0);
              const curCatTs = Number(curA.categoryUpdatedAt || 0);
              if (am.category && am.category !== curA.category && (incCatTs > curCatTs || (incCatTs === 0 && curCatTs === 0))) {
                curA.category = am.category;
                if (incCatTs > 0) curA.categoryUpdatedAt = incCatTs;
                changed = true;
                try { if (typeof persistMediaVaultsNow === 'function') persistMediaVaultsNow(true); } catch (_) {}
              }
              if (Array.isArray(am.comments) && am.comments.length) {
                if (!Array.isArray(curA.comments)) curA.comments = [];
                const seenAc = new Set(curA.comments.map(c => (c && (c.id || (c.author + ':' + c.text)))));
                am.comments.forEach(c => {
                  const key = c && (c.id || (c.author + ':' + c.text));
                  if (key && !seenAc.has(key)) { seenAc.add(key); curA.comments.push(c); changed = true; }
                });
              }
            });
          }
          // Prime 2 Game 1: Drawing Quiz sync
          if (Array.isArray(inc.drawQuizzes) && inc.drawQuizzes.length) {
            if (!Array.isArray(state.drawQuizzes)) state.drawQuizzes = [];
            const dqMap = new Map(state.drawQuizzes.map(x => [x && x.id, x]));
            inc.drawQuizzes.forEach(iq => {
              if (!iq || !iq.id) return;
              const ex = dqMap.get(iq.id);
              if (!ex) {
                state.drawQuizzes.unshift(iq);
                dqMap.set(iq.id, iq);
                changed = true;
                if (isLiveEvent && __isFromPartner) {
                  pushNotification('🎨', `${__pDispKo}이 그림 퀴즈를 냈어요!`, `${__pDispZh}画了一道你画我猜！`, '눌러서 그림을 보고 정답을 맞혀 보세요 🎨', '点击看看画了什么并猜答案吧 🎨', 'diary', 'drawquiz', 'post', false, __incPartnerRole);
                }
              } else if (iq.solvedAt && !ex.solvedAt) {
                ex.solvedAt = iq.solvedAt;
                ex.solvedBy = iq.solvedBy;
                ex.guessText = iq.guessText || '';
                changed = true;
                if (isLiveEvent && __isFromPartner) {
                  pushNotification('🎨', `${__pDispKo}이 그림 퀴즈를 맞혔어요! 🎉`, `${__pDispZh}猜对了你的画！🎉`, `정답: ${ex.answer || ''}`, `答案：${ex.answerZh || ex.answer || ''}`, 'diary', 'drawquiz', 'post', false, __incPartnerRole);
                }
              }
            });
            if (state.drawQuizzes.length > 25) state.drawQuizzes.length = 25;
          }
          // Prime 2 Game 2: Rock-Paper-Scissors sync
          if (inc.rpsGame && typeof inc.rpsGame === 'object') {
            if (!state.rpsGame) state.rpsGame = { round: 1, moves: { suwan: '', jingchan: '' }, score: { suwan: 0, jingchan: 0 }, wishKo: '', wishZh: '', updatedAt: 0 };
            const incR = inc.rpsGame;
            const curR = state.rpsGame;
            if (Number(incR.round || 1) > Number(curR.round || 1)) {
              state.rpsGame = JSON.parse(JSON.stringify(incR));
              changed = true;
              if (isLiveEvent && __isFromPartner) {
                pushNotification('✊', `${__pDispKo}이 가위바위보 새 판을 시작했어요!`, `${__pDispZh}发起了新一局猜拳！`, '눌러서 가위·바위·보를 골라 보세요 ✊✌️✋', '点击出拳决胜负吧 ✊✌️✋', 'diary', 'rps', 'post', false, __incPartnerRole);
              }
            } else if (Number(incR.round || 1) === Number(curR.round || 1) && incR.moves) {
              const pKey = __incPartnerRole === 'suwan' ? 'suwan' : 'jingchan';
              if (__isFromPartner && incR.moves[pKey] && incR.moves[pKey] !== (curR.moves && curR.moves[pKey])) {
                if (!curR.moves) curR.moves = { suwan: '', jingchan: '' };
                curR.moves[pKey] = incR.moves[pKey];
                if (incR.wishKo) { curR.wishKo = incR.wishKo; curR.wishZh = incR.wishZh || incR.wishKo; }
                curR.score = {
                  suwan: Math.max(Number(curR.score?.suwan || 0), Number(incR.score?.suwan || 0)),
                  jingchan: Math.max(Number(curR.score?.jingchan || 0), Number(incR.score?.jingchan || 0))
                };
                curR.updatedAt = Math.max(Number(curR.updatedAt || 0), Number(incR.updatedAt || Date.now()));
                changed = true;
                if (isLiveEvent) {
                  const myK = (state.myRole || 'suwan') === 'suwan' ? 'suwan' : 'jingchan';
                  const bothDone = !!(curR.moves.suwan && curR.moves.jingchan);
                  pushNotification('✊', bothDone ? `${__pDispKo}과 가위바위보 결과 공개!` : `${__pDispKo}이 가위바위보를 냈어요!`, bothDone ? `与${__pDispZh}的猜拳结果揭晓！` : `${__pDispZh}已经出拳啦！`, bothDone ? '눌러서 승자와 소원권을 확인하세요 🎉' : '눌러서 나도 내고 소원권을 노려보세요 ✊✌️✋', bothDone ? '点击查看胜者和许愿奖励 🎉' : '点击出拳争夺许愿权吧 ✊✌️✋', 'diary', 'rps', 'post', false, __incPartnerRole);
                }
              }
            }
          }
          // Prime 2 Game 3: Truth or Dare sync
          if (inc.truthDare && typeof inc.truthDare === 'object') {
            if (!state.truthDare) state.truthDare = { activeCard: null, history: [], updatedAt: 0 };
            if (inc.truthDare.activeCard && Number(inc.truthDare.updatedAt || 0) > Number(state.truthDare.updatedAt || 0)) {
              state.truthDare.activeCard = { ...inc.truthDare.activeCard };
              state.truthDare.updatedAt = Number(inc.truthDare.updatedAt || Date.now());
              changed = true;
              if (isLiveEvent && __isFromPartner) {
                const cTypeKo = inc.truthDare.activeCard.type === 'dare' ? '도전' : '진실';
                const cTypeZh = inc.truthDare.activeCard.type === 'dare' ? '大冒险' : '真心话';
                pushNotification('🃏', `${__pDispKo}이 ${cTypeKo} 카드를 뽑았어요!`, `${__pDispZh}抽到了${cTypeZh}卡片！`, inc.truthDare.activeCard.ko || '눌러서 같이 참여해 보세요 🃏', inc.truthDare.activeCard.zh || '点击一起参与吧 🃏', 'diary', 'truthdare', 'post', false, __incPartnerRole);
              }
            }
            if (Array.isArray(inc.truthDare.history) && inc.truthDare.history.length) {
              const prevTdIds = new Set((state.truthDare.history || []).map(x => x && x.id));
              const prevTdContent = new Set((state.truthDare.history || []).map(x => x ? `${x.author || ''}|${String(x.text || '').trim()}` : ''));
              const newTd = isLiveEvent && __isFromPartner ? inc.truthDare.history.find(x => x && x.id && !prevTdIds.has(x.id) && !prevTdContent.has(`${x.author || ''}|${String(x.text || '').trim()}`)) : null;
              const _mergedTd = mergeById(state.truthDare.history || [], inc.truthDare.history, true, false);
              const _tdSeenKey = new Set();
              state.truthDare.history = _mergedTd.filter(it => {
                if (!it) return false;
                const k = `${it.author || ''}|${String(it.text || '').trim()}|${it.time || ''}`;
                if (_tdSeenKey.has(k)) return false;
                _tdSeenKey.add(k);
                return true;
              }).slice(0, 40);
              if (newTd) {
                changed = true;
                pushNotification('🃏', `${__pDispKo}이 진실·도전에 답했어요!`, `${__pDispZh}回答了真心话大冒险！`, String(newTd.text || '').slice(0, 60), String(newTd.translated || newTd.text || '').slice(0, 60), 'diary', 'truthdare', 'post', false, __incPartnerRole);
              }
            }
          }
          // Balance Game sync
          if (inc.balanceGame && inc.balanceGame.answers && typeof inc.balanceGame.answers === 'object') {
            if (!state.balanceGame) state.balanceGame = { currentIdx: 0, answers: {}, updatedAt: 0 };
            if (!state.balanceGame.answers) state.balanceGame.answers = {};
            for (const [qId, ans] of Object.entries(inc.balanceGame.answers)) {
              if (!ans || typeof ans !== 'object') continue;
              const cur = state.balanceGame.answers[qId] || { suwan: '', jingchan: '', updatedAt: 0 };
              let qChanged = false;
              if (inc.myRole === 'suwan' && ans.suwan && ans.suwan !== cur.suwan) { cur.suwan = ans.suwan; qChanged = true; }
              if (inc.myRole === 'jingchan' && ans.jingchan && ans.jingchan !== cur.jingchan) { cur.jingchan = ans.jingchan; qChanged = true; }
              if (!cur.suwan && ans.suwan) { cur.suwan = ans.suwan; qChanged = true; }
              if (!cur.jingchan && ans.jingchan) { cur.jingchan = ans.jingchan; qChanged = true; }
              if (qChanged) {
                cur.updatedAt = Math.max(Number(cur.updatedAt || 0), Number(ans.updatedAt || Date.now()));
                state.balanceGame.answers[qId] = cur;
                changed = true;
                if (isLiveEvent && __isFromPartner && !window.__balNotifSentThisMerge) {
                  window.__balNotifSentThisMerge = true;
                  setTimeout(() => { window.__balNotifSentThisMerge = false; }, 1000);
                  pushNotification('⚖️', `${__pDispKo}이 밸런스 게임을 선택했어요!`, `${__pDispZh}选了默契二选一！`, '눌러서 내 선택도 고르고 결과를 확인해 보세요 💜', '点击选出你的答案，看看我们默契吗 💜', 'diary', 'balance', 'post', false, __incPartnerRole);
                }
              }
            }
          }
          // Date Stamp Map sync
          if (inc.dateStamps && typeof inc.dateStamps === 'object') {
            if (!state.dateStamps) state.dateStamps = JSON.parse(JSON.stringify(DEFAULT_STATE.dateStamps));
            if (Array.isArray(inc.dateStamps.deletedIds)) {
              const delS = new Set(state.dateStamps.deletedIds || []);
              inc.dateStamps.deletedIds.forEach(d => { if (d && !delS.has(d)) { delS.add(d); changed = true; } });
              state.dateStamps.deletedIds = Array.from(delS);
            }
            const delSetDm = new Set(state.dateStamps.deletedIds || []);
            if (Array.isArray(inc.dateStamps.customSpots)) {
              const seenDm = new Set((state.dateStamps.customSpots || []).map(x => x && x.id));
              inc.dateStamps.customSpots.forEach(sp => {
                if (sp && sp.id && !seenDm.has(sp.id) && !delSetDm.has(sp.id)) {
                  state.dateStamps.customSpots.unshift(sp);
                  seenDm.add(sp.id);
                  changed = true;
                }
              });
              state.dateStamps.customSpots = (state.dateStamps.customSpots || []).filter(sp => sp && !delSetDm.has(sp.id));
            }
            if (inc.dateStamps.stamps && typeof inc.dateStamps.stamps === 'object') {
              if (!state.dateStamps.stamps) state.dateStamps.stamps = {};
              for (const [sid, stObj] of Object.entries(inc.dateStamps.stamps)) {
                const curSt = state.dateStamps.stamps[sid];
                if (!curSt || Number(stObj?.updatedAt || 0) > Number(curSt?.updatedAt || 0)) {
                  state.dateStamps.stamps[sid] = { ...stObj };
                  changed = true;
                }
              }
            }
          }
          if (changed) {
            saveState(false);
            const actTab = document.querySelector('.tab-panel.active')?.id?.replace('tab-', '') || 'home';
            window.__cwDirtyTabs = window.__cwDirtyTabs || new Set();
            ['home', 'translator', 'diary', 'learn', 'anniversary'].forEach(t => { if (t !== actTab) window.__cwDirtyTabs.add(t); });
            if (actTab === 'home') renderHome();
            else if (actTab === 'translator') {
              if (chatChanged) renderChat();
              else updateChatDeliveryBadgesInPlace();
              renderTransHistory();
            }