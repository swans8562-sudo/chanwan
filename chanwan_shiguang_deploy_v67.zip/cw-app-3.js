            if (typeof window.__pushMediaSyncPacket === 'function') {
              window.__pushMediaSyncPacket('avatar', { target: activeAvatarTarget }, url, `avatar_${activeAvatarTarget}.jpg`);
            }
            showToast(state.lang === 'zh' ? '头像已保存并同步 ✨' : '프로필 사진이 저장되고 상대방에게도 동기화됐어요 ✨');
          } catch (_) { showToast(state.lang === 'zh' ? '图片处理时发生错误' : '이미지 처리 중 오류가 발생했습니다.'); }
          avatarInput.value = '';
        });

        // Home Quick Translator
        const runHomeTrans = async () => {
          const input = document.getElementById('homeTransInput').value.trim();
          if (!input) { showToast(state.lang === 'zh' ? '请输入要翻译的句子' : '번역할 문장을 입력해 주세요.'); return; }
          const out = document.getElementById('homeTransResult');
          out.classList.remove('hidden');
          out.innerHTML = `<div class="text-xs text-gold py-2">✨ 신경망 + 제미나이 초정밀 번역 분석 중...</div>`;
          const res = await geminiTranslate(input);
          out.innerHTML = renderNuanceCardHtml(res); if (typeof window.syncAllTabIconsToStyle === 'function') window.syncAllTabIconsToStyle(localStorage.getItem('chanwan_icon_style_v1') || 'pastel');
          if (res) {
            state.transHistory.unshift({ id: `tr_${Date.now()}`, author: state.myRole || 'suwan', time: new Date().toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' }), original: res.original, translated: res.translated, nuance: res.nuance, tgtLang: res.tgtLang, accuracy: res.accuracy || 92, engine: res.engine || '' });
            if (state.transHistory.length > 20) state.transHistory = state.transHistory.slice(0, 20);
            saveState(); renderTransHistory();
          }
        };
        document.getElementById('homeTransInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') runHomeTrans(); });

        let homeLiveTimer = null, homeLiveSeq = 0;
        const scheduleHomeLiveTrans = (e) => {
          if (e && e.isComposing) return;
          const inpEl = document.getElementById('homeTransInput');
          const val = (inpEl ? inpEl.value : '').trim();
          const out = document.getElementById('homeTransResult');
          clearTimeout(homeLiveTimer);
          if (!val) { homeLiveSeq++; out.dataset.cwLoading = '0'; out.classList.add('hidden'); return; }
          const seq = ++homeLiveSeq;
          out.classList.remove('hidden');
          if (out.dataset.cwLoading !== '1') {
            out.dataset.cwLoading = '1';
            out.innerHTML = `<div class="text-xs text-gold py-1.5">⚡ ${state.lang === 'zh' ? '正在实时翻译...' : '입력하는 대로 실시간 번역 중...'}</div>`;
          }
          homeLiveTimer = setTimeout(async () => {
            const res = await geminiTranslate(val, 'lover');
            if (seq !== homeLiveSeq) return;
            out.dataset.cwLoading = '0';
            if (res) {
              out.innerHTML = renderNuanceCardHtml(res);
              if (typeof window.syncAllTabIconsToStyle === 'function') window.syncAllTabIconsToStyle(localStorage.getItem('chanwan_icon_style_v1') || 'pastel', out);
            }
          }, 520);
        };
        document.getElementById('homeTransInput').addEventListener('input', scheduleHomeLiveTrans);
        document.getElementById('homeTransInput').addEventListener('compositionend', scheduleHomeLiveTrans);

        // Tab 4: 번역·메신저 (Tone Modes + Real-Time Live Studio + Messenger)
        document.querySelectorAll('.trans-subtab').forEach(btn => btn.addEventListener('click', () => switchTransSubtab(btn.getAttribute('data-subtab'))));

        let studioLiveTimer = null, studioLiveSeq = 0;
        function triggerStudioLiveTranslate(saveHist) {
          const val = document.getElementById('studioTransInput').value.trim();
          const out = document.getElementById('studioTransOutput');
          clearTimeout(studioLiveTimer);
          if (!val) { studioLiveSeq++; out.dataset.cwLoading = '0'; out.classList.add('hidden'); return; }
          const seq = ++studioLiveSeq;
          out.classList.remove('hidden');
          if (out.dataset.cwLoading !== '1') {
            out.dataset.cwLoading = '1';
            out.innerHTML = `<div class="text-xs text-gold py-2">⚡ ${state.lang === 'zh' ? '正在实时自动翻译...' : '작성하는 즉시 실시간 번역 중...'}</div>`;
          }
          studioLiveTimer = setTimeout(async () => {
            const res = await geminiTranslate(val, activeToneMode);
            if (seq !== studioLiveSeq) return;
            out.dataset.cwLoading = '0';
            out.innerHTML = renderNuanceCardHtml(res); if (typeof window.syncAllTabIconsToStyle === 'function') window.syncAllTabIconsToStyle(localStorage.getItem('chanwan_icon_style_v1') || 'pastel', out);
            if (res && res.original && res.original.length >= 2) {
              const last = state.transHistory[0];
              if (!last || last.original !== res.original) {
                state.transHistory.unshift({ id: `tr_${Date.now()}`, author: state.myRole || 'suwan', time: new Date().toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' }), original: res.original, translated: res.translated, nuance: res.nuance, tgtLang: res.tgtLang, accuracy: res.accuracy || 92, engine: res.engine || '' });
                if (state.transHistory.length > 20) state.transHistory = state.transHistory.slice(0, 20);
                saveState(); renderTransHistory();
              }
            }
          }, saveHist ? 0 : 420);
        }

        function syncToneButtonsUi(tone) {
          activeToneMode = tone || 'lover';
          if (state && state.chat) state.chat.toneMode = activeToneMode;
          document.querySelectorAll('.tone-mode-btn').forEach(b => {
            const isAct = b.getAttribute('data-tone') === activeToneMode;
            const inChatBar = !!b.closest('#chatToneBar');
            b.className = inChatBar ? `tone-mode-btn ${isAct ? 'btn-gold' : 'btn-ghost'} px-1 py-1 rounded-full text-[9.5px] font-semibold whitespace-nowrap text-center truncate` : `tone-mode-btn ${isAct ? 'btn-gold' : 'btn-ghost'} px-2.5 py-1 rounded-full text-[11px] font-semibold whitespace-nowrap shrink-0`;
          });
        }
        window.__syncToneButtonsUi = syncToneButtonsUi;
        window.__cwBridge = { getState: () => state, showToast: (m) => showToast(m), saveState: (s) => saveState(s), speakText: (t, l, sl) => speakText(t, l, sl) };
        document.querySelectorAll('.tone-mode-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            const t = btn.getAttribute('data-tone') || 'lover';
            syncToneButtonsUi(t);
            saveState(false);
            if (document.getElementById('studioTransInput') && document.getElementById('studioTransInput').value.trim()) triggerStudioLiveTranslate(false);
          });
        });

        const onStudioInputChanged = (e) => {
          if (e && e.isComposing) return;
          const inpEl = document.getElementById('studioTransInput');
          const v = (inpEl ? inpEl.value : '').trim();
          const el = document.getElementById('studioTransDetected');
          if (!v) {
            el.textContent = state.lang === 'zh' ? '等待自动识别语言（输入即实时翻译）' : '입력하면 버튼 없이 바로 실시간 번역돼요';
            clearTimeout(studioLiveTimer); studioLiveSeq++;
            const outEl = document.getElementById('studioTransOutput');
            if (outEl) { outEl.dataset.cwLoading = '0'; outEl.classList.add('hidden'); }
            return;
          }
          const nextLbl = state.lang === 'zh'
            ? (detectLanguage(v) === 'ko' ? '🇰🇷 识别到韩语 → 🇨🇳 实时自动翻译中' : '🇨🇳 识别到中文 → 🇰🇷 实时自动翻译中')
            : (detectLanguage(v) === 'ko' ? '🇰🇷 한국어 감지 → 🇨🇳 실시간 자동 번역 중' : '🇨🇳 중국어 감지 → 🇰🇷 실시간 자동 번역 중');
          if (el.textContent !== nextLbl) el.textContent = nextLbl;
          triggerStudioLiveTranslate(false);
        };
        document.getElementById('studioTransInput').addEventListener('input', onStudioInputChanged);
        document.getElementById('studioTransInput').addEventListener('compositionend', onStudioInputChanged);
        // ==================== v8.7 REAL-TIME VOICE RECOGNITION (KO & ZH SPEECH-TO-TEXT) ====================
        const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition || null;
        let activeRecognition = null;
        let activeMicBtnId = null;

        function stopVoiceRecognition() {
          if (activeRecognition) {
            try { activeRecognition.stop(); } catch (_) {}
            activeRecognition = null;
          }
          if (activeMicBtnId) {
            const prevBtn = document.getElementById(activeMicBtnId);
            if (prevBtn) {
              prevBtn.classList.remove('btn-royal', 'badge-pulse', 'cw-stt-active');
              if (activeMicBtnId !== 'chatMicBtn') prevBtn.classList.add('btn-ghost');
              if (activeMicBtnId === 'homeMicBtn' || activeMicBtnId === 'chatMicBtn') {
                prevBtn.innerHTML = '<span class="cw-ico-slot inline-flex items-center justify-center" data-ico="mic"></span>';
                if (typeof window.__refreshIconSlots === 'function') window.__refreshIconSlots(prevBtn);
                else if (typeof window.syncAllTabIconsToStyle === 'function') window.syncAllTabIconsToStyle(null, prevBtn);
              }
              else if (activeMicBtnId === 'studioMicKoBtn') prevBtn.textContent = I18N[state.lang].micKoBtn;
              else if (activeMicBtnId === 'studioMicZhBtn') prevBtn.textContent = I18N[state.lang].micZhBtn;
            }
            activeMicBtnId = null;
          }
        }

        function startVoiceInput(btnId, recLang, targetInputId) {
          if (activeMicBtnId === btnId) { stopVoiceRecognition(); return; }
          stopVoiceRecognition();
          if (!SpeechRec) {
            showToast(state.lang === 'zh' ? '当前浏览器不支持语音识别，请使用 Chrome 或 Safari 🎤' : '이 브라우저에서는 음성 인식을 지원하지 않아요. Chrome·Safari에서 사용해 주세요 🎤');
            return;
          }
          try {
            const rec = new SpeechRec();
            rec.lang = recLang;
            rec.interimResults = true;
            rec.continuous = false;
            speechPracticeRec = rec;
            activeMicBtnId = btnId;
            const btn = document.getElementById(btnId);
            if (btn) {
              btn.classList.remove('btn-ghost');
              btn.classList.add('cw-stt-active');
              if (btnId === 'homeMicBtn' || btnId === 'chatMicBtn') {
                btn.innerHTML = CW_MEDIA_SVG.stopSttBtn;
              } else {
                const waveMiniBars = '<svg viewBox="0 0 18 16" width="13" height="13" fill="none"><line class="cw-wave-bar" x1="3" y1="4" x2="3" y2="12" stroke="#ffffff" stroke-width="2.1" stroke-linecap="round"/><line class="cw-wave-bar b2" x1="8.5" y1="2" x2="8.5" y2="14" stroke="#ffffff" stroke-width="2.1" stroke-linecap="round"/><line class="cw-wave-bar b3" x1="14" y1="4" x2="14" y2="12" stroke="#ffffff" stroke-width="2.1" stroke-linecap="round"/></svg>';
                btn.innerHTML = `<span class="inline-flex items-center gap-1.5">${CW_MEDIA_SVG.stopBadge}${waveMiniBars}<span>${state.lang === 'zh' ? '聆听中 · 停止' : '듣는 중 · 중지'}</span></span>`;
              }
            }
            const inp = document.getElementById(targetInputId);
            rec.onresult = (event) => {
              let transcript = '';
              for (let i = 0; i < event.results.length; i++) {
                transcript += event.results[i][0].transcript;
              }
              if (inp && transcript.trim()) {
                inp.value = transcript.trim();
                inp.dispatchEvent(new Event('input'));
              }
            };
            rec.onerror = (ev) => {
              const code = ev && ev.error;
              if (code === 'not-allowed' || code === 'service-not-allowed') {
                if (typeof window.__openCwMicPermModal === 'function') window.__openCwMicPermModal();
                else showToast(state.lang === 'zh' ? '请允许麦克风权限以使用语音翻译 🎤' : '마이크 권한을 허용해 주시면 음성 번역이 작동해요 🎤');
              } else if (code !== 'no-speech' && code !== 'aborted') {
                showToast(state.lang === 'zh' ? '语音识别暂时中断，请再试一次' : '음성 인식이 잠시 중단됐어요. 다시 눌러 말씀해 주세요.');
              }
              stopVoiceRecognition();
            };
            rec.onend = () => stopVoiceRecognition();
            rec.start();
          } catch (_) {
            stopVoiceRecognition();
            showToast(state.lang === 'zh' ? '无法启动麦克风，请检查浏览器权限' : '마이크를 시작할 수 없어요. 브라우저 권한을 확인해 주세요.');
          }
        }

        const chatMicBtnEl = document.getElementById('chatMicBtn');
        if (chatMicBtnEl) {
          chatMicBtnEl.addEventListener('click', () => {
            const recLang = (state.myRole === 'jingchan' || state.lang === 'zh') ? 'zh-CN' : 'ko-KR';
            startVoiceInput('chatMicBtn', recLang, 'chatInput');
          });
        }
        const homeMicBtnEl = document.getElementById('homeMicBtn');
        if (homeMicBtnEl) {
          homeMicBtnEl.addEventListener('click', () => startVoiceInput('homeMicBtn', state.lang === 'zh' ? 'zh-CN' : 'ko-KR', 'homeTransInput'));
        }
        const studioMicKoEl = document.getElementById('studioMicKoBtn');
        if (studioMicKoEl) {
          studioMicKoEl.addEventListener('click', () => startVoiceInput('studioMicKoBtn', 'ko-KR', 'studioTransInput'));
        }
        const studioMicZhEl = document.getElementById('studioMicZhBtn');
        if (studioMicZhEl) {
          studioMicZhEl.addEventListener('click', () => startVoiceInput('studioMicZhBtn', 'zh-CN', 'studioTransInput'));
        }

        document.getElementById('studioTransClearBtn').addEventListener('click', () => {
          document.getElementById('studioTransInput').value = '';
          document.getElementById('studioTransOutput').classList.add('hidden');
          document.getElementById('studioTransDetected').textContent = '언어 자동 감지 대기 중';
        });

        document.getElementById('clearTransHistBtn').addEventListener('click', () => {
          state.transHistory = []; saveState(); renderTransHistory(); showToast(state.lang === 'zh' ? '已清空翻译记录' : '번역 기록을 비웠습니다.');
        });

        document.getElementById('senderSuwanBtn').addEventListener('click', () => applyMyRole('suwan', false));
        document.getElementById('senderJingchanBtn').addEventListener('click', () => applyMyRole('jingchan', false));
        document.querySelectorAll('.chat-quick-chip').forEach(chip => {
          chip.addEventListener('click', () => {
            const inp = document.getElementById('chatInput');
            if (!inp) return;
            inp.value = chip.getAttribute(state.lang === 'zh' ? 'data-zh' : 'data-ko') || chip.textContent;
            document.getElementById('chatForm').dispatchEvent(new Event('submit', { cancelable: true }));
          });
        });
        let pendingChatPhotoUrl = '', pendingChatMediaType = '', pendingChatPhotos = [];
        const chatPhotoInputEl = document.getElementById('chatPhotoInput');
        const chatPhotoBtnEl = document.getElementById('chatPhotoBtn');
        const chatPhotoBarEl = document.getElementById('chatPhotoPreviewBar');
        const chatPhotoImgEl = document.getElementById('chatPhotoPreviewImg');
        const chatVideoPrevEl = document.getElementById('chatVideoPreviewEl');
        const chatMediaReadyEl = document.getElementById('chatMediaReadyLabel');
        const chatPhotoCatEl = document.getElementById('chatPhotoCatPreview');
        const chatPhotoClearEl = document.getElementById('chatPhotoClearBtn');

        function clearPendingChatPhoto() {
          pendingChatPhotoUrl = '';
          pendingChatMediaType = '';
          pendingChatPhotos = [];
          if (chatPhotoInputEl) chatPhotoInputEl.value = '';
          const camIn = document.getElementById('chatCameraInput');
          const vidIn = document.getElementById('chatVideoCamInput');
          if (camIn) camIn.value = '';
          if (vidIn) vidIn.value = '';
          if (chatPhotoBarEl) chatPhotoBarEl.classList.add('hidden');
          const strip = document.getElementById('chatMultiThumbStrip');
          if (strip) {
            strip.querySelectorAll('.extra-thumb').forEach(el => el.remove());
          }
          if (chatPhotoImgEl) { chatPhotoImgEl.src = ''; chatPhotoImgEl.classList.remove('hidden'); }
          if (chatVideoPrevEl) { chatVideoPrevEl.src = ''; chatVideoPrevEl.classList.add('hidden'); }
          const sBtn = document.getElementById('chatSendBtn');
          if (sBtn) {
            sBtn.disabled = false;
            sBtn.textContent = state.lang === 'zh' ? '发送' : '전송';
          }
          if (typeof window.__syncWechatSendButton === 'function') window.__syncWechatSendButton();
        }
        const chatCameraBtnEl = document.getElementById('chatCameraBtn');
        const chatCameraInputEl = document.getElementById('chatCameraInput');
        const chatVideoCamBtnEl = document.getElementById('chatVideoCamBtn');
        const chatVideoCamInputEl = document.getElementById('chatVideoCamInput');
        async function handleCameraCaptureFile(inputEl, forceVideo) {
          const f = inputEl && inputEl.files && inputEl.files[0];
          if (!f) return;
          const plusDrawerEl = document.getElementById('chatPlusDrawer');
          if (plusDrawerEl) plusDrawerEl.classList.add('hidden');
          const isVideo = forceVideo || String(f.type || '').startsWith('video/') || /\.(mp4|mov|webm|m4v|3gp|mkv)$/i.test(f.name || '');
          if (isVideo) {
            // Unlimited video size allowed (chunked parallel transfer)
            try {
              pendingChatPhotoUrl = await (typeof window.__prepareVideoDataUrl === 'function'
                ? window.__prepareVideoDataUrl(f)
                : new Promise((resolve, reject) => {
                    const r = new FileReader();
                    r.onload = () => resolve(String(r.result || ''));
                    r.onerror = reject;
                    r.readAsDataURL(f);
                  }));
              pendingChatMediaType = 'video';
              if (chatPhotoImgEl) chatPhotoImgEl.classList.add('hidden');
              if (chatVideoPrevEl) { chatVideoPrevEl.src = pendingChatPhotoUrl; chatVideoPrevEl.classList.remove('hidden'); }
              if (chatMediaReadyEl) chatMediaReadyEl.textContent = state.lang === 'zh' ? '🎬 视频拍摄完成 · 将自动存入相册' : '🎬 동영상 촬영 완료 · 앨범 자동 저장';
              const curTxt = (document.getElementById('chatInput')?.value || '').trim();
              if (chatPhotoCatEl) chatPhotoCatEl.textContent = detectPhotoCategory(curTxt);
              if (chatPhotoBarEl) chatPhotoBarEl.classList.remove('hidden'); if (window.__syncWechatSendButton) window.__syncWechatSendButton();
            } catch (_) {
              showToast(state.lang === 'zh' ? '视频读取失败，请重试' : '촬영한 동영상을 불러오지 못했어요. 다시 시도해 주세요.');
            }
            inputEl.value = '';
            return;
          }
          try {
            pendingChatPhotoUrl = await compressImageToDataUrl(f, 720);
            pendingChatMediaType = 'image';
            if (chatVideoPrevEl) chatVideoPrevEl.classList.add('hidden');
            if (chatPhotoImgEl) { chatPhotoImgEl.src = pendingChatPhotoUrl; chatPhotoImgEl.classList.remove('hidden'); }
            if (chatMediaReadyEl) chatMediaReadyEl.textContent = state.lang === 'zh' ? '📸 拍照完成 · 将自动存入相册并发送' : '📸 촬영 완료 · 앨범 자동 저장 & 실시간 전송';
            const curTxt = (document.getElementById('chatInput')?.value || '').trim();
            if (chatPhotoCatEl) chatPhotoCatEl.textContent = detectPhotoCategory(curTxt);
            if (chatPhotoBarEl) chatPhotoBarEl.classList.remove('hidden'); if (window.__syncWechatSendButton) window.__syncWechatSendButton();
          } catch (_) {
            showToast(state.lang === 'zh' ? '拍照读取失败，请重试' : '촬영한 사진을 불러오지 못했어요. 다시 시도해 주세요.');
          }
          inputEl.value = '';
        }
        if (chatCameraBtnEl && chatCameraInputEl) {
          chatCameraBtnEl.addEventListener('click', () => chatCameraInputEl.click());
          chatCameraInputEl.addEventListener('change', () => handleCameraCaptureFile(chatCameraInputEl, false));
        }
        if (chatVideoCamBtnEl && chatVideoCamInputEl) {
          chatVideoCamBtnEl.addEventListener('click', () => chatVideoCamInputEl.click());
          chatVideoCamInputEl.addEventListener('change', () => handleCameraCaptureFile(chatVideoCamInputEl, true));
        }
        if (chatPhotoBtnEl && chatPhotoInputEl) {
          chatPhotoBtnEl.addEventListener('click', () => chatPhotoInputEl.click());
          chatPhotoInputEl.addEventListener('change', async () => {
            const files = Array.from(chatPhotoInputEl.files || []).slice(0, 9);
            if (!files.length) return;
            const showImmediateLoadingBar = (labelKo, labelZh) => {
              try {
                if (chatMediaReadyEl) chatMediaReadyEl.textContent = state.lang === 'zh' ? labelZh : labelKo;
                if (chatPhotoBarEl) chatPhotoBarEl.classList.remove('hidden');
              } catch (_) {}
            };
            if (files.length > 1) {
              showImmediateLoadingBar(`⏳ 사진 ${files.length}장 빠르게 불러오는 중...`, `⏳ 正在快速读取 ${files.length} 张照片...`);
              try {
                const imgFiles = files.filter(fItem => !String(fItem.type || '').startsWith('video/'));
                const loadedList = await Promise.all(imgFiles.map(async (fItem) => {
                  try {
                    const isG = String(fItem.type || '').toLowerCase() === 'image/gif' || /\.gif$/i.test(fItem.name || '');
                    const dUrl = isG
                      ? await new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result || '')); r.onerror = rej; r.readAsDataURL(fItem); })
                      : await compressImageToDataUrl(fItem, 640);
                    return dUrl ? { url: dUrl, type: 'image', name: fItem.name || '' } : null;
                  } catch (_) { return null; }
                }));
                pendingChatPhotos = loadedList.filter(Boolean);
                if (!pendingChatPhotos.length) return;
                pendingChatPhotoUrl = pendingChatPhotos[0].url;
                pendingChatMediaType = 'image';
                if (chatVideoPrevEl) chatVideoPrevEl.classList.add('hidden');
                if (chatPhotoImgEl) { chatPhotoImgEl.src = pendingChatPhotos[0].url; chatPhotoImgEl.classList.remove('hidden'); }
                const strip = document.getElementById('chatMultiThumbStrip');
                if (strip) {
                  strip.querySelectorAll('.extra-thumb').forEach(el => el.remove());
                  pendingChatPhotos.slice(1, 5).forEach(p => {
                    const img = document.createElement('img');
                    img.src = p.url;
                    img.className = 'extra-thumb w-11 h-11 rounded-xl object-cover shrink-0 border';
                    img.style.borderColor = 'var(--border-accent)';
                    strip.appendChild(img);
                  });
                }
                if (chatMediaReadyEl) chatMediaReadyEl.textContent = state.lang === 'zh'
                  ? `📷 已选 ${pendingChatPhotos.length} 张照片 · 打包发送并存入相册`
                  : `📷 사진 ${pendingChatPhotos.length}장 선택됨 · 묶어서 전송 & 앨범 자동 저장`;
                const curTxt = (document.getElementById('chatInput')?.value || '').trim();
                if (chatPhotoCatEl) chatPhotoCatEl.textContent = detectPhotoCategory(curTxt, pendingChatPhotos[0].name);
                if (chatPhotoBarEl) chatPhotoBarEl.classList.remove('hidden');
                if (window.__syncWechatSendButton) window.__syncWechatSendButton();
              } catch (_) {
                showToast(state.lang === 'zh' ? '批量图片读取失败，请重试' : '여러 장 사진을 불러오지 못했어요. 다시 시도해 주세요.');
              }
              chatPhotoInputEl.value = '';
              return;
            }
            const f = files[0];
            const isVideo = String(f.type || '').startsWith('video/') || /\.(mp4|mov|webm|m4v|3gp|mkv)$/i.test(f.name || '');
            if (isVideo) {
              showImmediateLoadingBar('⏳ 동영상 불러오는 중...', '⏳ 正在读取视频...');
              // Unlimited video size allowed (chunked parallel transfer)
              try {
                pendingChatPhotoUrl = await (typeof window.__prepareVideoDataUrl === 'function'
                  ? window.__prepareVideoDataUrl(f)
                  : new Promise((resolve, reject) => {
                      const r = new FileReader();
                      r.onload = () => resolve(String(r.result || ''));
                      r.onerror = reject;
                      r.readAsDataURL(f);
                    }));
                pendingChatMediaType = 'video';
                if (chatPhotoImgEl) chatPhotoImgEl.classList.add('hidden');
                if (chatVideoPrevEl) { chatVideoPrevEl.src = pendingChatPhotoUrl; chatVideoPrevEl.classList.remove('hidden'); }
                if (chatMediaReadyEl) chatMediaReadyEl.textContent = state.lang === 'zh' ? '🎬 已选视频 · 自动优化并跨网同步' : '🎬 동영상 첨부됨 · 자동 최적화 & 상대방 전송';
                const curTxt = (document.getElementById('chatInput')?.value || '').trim();
                if (chatPhotoCatEl) chatPhotoCatEl.textContent = detectPhotoCategory(curTxt);
                if (chatPhotoBarEl) chatPhotoBarEl.classList.remove('hidden'); if (window.__syncWechatSendButton) window.__syncWechatSendButton();
              } catch (_) {
                showToast(state.lang === 'zh' ? '视频读取失败，请重试' : '동영상을 불러오지 못했어요. 다시 선택해 주세요.');
              }
              chatPhotoInputEl.value = '';
              return;
            }
            showImmediateLoadingBar('⏳ 사진 불러오는 중...', '⏳ 正在读取照片...');
            try {
              const isGif = String(f.type || '').toLowerCase() === 'image/gif' || /\.gif$/i.test(f.name || '');
              if (isGif) {
                if (f.size > 4 * 1024 * 1024) {
                  showToast(state.lang === 'zh' ? '请选择 4MB 以内的动图 (GIF) 🎞️' : '4MB 이하의 움짤(GIF)을 선택해 주세요 🎞️');
                  chatPhotoInputEl.value = '';
                  return;
                }
                pendingChatPhotoUrl = await new Promise((resolve, reject) => {
                  const r = new FileReader();
                  r.onload = () => resolve(String(r.result || ''));
                  r.onerror = reject;
                  r.readAsDataURL(f);
                });
              } else {
                pendingChatPhotoUrl = await compressImageToDataUrl(f, 720);
              }
              pendingChatMediaType = 'image';
              if (chatVideoPrevEl) chatVideoPrevEl.classList.add('hidden');
              if (chatPhotoImgEl) { chatPhotoImgEl.src = pendingChatPhotoUrl; chatPhotoImgEl.classList.remove('hidden'); }
              if (chatMediaReadyEl) chatMediaReadyEl.textContent = isGif
                ? (state.lang === 'zh' ? '🎞️ 动图 (GIF) 已就绪 · 原画动画发送' : '🎞️ 움짤(GIF) 첨부됨 · 애니메이션 그대로 전송')
                : (state.lang === 'zh' ? '📷 已选照片 · 将自动分类存入相册' : '📷 사진 첨부됨 · 앨범 자동 분류 저장');
              const curTxt = (document.getElementById('chatInput')?.value || '').trim();
              if (chatPhotoCatEl) chatPhotoCatEl.textContent = detectPhotoCategory(curTxt);
              if (chatPhotoBarEl) chatPhotoBarEl.classList.remove('hidden'); if (window.__syncWechatSendButton) window.__syncWechatSendButton();
            } catch (_) {
              showToast(state.lang === 'zh' ? '图片读取失败，请重试' : '사진을 불러오지 못했어요. 다시 선택해 주세요.');
            }
            chatPhotoInputEl.value = '';
          });
        }
        if (chatPhotoClearEl) chatPhotoClearEl.addEventListener('click', clearPendingChatPhoto);
        document.getElementById('chatInput').addEventListener('input', (e) => {
          if (pendingChatPhotoUrl && chatPhotoCatEl) {
            chatPhotoCatEl.textContent = detectPhotoCategory(e.target.value);
          }
        });

        document.getElementById('addAlbumFolderBtn')?.addEventListener('click', () => {
          const inp = document.getElementById('newAlbumFolderInput');
          const raw = inp ? inp.value.trim() : '';
          if (!raw) return;
          const folderName = /^[^a-zA-Z0-9가-힣一-鿿]/.test(raw) ? raw : `📁 ${raw}`;
          ensureEditableAlbumFolders();
          if (!state.albumFolders.includes(folderName)) {
            state.albumFolders.push(folderName);
            state.albumFoldersUpdatedAt = Date.now();
            saveState(true);
            renderBucketAndAlbum();
            showToast(state.lang === 'zh' ? `📁 已创建文件夹「${folderName}」` : `📁 「${folderName}」 폴더를 만들었어요!`);
          }
          if (inp) inp.value = '';
        });
        document.querySelectorAll('.album-cat-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            window.__activeAlbumCat = btn.getAttribute('data-cat') || 'all';
            document.querySelectorAll('.album-cat-btn').forEach(b => {
              b.className = `album-cat-btn ${b === btn ? 'btn-royal' : 'btn-ghost'} px-3 py-1 rounded-full text-[11px] font-semibold whitespace-nowrap`;
            });
            renderBucketAndAlbum();
          });
        });

        const chatInputTa = document.getElementById('chatInput');
        if (chatInputTa) {
          chatInputTa.addEventListener('keydown', (ev) => {
            if (ev.key === 'Enter' && !ev.shiftKey && !ev.isComposing) {
              ev.preventDefault();
              document.getElementById('chatForm').dispatchEvent(new Event('submit', { cancelable: true }));
            }
          });
        }
        document.getElementById('chatForm').addEventListener('submit', async (e) => {
          e.preventDefault();
          const inputEl = document.getElementById('chatInput');
          let text = inputEl.value.trim();
          const batchPhotos = Array.isArray(pendingChatPhotos) && pendingChatPhotos.length > 1 ? pendingChatPhotos.slice() : [];
          const mediaData = pendingChatPhotoUrl;
          const mediaType = pendingChatMediaType || 'image';
          const isVid = !!mediaData && mediaType === 'video' && !batchPhotos.length;
          if (!text && !mediaData && !batchPhotos.length) return;
          if (!text && batchPhotos.length) text = state.lang === 'zh' ? `分享了 ${batchPhotos.length} 张照片 📷` : `사진 ${batchPhotos.length}장을 보냈어요 📷`;
          else if (!text && mediaData) text = isVid ? (state.lang === 'zh' ? '分享了一段视频 🎬' : '동영상을 보냈어요 🎬') : (state.lang === 'zh' ? '分享了一张照片 📷' : '사진을 보냈어요 📷');
          const __wasInputFocusedBeforeSend = (document.activeElement === inputEl);
          window.__cwLastChatSendTs = Date.now();
          window.__cwChatCursorPos = 0;
          inputEl.value = '';
          if (__wasInputFocusedBeforeSend) {
            try { inputEl.focus({ preventScroll: true }); } catch (_) { try { inputEl.focus(); } catch (__) {} }
          }
          if (window.__cwWasTyping) {
            window.__cwWasTyping = false;
            if (typeof window.__sendChatSignal === 'function') window.__sendChatSignal('typing', { active: false });
          }
          clearPendingChatPhoto(); document.getElementById('chatStickerTray')?.classList.add('hidden'); document.getElementById('chatPlusDrawer')?.classList.add('hidden'); if (window.__syncWechatSendButton) window.__syncWechatSendButton();
          const isPureUrl = /^https?:\/\/\S+$/i.test(text);
          const isEmojiOnly = (typeof window.isPureWechatEmoticonMsg === 'function' && window.isPureWechatEmoticonMsg(text)) || (!/[a-zA-Z0-9가-힣ㄱ-ㅎㅏ-ㅣ\u4e00-\u9fff]/.test(text) && text.length > 0);
          const needsAsyncTrans = !isPureUrl && !isEmojiOnly;
          const __cachedQuick = (needsAsyncTrans && typeof __getTransCache === 'function') ? (__getTransCache()[`${activeToneMode || 'lover'}|${text}`] || null) : null;
          const initRes = isPureUrl
            ? { original: text, translated: state.lang === 'zh' ? '🎬 分享了一个视频/网页链接' : '🎬 동영상·링크를 공유했어요', pronunciation: '', tone: '🎬 링크 공유', nuance: '', engine: '링크 직통', tgtLang: state.lang === 'zh' ? 'ko' : 'zh', accuracy: 100 }
            : (__cachedQuick && __cachedQuick.translated
                ? __cachedQuick
                : { original: text, translated: needsAsyncTrans ? (state.lang === 'zh' ? '⏳ 正在翻译...' : '⏳ 번역 중...') : '', pronunciation: '', tone: '', nuance: '', engine: '', tgtLang: state.lang === 'zh' ? 'ko' : 'zh', accuracy: 0 });
          const _myChatRole = state.myRole || state.chat.activeSender || 'suwan';
          const senderName = _myChatRole === 'suwan' ? '수완(完)' : '靖灿(灿)';
          const autoPhotoCat = mediaData ? detectPhotoCategory(text) : '';
          const nowEpoch = Date.now();
          const newMsgId = `msg_${nowEpoch}_${Math.random().toString(36).slice(2, 5)}`;
          const newAlbId = `alb_${nowEpoch}`;
          const msgTimeStr = new Date().toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' });
          const newMsgObj = {
            id: newMsgId, ts: nowEpoch, sender: _myChatRole, deliveryStatus: 'sending',
            time: msgTimeStr,
            original: text, translated: initRes.translated, altTranslated: '', pronunciation: initRes.pronunciation,
            tone: initRes.tone, nuance: initRes.nuance, engine: initRes.engine, tgtLang: initRes.tgtLang,
            accuracy: Number(initRes.accuracy) || 0,
            photoUrl: (!isVid && !batchPhotos.length) ? (mediaData || '') : '',
            photoUrls: batchPhotos.length ? batchPhotos.map(p => p.url) : undefined,
            videoUrl: isVid ? (mediaData || '') : '',
            photoCat: autoPhotoCat,
            replyTo: window.__pendingChatReply ? { ...window.__pendingChatReply } : null,
            reactions: []
          };
          // 0ms Optimistic Instant Send: display bubble & push to EMQX/ntfy IMMEDIATELY without blocking on translation!
          state.chat.messages.push(newMsgObj);
          const __who = _myChatRole === 'jingchan' ? '靖灿' : '수완';
          const __pushFallbackBody = text || (mediaData ? (isVid ? '🎬 동영상을 보냈어요' : '📷 사진을 보냈어요') : '새 메시지가 도착했어요');
          let __nativePushSent = false;
          let __nativePushWasFallback = false;
          const __pushSentAtMs = Date.now();
          const __fireTranslatedPushOnce = (pushBody, isFallback = false) => {
            if (__nativePushSent) {
              if (__nativePushWasFallback && !isFallback && pushBody && pushBody !== __pushFallbackBody && (Date.now() - __pushSentAtMs) < 8000) {
                __nativePushWasFallback = false;
                try { sendPartnerNativePush(`💌 ${__who}님의 새 메시지`, pushBody); } catch (_) {}
              }
              return;
            }
            __nativePushSent = true;
            __nativePushWasFallback = !!isFallback;
            try { sendPartnerNativePush(`💌 ${__who}님의 새 메시지`, pushBody || __pushFallbackBody); } catch (_) {}
          };
          if (!needsAsyncTrans) {
            __fireTranslatedPushOnce(__pushFallbackBody, false);
          } else if (__cachedQuick && __cachedQuick.translated) {
            __fireTranslatedPushOnce(__cachedQuick.translated, false);
          } else {
            setTimeout(() => __fireTranslatedPushOnce(__pushFallbackBody, true), 5200);
          }
          window.__pendingChatReply = null;
          document.getElementById('chatReplyBar')?.classList.add('hidden');
          if (batchPhotos.length) {
            if (!Array.isArray(state.albums)) state.albums = [];
            batchPhotos.forEach((bp, bIdx) => {
              const bCat = detectPhotoCategory(text, bp.name);
              const bAlbId = `${newAlbId}_${bIdx}`;
              state.albums.unshift({
                id: bAlbId, dataUrl: bp.url, mediaType: 'image',
                caption: text, translated: initRes.translated, date: getKstDateString(),
                category: bCat, source: 'messenger'
              });
              if (typeof window.__pushMediaSyncPacket === 'function') {
                setTimeout(() => {
                  window.__pushMediaSyncPacket('chat_photo', {
                    msgId: newMsgId, albumId: bAlbId, batchIdx: bIdx, batchTotal: batchPhotos.length,
                    sender: _myChatRole, time: msgTimeStr,
                    original: text, translated: newMsgObj.translated || '', pronunciation: newMsgObj.pronunciation || '',
                    tone: newMsgObj.tone || '', nuance: newMsgObj.nuance || '', engine: newMsgObj.engine || '', tgtLang: newMsgObj.tgtLang || '',
                    category: bCat, date: getKstDateString()
                  }, bp.url, `photo_${bIdx}.jpg`);
                }, bIdx * 240);
              }
            });
            showToast(state.lang === 'zh' ? `🖼️ ${batchPhotos.length} 张照片已自动分类存入相册` : `🖼️ 사진 ${batchPhotos.length}장이 커플앨범에 자동 분류 저장됐어요!`);
          } else if (mediaData) {
            if (!Array.isArray(state.albums)) state.albums = [];
            state.albums.unshift({
              id: newAlbId, dataUrl: mediaData, mediaType: isVid ? 'video' : 'image',
              caption: text, translated: initRes.translated, date: getKstDateString(),
              category: autoPhotoCat, source: 'messenger'
            });
            if (typeof window.__pushMediaSyncPacket === 'function') {
              window.__pushMediaSyncPacket(isVid ? 'chat_video' : 'chat_photo', {
                msgId: newMsgId, albumId: newAlbId, sender: _myChatRole, time: msgTimeStr,
                original: text, translated: newMsgObj.translated || '', pronunciation: newMsgObj.pronunciation || '',
                tone: newMsgObj.tone || '', nuance: newMsgObj.nuance || '', engine: newMsgObj.engine || '', tgtLang: newMsgObj.tgtLang || '',
                category: autoPhotoCat, date: getKstDateString()
              }, mediaData, isVid ? 'video.mp4' : 'photo.jpg');
            }
            showToast(isVid
              ? (state.lang === 'zh' ? `🎬 视频已自动分类存入相册 (${autoPhotoCat})` : `🎬 동영상이 커플앨범 「${autoPhotoCat}」에 자동 저장됐어요!`)
              : (state.lang === 'zh' ? `🖼️ 照片已自动分类存入相册 (${autoPhotoCat})` : `🖼️ 사진이 커플앨범 「${autoPhotoCat}」에 자동 저장됐어요!`));
          }
          window.__cwForceScrollBottom = true;
          renderChat();
          if (typeof window.__scrollChatToBottom === 'function') window.__scrollChatToBottom(true);
          saveState(true);
          if (__wasInputFocusedBeforeSend) {
            try { if (inputEl && document.activeElement !== inputEl) inputEl.focus({ preventScroll: true }); } catch (_) {}
          }
          pushNotification(isVid ? '🎬' : (mediaData ? '📷' : '💌'), `${senderName}의 새 ${isVid ? '동영상 메시지' : (mediaData ? '사진 메시지' : '메시지')}`, `${senderName}发来新${isVid ? '视频消息' : (mediaData ? '照片消息' : '消息')}`, text, text, 'translator', 'messenger', 'post', false, _myChatRole);
          // Background non-blocking translation -> updates bubble & syncs silently as soon as ready!
          if (needsAsyncTrans && !(__cachedQuick && __cachedQuick.translated)) {
            (async () => {
              let res = await translateWithAutoRetry(text, activeToneMode || 'lover').catch(() => null);
              if (!res || !res.translated) {
                res = await _coreTranslate(text, activeToneMode || 'lover').catch(() => null);
              }
              if (!res || !res.translated) { __fireTranslatedPushOnce(__pushFallbackBody, true); return; }
              __fireTranslatedPushOnce(res.translated);
              const liveM = (state.chat?.messages || []).find(x => x && x.id === newMsgId);
              if (!liveM) return;
              liveM.translated = res.translated || '';
              liveM.altTranslated = res.altTranslated || '';
              liveM.pronunciation = res.pronunciation || '';
              liveM.tone = res.tone || '';
              liveM.toneZh = res.toneZh || '';
              liveM.nuance = res.nuance || '';
              liveM.nuanceZh = res.nuanceZh || '';
              liveM.engine = res.engine || '';
              liveM.tgtLang = res.tgtLang || (state.lang === 'zh' ? 'ko' : 'zh');
              liveM.accuracy = Number(res.accuracy) || 0;
              saveState(true);
              const trPanel = document.getElementById('tab-translator');
              if (trPanel && trPanel.classList.contains('active')) renderChat();
            })().catch(() => {});
          }
        });
                // WeChat-Style Couple Sticker Pack, Quick Voice Bubble, Typing & Read Signals
        // 96 Iconic WeChat & Couple Emojis (Scrollable Touch Grid!)
        const WECHAT_OFFICIAL_EMOTICONS = [
          { tag: '[捂脸]', ko: '웃픔', zh: '捂脸', k: 'facepalm' },
          { tag: '[旺柴]', ko: '멍뭉눈치', zh: '旺柴', k: 'doge' },
          { tag: '[破涕为笑]', ko: '웃겨울어', zh: '破涕为笑', k: 'joy' },
          { tag: '[呲牙]', ko: '건치미소', zh: '呲牙', k: 'grin' },
          { tag: '[偷笑]', ko: '풉', zh: '偷笑', k: 'snicker' },
          { tag: '[亲亲]', ko: '쪽', zh: '亲亲', k: 'kiss' },
          { tag: '[害羞]', ko: '부끄', zh: '害羞', k: 'shy' },
          { tag: '[愉快]', ko: '신남', zh: '愉快', k: 'happy' },
          { tag: '[奸笑]', ko: '크크', zh: '奸笑', k: 'smirk' },
          { tag: '[机智]', ko: '똑똑', zh: '机智', k: 'smart' },
          { tag: '[吃瓜]', ko: '수박구경', zh: '吃瓜', k: 'melon' },
          { tag: '[让我看看]', ko: '빼꼼', zh: '让我看看', k: 'peek' },
          { tag: '[裂开]', ko: '멘붕', zh: '裂开', k: 'crack' },
          { tag: '[委屈]', ko: '삐짐', zh: '委屈', k: 'pout' },
          { tag: '[可怜]', ko: '초롱', zh: '可怜', k: 'puppy' },
          { tag: '[拥抱]', ko: '포옹', zh: '拥抱', k: 'hug' },
          { tag: '[色]', ko: '하트눈', zh: '色', k: 'hearteyes' },
          { tag: '[微笑]', ko: '미소', zh: '微笑', k: 'smile' },
          { tag: '[调皮]', ko: '메롱', zh: '调皮', k: 'tongue' },
          { tag: '[憨笑]', ko: '헤헤', zh: '憨笑', k: 'chuckle' },
          { tag: '[坏笑]', ko: '음흐흐', zh: '坏笑', k: 'sly' },
          { tag: '[嘿哈]', ko: '예이!', zh: '嘿哈', k: 'heiha' },
          { tag: '[哇]', ko: '우와', zh: '哇', k: 'wow' },
          { tag: '[666]', ko: '666최고', zh: '666', k: '666' },
          { tag: '[加油]', ko: '화이팅', zh: '加油', k: 'cheer' },
          { tag: '[好的]', ko: '오케이', zh: '好的', k: 'ok' },
          { tag: '[耶]', ko: '브이', zh: '耶', k: 'peace' },
          { tag: '[Emm]', ko: '흠...', zh: 'Emm', k: 'emm' },
          { tag: '[天啊]', ko: '세상에', zh: '天啊', k: 'omg' },
          { tag: '[打脸]', ko: '아차', zh: '打脸', k: 'slap' },
          { tag: '[翻白眼]', ko: '흰자', zh: '翻白眼', k: 'eyeroll' },
          { tag: '[叹气]', ko: '한숨', zh: '叹气', k: 'sigh' },
          { tag: '[苦涩]', ko: '씁쓸', zh: '苦涩', k: 'bitter' },
          { tag: '[皱眉]', ko: '찌푸림', zh: '皱眉', k: 'frown' },
          { tag: '[汗]', ko: '삐질', zh: '汗', k: 'sweat' },
          { tag: '[发呆]', ko: '멍...', zh: '发呆', k: 'daze' },
          { tag: '[流泪]', ko: '눈물', zh: '流泪', k: 'tears' },
          { tag: '[大哭]', ko: '엉엉', zh: '大哭', k: 'sob' },
          { tag: '[发怒]', ko: '버럭', zh: '发怒', k: 'angry' },
          { tag: '[惊讶]', ko: '헉!', zh: '惊讶', k: 'shock' },
          { tag: '[困]', ko: '졸려', zh: '困', k: 'sleepy' },
          { tag: '[睡]', ko: '쿨쿨', zh: '睡', k: 'zzz' },
          { tag: '[疑问]', ko: '물음표', zh: '疑问', k: 'question' },
          { tag: '[嘘]', ko: '쉿', zh: '嘘', k: 'shh' },
          { tag: '[晕]', ko: '어질', zh: '晕', k: 'dizzy' },
          { tag: '[再见]', ko: '빠이', zh: '再见', k: 'bye' },
          { tag: '[鼓掌]', ko: '박수', zh: '鼓掌', k: 'clap' },
          { tag: '[哈欠]', ko: '하품', zh: '哈欠', k: 'yawn' },
          { tag: '[玫瑰]', ko: '장미', zh: '玫瑰', k: 'rose' },
          { tag: '[爱心]', ko: '하트', zh: '爱心', k: 'heart' },
          { tag: '[心碎]', ko: '상처', zh: '心碎', k: 'broken' },
          { tag: '[嘴唇]', ko: '뽀뽀', zh: '嘴唇', k: 'lips' },
          { tag: '[猪头]', ko: '꿀꿀', zh: '猪头', k: 'pig' },
          { tag: '[强]', ko: '따봉', zh: '强', k: 'thumb' },
          { tag: '[合十]', ko: '부탁', zh: '合十', k: 'pray' },
          { tag: '[红包]', ko: '홍바오', zh: '红包', k: 'hongbao' }
        ];
        const WECHAT_TAG_MAP = new Map(WECHAT_OFFICIAL_EMOTICONS.map(x => [x.tag, x]));
        WECHAT_TAG_MAP.set('[笑哭]', WECHAT_TAG_MAP.get('[破涕为笑]'));
        WECHAT_TAG_MAP.set('[抱抱]', WECHAT_TAG_MAP.get('[拥抱]'));
        window.__WECHAT_OFFICIAL_EMOTICONS = WECHAT_OFFICIAL_EMOTICONS;

        function getWechatEmoticonSvg(tagOrKey, size = 28) {
          const entry = WECHAT_TAG_MAP.get(tagOrKey) || WECHAT_OFFICIAL_EMOTICONS.find(x => x.k === tagOrKey);
          const k = entry ? entry.k : 'smile';
          const vAlign = size >= 36 ? 'middle' : '-0.2em';
          const wrapSvg = (inner) => `<svg width="${size}" height="${size}" viewBox="0 0 64 64" style="display:inline-block;vertical-align:${vAlign};flex-shrink:0;">${inner}</svg>`;

          // Standalone non-yellow icons (100% pure hex fills — zero url(#...) paint server dependencies!)
          if (k === 'doge') {
            return wrapSvg(`<path d="M13 25L17 9l13 9M51 25L47 9l-13 9" fill="#E59838" stroke="#6E3B10" stroke-width="2.3" stroke-linejoin="round"/><circle cx="32" cy="36" r="21.5" fill="#F4B350" stroke="#6E3B10" stroke-width="2.3"/><ellipse cx="32" cy="42.5" rx="15.5" ry="12" fill="#FFF8EB"/><ellipse cx="23.5" cy="27.5" rx="3.4" ry="1.9" fill="#FFF8EB"/><ellipse cx="40.5" cy="27.5" rx="3.4" ry="1.9" fill="#FFF8EB"/><ellipse cx="23.5" cy="33" rx="4.6" ry="2.9" fill="#FFFFFF" stroke="#542C0C" stroke-width="1.8"/><circle cx="25.8" cy="33" r="2" fill="#2E1605"/><ellipse cx="40.5" cy="33" rx="4.6" ry="2.9" fill="#FFFFFF" stroke="#542C0C" stroke-width="1.8"/><circle cx="42.8" cy="33" r="2" fill="#2E1605"/><ellipse cx="32" cy="39" rx="3.3" ry="2.3" fill="#3B200B"/><path d="M25.5 44.2c3.5 2.6 9.8 2 13.5-1.6" fill="none" stroke="#542C0C" stroke-width="2.3" stroke-linecap="round"/>`);
          }
          if (k === 'rose') {
            return wrapSvg(`<path d="M32 34v22" stroke="#15803D" stroke-width="3.8" stroke-linecap="round"/><path d="M32 47c-9 0-13-5-13-10 7 0 11 4 13 10zm0 0c9 0 13-5 13-10-7 0-11 4-13 10z" fill="#22C55E" stroke="#14532D" stroke-width="1.8"/><path d="M19 22c0-9 6-13 13-8 7-5 13-1 13 8 0 9-6 14-13 14s-13-5-13-14z" fill="#EF4444" stroke="#991B1B" stroke-width="2.2"/><path d="M24 19c4 4 12 4 16 0" fill="none" stroke="#FCA5A5" stroke-width="2.2" stroke-linecap="round"/>`);
          }
          if (k === 'heart' || k === 'broken') {
            return wrapSvg(`<path d="M32 54S9 40 9 23c0-7.8 6-13.2 13-13.2 4.3 0 7.7 2.2 10 5.7 2.3-3.5 5.7-5.7 10-5.7 7 0 13 5.4 13 13.2 0 17-23 31-23 31z" fill="#EF4444" stroke="#991B1B" stroke-width="2.2"/>${k === 'broken' ? '<path d="M32 15l-4.5 10.5 7.5 6-5.5 10.5 2.5 10" fill="none" stroke="#FFFFFF" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"/>' : '<ellipse cx="20.5" cy="19.5" rx="4.5" ry="2.6" transform="rotate(-25 20.5 19.5)" fill="#FFFFFF" opacity="0.52"/>'}`);
          }
          if (k === 'lips') {
            return wrapSvg(`<path d="M9 33c6.5-9.5 14.5-11.5 23-5 8.5-6.5 16.5-4.5 23 5-7.5 11.5-15.5 15.5-23 15.5S16.5 44.5 9 33z" fill="#F43F5E" stroke="#9F1239" stroke-width="2.3"/><path d="M11 33c13 3.2 29 3.2 42 0" fill="none" stroke="#881337" stroke-width="2.2"/><ellipse cx="23" cy="28" rx="4" ry="1.6" fill="#FFFFFF" opacity="0.45"/>`);
          }
          if (k === 'pig') {
            return wrapSvg(`<ellipse cx="15" cy="18" rx="7.5" ry="9.5" fill="#FDA4AF" stroke="#9F1239" stroke-width="2.2"/><ellipse cx="49" cy="18" rx="7.5" ry="9.5" fill="#FDA4AF" stroke="#9F1239" stroke-width="2.2"/><circle cx="32" cy="35" r="21.5" fill="#FBCFE8" stroke="#9F1239" stroke-width="2.3"/><circle cx="23" cy="28.5" r="2.8" fill="#4C0519"/><circle cx="41" cy="28.5" r="2.8" fill="#4C0519"/><ellipse cx="32" cy="39" rx="10" ry="7" fill="#F472B6" stroke="#9F1239" stroke-width="2"/><circle cx="28.8" cy="39" r="2.1" fill="#881337"/><circle cx="35.2" cy="39" r="2.1" fill="#881337"/>`);
          }
          if (k === 'thumb') {
            return wrapSvg(`<path d="M12 31h9v22h-9a3 3 0 0 1-3-3V34a3 3 0 0 1 3-3z" fill="#3B82F6" stroke="#1D4ED8" stroke-width="2.2"/><path d="M21 31l7-16c1.5-3.5 6.5-3 6.5 1.5V26h13.5c3.5 0 5.5 3 4.5 6.2l-3.8 16.5c-.8 3-3.2 4.3-6.2 4.3H21V31z" fill="#FFDA3D" stroke="#B4690E" stroke-width="2.3" stroke-linejoin="round"/><ellipse cx="31" cy="16" rx="2" ry="4" fill="#FFF3A1" opacity="0.7"/>`);
          }
          if (k === 'pray') {
            return wrapSvg(`<path d="M31 11c-2.5 0-4 2.2-4 5.5V35l-9 9 8 9 6-6V11zm2 0v36l6 6 8-9-9-9V16.5c0-3.3-1.5-5.5-4-5.5z" fill="#FFDA3D" stroke="#B4690E" stroke-width="2.2" stroke-linejoin="round"/><path d="M15 45l10 10-5 4-10-10zm34 0L39 55l5 4 10-10z" fill="#EF4444" stroke="#991B1B" stroke-width="2"/><path d="M32 6v3M23 9l2 2.5M41 9l-2 2.5" stroke="#F59E0B" stroke-width="2.4" stroke-linecap="round"/>`);
          }
          if (k === 'hongbao') {
            return wrapSvg(`<rect x="14" y="8" width="36" height="48" rx="6" fill="#EF4444" stroke="#991B1B" stroke-width="2.3"/><path d="M14 21q18 12 36 0" fill="none" stroke="#FDE047" stroke-width="2.6"/><circle cx="32" cy="27" r="7" fill="#FACC15" stroke="#991B1B" stroke-width="1.8"/><path d="M29 24l3 3 3-3M28.5 27.5h7M28.5 30h7M32 27v5" stroke="#991B1B" stroke-width="1.6" stroke-linecap="round" fill="none"/>`);
          }

          // Special [裂开] (crack): True split 2-half WeChat yellow sphere with real rift gap down the middle!
          if (k === 'crack') {
            return wrapSvg(`
              <g transform="translate(-2.2, 0) rotate(-3 32 32)">
                <path d="M33 7 A25 25 0 0 0 33 57 L29 44 L34 32 L28 20 Z" fill="#FFDA3D" stroke="#B86B08" stroke-width="2" stroke-linejoin="round"/>
                <ellipse cx="20" cy="18" rx="5.5" ry="2.4" transform="rotate(-24 20 18)" fill="#FFFFFF" opacity="0.62"/>
                <circle cx="21.5" cy="28" r="3.1" fill="#4A2708"/><circle cx="20.5" cy="27" r="1" fill="#FFFFFF"/>
                <path d="M22 42h8" stroke="#4A2708" stroke-width="2.6" stroke-linecap="round"/>
              </g>
              <g transform="translate(2.2, 0.8) rotate(3.5 32 32)">
                <path d="M33 7 L28 20 L34 32 L29 44 L33 57 A25 25 0 0 0 33 7 Z" fill="#F7C927" stroke="#B86B08" stroke-width="2" stroke-linejoin="round"/>
                <circle cx="42.5" cy="28" r="3.1" fill="#4A2708"/><circle cx="41.5" cy="27" r="1" fill="#FFFFFF"/>
                <path d="M34 42h8" stroke="#4A2708" stroke-width="2.6" stroke-linecap="round"/>
              </g>`);
          }

          // 3D Glossy WeChat Yellow Sphere (100% pure hex layers — NEVER turns transparent!)
          const sphere = `<circle cx="32" cy="32.8" r="25" fill="#EA9F10"/><circle cx="32" cy="32" r="24.8" fill="#FFDA3D" stroke="#B86B08" stroke-width="2"/><ellipse cx="27.5" cy="21.5" rx="15.5" ry="11" transform="rotate(-14 27.5 21.5)" fill="#FFED78" opacity="0.72"/><ellipse cx="22" cy="15.5" rx="6" ry="2.5" transform="rotate(-24 22 15.5)" fill="#FFFFFF" opacity="0.68"/>`;
          const cheeks = `<ellipse cx="16.8" cy="36.5" rx="4.8" ry="2.8" fill="#FF6B6B" opacity="0.52"/><ellipse cx="47.2" cy="36.5" rx="4.8" ry="2.8" fill="#FF6B6B" opacity="0.52"/>`;
          const archEyes = `<path d="M18.5 27.5c2.2-3.8 7.2-3.8 9.4 0M36.1 27.5c2.2-3.8 7.2-3.8 9.4 0" fill="none" stroke="#4A2708" stroke-width="2.8" stroke-linecap="round"/>`;
          const dotEyes = `<circle cx="23.5" cy="27" r="3.2" fill="#4A2708"/><circle cx="22.4" cy="25.8" r="1" fill="#FFFFFF"/><circle cx="40.5" cy="27" r="3.2" fill="#4A2708"/><circle cx="39.4" cy="25.8" r="1" fill="#FFFFFF"/>`;

          let face = '';
          switch (k) {
            case 'facepalm':
              // Classic WeChat [捂脸]: curved laughing-crying right eye + tear drop + wide helpless toothy grin + sculpted 4-finger hand covering left face!
              face = `<path d="M36.5 21.5c3 1 5.8 2.8 7.5 5" fill="none" stroke="#4A2708" stroke-width="2.3" stroke-linecap="round"/>
                      <path d="M36 27.5c2.8-3.2 7.5-2.8 9.5 0.5" fill="none" stroke="#4A2708" stroke-width="2.7" stroke-linecap="round"/>
                      <path d="M46.5 28.5c3.8 3.2 4.6 8 1.6 9.6-2.8 1.5-5.8-2.2-1.6-9.6z" fill="#38BDF8" stroke="#0284C7" stroke-width="1.2"/>
                      <path d="M23 39h20c-1.2 7.5-5.5 10.8-10.5 10.8S24 46 23 39z" fill="#991B1B" stroke="#4A2708" stroke-width="2"/>
                      <path d="M24 39h18v3.2H24z" fill="#FFFFFF"/>
                      <path d="M12 37c0-7 4.5-13.5 11-18.5 2-1.5 4.2-.2 3.2 2l-3.2 6.5 8.2-9.2c1.8-2 4.4-.4 3 2l-5.8 8.8 8.2-7.2c1.9-1.6 4.2.2 2.6 2.3l-6.2 7.5 6-4.2c1.8-1.2 3.6.8 1.9 2.6-5.2 5.8-12 9.8-19.2 10.2-5.8.4-9.7-1.2-9.7-2.8z" fill="#FFE46B" stroke="#A65E08" stroke-width="2" stroke-linejoin="round"/>`;
              break;
            case 'joy':
              face = `<path d="M18 21l7 2.5M46 21l-7 2.5" stroke="#4A2708" stroke-width="2.3" stroke-linecap="round"/>${archEyes}
                      <path d="M19 35h26c-1.2 9.5-6.2 13.5-13 13.5S20.2 44.5 19 35z" fill="#991B1B" stroke="#4A2708" stroke-width="2.2"/><path d="M20.2 35h23.6v3.6H20.2z" fill="#FFFFFF"/>
                      <path d="M15 29c-4.8 4-5.2 9.5-1.8 11.2 3.2 1.6 6-3.2 1.8-11.2zM49 29c4.8 4 5.2 9.5 1.8 11.2-3.2 1.6-6-3.2-1.8-11.2z" fill="#38BDF8" stroke="#0284C7" stroke-width="1.2"/>`;
              break;
            case 'grin':
              face = `${archEyes}${cheeks}<path d="M17.5 34h29c-1.2 10.2-6.8 14.2-14.5 14.2S18.7 44.2 17.5 34z" fill="#FFFFFF" stroke="#4A2708" stroke-width="2.3"/><path d="M18.8 40.5h26.4M25.5 34v13M32 34v14M38.5 34v13" stroke="#4A2708" stroke-width="1.6"/>`;
              break;
            case 'snicker':
              face = `${archEyes}${cheeks}<path d="M23 51c0-8.5 4.2-14 9.5-14s9 5.5 9 14z" fill="#FFE46B" stroke="#A65E08" stroke-width="2.1" stroke-linejoin="round"/><path d="M28 40v6.5M32.5 39v7.5M37 40v6.5" stroke="#A65E08" stroke-width="1.6" stroke-linecap="round"/>`;
              break;
            case 'kiss':
              face = `<path d="M19 27c2-3.2 6.5-3.2 8.5 0" fill="none" stroke="#4A2708" stroke-width="2.7" stroke-linecap="round"/><circle cx="40.5" cy="27" r="3" fill="#4A2708"/>${cheeks}<path d="M30 35.5c3.5-1.8 5.2.8 2.4 2.8 2.8 2 1 4.8-2.4 2.8" fill="none" stroke="#4A2708" stroke-width="2.7" stroke-linecap="round"/><path d="M49 23c-2.2-3.2-6.8-1.6-6.8 2.2 0 3.5 6.8 7 6.8 7s6.8-3.5 6.8-7c0-3.8-4.6-5.4-6.8-2.2z" fill="#EF4444" stroke="#991B1B" stroke-width="1.3"/>`;
              break;
            case 'shy':
              face = `<path d="M18.5 27.5c2.2 2.8 6.5 2.8 8.8 0M36.7 27.5c2.2 2.8 6.5 2.8 8.8 0" fill="none" stroke="#4A2708" stroke-width="2.6" stroke-linecap="round"/>${cheeks}<path d="M26.5 40c3.2 3.2 7.8 3.2 11 0" fill="none" stroke="#4A2708" stroke-width="2.5" stroke-linecap="round"/>`;
              break;
            case 'happy':
              face = `${archEyes}${cheeks}<path d="M21 36c3.5 7.5 18.5 7.5 22 0" fill="none" stroke="#4A2708" stroke-width="2.8" stroke-linecap="round"/>`;
              break;
            case 'chuckle':
              face = `<path d="M18 20.5c3-2 7.5-1.5 9.5 1M46 20.5c-3-2-7.5-1.5-9.5 1" fill="none" stroke="#4A2708" stroke-width="2.6" stroke-linecap="round"/>${dotEyes}${cheeks}<path d="M19 35.5h26c-1.5 8.5-6.5 12-13 12s-11.5-3.5-13-12z" fill="#991B1B" stroke="#4A2708" stroke-width="2.2"/><path d="M20.5 35.5h23v3.5h-23z" fill="#FFFFFF"/>`;
              break;
            case 'sly':
              face = `<path d="M18 23l9-2.5M37 20.5c3-1.8 7-.8 9 1.8" fill="none" stroke="#4A2708" stroke-width="2.5" stroke-linecap="round"/>${archEyes}<path d="M22 39c6 4.5 16 2.5 21-3.5" fill="none" stroke="#4A2708" stroke-width="2.7" stroke-linecap="round"/>`;
              break;
            case 'heiha':
              face = `${archEyes}${cheeks}<path d="M22 36h20c-1 7-5 10-10 10s-9-3-10-10z" fill="#991B1B" stroke="#4A2708" stroke-width="2"/><path d="M9 28c-2-7 3-11 6-6l3 7M55 28c2-7-3-11-6-6l-3 7" fill="#FFE46B" stroke="#A65E08" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>`;
              break;
            case 'smirk':
              face = `<path d="M18 21.5l9-2M46 21.5l-9-2" stroke="#4A2708" stroke-width="2.4" stroke-linecap="round"/><ellipse cx="23.5" cy="27" rx="5.2" ry="2.8" fill="#FFFFFF" stroke="#4A2708" stroke-width="1.8"/><circle cx="25.8" cy="27" r="1.9" fill="#2E1605"/><ellipse cx="40.5" cy="27" rx="5.2" ry="2.8" fill="#FFFFFF" stroke="#4A2708" stroke-width="1.8"/><circle cx="42.8" cy="27" r="1.9" fill="#2E1605"/><path d="M18 36.5c6 8.5 22 8.5 28-1.5-5 2.2-23 2.2-28 1.5z" fill="#FFFFFF" stroke="#4A2708" stroke-width="2.2"/>`;
              break;
            case 'smart':
              face = `<ellipse cx="23.5" cy="27" rx="4.8" ry="3.2" fill="#FFFFFF" stroke="#4A2708" stroke-width="1.8"/><circle cx="25.8" cy="27" r="2" fill="#2E1605"/><ellipse cx="40.5" cy="27" rx="4.8" ry="3.2" fill="#FFFFFF" stroke="#4A2708" stroke-width="1.8"/><circle cx="42.8" cy="27" r="2" fill="#2E1605"/><path d="M25.5 38.5c4 2.2 9.2 1.5 12.5-1" fill="none" stroke="#4A2708" stroke-width="2.4" stroke-linecap="round"/><path d="M21 50h17c2.5 0 3.2-3.5 0-4.2H26" fill="#FFE46B" stroke="#A65E08" stroke-width="2" stroke-linecap="round"/><path d="M49 14l1.6 3.6L54.2 19l-3.6 1.6L49 24.2l-1.6-3.6L43.8 19l3.6-1.4z" fill="#FFFFFF" stroke="#D97706" stroke-width="1"/>`;
              break;
            case 'melon':
              face = `<ellipse cx="23.5" cy="25.5" rx="4.4" ry="3" fill="#FFFFFF" stroke="#4A2708" stroke-width="1.8"/><circle cx="25.5" cy="25.5" r="1.9" fill="#2E1605"/><ellipse cx="40.5" cy="25.5" rx="4.4" ry="3" fill="#FFFFFF" stroke="#4A2708" stroke-width="1.8"/><circle cx="42.5" cy="25.5" r="1.9" fill="#2E1605"/><path d="M15.5 36.5h33c-2 11.5-9.2 16.5-16.5 16.5s-14.5-5-16.5-16.5z" fill="#EF4444" stroke="#15803D" stroke-width="3.2"/><circle cx="27" cy="42" r="1.1" fill="#1F2937"/><circle cx="32" cy="44" r="1.1" fill="#1F2937"/><circle cx="37" cy="42" r="1.1" fill="#1F2937"/>`;
              break;
            case 'peek':
              face = `<circle cx="38.5" cy="28" r="4.5" fill="#FFFFFF" stroke="#4A2708" stroke-width="2"/><circle cx="38.5" cy="28" r="2.1" fill="#2E1605"/><rect x="12" y="22" width="18" height="24" rx="4" fill="#FFE46B" stroke="#A65E08" stroke-width="2"/><rect x="44.5" y="23" width="8.5" height="22" rx="3.5" fill="#FFE46B" stroke="#A65E08" stroke-width="2"/><path d="M18 23v22M24 23v22" stroke="#A65E08" stroke-width="1.8"/>`;
              break;
            case 'pout':
              face = `<path d="M18 22l7-2M46 22l-7-2" stroke="#4A2708" stroke-width="2.2" stroke-linecap="round"/><circle cx="23" cy="29" r="3.8" fill="#4A2708"/><circle cx="21.8" cy="27.6" r="1.4" fill="#FFFFFF"/><circle cx="41" cy="29" r="3.8" fill="#4A2708"/><circle cx="39.8" cy="27.6" r="1.4" fill="#FFFFFF"/>${cheeks}<path d="M25 43.5c4-3.8 10-3.8 14 0" fill="none" stroke="#4A2708" stroke-width="2.6" stroke-linecap="round"/>`;
              break;
            case 'puppy':
              face = `<circle cx="23" cy="29" r="5.6" fill="#4A2708"/><circle cx="21.2" cy="27" r="2.3" fill="#FFFFFF"/><circle cx="25" cy="31.2" r="1.1" fill="#FFFFFF"/><circle cx="41" cy="29" r="5.6" fill="#4A2708"/><circle cx="39.2" cy="27" r="2.3" fill="#FFFFFF"/><circle cx="43" cy="31.2" r="1.1" fill="#FFFFFF"/>${cheeks}<path d="M27.5 42.5c2.5-2.2 6.5-2.2 9 0" fill="none" stroke="#4A2708" stroke-width="2.4" stroke-linecap="round"/>`;
              break;
            case 'hug':
              face = `${archEyes}${cheeks}<path d="M25 36.5c3.5 3.5 10.5 3.5 14 0" fill="none" stroke="#4A2708" stroke-width="2.5" stroke-linecap="round"/><path d="M11 41c6.5-4 12.5 2 10.5 8.5-5.5 1-11.5-3-10.5-8.5zm42 0c-6.5-4-12.5 2-10.5 8.5 5.5 1 11.5-3 10.5-8.5z" fill="#FFE46B" stroke="#A65E08" stroke-width="2.1"/>`;
              break;
            case 'hearteyes':
              face = `<path d="M22.5 31.5s-6.2-4-6.2-8.6c0-2.6 2-4.3 4.3-4.3 1.5 0 2.7.8 1.9 2.1 1.2-1.3 2.4-2.1 3.9-2.1 2.3 0 4.3 1.7 4.3 4.3 0 4.6-8.2 8.6-8.2 8.6zm19 0s-6.2-4-6.2-8.6c0-2.6 2-4.3 4.3-4.3 1.5 0 2.7.8 1.9 2.1 1.2-1.3 2.4-2.1 3.9-2.1 2.3 0 4.3 1.7 4.3 4.3 0 4.6-8.2 8.6-8.2 8.6z" fill="#EF4444" stroke="#991B1B" stroke-width="1.2"/><path d="M21.5 39c4.2 6.5 16.8 6.5 21 0" fill="none" stroke="#4A2708" stroke-width="2.7" stroke-linecap="round"/>`;
              break;
            case 'tongue':
              face = `<circle cx="23" cy="27" r="3.1" fill="#4A2708"/><path d="M36 27h9.5" stroke="#4A2708" stroke-width="2.8" stroke-linecap="round"/>${cheeks}<path d="M22.5 37c4 4 15 4 19 0" fill="none" stroke="#4A2708" stroke-width="2.5" stroke-linecap="round"/><path d="M28.5 39v6.5a3.8 3.8 0 0 0 7.6 0V39z" fill="#FB7185" stroke="#9F1239" stroke-width="1.8"/>`;
              break;
            case 'tears':
              face = `${dotEyes}<path d="M26 42.5c3.5-3 8.5-3 12 0" fill="none" stroke="#4A2708" stroke-width="2.5" stroke-linecap="round"/><path d="M22.5 32.5v14M41.5 32.5v14" stroke="#38BDF8" stroke-width="4.4" stroke-linecap="round"/>`;
              break;
            case 'sob':
              face = `<path d="M18.5 25.5l8 3.2-8 3.2M45.5 25.5l-8 3.2 8 3.2" fill="none" stroke="#4A2708" stroke-width="2.7" stroke-linecap="round" stroke-linejoin="round"/><path d="M20.5 31v18.5M43.5 31v18.5" stroke="#38BDF8" stroke-width="5.2" stroke-linecap="round"/><ellipse cx="32" cy="42" rx="7.2" ry="5.6" fill="#991B1B" stroke="#4A2708" stroke-width="2.1"/>`;
              break;
            case 'angry':
              face = `<path d="M17.5 21.5l9.5 4.5M46.5 21.5L37 26" stroke="#4A2708" stroke-width="3.1" stroke-linecap="round"/>${dotEyes}<path d="M23.5 43.5c4.2-4.5 12.8-4.5 17 0" fill="none" stroke="#4A2708" stroke-width="2.8" stroke-linecap="round"/>`;
              break;
            case 'wow':
              face = `<path d="M23 19.5l2.2 4.8 4.8 2.2-4.8 2.2-2.2 4.8-2.2-4.8-4.8-2.2 4.8-2.2zm18 0l2.2 4.8 4.8 2.2-4.8 2.2-2.2 4.8-2.2-4.8-4.8-2.2 4.8-2.2z" fill="#FFFFFF" stroke="#D97706" stroke-width="1.3"/>${cheeks}<ellipse cx="32" cy="41.5" rx="6.2" ry="7.2" fill="#991B1B" stroke="#4A2708" stroke-width="2.1"/>`;
              break;
            case '666':
              face = `<rect x="15" y="23" width="15" height="8" rx="2.5" fill="#1F2937"/><rect x="34" y="23" width="15" height="8" rx="2.5" fill="#1F2937"/><path d="M30 26h4" stroke="#1F2937" stroke-width="2.4"/><path d="M24 39c3.5 4 12.5 4 16 0" fill="none" stroke="#4A2708" stroke-width="2.6" stroke-linecap="round"/><rect x="36" y="42" width="22" height="14" rx="5" fill="#EF4444" stroke="#991B1B" stroke-width="1.6"/><text x="47" y="52.5" text-anchor="middle" font-size="10.5" font-weight="900" fill="#FFFFFF">666</text>`;
              break;
            case 'cheer':
              face = `<path d="M11 20h42v5H11z" fill="#EF4444"/><path d="M18 29c2-3 6-3 8 0M36 29c2-3 6-3 8 0" fill="none" stroke="#4A2708" stroke-width="2.7" stroke-linecap="round"/><path d="M24 39c3.5 4 12.5 4 16 0" fill="none" stroke="#4A2708" stroke-width="2.6" stroke-linecap="round"/><path d="M46 46c3-9 10-8 10-1 0 6-6 9-12 7z" fill="#FFE46B" stroke="#A65E08" stroke-width="2"/>`;
              break;
            case 'ok':
              face = `<circle cx="23" cy="27" r="3.1" fill="#4A2708"/><path d="M36 27.5c2.2-3.2 6.8-3.2 9 0" fill="none" stroke="#4A2708" stroke-width="2.7" stroke-linecap="round"/>${cheeks}<path d="M23 38c4 4.5 13 4.5 17 0" fill="none" stroke="#4A2708" stroke-width="2.5" stroke-linecap="round"/><circle cx="48" cy="46" r="5" fill="#FFE46B" stroke="#A65E08" stroke-width="2"/><circle cx="48" cy="46" r="2" fill="#FFFFFF"/><path d="M51 42l3-6M53 45l4-4" stroke="#A65E08" stroke-width="2.2" stroke-linecap="round"/>`;
              break;
            case 'peace':
              face = `${archEyes}${cheeks}<path d="M23 38c4 5 14 5 18 0" fill="none" stroke="#4A2708" stroke-width="2.6" stroke-linecap="round"/><path d="M46 43l-2-10M50 43l3-10" stroke="#A65E08" stroke-width="3.6" stroke-linecap="round"/><path d="M46 43l-2-10M50 43l3-10" stroke="#FFE46B" stroke-width="1.8" stroke-linecap="round"/><circle cx="48" cy="47" r="5.5" fill="#FFE46B" stroke="#A65E08" stroke-width="2"/>`;
              break;
            case 'clap':
              face = `${archEyes}${cheeks}<path d="M23 37c4 4.5 14 4.5 18 0" fill="none" stroke="#4A2708" stroke-width="2.5" stroke-linecap="round"/><path d="M22 52l6-9 5 4-5 8zm20 0l-6-9-5 4 5 8z" fill="#FFE46B" stroke="#A65E08" stroke-width="2" stroke-linejoin="round"/><path d="M32 39v-3M26 41l-2-2M38 41l2-2" stroke="#EF4444" stroke-width="2" stroke-linecap="round"/>`;
              break;
            case 'bye':
              face = `<ellipse cx="23.5" cy="26" rx="4.5" ry="3.2" fill="#FFFFFF" stroke="#4A2708" stroke-width="1.8"/><circle cx="23.5" cy="24.5" r="2" fill="#2E1605"/><ellipse cx="40.5" cy="26" rx="4.5" ry="3.2" fill="#FFFFFF" stroke="#4A2708" stroke-width="1.8"/><circle cx="40.5" cy="24.5" r="2" fill="#2E1605"/><path d="M24 39c4 3.5 12 3.5 16 0" fill="none" stroke="#4A2708" stroke-width="2.5" stroke-linecap="round"/><path d="M47 48c-2-5 1-12 6-11 4 1 5 8 1 13-3 3-6 1-7-2z" fill="#FFE46B" stroke="#A65E08" stroke-width="2"/>`;
              break;
            case 'sleepy':
            case 'zzz':
              face = `<path d="M18.5 29c2.2 2.2 6.5 2.2 8.8 0M36.7 29c2.2 2.2 6.5 2.2 8.8 0" fill="none" stroke="#4A2708" stroke-width="2.6" stroke-linecap="round"/><circle cx="32" cy="41.5" r="3.4" fill="#4A2708"/>${k === 'sleepy' ? '<ellipse cx="38" cy="43" rx="4.5" ry="3.2" fill="#BAE6FD" stroke="#0284C7" stroke-width="1.4"/>' : '<text x="47" y="19" font-size="12" font-weight="900" fill="#2563EB">Zzz</text>'}`;
              break;
            case 'shh':
              face = `${dotEyes}<circle cx="32" cy="38" r="3.5" fill="#4A2708"/><rect x="29.2" y="34" width="5.6" height="20" rx="2.8" fill="#FFE46B" stroke="#A65E08" stroke-width="2"/>`;
              break;
            case 'dizzy':
              face = `<path d="M23 27m-4 0a4 4 0 1 0 8 0a3 3 0 1 0 -6 0M41 27m-4 0a4 4 0 1 0 8 0a3 3 0 1 0 -6 0" fill="none" stroke="#4A2708" stroke-width="2.1" stroke-linecap="round"/><ellipse cx="32" cy="42" rx="4.5" ry="5.2" fill="#991B1B" stroke="#4A2708" stroke-width="2"/>`;
              break;
            case 'slap':
              face = `<path d="M18 26l8 3-8 2M37 28c2.2 2 6.5 2 8.5 0" fill="none" stroke="#4A2708" stroke-width="2.5" stroke-linecap="round"/><path d="M25 42c4-2.5 10-2.5 14 0" fill="none" stroke="#4A2708" stroke-width="2.5" stroke-linecap="round"/><ellipse cx="44" cy="36" rx="6.5" ry="5" fill="#EF4444" opacity="0.62"/>`;
              break;
            case 'sigh':
              face = `<path d="M18 24l8-2M46 24l-8-2" stroke="#4A2708" stroke-width="2.2" stroke-linecap="round"/><path d="M19 29c2.2 2 6.5 2 8.5 0M36.5 29c2.2 2 6.5 2 8.5 0" fill="none" stroke="#4A2708" stroke-width="2.5" stroke-linecap="round"/><path d="M26 41h12" stroke="#4A2708" stroke-width="2.4" stroke-linecap="round"/><path d="M38 43c6 0 10 3 10 6s-5 4-9 2c-3 1-6-2-4-5z" fill="#FFFFFF" stroke="#94A3B8" stroke-width="1.4"/>`;
              break;
            case 'bitter':
              face = `<path d="M18 22c3-1 6-2.5 8-4.5M46 22c-3-1-6-2.5-8-4.5" fill="none" stroke="#4A2708" stroke-width="2.2" stroke-linecap="round"/>${dotEyes}<path d="M19.5 30.5h8M36.5 30.5h8" stroke="#38BDF8" stroke-width="2.8" stroke-linecap="round"/><path d="M24 41c4 3.5 12 3.5 16 0" fill="none" stroke="#4A2708" stroke-width="2.5" stroke-linecap="round"/>`;
              break;
            case 'frown':
              face = `<path d="M19 21l8 3.5M45 21l-8 3.5" stroke="#4A2708" stroke-width="2.6" stroke-linecap="round"/>${dotEyes}<path d="M25 43c4-3.2 10-3.2 14 0" fill="none" stroke="#4A2708" stroke-width="2.6" stroke-linecap="round"/>`;
              break;
            case 'daze':
              face = `<circle cx="23.5" cy="27" r="5" fill="#FFFFFF" stroke="#4A2708" stroke-width="2"/><circle cx="23.5" cy="27" r="2" fill="#2E1605"/><circle cx="40.5" cy="27" r="5" fill="#FFFFFF" stroke="#4A2708" stroke-width="2"/><circle cx="40.5" cy="27" r="2" fill="#2E1605"/><circle cx="32" cy="42" r="3" fill="#4A2708"/>`;
              break;
            case 'eyeroll':
              face = `<circle cx="24" cy="26.5" r="5.2" fill="#FFFFFF" stroke="#4A2708" stroke-width="1.9"/><circle cx="24" cy="23.2" r="2.3" fill="#2E1605"/><circle cx="40" cy="26.5" r="5.2" fill="#FFFFFF" stroke="#4A2708" stroke-width="1.9"/><circle cx="40" cy="23.2" r="2.3" fill="#2E1605"/><path d="M25 42h14" stroke="#4A2708" stroke-width="2.6" stroke-linecap="round"/>`;
              break;
            case 'sweat':
              face = `${dotEyes}<path d="M49.5 16c4.2 5.5 4.2 10.5 0 12-4.2-1.5-4.2-6.5 0-12z" fill="#38BDF8" stroke="#0284C7" stroke-width="1.2"/><path d="M25 42h14" stroke="#4A2708" stroke-width="2.5" stroke-linecap="round"/>`;
              break;
            case 'question':
              face = `<path d="M18 22l7-2M38 20l8 2" stroke="#4A2708" stroke-width="2.3" stroke-linecap="round"/>${dotEyes}<path d="M26 42c3-2 9-2 12 0" fill="none" stroke="#4A2708" stroke-width="2.5" stroke-linecap="round"/><text x="49" y="21" font-size="16" font-weight="900" fill="#DC2626">?</text>`;
              break;
            case 'emm':
              face = `${dotEyes}<path d="M22 41c4-2.5 14 2.5 20 0" fill="none" stroke="#4A2708" stroke-width="2.7" stroke-linecap="round"/>`;
              break;
            case 'omg':
            case 'shock':
            case 'yawn':
              face = `${k === 'yawn' ? archEyes : dotEyes}<ellipse cx="32" cy="41.5" rx="${k === 'yawn' ? '7' : '4.8'}" ry="${k === 'yawn' ? '8' : '6'}" fill="#991B1B" stroke="#4A2708" stroke-width="2.1"/>${k === 'omg' ? '<path d="M13 42l5-8M51 42l-5-8" stroke="#A65E08" stroke-width="3.6" stroke-linecap="round"/>' : ''}`;
              break;
            default:
              face = `${k === 'smile' ? dotEyes : archEyes}${cheeks}<path d="M22 36.5c4 6 16 6 20 0" fill="none" stroke="#4A2708" stroke-width="2.7" stroke-linecap="round"/>`;
          }

          return wrapSvg(`${sphere}${face}`);
        }
        window.getWechatEmoticonSvg = getWechatEmoticonSvg;

        function isPureWechatEmoticonMsg(str) {
          const s = String(str || '').trim();
          if (!s) return false;
          const stripped = s.replace(/\[[^\[\]]{1,6}\]/g, (m) => (WECHAT_TAG_MAP.has(m) ? '' : m)).trim();
          return stripped.length === 0 && /\[[^\[\]]{1,6}\]/.test(s);
        }
        window.isPureWechatEmoticonMsg = isPureWechatEmoticonMsg;

        function renderTextWithWechatEmoticons(escapedText, pxSize = 22) {
          const s = String(escapedText || '');
          if (!s.includes('[')) return s;
          return s.replace(/\[([^\[\]]{1,6})\]/g, (full) => {
            if (WECHAT_TAG_MAP.has(full)) return getWechatEmoticonSvg(full, pxSize);
            return full;
          });
        }
        window.renderTextWithWechatEmoticons = renderTextWithWechatEmoticons;
        // Bespoke Pastel Illustrated SVG Sticker Art Pack (100% China-Direct & Offline!)
        function getPastelStickerSvg(idx, size = 44) {
          const svgs = [
            // 0: 안아줘 (Hug)
            `<svg style="width:${size}px;height:${size}px;" viewBox="0 0 64 64" fill="none"><circle cx="32" cy="34" r="22" fill="#fde8f2" stroke="#5b3d8a" stroke-width="2.4"/><circle cx="24" cy="31" r="2.6" fill="#5b3d8a"/><circle cx="40" cy="31" r="2.6" fill="#5b3d8a"/><ellipse cx="19" cy="36" rx="4" ry="2.4" fill="#f9a8d4"/><ellipse cx="45" cy="36" rx="4" ry="2.4" fill="#f9a8d4"/><path d="M27 38c2 3 8 3 10 0" stroke="#5b3d8a" stroke-width="2.2" stroke-linecap="round"/><path d="M12 40c-4-4-2-10 3-8M52 40c4-4 2-10-3-8" stroke="#5b3d8a" stroke-width="2.4" stroke-linecap="round"/><path d="M32 15c-2.5-3.5-8-2-8 2 0 3.5 8 7.5 8 7.5s8-4 8-7.5c0-4-5.5-5.5-8-2z" fill="#f472b6" stroke="#5b3d8a" stroke-width="1.8"/></svg>`,
            // 1: 보고 싶어 (Miss you)
            `<svg style="width:${size}px;height:${size}px;" viewBox="0 0 64 64" fill="none"><circle cx="32" cy="34" r="22" fill="#ede9fe" stroke="#5b3d8a" stroke-width="2.4"/><circle cx="24" cy="31" r="4" fill="#5b3d8a"/><circle cx="22.6" cy="29.5" r="1.5" fill="#fff"/><circle cx="40" cy="31" r="4" fill="#5b3d8a"/><circle cx="38.6" cy="29.5" r="1.5" fill="#fff"/><ellipse cx="18" cy="37" rx="3.5" ry="2" fill="#f9a8d4"/><ellipse cx="46" cy="37" rx="3.5" ry="2" fill="#f9a8d4"/><path d="M28 40c2-2 6-2 8 0" stroke="#5b3d8a" stroke-width="2.2" stroke-linecap="round"/><path d="M48 16c-1.5-2.2-5-1.2-5 1.3 0 2.3 5 4.7 5 4.7s5-2.4 5-4.7c0-2.5-3.5-3.5-5-1.3z" fill="#c084fc" stroke="#5b3d8a" stroke-width="1.6"/></svg>`,
            // 2: 쪽! 뽀뽀 (Kiss)
            `<svg style="width:${size}px;height:${size}px;" viewBox="0 0 64 64" fill="none"><circle cx="30" cy="34" r="21" fill="#fef3c7" stroke="#5b3d8a" stroke-width="2.4"/><path d="M21 30c1.5-2 4.5-2 6 0M36 30c1.5-2 4.5-2 6 0" stroke="#5b3d8a" stroke-width="2.3" stroke-linecap="round"/><ellipse cx="18" cy="36" rx="3.8" ry="2.2" fill="#fda4af"/><ellipse cx="42" cy="36" rx="3.8" ry="2.2" fill="#fda4af"/><path d="M28 38c2-1.5 4 0 2.5 1.8 1.5 1.8-.5 3.2-2.5 1.8" stroke="#5b3d8a" stroke-width="2.2" stroke-linecap="round"/><path d="M51 28c-2-3-6.5-1.5-6.5 1.8 0 3 6.5 6.2 6.5 6.2s6.5-3.2 6.5-6.2c0-3.3-4.5-4.8-6.5-1.8z" fill="#fb7185" stroke="#5b3d8a" stroke-width="1.8"/></svg>`,
            // 3: 사랑해 (Love you)
            `<svg style="width:${size}px;height:${size}px;" viewBox="0 0 64 64" fill="none"><path d="M32 54s-20-12.5-24-24C4.5 20.5 11 11 20 11c5.2 0 9.5 2.8 12 7 2.5-4.2 6.8-7 12-7 9 0 15.5 9.5 12 19-4 11.5-24 24-24 24z" fill="#f9a8d4" stroke="#5b3d8a" stroke-width="2.4" stroke-linejoin="round"/><circle cx="24" cy="28" r="2.2" fill="#5b3d8a"/><circle cx="40" cy="28" r="2.2" fill="#5b3d8a"/><path d="M27 34c2.5 3 7.5 3 10 0" stroke="#5b3d8a" stroke-width="2.2" stroke-linecap="round"/><circle cx="19" cy="21" r="2.5" fill="#fff" opacity="0.7"/></svg>`,
            // 4: 밥 먹었어? (Meal)
            `<svg style="width:${size}px;height:${size}px;" viewBox="0 0 64 64" fill="none"><path d="M12 34h40c0 12-9 20-20 20s-20-8-20-20z" fill="#ddd6fe" stroke="#5b3d8a" stroke-width="2.4" stroke-linejoin="round"/><path d="M16 34c0-9 7-15 16-15s16 6 16 15" fill="#fffbeb" stroke="#5b3d8a" stroke-width="2.2"/><path d="M24 14c0-3 2-5 2-5M32 12c0-3 2-5 2-5M40 14c0-3 2-5 2-5" stroke="#c084fc" stroke-width="2.2" stroke-linecap="round"/><circle cx="26" cy="42" r="2" fill="#5b3d8a"/><circle cx="38" cy="42" r="2" fill="#5b3d8a"/><path d="M29 46c1.5 1.8 4.5 1.8 6 0" stroke="#5b3d8a" stroke-width="2" stroke-linecap="round"/></svg>`,
            // 5: 잘 자 (Good night)
            `<svg style="width:${size}px;height:${size}px;" viewBox="0 0 64 64" fill="none"><path d="M44 42a18 18 0 1 1-19-28 14 14 0 1 0 19 28z" fill="#fde68a" stroke="#5b3d8a" stroke-width="2.4" stroke-linejoin="round"/><path d="M44 16l1.5 3.5L49 21l-3.5 1.5L44 26l-1.5-3.5L39 21l3.5-1.5L44 16z" fill="#c4b5fd" stroke="#5b3d8a" stroke-width="1.4"/><circle cx="51" cy="32" r="2.2" fill="#f9a8d4"/></svg>`,
            // 6: 좋은 아침 (Good morning)
            `<svg style="width:${size}px;height:${size}px;" viewBox="0 0 64 64" fill="none"><circle cx="32" cy="32" r="16" fill="#fef08a" stroke="#5b3d8a" stroke-width="2.4"/><path d="M32 8v5M32 51v5M8 32h5M51 32h5M15 15l3.5 3.5M45.5 45.5L49 49M49 15l-3.5 3.5M18.5 45.5L15 49" stroke="#f59e0b" stroke-width="2.5" stroke-linecap="round"/><circle cx="26" cy="30" r="2.2" fill="#5b3d8a"/><circle cx="38" cy="30" r="2.2" fill="#5b3d8a"/><path d="M27 36c2.5 2.8 7.5 2.8 10 0" stroke="#5b3d8a" stroke-width="2.2" stroke-linecap="round"/></svg>`,
            // 7: 오늘도 힘내 (Cheer up)
            `<svg style="width:${size}px;height:${size}px;" viewBox="0 0 64 64" fill="none"><path d="M32 10l6.2 12.8L52 24.8l-10 9.8 2.4 13.8L32 41.8 19.6 48.4 22 34.6l-10-9.8 13.8-2L32 10z" fill="#fde68a" stroke="#5b3d8a" stroke-width="2.4" stroke-linejoin="round"/><circle cx="27" cy="30" r="2" fill="#5b3d8a"/><circle cx="37" cy="30" r="2" fill="#5b3d8a"/><path d="M29 35c1.5 2 4.5 2 6 0" stroke="#5b3d8a" stroke-width="2" stroke-linecap="round"/></svg>`,
            // 8: 미안해 (Sorry)
            `<svg style="width:${size}px;height:${size}px;" viewBox="0 0 64 64" fill="none"><circle cx="32" cy="36" r="20" fill="#e0e7ff" stroke="#5b3d8a" stroke-width="2.4"/><path d="M18 22c-4-8 4-12 8-4M46 22c4-8-4-12-8-4" fill="#c7d2fe" stroke="#5b3d8a" stroke-width="2.2" stroke-linejoin="round"/><path d="M22 33l5 2M42 33l-5 2" stroke="#5b3d8a" stroke-width="2.2" stroke-linecap="round"/><path d="M28 43c2-2 6-2 8 0" stroke="#5b3d8a" stroke-width="2.2" stroke-linecap="round"/><circle cx="20" cy="40" r="2.2" fill="#93c5fd"/></svg>`,
            // 9: 흥 삐졌어 (Pouty)
            `<svg style="width:${size}px;height:${size}px;" viewBox="0 0 64 64" fill="none"><circle cx="32" cy="34" r="21" fill="#ffe4e6" stroke="#5b3d8a" stroke-width="2.4"/><path d="M21 29l6 3M43 29l-6 3" stroke="#5b3d8a" stroke-width="2.4" stroke-linecap="round"/><ellipse cx="19" cy="37" rx="4.2" ry="2.6" fill="#fda4af"/><ellipse cx="45" cy="37" rx="4.2" ry="2.6" fill="#fda4af"/><path d="M28 42c2-2.2 6-2.2 8 0" stroke="#5b3d8a" stroke-width="2.2" stroke-linecap="round"/><path d="M49 16c3-2 6 0 4 3" stroke="#f43f5e" stroke-width="2.2" stroke-linecap="round"/></svg>`,
            // 10: 아 웃겨 ㅋㅋ (LOL)
            `<svg style="width:${size}px;height:${size}px;" viewBox="0 0 64 64" fill="none"><circle cx="32" cy="34" r="21" fill="#fef3c7" stroke="#5b3d8a" stroke-width="2.4"/><path d="M20 29l6 3-6 3M44 29l-6 3 6 3" stroke="#5b3d8a" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"/><path d="M23 40h18c0 6-4 9-9 9s-9-3-9-9z" fill="#f9a8d4" stroke="#5b3d8a" stroke-width="2"/><circle cx="15" cy="36" r="2.8" fill="#93c5fd"/><circle cx="49" cy="36" r="2.8" fill="#93c5fd"/></svg>`,
            // 11: 최고야!! (Awesome)
            `<svg style="width:${size}px;height:${size}px;" viewBox="0 0 64 64" fill="none"><circle cx="32" cy="36" r="20" fill="#f3e8ff" stroke="#5b3d8a" stroke-width="2.4"/><path d="M22 18l10-8 10 8" fill="#fde68a" stroke="#5b3d8a" stroke-width="2.2" stroke-linejoin="round"/><circle cx="25" cy="33" r="2.4" fill="#5b3d8a"/><circle cx="39" cy="33" r="2.4" fill="#5b3d8a"/><path d="M25 40c3 4 11 4 14 0" stroke="#5b3d8a" stroke-width="2.3" stroke-linecap="round"/><circle cx="13" cy="20" r="2.2" fill="#f472b6"/><circle cx="51" cy="20" r="2.2" fill="#60a5fa"/></svg>`,
            // 12: 강아지 눈빛 (Puppy)
            `<svg style="width:${size}px;height:${size}px;" viewBox="0 0 64 64" fill="none"><ellipse cx="14" cy="34" rx="7" ry="13" fill="#fde68a" stroke="#5b3d8a" stroke-width="2.2"/><ellipse cx="50" cy="34" rx="7" ry="13" fill="#fde68a" stroke="#5b3d8a" stroke-width="2.2"/><circle cx="32" cy="35" r="19" fill="#fffbeb" stroke="#5b3d8a" stroke-width="2.4"/><circle cx="25" cy="33" r="3" fill="#5b3d8a"/><circle cx="24" cy="31.8" r="1.1" fill="#fff"/><circle cx="39" cy="33" r="3" fill="#5b3d8a"/><circle cx="38" cy="31.8" r="1.1" fill="#fff"/><ellipse cx="32" cy="38" rx="3" ry="2" fill="#5b3d8a"/><path d="M28 42c2 2.2 6 2.2 8 0" stroke="#5b3d8a" stroke-width="2" stroke-linecap="round"/><ellipse cx="20" cy="39" rx="3.2" ry="1.8" fill="#fda4af"/><ellipse cx="44" cy="39" rx="3.2" ry="1.8" fill="#fda4af"/></svg>`,
            // 13: 야옹~ 내꺼 (Kitty)
            `<svg style="width:${size}px;height:${size}px;" viewBox="0 0 64 64" fill="none"><path d="M16 26l4-13 10 8M48 26l-4-13-10 8" fill="#fbcfe8" stroke="#5b3d8a" stroke-width="2.2" stroke-linejoin="round"/><circle cx="32" cy="37" r="19" fill="#fdf2f8" stroke="#5b3d8a" stroke-width="2.4"/><circle cx="25" cy="35" r="2.5" fill="#5b3d8a"/><circle cx="39" cy="35" r="2.5" fill="#5b3d8a"/><path d="M29 40c1.5 1.8 3 0 3 0s1.5 1.8 3 0" stroke="#5b3d8a" stroke-width="2" stroke-linecap="round"/><path d="M11 36h7M12 40h6M46 36h7M46 40h6" stroke="#5b3d8a" stroke-width="1.8" stroke-linecap="round"/><ellipse cx="20" cy="40" rx="3" ry="1.8" fill="#f9a8d4"/><ellipse cx="44" cy="40" rx="3" ry="1.8" fill="#f9a8d4"/></svg>`,
            // 14: 토끼 깡총 (Bunny)
            `<svg style="width:${size}px;height:${size}px;" viewBox="0 0 64 64" fill="none"><ellipse cx="24" cy="18" rx="5.5" ry="13" fill="#fff1f2" stroke="#5b3d8a" stroke-width="2.2"/><ellipse cx="24" cy="18" rx="2.5" ry="8" fill="#fbcfe8"/><ellipse cx="40" cy="18" rx="5.5" ry="13" fill="#fff1f2" stroke="#5b3d8a" stroke-width="2.2"/><ellipse cx="40" cy="18" rx="2.5" ry="8" fill="#fbcfe8"/><circle cx="32" cy="40" r="17" fill="#fff" stroke="#5b3d8a" stroke-width="2.4"/><circle cx="26" cy="38" r="2.3" fill="#5b3d8a"/><circle cx="38" cy="38" r="2.3" fill="#5b3d8a"/><ellipse cx="21" cy="42" rx="3" ry="1.8" fill="#fda4af"/><ellipse cx="43" cy="42" rx="3" ry="1.8" fill="#fda4af"/><path d="M29 43c1.5 1.8 4.5 1.8 6 0" stroke="#5b3d8a" stroke-width="2" stroke-linecap="round"/></svg>`,
            // 15: 곰돌이 포옹 (Teddy Bear)
            `<svg style="width:${size}px;height:${size}px;" viewBox="0 0 64 64" fill="none"><circle cx="17" cy="20" r="7" fill="#fed7aa" stroke="#5b3d8a" stroke-width="2.2"/><circle cx="47" cy="20" r="7" fill="#fed7aa" stroke="#5b3d8a" stroke-width="2.2"/><circle cx="32" cy="36" r="19" fill="#ffedd5" stroke="#5b3d8a" stroke-width="2.4"/><ellipse cx="32" cy="40" rx="7" ry="5.5" fill="#fff7ed"/><circle cx="25" cy="33" r="2.4" fill="#5b3d8a"/><circle cx="39" cy="33" r="2.4" fill="#5b3d8a"/><ellipse cx="32" cy="38" rx="2.8" ry="1.9" fill="#5b3d8a"/><path d="M29 42c1.5 1.8 4.5 1.8 6 0" stroke="#5b3d8a" stroke-width="2" stroke-linecap="round"/><path d="M32 51c-2-2.5-6-1.2-6 1.5 0 2.5 6 5 6 5s6-2.5 6-5c0-2.7-4-4-6-1.5z" fill="#fb7185" stroke="#5b3d8a" stroke-width="1.6"/></svg>`,
            // 16: 감동이야 ㅠㅠ (Touched)
            `<svg style="width:${size}px;height:${size}px;" viewBox="0 0 64 64" fill="none"><circle cx="32" cy="34" r="21" fill="#f3e8ff" stroke="#5b3d8a" stroke-width="2.4"/><circle cx="24" cy="32" r="4.5" fill="#5b3d8a"/><circle cx="22.5" cy="30.2" r="1.8" fill="#fff"/><circle cx="25.8" cy="33.8" r="1" fill="#fff"/><circle cx="40" cy="32" r="4.5" fill="#5b3d8a"/><circle cx="38.5" cy="30.2" r="1.8" fill="#fff"/><circle cx="41.8" cy="33.8" r="1" fill="#fff"/><ellipse cx="18" cy="39" rx="3.6" ry="2" fill="#f9a8d4"/><ellipse cx="46" cy="39" rx="3.6" ry="2" fill="#f9a8d4"/><path d="M27 42c2.5 2.5 7.5 2.5 10 0" stroke="#5b3d8a" stroke-width="2.2" stroke-linecap="round"/><path d="M13 18l1.2 2.8L17 22l-2.8 1.2L13 26l-1.2-2.8L9 22l2.8-1.2L13 18z" fill="#fde047"/></svg>`,
            // 17: 꽃 선물 줄게 (Tulip)
            `<svg style="width:${size}px;height:${size}px;" viewBox="0 0 64 64" fill="none"><path d="M32 36v18" stroke="#10b981" stroke-width="3" stroke-linecap="round"/><path d="M32 48c-8 0-12-5-12-10 6 0 11 3 12 10zM32 48c8 0 12-5 12-10-6 0-11 3-12 10z" fill="#a7f3d0" stroke="#5b3d8a" stroke-width="2" stroke-linejoin="round"/><path d="M20 20c0-7 5-10 12-5 7-5 12-2 12 5 0 10-5 16-12 16s-12-6-12-16z" fill="#f9a8d4" stroke="#5b3d8a" stroke-width="2.3" stroke-linejoin="round"/><circle cx="28" cy="24" r="1.8" fill="#5b3d8a"/><circle cx="36" cy="24" r="1.8" fill="#5b3d8a"/><path d="M30 28c1 1.4 3 1.4 4 0" stroke="#5b3d8a" stroke-width="1.8" stroke-linecap="round"/></svg>`,
            // 18: 러브레터 도착 (Love Letter)
            `<svg style="width:${size}px;height:${size}px;" viewBox="0 0 64 64" fill="none"><rect x="10" y="18" width="44" height="30" rx="7" fill="#fdf2f8" stroke="#5b3d8a" stroke-width="2.4"/><path d="M12 20l20 15 20-15" stroke="#5b3d8a" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/><path d="M32 31c-2-2.8-6.5-1.5-6.5 1.8 0 2.8 6.5 6 6.5 6s6.5-3.2 6.5-6c0-3.3-4.5-4.6-6.5-1.8z" fill="#f472b6" stroke="#5b3d8a" stroke-width="1.7"/></svg>`,
            // 19: 커피 한 잔 어때? (Latte)
            `<svg style="width:${size}px;height:${size}px;" viewBox="0 0 64 64" fill="none"><path d="M16 24h28v16c0 8-6 14-14 14s-14-6-14-14V24z" fill="#fef3c7" stroke="#5b3d8a" stroke-width="2.4" stroke-linejoin="round"/><path d="M44 28h5a5 5 0 0 1 0 10h-5" stroke="#5b3d8a" stroke-width="2.4" stroke-linecap="round"/><path d="M24 16c0-3 2-5 2-5M32 14c0-3 2-5 2-5" stroke="#c084fc" stroke-width="2.2" stroke-linecap="round"/><path d="M30 35c-1.5-2-4.8-1-4.8 1.4 0 2.2 4.8 4.6 4.8 4.6s4.8-2.4 4.8-4.6c0-2.4-3.3-3.4-4.8-1.4z" fill="#fb7185"/></svg>`,
            // 20: 달콤한 디저트 (Cake)
            `<svg style="width:${size}px;height:${size}px;" viewBox="0 0 64 64" fill="none"><path d="M14 34h36v16a4 4 0 0 1-4 4H18a4 4 0 0 1-4-4V34z" fill="#fef9c3" stroke="#5b3d8a" stroke-width="2.3"/><path d="M14 34l18-12 18 12H14z" fill="#fbcfe8" stroke="#5b3d8a" stroke-width="2.3" stroke-linejoin="round"/><path d="M14 43h36" stroke="#f9a8d4" stroke-width="4"/><circle cx="32" cy="18" r="5.5" fill="#fb7185" stroke="#5b3d8a" stroke-width="2"/><path d="M32 12c2-3 5-3 5-3" stroke="#10b981" stroke-width="2" stroke-linecap="round"/></svg>`,
            // 21: 평생 내 옆에 (Ring)
            `<svg style="width:${size}px;height:${size}px;" viewBox="0 0 64 64" fill="none"><circle cx="32" cy="38" r="15" stroke="#fbbf24" stroke-width="5"/><circle cx="32" cy="38" r="15" stroke="#5b3d8a" stroke-width="2"/><path d="M24 18l8-7 8 7-8 8-8-8z" fill="#bae6fd" stroke="#5b3d8a" stroke-width="2.2" stroke-linejoin="round"/><path d="M14 14l1.5 3L19 18.5 15.5 20 14 23l-1.5-3L9 18.5 12.5 17 14 14z" fill="#f472b6"/></svg>`,
            // 22: 너무 귀여워 (Ribbon Bow)
            `<svg style="width:${size}px;height:${size}px;" viewBox="0 0 64 64" fill="none"><path d="M32 32C20 18 10 22 10 32s10 14 22 0zM32 32c12-14 22-10 22 0s-10 14-22 0z" fill="#fbcfe8" stroke="#5b3d8a" stroke-width="2.4" stroke-linejoin="round"/><path d="M28 36l-6 15M36 36l6 15" stroke="#f472b6" stroke-width="4" stroke-linecap="round"/><circle cx="32" cy="32" r="5.5" fill="#f472b6" stroke="#5b3d8a" stroke-width="2.2"/><circle cx="50" cy="16" r="2.2" fill="#fde047"/></svg>`,
            // 23: 딸기처럼 달콤해 (Strawberry)
            `<svg style="width:${size}px;height:${size}px;" viewBox="0 0 64 64" fill="none"><path d="M32 54c-11 0-18-11-18-22 0-8 7-13 18-13s18 5 18 13c0 11-7 22-18 22z" fill="#fda4af" stroke="#5b3d8a" stroke-width="2.4"/><path d="M22 20c4-6 16-6 20 0-4 3-16 3-20 0z" fill="#86efac" stroke="#5b3d8a" stroke-width="2" stroke-linejoin="round"/><circle cx="26" cy="33" r="2.2" fill="#5b3d8a"/><circle cx="38" cy="33" r="2.2" fill="#5b3d8a"/><path d="M29 39c1.5 2 4.5 2 6 0" stroke="#5b3d8a" stroke-width="2" stroke-linecap="round"/><circle cx="22" cy="43" r="1.3" fill="#fff"/><circle cx="42" cy="43" r="1.3" fill="#fff"/></svg>`,
            // 24: 하트 뿅뿅 (Double Hearts)
            `<svg style="width:${size}px;height:${size}px;" viewBox="0 0 64 64" fill="none"><path d="M24 44s-13-8-15-15c-2-6 2-12 8-12 3.5 0 6 2 7 4.5 1-2.5 3.5-4.5 7-4.5 6 0 10 6 8 12-2 7-15 15-15 15z" fill="#c4b5fd" stroke="#5b3d8a" stroke-width="2.2" stroke-linejoin="round"/><path d="M43 52s-12-7.5-14-14c-1.8-5.5 2-11 7.5-11 3.2 0 5.5 1.8 6.5 4 1-2.2 3.3-4 6.5-4 5.5 0 9.3 5.5 7.5 11-2 6.5-14 14-14 14z" fill="#f9a8d4" stroke="#5b3d8a" stroke-width="2.2" stroke-linejoin="round"/></svg>`,
            // 25: 푹 쉬어 자기 (Fluffy Cloud)
            `<svg style="width:${size}px;height:${size}px;" viewBox="0 0 64 64" fill="none"><path d="M18 46h29a11 11 0 0 0 2-21.8A14 14 0 0 0 22 22a11 11 0 0 0-4 24z" fill="#e0f2fe" stroke="#5b3d8a" stroke-width="2.4" stroke-linejoin="round"/><path d="M24 35c1.5-1.8 4-1.8 5.5 0M36 35c1.5-1.8 4-1.8 5.5 0" stroke="#5b3d8a" stroke-width="2.1" stroke-linecap="round"/><path d="M30 40c1.5 1.6 3.5 1.6 5 0" stroke="#5b3d8a" stroke-width="2" stroke-linecap="round"/><ellipse cx="21" cy="39" rx="2.8" ry="1.6" fill="#fda4af"/><ellipse cx="44" cy="39" rx="2.8" ry="1.6" fill="#fda4af"/></svg>`,
            // 26: 서프라이즈 선물 (Gift Box)
            `<svg style="width:${size}px;height:${size}px;" viewBox="0 0 64 64" fill="none"><rect x="13" y="26" width="38" height="26" rx="5" fill="#ede9fe" stroke="#5b3d8a" stroke-width="2.4"/><rect x="10" y="20" width="44" height="9" rx="4" fill="#ddd6fe" stroke="#5b3d8a" stroke-width="2.4"/><path d="M32 20v32" stroke="#f472b6" stroke-width="5"/><path d="M32 20c-6-9-15-5-11 0h11zm0 0c6-9 15-5 11 0H32z" fill="#f9a8d4" stroke="#5b3d8a" stroke-width="2" stroke-linejoin="round"/></svg>`,
            // 27: 내 귀요미 (Cute Peach)
            `<svg style="width:${size}px;height:${size}px;" viewBox="0 0 64 64" fill="none"><path d="M32 54c-12-3-20-12-20-23 0-9 7-15 15-15 3 0 5 1.5 5 3 0-1.5 2-3 5-3 8 0 15 6 15 15 0 11-8 20-20 23z" fill="#fed7aa" stroke="#5b3d8a" stroke-width="2.4" stroke-linejoin="round"/><path d="M32 16c2-6 9-7 11-3-3 4-8 5-11 3z" fill="#86efac" stroke="#5b3d8a" stroke-width="1.8" stroke-linejoin="round"/><circle cx="25" cy="34" r="2.3" fill="#5b3d8a"/><circle cx="39" cy="34" r="2.3" fill="#5b3d8a"/><ellipse cx="20" cy="39" rx="3.2" ry="1.8" fill="#fda4af"/><ellipse cx="44" cy="39" rx="3.2" ry="1.8" fill="#fda4af"/><path d="M29 40c1.5 2 4.5 2 6 0" stroke="#5b3d8a" stroke-width="2" stroke-linecap="round"/></svg>`
          ];
          return svgs[idx % svgs.length];
        }
        window.getPastelStickerSvg = getPastelStickerSvg;

        const COUPLE_STICKERS = [
          { icon: '🤗', ko: '안아줘!', zh: '抱抱！' },
          { icon: '🥺', ko: '보고 싶어', zh: '好想你' },
          { icon: '💋', ko: '쪽! 뽀뽀', zh: '么么哒' },
          { icon: '🥰', ko: '사랑해', zh: '我爱你' },
          { icon: '🍽️', ko: '밥 먹었어?', zh: '吃饭了吗？' },
          { icon: '🌙', ko: '잘 자, 좋은 꿈 꿔', zh: '晚安好梦' },
          { icon: '☀️', ko: '좋은 아침!', zh: '早安呀！' },
          { icon: '💪', ko: '오늘도 힘내!', zh: '今天也加油！' },
          { icon: '🙏', ko: '미안해 화 풀어', zh: '对不起别生气啦' },
          { icon: '😤', ko: '흥 삐졌어!', zh: '哼生气了！' },
          { icon: '😂', ko: '아 웃겨 ㅋㅋㅋ', zh: '哈哈笑死我了' },
          { icon: '🎉', ko: '최고야!!', zh: '太棒啦！！' },
          { icon: '🐶', ko: '강아지 눈빛~', zh: '旺柴乖巧~' },
          { icon: '🐱', ko: '야옹~ 내꺼!', zh: '喵~ 你是我的' },
          { icon: '🐰', ko: '토끼 깡총~', zh: '兔兔想你啦' },
          { icon: '🐻', ko: '곰돌이 포옹', zh: '小熊抱抱' },
          { icon: '🥹', ko: '감동이야 ㅠㅠ', zh: '好感动呀' },
          { icon: '🌷', ko: '꽃 선물 줄게', zh: '送你一朵小红花' },
          { icon: '💌', ko: '러브레터 도착', zh: '情书送达' },
          { icon: '☕', ko: '커피 한 잔 어때?', zh: '一起喝杯咖啡吧' },
          { icon: '🍰', ko: '달콤한 디저트', zh: '甜蜜小蛋糕' },
          { icon: '💍', ko: '평생 내 옆에', zh: '永远陪在我身边' },
          { icon: '🎀', ko: '너무 귀여워!', zh: '太可爱啦！' },
          { icon: '🍓', ko: '딸기처럼 달콤해', zh: '像草莓一样甜' },
          { icon: '🫶', ko: '하트 뿅뿅', zh: '比心心' },
          { icon: '☁️', ko: '푹 쉬어 자기', zh: '好好休息呀' },
          { icon: '🎁', ko: '서프라이즈 선물', zh: '惊喜小礼物' },
          { icon: '🍑', ko: '내 귀요미', zh: '我的小可爱' }
        ];
        window.__activeStickerTab = 'wechat';
        const stickerGrid = document.getElementById('chatStickerGrid');
        const stickerTray = document.getElementById('chatStickerTray');
        const stickerBtn = document.getElementById('chatStickerBtn');
        document.getElementById('closeStickerTrayBtn')?.addEventListener('click', () => stickerTray?.classList.add('hidden'));
        document.getElementById('emojiBackspaceBtn')?.addEventListener('click', () => {
          const ta = document.getElementById('chatInput');
          if (!ta || !ta.value) return;
          const mTag = ta.value.match(/\[[^\[\]]{1,6}\]$/);
          if (mTag && WECHAT_TAG_MAP.has(mTag[0])) {
            ta.value = ta.value.slice(0, -mTag[0].length);
          } else {
            const chars = Array.from(ta.value);
            chars.pop();
            ta.value = chars.join('');
          }
          window.__cwChatCursorPos = ta.value.length;
          if (typeof window.__syncWechatSendButton === 'function') window.__syncWechatSendButton();
          ta.dispatchEvent(new Event('input', { bubbles: true }));
        });
        document.getElementById('customGifFileInput')?.addEventListener('change', (e) => {
          const f = e.target.files && e.target.files[0];
          if (!f) return;
          if (f.size > 3 * 1024 * 1024) {
            showToast(state.lang === 'zh' ? '请选择 3MB 以内的动图 (GIF) 🎞️' : '3MB 이하의 움짤(GIF)을 올려주세요 🎞️');
            e.target.value = '';
            return;
          }
          const reader = new FileReader();
          reader.onload = () => {
            if (!Array.isArray(state.customGifs)) state.customGifs = [];
            state.customGifs.unshift({ id: `gif_${Date.now()}`, name: f.name || 'gif', dataUrl: String(reader.result || ''), addedBy: state.myRole || 'suwan' });
            saveState(true);
            window.__activeStickerTab = 'gifs';
            renderChatStickers();
            showToast(state.lang === 'zh' ? '动图已添加并同步给对方 🎞️' : '우리 움짤에 추가되어 상대방과 공유됐어요 🎞️');
          };
          reader.readAsDataURL(f);
          e.target.value = '';
        });
        document.querySelectorAll('.sticker-tab-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            window.__activeStickerTab = btn.getAttribute('data-st-tab') || 'wechat';
            renderChatStickers();
          });
        });
        function renderChatStickers() {
          if (!stickerGrid) return;
          const isZhSt = state.lang === 'zh';
          const tab = window.__activeStickerTab || 'wechat';
          document.querySelectorAll('.sticker-tab-btn').forEach(b => {
            const act = b.getAttribute('data-st-tab') === tab;
            b.className = `sticker-tab-btn w-10 h-8 rounded-xl flex items-center justify-center transition ${act ? 'btn-royal' : 'btn-ghost'}`;
          });
          const bsBtn = document.getElementById('emojiBackspaceBtn');
          if (bsBtn) bsBtn.classList.toggle('hidden', tab !== 'wechat');
          if (tab === 'gifs') {
            const gifs = Array.isArray(state.customGifs) ? state.customGifs : [];
            delete stickerGrid.dataset.cwGridCacheKey;
            stickerGrid.className = 'cw-gif-grid-3 max-h-48 overflow-y-auto pr-0.5';
            stickerGrid.innerHTML = `
              <button type="button" id="addCustomGifBtn" class="royal-subcard hover:border-purple-400 rounded-xl aspect-square flex flex-col items-center justify-center gap-1 p-2 text-center border-dashed border transition" style="border-color: var(--border-accent);">
                <span class="text-2xl leading-none">＋</span>
                <span class="text-[10px] font-bold text-gold leading-tight">${isZhSt ? '添加动图\n(GIF)' : '움짤 추가\n(GIF)'}</span>
              </button>
              ${gifs.map(g => `
                <div class="relative royal-subcard rounded-xl aspect-square overflow-hidden group">
                  <button type="button" class="send-gif-btn w-full h-full block" data-id="${escapeHtml(g.id)}">
                    <img src="${g.dataUrl}" alt="gif" class="w-full h-full object-cover" />
                  </button>
                  <button type="button" class="del-gif-btn absolute top-1 right-1 w-5 h-5 rounded-full text-[10px] flex items-center justify-center text-white" style="background: rgba(20,12,35,0.72);" data-id="${escapeHtml(g.id)}">✕</button>
                </div>
              `).join('')}
            `;
            document.getElementById('addCustomGifBtn')?.addEventListener('click', () => document.getElementById('customGifFileInput')?.click());
            stickerGrid.querySelectorAll('.send-gif-btn').forEach(btn => {
              btn.addEventListener('click', () => {
                const g = (state.customGifs || []).find(x => x.id === btn.getAttribute('data-id'));
                if (!g) return;
                const sender = state.myRole || state.chat.activeSender || 'suwan';
                const senderName = sender === 'suwan' ? '수완(完)' : '靖灿(灿)';
                const isZh = state.lang === 'zh';
                ((__m) => { state.chat.messages.push(__m); try { if (__m && __m.sender === (state.myRole || "suwan")) { const __who = __m.sender === "jingchan" ? "靖灿" : "수완"; sendPartnerNativePush(`💌 ${__who}님의 새 메시지`, __m.original || (__m.photoUrl ? "📷 사진을 보냈어요" : (__m.audioUrl ? "🎙️ 음성 메시지를 보냈어요" : "새 메시지가 도착했어요"))); } } catch (_) {} })({
                  id: `msg_gif_${Date.now()}`, ts: Date.now(), sender, deliveryStatus: 'sending',
                  time: new Date().toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' }),
                  photoUrl: g.dataUrl,
                  original: isZh ? '🎞️ [动图]' : '🎞️ [움짤]',
                  translated: isZh ? '🎞️ [움짤]' : '🎞️ [动图]',
                  pronunciation: '', tone: '', nuance: '', engine: '', tgtLang: isZh ? 'ko' : 'zh',
                  replyTo: window.__pendingChatReply ? { ...window.__pendingChatReply } : null,
                  reactions: []
                });
                window.__pendingChatReply = null;
                document.getElementById('chatReplyBar')?.classList.add('hidden');
                if (stickerTray) stickerTray.classList.add('hidden');
                saveState(true); renderChat(); renderHome();
                pushNotification('🎞️', `${senderName}의 움짤`, `${senderName}发来动图`, '🎞️ 움짤을 보냈어요', '🎞️ 发来一张动图', 'translator', 'messenger', 'post', false, sender);
              });
            });
            stickerGrid.querySelectorAll('.del-gif-btn').forEach(btn => {
              btn.addEventListener('click', (ev) => {
                ev.stopPropagation();
                const gid = btn.getAttribute('data-id');
                openConfirm(
                  state.lang === 'zh' ? '删除收藏动图' : '저장된 움짤 삭제',
                  state.lang === 'zh' ? '确定要删除这个动图吗？' : '이 움짤을 삭제할까요?',
                  () => {
                    state.customGifs = (state.customGifs || []).filter(x => x.id !== gid);
                    saveState(true); renderChatStickers();
                  }
                );
              });
            });
            return;
          }
          if (tab === 'wechat') {
            let recentIcons = [];
            try { recentIcons = JSON.parse(localStorage.getItem('chanwan_recent_wechat_v2') || '[]'); } catch (_) {}
            if (!Array.isArray(recentIcons) || !recentIcons.length) {
              recentIcons = ['[捂脸]', '[旺柴]', '[破涕为笑]', '[呲牙]', '[亲亲]', '[害羞]', '[偷笑]', '[拥抱]'];
            }
            const cacheKey = `wc|${isZhSt ? 'zh' : 'ko'}|${recentIcons.slice(0, 7).join(',')}`;
            if (stickerGrid.dataset.cwGridCacheKey !== cacheKey || !stickerGrid.firstElementChild) {
              const renderWcCell = (tok) => {
                const meta = WECHAT_TAG_MAP.get(tok);
                if (meta) {
                  const lbl = isZhSt ? meta.zh : meta.ko;
                  return `<button type="button" class="insert-wc-emoji-btn flex flex-col items-center justify-center gap-0.5 py-1.5 rounded-xl active:scale-90 transition" data-icon="${escapeHtml(meta.tag)}" title="${escapeHtml(lbl)}">${getWechatEmoticonSvg(meta.tag, 30)}<span class="text-[9.5px] leading-tight text-mut truncate max-w-[42px]">${escapeHtml(lbl)}</span></button>`;
                }
                return `<button type="button" class="insert-wc-emoji-btn text-[24px] leading-none py-1 rounded-xl active:opacity-60" data-icon="${escapeHtml(tok)}">${escapeHtml(tok)}</button>`;
              };
              stickerGrid.className = 'space-y-2.5 max-h-[225px] overflow-y-auto px-0.5 pb-10';
              stickerGrid.innerHTML = `
                <div>
                  <div class="text-[11px] font-semibold text-mut px-1 mb-1">${isZhSt ? '最近使用 · 微信表情' : '최근 사용한 위챗 이모티콘'}</div>
                  <div class="grid grid-cols-7 gap-1 text-center">
                    ${recentIcons.slice(0, 7).map(renderWcCell).join('')}
                  </div>
                </div>
                <div>
                  <div class="text-[11px] font-semibold text-mut px-1 mb-1">${isZhSt ? '微信经典黄脸表情 (56种)' : '위챗 시그니처 이모티콘 (56종)'}</div>
                  <div class="grid grid-cols-7 gap-1 text-center">
                    ${WECHAT_OFFICIAL_EMOTICONS.map(em => renderWcCell(em.tag)).join('')}
                  </div>
                </div>
              `;
              stickerGrid.dataset.cwGridCacheKey = cacheKey;
            }
            if (!stickerGrid.__cwWcDelegated) {
              stickerGrid.__cwWcDelegated = true;
              stickerGrid.addEventListener('click', (ev) => {
                const btn = ev.target && ev.target.closest ? ev.target.closest('.insert-wc-emoji-btn') : null;
                if (!btn) return;
                ev.preventDefault();
                const icon = btn.getAttribute('data-icon') || '';
                const openEditBox = document.querySelector('[id^="editMsgBox_"]:not(.hidden)');
                const editTa = openEditBox ? openEditBox.querySelector('textarea') : null;
                const ta = editTa || document.getElementById('chatInput');
                if (!icon || !ta) return;
                const val = ta.value || '';
                if (editTa) {
                  const sPos = (typeof editTa.selectionStart === 'number' && editTa.selectionStart >= 0 && editTa.selectionStart <= val.length) ? editTa.selectionStart : val.length;
                  const ePos = (typeof editTa.selectionEnd === 'number' && editTa.selectionEnd >= sPos) ? editTa.selectionEnd : sPos;
                  editTa.value = val.slice(0, sPos) + icon + val.slice(ePos);
                  try { editTa.setSelectionRange(sPos + icon.length, sPos + icon.length); } catch (_) {}
                  editTa.dispatchEvent(new Event('input', { bubbles: true }));
                } else {
                  const pos = (typeof window.__cwChatCursorPos === 'number' && window.__cwChatCursorPos >= 0 && window.__cwChatCursorPos <= val.length)
                    ? window.__cwChatCursorPos
                    : val.length;
                  ta.value = val.slice(0, pos) + icon + val.slice(pos);
                  window.__cwChatCursorPos = pos + icon.length;
                  if (typeof window.__syncWechatSendButton === 'function') window.__syncWechatSendButton();
                }
                try {
                  let rec = JSON.parse(localStorage.getItem('chanwan_recent_wechat_v2') || '[]');
                  if (!Array.isArray(rec)) rec = [];
                  rec = [icon, ...rec.filter(x => x !== icon)].slice(0, 8);
                  localStorage.setItem('chanwan_recent_wechat_v2', JSON.stringify(rec));
                } catch (_) {}
              });
            }
            return;
          }
          delete stickerGrid.dataset.cwGridCacheKey;
          stickerGrid.className = 'cw-sticker-grid-4 max-h-44 overflow-y-auto pr-0.5';
          stickerGrid.innerHTML = COUPLE_STICKERS.map((st, idx) => `
            <button type="button" class="send-sticker-btn royal-subcard hover:border-purple-400 rounded-xl py-2 px-1 text-center transition flex flex-col items-center justify-center" data-idx="${idx}">
              <div class="flex items-center justify-center">${idx < 28 ? getPastelStickerSvg(idx, 42) : `<span class="text-2xl leading-none">${st.icon}</span>`}</div>
              <div class="text-[10px] font-semibold mt-1 truncate w-full text-sec">${escapeHtml(isZhSt ? st.zh : st.ko)}</div>
            </button>
          `).join('');
          stickerGrid.querySelectorAll('.send-sticker-btn').forEach(btn => {
            btn.addEventListener('click', () => {
              const st = COUPLE_STICKERS[Number(btn.getAttribute('data-idx'))];
              if (!st) return;
              const sender = state.myRole || state.chat.activeSender || 'suwan';
              const senderName = sender === 'suwan' ? '수완(完)' : '靖灿(灿)';
              const isZh = state.lang === 'zh';
              ((__m) => { state.chat.messages.push(__m); try { if (__m && __m.sender === (state.myRole || "suwan")) { const __who = __m.sender === "jingchan" ? "靖灿" : "수완"; sendPartnerNativePush(`💌 ${__who}님의 새 메시지`, __m.original || (__m.photoUrl ? "📷 사진을 보냈어요" : (__m.audioUrl ? "🎙️ 음성 메시지를 보냈어요" : "새 메시지가 도착했어요"))); } } catch (_) {} })({
                id: `msg_st_${Date.now()}`, ts: Date.now(), sender, deliveryStatus: 'sending',
                time: new Date().toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' }),
                sticker: st.icon,
                stickerIdx: Number(btn.getAttribute('data-idx')),
                original: isZh ? st.zh : st.ko,
                translated: isZh ? st.ko : st.zh,
                pronunciation: '', tone: '🎀 커플 스티커', nuance: '', engine: '', tgtLang: isZh ? 'ko' : 'zh',
                replyTo: window.__pendingChatReply ? { ...window.__pendingChatReply } : null,
                reactions: []
              });
              window.__pendingChatReply = null;
              document.getElementById('chatReplyBar')?.classList.add('hidden');
              if (stickerTray) stickerTray.classList.add('hidden');
              saveState(true); renderChat(); renderHome();
              pushNotification(st.icon, `${senderName}의 스티커`, `${senderName}发来表情贴纸`, `${st.icon} ${st.ko}`, `${st.icon} ${st.zh}`, 'translator', 'messenger', 'post', false, sender);
            });
          });
        }
        window.renderChatStickers = renderChatStickers;
        renderChatStickers();
        const chatPlusBtn = document.getElementById('chatPlusBtn');
        const chatPlusDrawer = document.getElementById('chatPlusDrawer');
        function renderChatPinnedBanner() {
          const bar = document.getElementById('chatPinnedBanner');
          const au = document.getElementById('chatPinnedAuthor');
          const tx = document.getElementById('chatPinnedText');
          if (!bar || !au || !tx) return;
          const p = state.chat && state.chat.pinnedMsg;
          if (!p || !p.text) {
            bar.classList.add('hidden');
            return;
          }
          const isZh = state.lang === 'zh';
          const who = p.authorRole === 'jingchan' ? (isZh ? '靖灿' : '징찬') : (isZh ? '完' : '수완');
          const primary = isZh ? (p.translated && /[一-鿿]/.test(p.translated) ? p.translated : p.text) : (p.translated && /[가-힣]/.test(p.translated) && !/[가-힣]/.test(p.text) ? p.translated : p.text);
          au.textContent = who;
          tx.textContent = primary;
          bar.classList.remove('hidden');
        }
        window.__renderChatPinnedBanner = renderChatPinnedBanner;
        document.getElementById('unpinChatNoticeBtn')?.addEventListener('click', () => {
          if (!state.chat) state.chat = {};
          state.chat.pinnedMsg = { id: '', text: '', translated: '', updatedAt: Date.now() };
          saveState(true);
          renderChatPinnedBanner();
          showToast(state.lang === 'zh' ? '已取消置顶公告' : '상단 공지 고정을 해제했어요');
        });
        const __supportsFieldSizing = (typeof CSS !== 'undefined' && typeof CSS.supports === 'function' && CSS.supports('field-sizing', 'content'));
        const __cachedChatSendBtn = document.getElementById('chatSendBtn');
        let __lastShowSendState = null;
        let __chatTaIsMultiLine = false;
        let __chatHeightRaf = 0;

        function syncWechatSendButton() {
          const rawVal = chatInputTa ? chatInputTa.value : '';
          const hasText = rawVal.length > 0 && /\S/.test(rawVal);
          const hasMedia = !!(pendingChatPhotoUrl || (Array.isArray(pendingChatPhotos) && pendingChatPhotos.length > 0));
          const showSend = hasText || hasMedia;
          if (showSend !== __lastShowSendState) {
            __lastShowSendState = showSend;
            const sBtn = __cachedChatSendBtn || document.getElementById('chatSendBtn');
            if (sBtn) {
              sBtn.classList.toggle('hidden', !showSend);
              if (!showSend) {
                sBtn.disabled = false;
                sBtn.textContent = state.lang === 'zh' ? '发送' : '전송';
              }
            }
            if (chatPlusBtn) chatPlusBtn.classList.toggle('hidden', showSend);
          }
          if (!chatInputTa || __supportsFieldSizing) return;
          // Zero-reflow single-line fast path: never touch style.height or read scrollHeight for short single-line input!
          if (!rawVal) {
            if (__chatTaIsMultiLine || chatInputTa.style.height) {
              chatInputTa.style.height = '';
              __chatTaIsMultiLine = false;
            }
            return;
          }
          const mightWrap = rawVal.indexOf('\n') !== -1 || rawVal.length > 22 || __chatTaIsMultiLine;
          if (!mightWrap) return;
          if (__chatHeightRaf) return;
          __chatHeightRaf = requestAnimationFrame(() => {
            __chatHeightRaf = 0;
            if (!chatInputTa) return;
            const vNow = chatInputTa.value || '';
            if (!vNow) {
              chatInputTa.style.height = '';
              __chatTaIsMultiLine = false;
              return;
            }
            chatInputTa.style.height = 'auto';
            const nextH = Math.min(chatInputTa.scrollHeight, 66);
            chatInputTa.style.height = nextH + 'px';
            __chatTaIsMultiLine = nextH > 34;
          });
        }
        window.__syncWechatSendButton = syncWechatSendButton;
        const saveChatCursorAndDismissKb = () => {
          if (!chatInputTa) return;
          if (typeof chatInputTa.selectionStart === 'number') {
            window.__cwChatCursorPos = chatInputTa.selectionStart;
          }
          if (document.activeElement === chatInputTa) {
            try { chatInputTa.blur(); } catch (_) {}
          }
        };
        const syncChatPlusBtnIcon = (isOpen) => {
          if (!chatPlusBtn) return;
          if (isOpen) {
            chatPlusBtn.innerHTML = CW_MEDIA_SVG.closeDrawer;
          } else {
            chatPlusBtn.innerHTML = (typeof window.getAppIconHtml === 'function' && window.getAppIconHtml('plus'))
              ? `<span class="cw-ico-slot inline-flex items-center justify-center" data-ico="plus">${window.getAppIconHtml('plus')}</span>`
              : CW_MEDIA_SVG.closeDrawer;
          }
        };
        window.__syncChatPlusBtnIcon = syncChatPlusBtnIcon;
        const bindInstantDrawerToggle = (btnEl, onToggle) => {
          if (!btnEl) return;
          let lastPtrTs = 0;
          btnEl.addEventListener('pointerdown', (ev) => {
            if (ev.pointerType === 'mouse' && ev.button !== 0) return;
            ev.preventDefault();
            ev.stopPropagation();
            lastPtrTs = Date.now();
            window.__cwLastDrawerToggleTs = lastPtrTs;
            onToggle();
          });
          btnEl.addEventListener('click', (ev) => {
            ev.stopPropagation();
            if (Date.now() - lastPtrTs < 450) {
              ev.preventDefault();
              return;
            }
            window.__cwLastDrawerToggleTs = Date.now();
            onToggle();
          });
        };
        const chatSendBtnEl = document.getElementById('chatSendBtn');
        if (chatSendBtnEl) {
          chatSendBtnEl.addEventListener('pointerdown', (ev) => {
            // Keep current focus state untouched (if keyboard is open, keep it open; if closed/emoji drawer, keep keyboard closed!)
            ev.preventDefault();
          });
        }
        if (chatInputTa) {
          chatInputTa.addEventListener('input', () => {
            syncWechatSendButton();
          });
          chatInputTa.addEventListener('click', () => {
            if (typeof chatInputTa.selectionStart === 'number') window.__cwChatCursorPos = chatInputTa.selectionStart;
          }, { passive: true });
        }
        if (chatPlusBtn && chatPlusDrawer) {
          bindInstantDrawerToggle(chatPlusBtn, () => {
            const willOpen = chatPlusDrawer.classList.contains('hidden');
            if (willOpen) {
              saveChatCursorAndDismissKb();
              if (stickerTray) stickerTray.classList.add('hidden');
              chatPlusDrawer.classList.remove('hidden');
              if (typeof window.__scrollChatToBottom === 'function') window.__scrollChatToBottom(true);
            } else {
              chatPlusDrawer.classList.add('hidden');
            }
            syncChatPlusBtnIcon(willOpen);
          });
          ['chatCameraBtn', 'chatVideoCamBtn', 'chatPhotoBtn'].forEach(id => {
            document.getElementById(id)?.addEventListener('click', () => {
              chatPlusDrawer.classList.add('hidden');
              syncChatPlusBtnIcon(false);
            });
          });
        }
        if (stickerBtn && stickerTray) {
          bindInstantDrawerToggle(stickerBtn, () => {
            const willOpen = stickerTray.classList.contains('hidden');
            if (willOpen) {
              saveChatCursorAndDismissKb();
              if (chatPlusDrawer && !chatPlusDrawer.classList.contains('hidden')) {
                chatPlusDrawer.classList.add('hidden');
              }
              syncChatPlusBtnIcon(false);
              if ((window.__activeStickerTab || 'wechat') === 'wechat') renderChatStickers();
              stickerTray.classList.remove('hidden');
              if (typeof window.__scrollChatToBottom === 'function') window.__scrollChatToBottom(true);
            } else {
              stickerTray.classList.add('hidden');
            }
          });
        }
        document.getElementById('chatReplyClearBtn')?.addEventListener('click', () => {
          window.__pendingChatReply = null;
          document.getElementById('chatReplyBar')?.classList.add('hidden');
        });

        // Plus 1.4: Reliable Multi-Frame Auto-Scroll Helper for Messenger (never lets keyboard or drawer cover bottom messages!)
        let __cwScrollTimers = [];
        function scrollChatToBottom(afterSendOrResize) {
          const applyBot = () => {
            const listEl = document.getElementById('chatMessagesList');
            if (!listEl) return;
            listEl.scrollTop = listEl.scrollHeight + 200;
          };
          applyBot();
          requestAnimationFrame(applyBot);
          if (afterSendOrResize) {
            __cwScrollTimers.forEach(t => clearTimeout(t));
            __cwScrollTimers = [
              setTimeout(applyBot, 70),
              setTimeout(applyBot, 180),
              setTimeout(applyBot, 310)
            ];
          }
        }
        window.__scrollChatToBottom = scrollChatToBottom;
        // Mobile Virtual Keyboard Overlap Prevention (Android WebView adjustResize + Chrome + iOS Safari)
        let cwBaseVh = window.innerHeight || (window.visualViewport ? window.visualViewport.height : 700);
        let cwKbBlurTimer = null;
        let __lastAppliedVvh = 0;
        let __prevObservedVh = cwBaseVh;
        let __lastKbOpen = false;
        const __isNativeWebViewApk = typeof window.ChanwanNative !== 'undefined';
        function syncChatKeyboardViewport(forceFocusState) {
          try {
            const vv = window.visualViewport;
            const vh = vv ? Math.round(vv.height) : window.innerHeight;
            const vTop = vv ? Math.max(0, Math.round(vv.offsetTop)) : 0;
            if (vh > cwBaseVh) cwBaseVh = vh;
            const vhDroppedNow = (__prevObservedVh - vh) >= 24;
            __prevObservedVh = vh;

            const trPanel = document.getElementById('tab-translator');
            const isChatActive = !!(trPanel && trPanel.classList.contains('active'));
            const actEl = document.activeElement;
            const isChatTextFocused = !!(actEl && (actEl.id === 'chatInput' || (actEl.tagName === 'TEXTAREA' && actEl.closest('#chatMessagesList')) || (actEl.tagName === 'INPUT' && actEl.closest('#trans-sub-messenger'))));
            const heightShrank = (cwBaseVh - vh) > 110;
            const kbOpen = isChatActive && (forceFocusState === true || isChatTextFocused || heightShrank);

            if (isChatActive) {
              if (!__isNativeWebViewApk && Math.abs(vh - __lastAppliedVvh) >= 6) {
                __lastAppliedVvh = vh;
                document.documentElement.style.setProperty('--cw-vvh', vh + 'px');
              }
              if (!__isNativeWebViewApk) {
                document.documentElement.style.setProperty('--cw-vv-top', (kbOpen ? vTop : 0) + 'px');
              }
            } else {
              __lastAppliedVvh = 0;
              document.documentElement.style.removeProperty('--cw-vvh');
              document.documentElement.style.removeProperty('--cw-vv-top');
            }
            const kbJustOpened = kbOpen && !__lastKbOpen;
            __lastKbOpen = kbOpen;
            document.documentElement.classList.toggle('cw-kb-open', kbOpen);
            document.body.classList.toggle('cw-kb-open', kbOpen);
            if (isChatActive && (kbJustOpened || vhDroppedNow)) {
              const ml = document.getElementById('chatMessagesList');
              const distFromBot = ml ? (ml.scrollHeight - ml.scrollTop - ml.clientHeight) : 0;
              const recentlySent = (Date.now() - (window.__cwLastChatSendTs || 0)) < 2500;
              if (!ml || distFromBot < 360 || recentlySent) {
                scrollChatToBottom(true);
              }
            }
          } catch (_) {}
        }
        window.__syncChatKeyboardViewport = syncChatKeyboardViewport;
        let __vvRafId = 0;
        const scheduleViewportSync = () => {
          if (__vvRafId) return;
          __vvRafId = requestAnimationFrame(() => {
            __vvRafId = 0;
            syncChatKeyboardViewport();
          });
        };
        if (window.visualViewport) {
          window.visualViewport.addEventListener('resize', scheduleViewportSync, { passive: true });
        }
        window.addEventListener('resize', scheduleViewportSync, { passive: true });

        // Typing signal (off-thread, throttled 3.2s), zero compositionupdate overhead!
        let lastTypingSigTs = 0;
        if (chatInputTa) {
          chatInputTa.addEventListener('input', () => {
            const rawV = chatInputTa.value;
            const hasTxt = rawV.length > 0 && /\S/.test(rawV);
            const now = Date.now();
            if (hasTxt && (now - lastTypingSigTs) > 3200) {
              lastTypingSigTs = now;
              window.__cwWasTyping = true;
              setTimeout(() => {
                if (typeof window.__sendChatSignal === 'function') window.__sendChatSignal('typing', { active: true });
              }, 0);
            } else if (!hasTxt && window.__cwWasTyping) {
              window.__cwWasTyping = false;
              lastTypingSigTs = 0;
              setTimeout(() => {
                if (typeof window.__sendChatSignal === 'function') window.__sendChatSignal('typing', { active: false });
              }, 0);
            }
          });
          chatInputTa.addEventListener('focus', () => {
            if (cwKbBlurTimer) { clearTimeout(cwKbBlurTimer); cwKbBlurTimer = null; }
            if (stickerTray && !stickerTray.classList.contains('hidden')) stickerTray.classList.add('hidden');
            if (chatPlusDrawer && !chatPlusDrawer.classList.contains('hidden')) {
              chatPlusDrawer.classList.add('hidden');
              if (typeof window.__syncChatPlusBtnIcon === 'function') window.__syncChatPlusBtnIcon(false);
            }
            syncChatKeyboardViewport(true);
            setTimeout(() => syncChatKeyboardViewport(true), 180);
            if (typeof window.__emitChatReadIfVisible === 'function') window.__emitChatReadIfVisible(false);
          });
          chatInputTa.addEventListener('blur', () => {
            if (typeof chatInputTa.selectionStart === 'number') window.__cwChatCursorPos = chatInputTa.selectionStart;
            if (window.__cwWasTyping) {
              window.__cwWasTyping = false;
              if (typeof window.__sendChatSignal === 'function') window.__sendChatSignal('typing', { active: false });
            }
            if (cwKbBlurTimer) clearTimeout(cwKbBlurTimer);
            cwKbBlurTimer = setTimeout(() => syncChatKeyboardViewport(false), 90);
          });
        }
        document.querySelectorAll('.dock-item[data-tab="translator"]').forEach(b => {
          b.addEventListener('click', () => {
            setTimeout(() => {
              scrollChatToBottom(false);
              if (typeof window.__emitChatReadIfVisible === 'function') window.__emitChatReadIfVisible(false);
            }, 60);
          });
        });
        document.getElementById('chatMessagesList')?.addEventListener('click', () => {
          if (typeof window.__emitChatReadIfVisible === 'function') window.__emitChatReadIfVisible(false);
        });

        // Quick 1-Tap Messenger Voice Message Bubble (WeChat style)
        let cmRec = null, cmStream = null, cmTimer = null, cmMax = null, cmStartTs = 0, cmIsRec = false, cmConnecting = false;
        let cmPcmCtx = null, cmPcmProc = null, cmPcmBufs = [];
        const chatVoiceBtn = document.getElementById('chatVoiceMsgBtn');
        const cmCleanup = () => {
          if (cmTimer) { clearInterval(cmTimer); cmTimer = null; }
          if (cmMax) { clearTimeout(cmMax); cmMax = null; }
          if (cmPcmProc) { try { cmPcmProc.disconnect(); } catch (_) {} cmPcmProc = null; }
          if (cmPcmCtx) { try { cmPcmCtx.close(); } catch (_) {} cmPcmCtx = null; }
          if (cmStream) { try { cmStream.getTracks().forEach(t => t.stop()); } catch (_) {} cmStream = null; }
          cmRec = null; cmIsRec = false; cmConnecting = false;
          if (chatVoiceBtn) {
            chatVoiceBtn.classList.remove('btn-royal', 'badge-pulse', 'cw-vrec-active');
            chatVoiceBtn.classList.add('btn-ghost');
            chatVoiceBtn.innerHTML = '<span class="cw-ico-slot inline-flex items-center justify-center" data-ico="voice"></span>';
            if (typeof window.__refreshIconSlots === 'function') window.__refreshIconSlots(chatVoiceBtn);
            else if (typeof window.syncAllTabIconsToStyle === 'function') window.syncAllTabIconsToStyle(null, chatVoiceBtn);
          }
        };
        const sendQuickVoiceBubble = (rawAudioDataUrl) => {
          const audioDataUrl = normalizeAudioDataUrl(rawAudioDataUrl);
          if (!audioDataUrl) return;
          const sender = state.myRole || state.chat.activeSender || 'suwan';
          const senderName = sender === 'suwan' ? '수완(完)' : '靖灿(灿)';
          if (!String(audioDataUrl).startsWith('data:audio/')) return;
          const nowEpoch = Date.now();
          const msgId = `msg_v_${nowEpoch}`;
          const tStr = new Date().toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' });
          const origTxt = state.lang === 'zh' ? '🎙️ 语音消息' : '🎙️ 음성 메시지';
          const trTxt = state.lang === 'zh' ? '🎙️ 음성 메시지' : '🎙️ 语音消息';
          ((__m) => { state.chat.messages.push(__m); try { if (__m && __m.sender === (state.myRole || "suwan")) { const __who = __m.sender === "jingchan" ? "靖灿" : "수완"; sendPartnerNativePush(`💌 ${__who}님의 새 메시지`, __m.original || (__m.photoUrl ? "📷 사진을 보냈어요" : (__m.audioUrl ? "🎙️ 음성 메시지를 보냈어요" : "새 메시지가 도착했어요"))); } } catch (_) {} })({
            id: msgId, ts: nowEpoch, sender, deliveryStatus: 'sending', time: tStr, original: origTxt, translated: trTxt,
            pronunciation: '', tone: '🎙️ 보이스 챗', nuance: '', engine: '', tgtLang: state.lang === 'zh' ? 'ko' : 'zh',
            audioUrl: audioDataUrl,
            replyTo: window.__pendingChatReply ? { ...window.__pendingChatReply } : null,
            reactions: []
          });
          window.__pendingChatReply = null;
          document.getElementById('chatReplyBar')?.classList.add('hidden');
          if (!Array.isArray(state.voiceLetters)) state.voiceLetters = [];
          const vlArchId = `vl_chat_${msgId}`;
          if (!state.voiceLetters.some(v => v && v.id === vlArchId)) {
            state.voiceLetters.unshift({
              id: vlArchId, sender, source: 'messenger',
              tag: state.lang === 'zh' ? '💬 聊天语音' : '💬 메신저 음성',
              note: '', translated: '',
              date: getKstDateString(), time: tStr, audioUrl: audioDataUrl
            });
          }
          saveState(true); renderChat(); renderHome();
          if (typeof renderVoiceLetters === 'function') renderVoiceLetters();
          if (typeof window.__pushMediaSyncPacket === 'function') {
            const ext = audioDataUrl.includes('audio/wav') ? 'wav' : (audioDataUrl.includes('audio/mp4') ? 'mp4' : 'webm');
            window.__pushMediaSyncPacket('chat_voice', { msgId, sender, time: tStr, original: origTxt, translated: trTxt, tgtLang: state.lang === 'zh' ? 'ko' : 'zh' }, audioDataUrl, `chatvoice.${ext}`);
          }
          showToast(state.lang === 'zh' ? '🎙️ 语音消息已发送！' : '🎙️ 음성 메시지를 보냈어요!');
          pushNotification('🎙️', `${senderName}의 음성 메시지`, `${senderName}发来语音消息`, '메신저에서 바로 들어보세요 💜', '快去聊天里听听吧 💜', 'translator', 'messenger', 'post', false, sender);
        };
        let pendingVoiceDataUrl = '', pendingVoiceAudio = null, pendingVoicePlaying = false;
        const setPrevPlayBtnState = (playing) => {
          const pBtn = document.getElementById('chatVoicePrevPlayBtn');
          if (!pBtn) return;
          pBtn.classList.toggle('cw-prev-playing', !!playing);
          pBtn.innerHTML = playing ? CW_MEDIA_SVG.stop : CW_MEDIA_SVG.play;
        };
        const closeVoiceConfirmBar = () => {
          if (pendingVoiceAudio) { try { pendingVoiceAudio.pause(); } catch (_) {} pendingVoiceAudio = null; }
          pendingVoicePlaying = false;
          pendingVoiceDataUrl = '';
          const bar = document.getElementById('chatVoiceConfirmBar');
          setPrevPlayBtnState(false);
          if (bar) bar.classList.add('hidden');
        };
        const openVoiceConfirmBar = (dataUrl, sec) => {
          if (!dataUrl || !String(dataUrl).startsWith('data:audio/')) return;
          closeVoiceConfirmBar();
          pendingVoiceDataUrl = dataUrl;
          const isZh = state.lang === 'zh';
          const mm = String(Math.floor(sec / 60)).padStart(2, '0');
          const ss = String(sec % 60).padStart(2, '0');
          const bar = document.getElementById('chatVoiceConfirmBar');
          const ttl = document.getElementById('chatVoicePrevTitle');
          const sub = document.getElementById('chatVoicePrevSub');
          const cBtn = document.getElementById('chatVoicePrevCancelBtn');
          const sBtn = document.getElementById('chatVoicePrevSendBtn');
          if (ttl) ttl.innerHTML = `<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" style="color: var(--accent-royal); flex-shrink:0;"><path d="M4 10v4M8 7v10M12 4v16M16 7v10M20 10v4"/></svg><span>${isZh ? `录音完成 (${mm}:${ss})` : `음성 녹음 완료 (${mm}:${ss})`}</span>`;
          if (sub) sub.textContent = isZh ? '先试听确认后再发送哦' : '미리 들어보고 확인 후 전송해 주세요';
          if (cBtn) cBtn.innerHTML = `<svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg><span>${isZh ? '取消' : '취소'}</span>`;
          if (sBtn) sBtn.innerHTML = `<svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 2L11 13"/><path d="M22 2L15 22l-4-9-9-4 20-7z"/></svg><span>${isZh ? '发送' : '전송'}</span>`;
          if (bar) bar.classList.remove('hidden');
        };
        document.getElementById('chatVoicePrevPlayBtn')?.addEventListener('click', () => {
          if (!pendingVoiceDataUrl) return;
          if (pendingVoicePlaying && pendingVoiceAudio) {
            try { pendingVoiceAudio.pause(); } catch (_) {}
            pendingVoicePlaying = false;
            setPrevPlayBtnState(false);
            return;
          }
          try {
            pendingVoiceAudio = new Audio(pendingVoiceDataUrl);
            pendingVoiceAudio.onended = () => { pendingVoicePlaying = false; setPrevPlayBtnState(false); };
            pendingVoiceAudio.onerror = () => { pendingVoicePlaying = false; setPrevPlayBtnState(false); };
            pendingVoicePlaying = true;
            setPrevPlayBtnState(true);
            pendingVoiceAudio.play().catch(() => { pendingVoicePlaying = false; setPrevPlayBtnState(false); });
          } catch (_) {}
        });
        document.getElementById('chatVoicePrevCancelBtn')?.addEventListener('click', () => {
          closeVoiceConfirmBar();
          showToast(state.lang === 'zh' ? '已取消语音发送' : '음성 메시지 전송을 취소했어요');
        });
        document.getElementById('chatVoicePrevSendBtn')?.addEventListener('click', () => {
          const urlToSend = pendingVoiceDataUrl;
          closeVoiceConfirmBar();
          if (urlToSend) sendQuickVoiceBubble(urlToSend);
        });

        let cmUsingNativeBridgeRec = false;
        const stopCmRec = () => {
          if (!cmIsRec) return;
          if (cmTimer) { clearInterval(cmTimer); cmTimer = null; }
          if (cmMax) { clearTimeout(cmMax); cmMax = null; }
          if (cmUsingNativeBridgeRec && window.ChanwanNative && typeof window.ChanwanNative.stopNativeAudioRecord === 'function') {
            cmUsingNativeBridgeRec = false;
            const recMs = Date.now() - cmStartTs;
            let b64Url = '';
            try { b64Url = String(window.ChanwanNative.stopNativeAudioRecord() || ''); } catch (_) {}
            cmCleanup();
            if (recMs >= 600 && b64Url.startsWith('data:audio/')) {
              openVoiceConfirmBar(b64Url, Math.max(1, Math.round(recMs / 1000)));
            } else {
              showToast(state.lang === 'zh' ? '录音时间太短已取消（请录满1秒）' : '녹음이 너무 짧아 취소됐어요 (1초 이상 말씀해 주세요)');
            }
            return;
          }
          if (cmRec && cmRec.state !== 'inactive') {
            try { cmRec.requestData && cmRec.requestData(); } catch (_) {}
            try { cmRec.stop(); } catch (_) { cmCleanup(); }
            return;
          }
          if (cmPcmBufs.length) {
            const sec = Math.max(1, Math.round((Date.now() - cmStartTs) / 1000));
            const sr = cmPcmCtx ? cmPcmCtx.sampleRate : 16000;
            const wav = encodePcmToWavDataUrl(cmPcmBufs, sr);
            cmPcmBufs = []; cmCleanup(); openVoiceConfirmBar(wav, sec);
            return;
          }
          cmCleanup();
        };
        const openCwMicPermModal = (customReason) => {
          const modal = document.getElementById('cwMicPermModal');
          if (!modal) return;
          const isZh = state.lang === 'zh';
          const hasNat = typeof window.ChanwanNative !== 'undefined';
          const webMicSupported = !!(navigator.mediaDevices && typeof navigator.mediaDevices.getUserMedia === 'function');
          const ttl = document.getElementById('cwMicModalTitle');
          const dsc = document.getElementById('cwMicModalDesc');
          const reqBtn = document.getElementById('cwMicRequestNowBtn');
          const setBtn = document.getElementById('cwMicOpenSettingsBtn');
          const natBtn = document.getElementById('cwMicNativeRecBtn');
          if (ttl) ttl.textContent = isZh ? '开启麦克风 · 发送语音消息' : '마이크 권한 허용 · 음성 보내기';
          if (dsc) {
            if (customReason === 'denied_browser') {
              dsc.textContent = isZh
                ? '⚠️ 当前浏览器已拦截此网页麦克风！请点击浏览器地址栏旁的「🔒 或设置图标 → 允许麦克风」，或直接点下方黄色按钮用手机自带录音发送 💜'
                : '⚠️ 현재 브라우저에서 마이크 권한이 차단되어 있어요! 주소창 옆 「🔒 자물쇠 → 사이트 설정 → 마이크 허용」으로 켜주시거나, 바로 아래 노란 버튼을 눌러 녹음해 보내주세요 💜';
            } else if (!hasNat && !webMicSupported) {
              dsc.textContent = isZh
                ? '当前浏览器（如微信内置页）不支持网页直接录音，请直接点击下方黄色按钮「用手机自带录音发送」即可秒发语音 💜'
                : '현재 브라우저에서는 웹 직접 녹음을 지원하지 않아요. 바로 아래 노란 버튼 「휴대폰 기본 녹음기로 보내기」를 누르면 바로 녹음해 전송돼요 💜';
            } else {
              dsc.textContent = isZh
                ? (hasNat ? '点击下方紫色按钮即可开启麦克风并录音；若曾点过拒绝，会自动为您打开系统权限页开启麦克风 💜' : '点击下方紫色按钮弹出浏览器麦克风授权；若无法弹出，可直接点黄色按钮用手机录音发送 💜')
                : (hasNat ? '아래 보라색 버튼을 누르면 바로 권한 허용 또는 설정 창이 열려요! 허용 후 즉시 앱 안에서 녹음됩니다 💜' : '아래 보라색 버튼으로 마이크 허용 창을 띄우거나, 노란 버튼으로 바로 휴대폰 녹음기를 열어 보낼 수 있어요 💜');
            }
          }
          if (reqBtn) {
            reqBtn.classList.toggle('hidden', !hasNat && !webMicSupported);
            reqBtn.textContent = isZh ? '🎙️ 立即允许麦克风并开始录音' : '🎙️ 지금 마이크 권한 허용하고 녹음하기';
          }
          if (setBtn) {
            setBtn.textContent = isZh ? '⚙️ 打开灿完时光权限设置（手动开启麦克风）' : '⚙️ 앱 권한 설정 바로 열기 (마이크 켜기)';
            setBtn.classList.toggle('hidden', !(hasNat && typeof window.ChanwanNative.openAppSettings === 'function'));
          }
          if (natBtn) natBtn.textContent = isZh ? '📱 用手机自带录音机直接录制发送' : '📱 휴대폰 기본 녹음기로 바로 녹음·전송';
          modal.classList.remove('hidden');
        };
        window.__openCwMicPermModal = openCwMicPermModal;

        const buildLiveRecBadgeHtml = (tLabel) => `<span class="inline-flex items-center gap-1.5">${CW_MEDIA_SVG.stopBadge}<svg viewBox="0 0 15 16" width="13" height="13" fill="none"><line class="cw-wave-bar" x1="2.5" y1="4" x2="2.5" y2="12" stroke="#ffffff" stroke-width="2.1" stroke-linecap="round"/><line class="cw-wave-bar b2" x1="7.5" y1="2" x2="7.5" y2="14" stroke="#ffffff" stroke-width="2.1" stroke-linecap="round"/><line class="cw-wave-bar b3" x1="12.5" y1="4" x2="12.5" y2="12" stroke="#ffffff" stroke-width="2.1" stroke-linecap="round"/></svg><span class="text-[10.5px] font-bold tabular-nums leading-none">${tLabel}</span></span>`;

        const startCmVoiceRecording = async (fromModalRetry) => {
          const isZh = state.lang === 'zh';
          if (cmIsRec) { stopCmRec(); return; }
          if (cmConnecting) return;
          try { if (typeof stopVoiceRecognition === 'function') stopVoiceRecognition(); } catch (_) {}

          // Engine 0 (100% Bulletproof Native APK MediaRecorder — bypasses WebView getUserMedia bugs completely!)
          const hasNativeApkBridge = typeof window.ChanwanNative !== 'undefined';
          if (hasNativeApkBridge) {
            const hasMic = typeof window.ChanwanNative.hasMicPermission === 'function' ? !!window.ChanwanNative.hasMicPermission() : false;
            if (!hasMic) {
              if (fromModalRetry && typeof window.ChanwanNative.requestMicPermission === 'function') {
                try { window.ChanwanNative.requestMicPermission(); } catch (_) {}
              } else {
                openCwMicPermModal();
              }
              return;
            }
            if (typeof window.ChanwanNative.startNativeAudioRecord === 'function') {
              try {
                const startedNat = !!window.ChanwanNative.startNativeAudioRecord();
                if (startedNat) {
                  document.getElementById('cwMicPermModal')?.classList.add('hidden');
                  cmUsingNativeBridgeRec = true;
                  cmConnecting = false;
                  cmIsRec = true;
                  cmStartTs = Date.now();
                  if (chatVoiceBtn) {
                    chatVoiceBtn.classList.remove('btn-ghost');
                    chatVoiceBtn.classList.add('cw-vrec-active');
                    chatVoiceBtn.innerHTML = buildLiveRecBadgeHtml('0:00');
                  }
                  cmTimer = setInterval(() => {
                    const sec = Math.floor((Date.now() - cmStartTs) / 1000);
                    if (chatVoiceBtn) chatVoiceBtn.innerHTML = buildLiveRecBadgeHtml(`${Math.floor(sec / 60)}:${String(sec % 60).padStart(2, '0')}`);
                  }, 500);
                  cmMax = setTimeout(() => { if (cmIsRec) stopCmRec(); }, 45000);
                  return;
                }
              } catch (_) {}
            }
          }

          if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            openCwMicPermModal('unsupported');
            return;
          }
          cmConnecting = true;
          if (chatVoiceBtn) chatVoiceBtn.innerHTML = '<svg class="animate-spin" viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><circle cx="12" cy="12" r="9" opacity="0.25"/><path d="M21 12a9 9 0 0 0-9-9"/></svg>';
          try {
            const stream = await requestSafeAudioStream();
            document.getElementById('cwMicPermModal')?.classList.add('hidden');
            cmConnecting = false; cmStream = stream; cmIsRec = true; cmStartTs = Date.now();
            if (chatVoiceBtn) {
              chatVoiceBtn.classList.remove('btn-ghost');
              chatVoiceBtn.classList.add('cw-vrec-active');
              chatVoiceBtn.innerHTML = buildLiveRecBadgeHtml('0:00');
            }
            cmTimer = setInterval(() => {
              const sec = Math.floor((Date.now() - cmStartTs) / 1000);
              if (chatVoiceBtn) chatVoiceBtn.innerHTML = buildLiveRecBadgeHtml(`${Math.floor(sec / 60)}:${String(sec % 60).padStart(2, '0')}`);
            }, 500);
            let ok = false;
            if (typeof MediaRecorder !== 'undefined') {
              try {
                const mime = ['audio/webm;codecs=opus', 'audio/webm', 'audio/ogg;codecs=opus', 'audio/mp4'].find(m => MediaRecorder.isTypeSupported && MediaRecorder.isTypeSupported(m)) || '';
                const rec = mime ? new MediaRecorder(stream, { mimeType: mime }) : new MediaRecorder(stream);
                const chunks = [];
                cmRec = rec;
                rec.ondataavailable = (ev) => { if (ev.data && ev.data.size > 0) chunks.push(ev.data); };
                rec.onstop = () => {
                  try {
                    const recMs = Date.now() - cmStartTs;
                    const outMime = (rec.mimeType || mime || (chunks[0] && chunks[0].type) || 'audio/webm').split(';')[0];
                    const blob = new Blob(chunks, { type: outMime });
                    if (recMs >= 600 && blob.size > 400) {
                      const sec = Math.max(1, Math.round(recMs / 1000));
                      const r = new FileReader();
                      r.onloadend = () => {
                        let dUrl = String(r.result || '');
                        if (dUrl.startsWith('data:video/')) dUrl = 'data:audio/' + dUrl.slice(11);
                        openVoiceConfirmBar(dUrl, sec);
                      };
                      r.readAsDataURL(blob);
                    } else if (cmPcmBufs.length) {
                      const sec = Math.max(1, Math.round(recMs / 1000));
                      const sr = cmPcmCtx ? cmPcmCtx.sampleRate : 16000;
                      openVoiceConfirmBar(encodePcmToWavDataUrl(cmPcmBufs, sr), sec);
                    } else {
                      showToast(state.lang === 'zh' ? '录音时间太短已自动取消（请录满1秒）' : '녹음이 너무 짧아 취소됐어요 (1초 이상 말씀해 주세요)');
                    }
                  } catch (_) {}
                  cmCleanup();
                };
                rec.start(250); ok = true;
              } catch (_) { cmRec = null; }
            }
            if (!ok) {
              const AC = window.AudioContext || window.webkitAudioContext;
              cmPcmCtx = new AC();
              if (cmPcmCtx.state === 'suspended') { try { await cmPcmCtx.resume(); } catch (_) {} }
              const src = cmPcmCtx.createMediaStreamSource(stream);
              cmPcmProc = cmPcmCtx.createScriptProcessor(4096, 1, 1);
              cmPcmBufs = [];
              cmPcmProc.onaudioprocess = (e) => { if (cmIsRec) cmPcmBufs.push(new Float32Array(e.inputBuffer.getChannelData(0))); };
              src.connect(cmPcmProc); cmPcmProc.connect(cmPcmCtx.destination);
            }
            cmMax = setTimeout(() => { if (cmIsRec) stopCmRec(); }, 45000);
          } catch (recErr) {
            cmCleanup();
            openCwMicPermModal('denied_browser');
          }
        };

        window.__onNativeMicGranted = () => {
          document.getElementById('cwMicPermModal')?.classList.add('hidden');
          startCmVoiceRecording(true);
        };

        if (chatVoiceBtn) {
          chatVoiceBtn.addEventListener('click', () => startCmVoiceRecording(false));
        }
        // Delegated listeners for #cwMicPermModal (Note: #cwMicNativeRecBtn is now a native <label for="cwNativeVoiceCaptureInput"> so browser opens recorder natively!)
        document.addEventListener('click', (e) => {
          const t = e.target;
          if (!t || !t.closest) return;
          if (t.id === 'cwMicPermModal' || t.closest('#cwMicModalCloseBtn')) {
            document.getElementById('cwMicPermModal')?.classList.add('hidden');
            return;
          }
          if (t.closest('#cwMicOpenSettingsBtn')) {
            document.getElementById('cwMicPermModal')?.classList.add('hidden');
            if (window.ChanwanNative && typeof window.ChanwanNative.openAppSettings === 'function') {
              try { window.ChanwanNative.openAppSettings(); } catch (_) {}
            } else {
              showToast(state.lang === 'zh' ? '请点浏览器地址栏旁 🔒 图标允许麦克风' : '주소창 옆 🔒 아이콘 → 사이트 설정에서 마이크를 허용해 주세요');
            }
            return;
          }
          if (t.closest('#cwMicRequestNowBtn')) {
            const hasNat = !!(window.ChanwanNative && typeof window.ChanwanNative.requestMicPermission === 'function');
            if (hasNat) {
              const alreadyGranted = typeof window.ChanwanNative.hasMicPermission === 'function' ? !!window.ChanwanNative.hasMicPermission() : false;
              if (alreadyGranted) {
                document.getElementById('cwMicPermModal')?.classList.add('hidden');
                startCmVoiceRecording(true);
              } else {
                try { window.ChanwanNative.requestMicPermission(); } catch (_) {}
              }
              return;
            }
            if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
              const natInp = document.getElementById('cwNativeVoiceCaptureInput');
              if (natInp) { try { natInp.click(); } catch (_) {} }
              openCwMicPermModal('unsupported');
              return;
            }
            // Synchronous call inside user tap gesture!
            startCmVoiceRecording(true);
          }
        });
        document.addEventListener('change', (e) => {
          const inp = e.target;
          if (!inp || inp.id !== 'cwNativeVoiceCaptureInput') return;
          const f = inp.files && inp.files[0];
          if (!f) return;
          document.getElementById('cwMicPermModal')?.classList.add('hidden');
          const r = new FileReader();
          r.onloadend = () => {
            const dUrl = normalizeAudioDataUrl(String(r.result || ''));
            openVoiceConfirmBar(dUrl, Math.max(2, Math.round((f.size || 16000) / 8000)));
          };
          r.readAsDataURL(f);
          inp.value = '';
        });


        // Patch Notes (Bilingual Changelog History — updated every release)
        const PATCH_NOTES_HISTORY = [
        {
          ver: 'Prime 4 · v67',
          date: '2026-11-26',
          koTitle: 'Prime 4 정식 완성 · 초고속 Gemini 3.5 번역 · 무제한 동영상 · 명품 부티크 UI',
          zhTitle: 'Prime 4 正式版 · 极速 Gemini 3.5 翻译 · 无限大视频 · 精品奢华界面',
          koItems: [
            '⚡ 초고속 Gemini 3.5 Flash-Lite 번역: 추론 최소화·즉시 번역 중 표시·캐시 0ms 응답, 수완·징찬(俊灿 포함)·자기·오빠 커플 호칭 완벽 교정',
            '🎬 무제한 병렬 동영상 & 사진첩 폴더 영구 저장: 10MB·30MB 제한 해제, 3배속 병렬 분할 전송, 말풍선 동영상 불러오기, 사진첩 폴더 이동 리셋 버그 완전 해결',
            '💬 커플 메신저 확장: 말풍선 스와이프 답장·더블탭 하트·사랑해/보고싶어 이펙트·퀵 멘트 바·커플 배경 꾸미기·실시간 상태 배지(양쪽 동기화)·추억 타임머신',
            '✨ 명품 부티크 UI & 안정성: 라이트/다크 전 테마 가독성 통일, 잘림 없는 툴바·배지·하단 여백, 깔끔한 1줄 알림 배너, 앱 재실행 시 항상 홈 시작, 한↔中 전체 즉시 전환'
          ],
          zhItems: [
            '⚡ 极速 Gemini 3.5 Flash-Lite 翻译：极简推理与 0ms 缓存秒翻，全面纠偏秀完/靖灿/宝贝/欧巴等恋人称呼与撒娇口语',
            '🎬 无限容量并行视频与相册文件夹永久同步：解除 10MB/30MB 限制，3倍速分片直传，支持气泡一键加载视频，彻底修复相册移动重置问题',
            '💬 情侣互动全新升级：气泡右滑回复、双击点赞红心、想你/我爱你全屏特效、快捷短语栏、自定义聊天背景、双方实时状态徽章与回忆时光机',
            '✨ 精品奢华界面与流畅体验：浅色/深色全主题高对比度、零裁切状态栏与底部安全区、极简通知横幅、重启直达首页、中韩界面一键全量切换'
          ]
        }
        ];
        function renderPatchNotes() {
          const isZh = state.lang === 'zh';
          const titleEl = document.getElementById('patchNotesTitle');
          const bodyEl = document.getElementById('patchNotesBody');
          if (titleEl) titleEl.textContent = isZh ? '📜 灿完时光 Prime 4 · v67 更新日志' : '📜 灿完时光 Prime 4 · v67 업데이트 소식';
          if (!bodyEl) return;
          const latestOnly = PATCH_NOTES_HISTORY.slice(0, 1);
          bodyEl.innerHTML = latestOnly.map((entry) => `
            <div class="royal-subcard rounded-2xl p-3.5 space-y-2" style="border: 1px solid var(--border-accent);">
              <div class="flex items-center justify-between gap-2">
                <div class="font-bold text-gold">✨ ${escapeHtml(entry.ver)} · ${escapeHtml(isZh ? entry.zhTitle : entry.koTitle)}</div>
                <span class="text-[10px] text-mut shrink-0">${escapeHtml(entry.date)}</span>
              </div>
              <div class="space-y-1.5 text-[11.5px] leading-relaxed">
                ${(isZh ? entry.zhItems : entry.koItems).map(item => `<p>• ${item}</p>`).join('')}
              </div>
            </div>
          `).join('');
        }
        const pModal = document.getElementById('patchNotesModal');
        document.getElementById('openPatchNotesBtn2').addEventListener('click', () => { renderPatchNotes(); pModal.classList.remove('hidden'); });
        document.getElementById('closePatchNotesModal').addEventListener('click', () => pModal.classList.add('hidden'));
        pModal.addEventListener('click', (e) => { if (e.target === pModal) pModal.classList.add('hidden'); });

        // ==================== CW TALK KEYWORD SEARCH & MEDIA/LINK VAULT ====================
        window.__chatSearchQuery = '';
        window.__chatVaultTab = 'media';
        const chatSearchBar = document.getElementById('chatSearchBar');
        const chatSearchInput = document.getElementById('chatSearchInput');
        document.getElementById('toggleChatSearchBtn')?.addEventListener('click', () => {
          if (!chatSearchBar) return;
          chatSearchBar.classList.toggle('hidden');
          if (!chatSearchBar.classList.contains('hidden')) { chatSearchInput?.focus(); }
          else { window.__chatSearchQuery = ''; if (chatSearchInput) chatSearchInput.value = ''; renderChat(); }
        });
        document.getElementById('closeChatSearchBtn')?.addEventListener('click', () => {
          if (chatSearchBar) chatSearchBar.classList.add('hidden');
          window.__chatSearchQuery = '';
          if (chatSearchInput) chatSearchInput.value = '';
          renderChat();
        });
        chatSearchInput?.addEventListener('input', () => {
          window.__chatSearchQuery = chatSearchInput.value || '';
          renderChat();
        });

        window.renderChatVault = renderChatVault;
        function renderChatVault() {
          const body = document.getElementById('chatVaultBody');
          if (!body) return;
          const isZh = state.lang === 'zh';
          const tab = window.__chatVaultTab || 'media';
          document.querySelectorAll('.vault-tab-btn').forEach(b => {
            const act = b.getAttribute('data-vault-tab') === tab;
            b.className = `vault-tab-btn ${act ? 'btn-royal' : 'btn-ghost'} py-2 px-2 rounded-xl text-xs font-bold whitespace-nowrap`;
          });
          if (state.chat && Array.isArray(state.chat.messages) && state.chat.messages.length > 1 && typeof sortChatMessagesStable === 'function') {
            state.chat.messages = sortChatMessagesStable(state.chat.messages);
          }
          const msgs = state.chat.messages || [];
          if (tab === 'media') {
            const mediaItems = [];
            msgs.slice().reverse().forEach(m => {
              if (Array.isArray(m.photoUrls) && m.photoUrls.length) {
                m.photoUrls.forEach(u => mediaItems.push({ photoUrl: u, sender: m.sender, time: m.time }));
              } else if (m.photoUrl || m.videoUrl) {
                mediaItems.push(m);
              }
            });
            if (!mediaItems.length) {
              body.innerHTML = `<div class="royal-subcard rounded-2xl p-8 text-center text-xs text-mut">${isZh ? '聊天中还没有发送过照片或视频 🖼️' : '메신저에서 주고받은 사진·영상이 아직 없어요 🖼️'}</div>`;
              return;
            }
            if (!window.__chatVaultLimit || window.__chatVaultLimit < 18) window.__chatVaultLimit = 18;
            const shownMedia = mediaItems.slice(0, window.__chatVaultLimit);
            const remainMedia = mediaItems.length - shownMedia.length;
            body.innerHTML = `<div class="grid grid-cols-2 sm:grid-cols-3 gap-2">${shownMedia.map(m => `
              <div class="royal-subcard rounded-2xl overflow-hidden flex flex-col">
                <div class="aspect-square bg-purple-100/30 relative overflow-hidden">
                  ${m.videoUrl
                    ? `<video src="${__cwMediaUrl(m.videoUrl, 'video/mp4')}" controls playsinline webkit-playsinline preload="none" class="w-full h-full object-cover bg-black/85"></video>`
                    : `<button type="button" class="cw-zoom-direct w-full h-full block" data-src="${__cwMediaUrl(m.photoUrl)}"><img src="${__cwMediaUrl(m.photoUrl)}" alt="media" loading="lazy" decoding="async" class="w-full h-full object-cover" /></button>`}
                </div>
                <div class="px-2 py-1.5 text-[10px] text-mut flex items-center justify-between gap-1">
                  <span class="truncate">${m.sender === 'suwan' ? '수완' : '靖灿'}</span>
                  <span class="shrink-0">${escapeHtml(m.time || '')}</span>
                </div>
              </div>
            `).join('')}</div>${remainMedia > 0 ? `<button type="button" onclick="window.__chatVaultLimit=(window.__chatVaultLimit||18)+18;renderChatVault();" class="w-full mt-3 py-2.5 rounded-2xl btn-ghost text-xs font-bold">${isZh ? `查看更多 (${remainMedia} 项)` : `더 보기 (${remainMedia}개 남음)`}</button>` : ''}`;
          } else {
            const urlRx = /https?:\/\/[^\s<>"'\)\]]+/gi;
            const links = [];
            msgs.slice().reverse().forEach(m => {
              const found = String(m.original || '').match(urlRx);
              if (found) {
                found.forEach(u => {
                  let host = u;
                  try { host = new URL(u).hostname.replace(/^www\./, ''); } catch (_) {}
                  links.push({ url: u, host, sender: m.sender === 'suwan' ? '수완(完)' : '靖灿(灿)', time: m.time || '', text: m.original });
                });
              }
            });
            if (!links.length) {
              body.innerHTML = `<div class="royal-subcard rounded-2xl p-8 text-center text-xs text-mut">${isZh ? '聊天中还没有分享过链接 🔗' : '메신저에서 주고받은 링크가 아직 없어요 🔗'}</div>`;
              return;
            }
            body.innerHTML = links.map(lk => `
              <a href="${escapeHtml(lk.url)}" target="_blank" rel="noopener noreferrer" class="royal-subcard rounded-2xl p-3 flex items-start justify-between gap-2.5 hover:opacity-90 transition block">
                <div class="min-w-0 flex-1 space-y-1">
                  <div class="flex items-center gap-1.5 text-[10px]">
                    <span class="px-2 py-0.5 rounded-full font-semibold" style="background: var(--accent-royal-soft); color: var(--accent-royal);">🔗 ${escapeHtml(lk.host)}</span>
                    <span class="text-mut">${escapeHtml(lk.sender)} · ${escapeHtml(lk.time)}</span>
                  </div>
                  <div class="text-xs font-semibold text-gold truncate">${escapeHtml(lk.url)}</div>
                </div>
                <span class="text-xs text-mut shrink-0 pt-1">↗</span>
              </a>
            `).join('');
          }
        }
        // ==================== Plus 1.3: FULLSCREEN PHOTO LIGHTBOX CONTROLLER ====================
        let lbList = [], lbIndex = 0;
        const lbModal = document.getElementById('photoLightboxModal');
        const lbImg = document.getElementById('lightboxImg');
        const lbVid = document.getElementById('lightboxVideo');
        const lbCount = document.getElementById('lightboxCounter');
        const lbDl = document.getElementById('lightboxDownloadBtn');
        const lbPrev = document.getElementById('lightboxPrevBtn');
        const lbNext = document.getElementById('lightboxNextBtn');
        let lbMediaKind = 'image';
        function closePhotoLightbox() {
          if (lbVid) { try { lbVid.pause(); } catch (_) {} lbVid.src = ''; lbVid.classList.add('hidden'); }
          lbModal?.classList.add('hidden');
        }
        function renderLightboxSlide() {
          if (!lbList.length) return;
          lbIndex = (lbIndex + lbList.length) % lbList.length;
          const curUrl = lbList[lbIndex];
          if (lbMediaKind === 'video') {
            if (lbImg) lbImg.classList.add('hidden');
            if (lbVid) { lbVid.src = curUrl; lbVid.classList.remove('hidden'); lbVid.play().catch(() => {}); }
            if (lbDl) { lbDl.href = curUrl; lbDl.setAttribute('download', 'chanwan_video.mp4'); }
          } else {
            if (lbVid) { try { lbVid.pause(); } catch (_) {} lbVid.classList.add('hidden'); }
            if (lbImg) { lbImg.src = curUrl; lbImg.classList.remove('hidden'); }
            if (lbDl) { lbDl.href = curUrl; lbDl.setAttribute('download', 'chanwan_photo.jpg'); }
          }
          if (lbCount) lbCount.textContent = lbList.length > 1 ? `${lbIndex + 1} / ${lbList.length}` : '';
          if (lbPrev) lbPrev.classList.toggle('hidden', lbList.length <= 1);
          if (lbNext) lbNext.classList.toggle('hidden', lbList.length <= 1);
        }
        function openPhotoLightbox(urls, startIdx = 0, kind = 'image') {
          lbMediaKind = kind || 'image';
          lbList = (Array.isArray(urls) ? urls : [urls]).filter(Boolean);
          if (!lbList.length) return;
          lbIndex = startIdx || 0;
          renderLightboxSlide();
          lbModal?.classList.remove('hidden');
        }
        window.openPhotoLightbox = openPhotoLightbox;
        document.getElementById('closeLightboxBtn')?.addEventListener('click', closePhotoLightbox);
        lbPrev?.addEventListener('click', (e) => { e.stopPropagation(); lbIndex--; renderLightboxSlide(); });
        lbNext?.addEventListener('click', (e) => { e.stopPropagation(); lbIndex++; renderLightboxSlide(); });
        lbModal?.addEventListener('click', (e) => { if (e.target === lbModal) closePhotoLightbox(); });
        // Delegated click for CW Talk, Chat Vault, and Album photos!
        document.addEventListener('click', (e) => {
          if (window.__cwSuppressZoomUntil && Date.now() < window.__cwSuppressZoomUntil) return;
          const zBtn = e.target.closest('.cw-zoom-photo');
          if (zBtn) {
            const msgId = zBtn.getAttribute('data-msg-id');
            const idx = Number(zBtn.getAttribute('data-idx') || 0);
            const msg = (state.chat && state.chat.messages || []).find(x => x && x.id === msgId);
            if (msg) {
              const urls = (Array.isArray(msg.photoUrls) && msg.photoUrls.length) ? msg.photoUrls : [msg.photoUrl];
              openPhotoLightbox(urls, idx);
            }
            return;
          }
          const vBtn = e.target.closest('.cw-zoom-video');
          if (vBtn) {
            const u = vBtn.getAttribute('data-src');
            if (u) openPhotoLightbox([u], 0, 'video');
            return;
          }
          const dBtn = e.target.closest('.cw-zoom-direct');
          if (dBtn) {
            const u = dBtn.getAttribute('data-src');
            if (u) openPhotoLightbox([u], 0, 'image');
          }
        });

        const chatVaultModal = document.getElementById('chatVaultModal');
        document.getElementById('openChatVaultBtn')?.addEventListener('click', () => { renderChatVault(); chatVaultModal?.classList.remove('hidden'); });
        document.getElementById('closeChatVaultModal')?.addEventListener('click', () => chatVaultModal?.classList.add('hidden'));
        chatVaultModal?.addEventListener('click', (e) => { if (e.target === chatVaultModal) chatVaultModal.classList.add('hidden'); });
        document.querySelectorAll('.vault-tab-btn').forEach(btn => {
          btn.addEventListener('click', () => { window.__chatVaultTab = btn.getAttribute('data-vault-tab') || 'media'; renderChatVault(); });
        });

        // ==================== SHARED MONTHLY COUPLE CALENDAR ====================
        const todayStrInit = getKstDateString();
        const [initY, initM] = todayStrInit.split('-').map(Number);
        window.__calYear = initY;
        window.__calMonth = initM; // 1..12
        window.__calSelectedDate = todayStrInit;

        function renderCoupleCalendar() {
          const isZh = state.lang === 'zh';
          const y = window.__calYear, m = window.__calMonth;
          const titleEl = document.getElementById('calMonthTitle');
          const gridEl = document.getElementById('calGridDays');
          if (!gridEl) return;
          if (titleEl) titleEl.textContent = isZh ? `${y}年 ${m}月` : `${y}년 ${m}월`;

          const firstDay = new Date(y, m - 1, 1).getDay();
          const daysInMonth = new Date(y, m, 0).getDate();
          const todayKey = getKstDateString();
          const pad2 = n => String(n).padStart(2, '0');

          const schedSet = new Set((state.schedules || []).map(s => s.date));
          const diarySet = new Set((state.diaries || []).map(d => d.date));
          const annivSet = new Set((state.anniversaries || []).map(a => a.date));
          const annivMdSet = new Set((state.anniversaries || []).filter(a => a.date).map(a => a.date.slice(5)));

          let cells = '';
          for (let i = 0; i < firstDay; i++) cells += '<div></div>';
          for (let d = 1; d <= daysInMonth; d++) {
            const dk = `${y}-${pad2(m)}-${pad2(d)}`;
            const md = `${pad2(m)}-${pad2(d)}`;
            const isSel = dk === window.__calSelectedDate;
            const isToday = dk === todayKey;
            const hasSched = schedSet.has(dk);
            const hasAnniv = annivSet.has(dk) || annivMdSet.has(md);
            const hasDiary = diarySet.has(dk);
            cells += `
              <button type="button" class="cal-day-btn rounded-xl py-1.5 px-1 flex flex-col items-center justify-center gap-0.5 text-xs transition ${isSel ? 'btn-royal font-bold' : (isToday ? 'royal-subcard font-bold text-gold' : 'hover:opacity-80')}" data-date="${dk}">
                <span>${d}</span>
                <span class="flex items-center justify-center gap-0.5 h-1.5">
                  ${hasSched ? '<span class="w-1.5 h-1.5 rounded-full bg-purple-400"></span>' : ''}
                  ${hasAnniv ? '<span class="w-1.5 h-1.5 rounded-full bg-pink-400"></span>' : ''}
                  ${hasDiary ? '<span class="w-1.5 h-1.5 rounded-full bg-sky-400"></span>' : ''}
                </span>
              </button>`;
          }
          gridEl.innerHTML = cells;
          gridEl.querySelectorAll('.cal-day-btn').forEach(btn => {
            btn.addEventListener('click', () => { window.__calSelectedDate = btn.getAttribute('data-date'); renderCoupleCalendar(); });
          });

          const sel = window.__calSelectedDate;
          const selMd = sel.slice(5);
          const lblEl = document.getElementById('calSelectedDateLabel');
          if (lblEl) lblEl.textContent = `📅 ${sel}`;

          const dayScheds = (state.schedules || []).filter(s => s.date === sel);
          const dayAnnivs = (state.anniversaries || []).filter(a => a.date === sel || (a.date && a.date.slice(5) === selMd));
          const dayDiaries = (state.diaries || []).filter(d => d.date === sel);

          const listEl = document.getElementById('calSelectedList');
          if (!listEl) return;
          const rows = [];
          dayAnnivs.forEach(a => rows.push(`
            <div class="royal-subcard rounded-2xl p-3 flex items-center justify-between gap-2">
              <div class="text-xs font-semibold">🩷 ${escapeHtml(a.title)} <span class="text-[10px] text-mut">(${escapeHtml(a.date)})</span></div>
            </div>`));
          dayScheds.forEach(s => {
            const sTrOk = s.translated && !/^\[(?:한국어|中文)\]\s*/.test(String(s.translated));
            rows.push(`
            <div class="royal-subcard rounded-2xl p-3 flex items-start justify-between gap-2">
              <div class="min-w-0 flex-1 space-y-0.5">
                <div class="text-xs font-semibold break-words">🟣 ${escapeHtml(s.text)}</div>
                ${sTrOk ? `<div class="text-[11px] text-gold break-words">${escapeHtml(s.translated)}</div>` : ''}
                <div class="text-[10px] text-mut">${escapeHtml(s.author || '')}</div>
              </div>
              <div class="flex items-center gap-1.5 shrink-0">
                <button type="button" class="retrans-cal-sched-btn text-xs text-mut hover:text-gold" data-id="${escapeHtml(s.id)}" title="${isZh ? '重新翻译' : '재번역'}">🔄</button>
                <button type="button" class="del-sched-btn text-xs text-mut hover:text-rose-400" data-id="${escapeHtml(s.id)}">✕</button>
              </div>
            </div>`);
          });
          const seenCalDiaries = new Set();
          const uniqueDayDiaries = dayDiaries.filter(d => {
            if (!d) return false;
            const dk = `${String(d.author || '').trim()}|${String(d.title || '').trim()}|${String(d.content || '').trim()}`;
            if (seenCalDiaries.has(dk)) return false;
            seenCalDiaries.add(dk);
            return true;
          });
          uniqueDayDiaries.forEach(d => {
            const tTrOk = d.titleTranslated && !/^\[(?:한국어|中文)\]\s*/.test(String(d.titleTranslated));
            const cTrOk = d.translated && !/^\[(?:한국어|中文)\]\s*/.test(String(d.translated));
            const showBody = String(d.content || '').trim() && String(d.content || '').trim() !== String(d.title || '').trim();
            rows.push(`
            <div class="royal-subcard rounded-2xl p-3 flex items-start justify-between gap-2">
              <div class="min-w-0 flex-1 space-y-0.5">
                <div class="text-xs font-semibold break-words">🩵 ${escapeHtml(d.title)} <span class="text-[10px] text-mut">· ${escapeHtml(d.author)}</span></div>
                ${tTrOk ? `<div class="text-[11px] text-gold break-words">${escapeHtml(d.titleTranslated)}</div>` : ''}
                ${showBody ? `<div class="text-[11px] text-sec break-words">${escapeHtml(d.content)}</div>` : ''}
                ${cTrOk && (!tTrOk || String(d.translated).trim() !== String(d.titleTranslated).trim()) ? `<div class="text-[11px] text-gold break-words">${escapeHtml(d.translated)}</div>` : ''}
              </div>
              <button type="button" class="retrans-cal-diary-btn text-xs text-mut hover:text-gold shrink-0" data-id="${escapeHtml(d.id)}" title="${isZh ? '重新翻译' : '재번역'}">🔄</button>
            </div>`);
          });

          listEl.innerHTML = rows.length ? rows.join('') : `<div class="text-center text-xs text-mut py-4">${isZh ? '这一天还没有日程或记录 ✨' : '이 날짜에 등록된 일정이나 기록이 없어요 ✨'}</div>`;
          listEl.querySelectorAll('.retrans-cal-sched-btn').forEach(btn => {
            btn.addEventListener('click', async () => {
              const sid = btn.getAttribute('data-id');
              const s = (state.schedules || []).find(x => x && x.id === sid);
              if (!s || !s.text) return;
              btn.disabled = true; btn.textContent = '⏳';
              try {
                const r = await geminiTranslate(s.text, 'casual');
                if (r && r.translated && !/^\[(?:한국어|中文)\]\s*/.test(String(r.translated))) {
                  s.translated = r.translated;
                  saveState(true); renderCoupleCalendar();
                } else { btn.disabled = false; btn.textContent = '🔄'; }
              } catch (_) { btn.disabled = false; btn.textContent = '🔄'; }
            });
          });
          listEl.querySelectorAll('.retrans-cal-diary-btn').forEach(btn => {
            btn.addEventListener('click', async () => {
              const did = btn.getAttribute('data-id');
              const d = (state.diaries || []).find(x => x && x.id === did);
              if (!d) return;
              btn.disabled = true; btn.textContent = '⏳';
              try {
                if (d.title) {
                  const rt = await geminiTranslate(d.title, 'lover');
                  if (rt && rt.translated && !/^\[(?:한국어|中文)\]\s*/.test(String(rt.translated))) d.titleTranslated = rt.translated;
                }
                if (d.content) {
                  const rc = await geminiTranslate(d.content, 'lover');
                  if (rc && rc.translated && !/^\[(?:한국어|中文)\]\s*/.test(String(rc.translated))) d.translated = rc.translated;
                }
                saveState(true); renderCoupleCalendar();
                if (typeof renderDiaries === 'function') renderDiaries();
              } catch (_) { btn.disabled = false; btn.textContent = '🔄'; }
            });
          });
          if (!window.__cwCalAutoFixIds) window.__cwCalAutoFixIds = new Set();
          uniqueDayDiaries.forEach(d => {
            if (!d || !d.id || window.__cwCalAutoFixIds.has(d.id)) return;
            const needT = d.title && (!d.titleTranslated || /^\[(?:한국어|中文)\]\s*/.test(String(d.titleTranslated)));
            const needC = d.content && (!d.translated || /^\[(?:한국어|中文)\]\s*/.test(String(d.translated)));
            if (needT || needC) {
              window.__cwCalAutoFixIds.add(d.id);
              (async () => {
                let updated = false;
                if (needT) {
                  const rt = await geminiTranslate(d.title, 'lover').catch(() => null);
                  if (rt && rt.translated && !/^\[(?:한국어|中文)\]\s*/.test(String(rt.translated))) { d.titleTranslated = rt.translated; updated = true; }
                }
                if (needC) {
                  const rc = await geminiTranslate(d.content, 'lover').catch(() => null);
                  if (rc && rc.translated && !/^\[(?:한국어|中文)\]\s*/.test(String(rc.translated))) { d.translated = rc.translated; updated = true; }
                }
                if (updated) { saveState(true); renderCoupleCalendar(); }
              })();
            }
          });
          listEl.querySelectorAll('.del-sched-btn').forEach(btn => {
            btn.addEventListener('click', () => {
              const sid = btn.getAttribute('data-id');
              openConfirm(
                state.lang === 'zh' ? '删除日程' : '일정 삭제',
                state.lang === 'zh' ? '确定要删除这条日程吗？' : '이 일정을 삭제할까요?',
                () => {
                  state.schedules = (state.schedules || []).filter(x => x.id !== sid);
                  saveState(true); renderCoupleCalendar();
                }
              );
            });
          });
        }
        window.renderCoupleCalendar = renderCoupleCalendar;

        document.getElementById('calPrevMonthBtn')?.addEventListener('click', () => {
          window.__calMonth--; if (window.__calMonth < 1) { window.__calMonth = 12; window.__calYear--; }
          renderCoupleCalendar();
        });
        document.getElementById('calNextMonthBtn')?.addEventListener('click', () => {
          window.__calMonth++; if (window.__calMonth > 12) { window.__calMonth = 1; window.__calYear++; }
          renderCoupleCalendar();
        });
        document.getElementById('calTodayBtn')?.addEventListener('click', () => {
          const t = getKstDateString(); const [ty, tm] = t.split('-').map(Number);
          window.__calYear = ty; window.__calMonth = tm; window.__calSelectedDate = t;
          renderCoupleCalendar();
        });
        document.getElementById('calScheduleForm')?.addEventListener('submit', async (e) => {
          e.preventDefault();
          const inp = document.getElementById('calScheduleInput');
          const text = inp ? inp.value.trim() : '';
          if (!text) return;
          inp.value = '';
          const res = await geminiTranslate(text, 'casual');
          const author = (state.myRole === 'jingchan') ? '靖灿(灿)' : '수완(完)';
          if (!Array.isArray(state.schedules)) state.schedules = [];
          state.schedules.unshift({ id: `sch_${Date.now()}`, date: window.__calSelectedDate, author, text, translated: res.translated });
          saveState(true); renderCoupleCalendar();
          pushNotification('📅', `${author}의 새 일정 (${window.__calSelectedDate})`, `${author}添加了新日程 (${window.__calSelectedDate})`, text, res.translated, 'diary', 'calendar', 'post', false);
        });

        // ==================== 4-DIGIT PIN APP LOCK (PER-DEVICE) ====================
        const PIN_KEY = 'chanwan_pin_lock_v1';
        let pinMode = 'unlock'; // 'unlock' | 'setup1' | 'setup2'
        let pinBuffer = '';
        let pinFirstEntry = '';
        const pinOverlay = document.getElementById('pinLockOverlay');
        const pinTitleEl = document.getElementById('pinOverlayTitle');
        const pinDescEl = document.getElementById('pinOverlayDesc');
        const pinCancelBtn = document.getElementById('pinCancelBtn');
        const pinForgotBtn = document.getElementById('pinForgotBtn');

        function updatePinSettingsUI() {
          const hasPin = !!localStorage.getItem(PIN_KEY);
          const badge = document.getElementById('pinLockStatusBadge');
          const setBtn = document.getElementById('setupPinBtn');
          const offBtn = document.getElementById('disablePinBtn');
          const isZh = state.lang === 'zh';
          if (badge) {
            badge.textContent = hasPin ? 'ON' : 'OFF';
            badge.style.background = hasPin ? 'rgba(16,185,129,0.14)' : 'var(--surface-2)';
            badge.style.color = hasPin ? '#059669' : 'var(--text-muted)';
          }
          if (setBtn) setBtn.textContent = hasPin ? (isZh ? '修改 PIN' : 'PIN 변경') : (isZh ? '设置 PIN' : 'PIN 설정');
          if (offBtn) offBtn.classList.toggle('hidden', !hasPin);
        }
        function renderPinDots() {
          document.querySelectorAll('#pinDotsRow .pin-dot').forEach((dot, idx) => {
            dot.style.background = idx < pinBuffer.length ? 'var(--accent-royal)' : 'transparent';
          });
        }
        function openPinOverlay(mode) {
          pinMode = mode; pinBuffer = ''; pinFirstEntry = '';
          const isZh = state.lang === 'zh';
          if (pinTitleEl) pinTitleEl.textContent = mode === 'unlock' ? (isZh ? '灿完时光 已锁定' : '灿完时光 잠금') : (isZh ? '设置 4 位 PIN' : '4자리 PIN 설정');
          if (pinDescEl) pinDescEl.textContent = mode === 'unlock' ? (isZh ? '请输入 4 位解锁密码' : '4자리 PIN 번호를 입력해 주세요') : (isZh ? '请输入新的 4 位数字密码' : '사용할 4자리 숫자를 입력해 주세요');
          if (pinCancelBtn) pinCancelBtn.classList.toggle('invisible', mode === 'unlock');
          if (pinForgotBtn) pinForgotBtn.classList.toggle('hidden', mode !== 'unlock');
          renderPinDots();
          pinOverlay?.classList.remove('hidden');
        }
        function handlePinComplete() {
          const isZh = state.lang === 'zh';
          if (pinMode === 'unlock') {
            if (pinBuffer === localStorage.getItem(PIN_KEY)) {
              pinOverlay?.classList.add('hidden');
              pinBuffer = ''; renderPinDots();
            } else {
              pinBuffer = ''; renderPinDots();
              if (pinDescEl) pinDescEl.textContent = isZh ? '密码不正确，请重试 ❌' : 'PIN 번호가 틀렸어요. 다시 입력해 주세요 ❌';
            }
          } else if (pinMode === 'setup1') {
            pinFirstEntry = pinBuffer; pinBuffer = ''; pinMode = 'setup2'; renderPinDots();
            if (pinDescEl) pinDescEl.textContent = isZh ? '请再次输入以确认' : '확인을 위해 한 번 더 입력해 주세요';
          } else if (pinMode === 'setup2') {
            if (pinBuffer === pinFirstEntry) {
              localStorage.setItem(PIN_KEY, pinBuffer);
              pinOverlay?.classList.add('hidden');
              updatePinSettingsUI();
              showToast(isZh ? '4位 PIN 应用锁已开启 🔒' : '4자리 PIN 앱 잠금이 설정되었어요 🔒');
            } else {
              pinMode = 'setup1'; pinBuffer = ''; pinFirstEntry = ''; renderPinDots();
              if (pinDescEl) pinDescEl.textContent = isZh ? '两次输入不一致，请重新输入' : '번호가 일치하지 않아요. 처음부터 다시 입력해 주세요';
            }
          }
        }
        document.querySelectorAll('.pin-key').forEach(btn => {
          btn.addEventListener('click', () => {
            if (pinBuffer.length >= 4) return;
            pinBuffer += btn.getAttribute('data-key');
            renderPinDots();
            if (pinBuffer.length === 4) setTimeout(handlePinComplete, 120);
          });
        });
        document.getElementById('pinBackspaceBtn')?.addEventListener('click', () => { pinBuffer = pinBuffer.slice(0, -1); renderPinDots(); });
        pinCancelBtn?.addEventListener('click', () => { if (pinMode !== 'unlock') pinOverlay?.classList.add('hidden'); });
        pinForgotBtn?.addEventListener('click', () => {
          localStorage.removeItem(PIN_KEY);
          pinOverlay?.classList.add('hidden');
          updatePinSettingsUI();
          showToast(state.lang === 'zh' ? 'PIN 锁已重置 🔓' : 'PIN 잠금이 초기화되었어요 🔓');
        });
        document.getElementById('setupPinBtn')?.addEventListener('click', () => openPinOverlay('setup1'));
        document.getElementById('disablePinBtn')?.addEventListener('click', () => {
          localStorage.removeItem(PIN_KEY);
          updatePinSettingsUI();
          showToast(state.lang === 'zh' ? 'PIN 锁已关闭 🔓' : 'PIN 앱 잠금이 해제되었어요 🔓');
        });
        updatePinSettingsUI();
        if (localStorage.getItem(PIN_KEY)) openPinOverlay('unlock');

        // ==================== NOTIFICATION SOUND PICKER & CUSTOM UPLOAD ====================
        function syncSoundToneUI() {
          const cur = localStorage.getItem(SOUND_TONE_KEY) || state.settings.notifTone || 'chime';
          const hasCustom = !!localStorage.getItem(CUSTOM_SOUND_KEY);
          const customBtn = document.getElementById('customSoundToneBtn');
          const infoBox = document.getElementById('customSoundFileInfo');
          const nameEl = document.getElementById('customSoundFileName');
          if (customBtn) customBtn.classList.toggle('hidden', !hasCustom);
          if (infoBox) infoBox.classList.toggle('hidden', !hasCustom);
          if (nameEl && hasCustom) nameEl.textContent = localStorage.getItem(CUSTOM_SOUND_NAME_KEY) || 'custom.mp3';
          document.querySelectorAll('.sound-tone-btn').forEach(btn => {
            const act = btn.getAttribute('data-tone-key') === cur;
            const hide = btn.id === 'customSoundToneBtn' && !hasCustom;
            btn.className = `sound-tone-btn ${hide ? 'hidden ' : ''}${act ? 'btn-royal' : 'btn-ghost'} px-2.5 py-1 rounded-full text-[11px] font-semibold whitespace-nowrap`;
          });
        }
        document.querySelectorAll('.sound-tone-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            const key = btn.getAttribute('data-tone-key') || 'chime';
            localStorage.setItem(SOUND_TONE_KEY, key);
            state.settings.notifTone = key;
            saveState();
            syncSoundToneUI();
            playGentleChime(key);
          });
        });
        document.getElementById('previewCurrentSoundBtn')?.addEventListener('click', () => {
          const cur = localStorage.getItem(SOUND_TONE_KEY) || state.settings.notifTone || 'chime';
          playGentleChime(cur);
        });
        document.getElementById('customSoundFileInput')?.addEventListener('change', (e) => {
          const file = e.target.files && e.target.files[0];
          if (!file) return;
          if (file.size > 1200 * 1024) {
            showToast(state.lang === 'zh' ? '请选择 1.2MB 以下的短音频文件 🎵' : '1.2MB 이하의 짧은 알림음 파일을 선택해 주세요 🎵');
            e.target.value = '';
            return;
          }
          const reader = new FileReader();
          reader.onload = () => {
            try {
              localStorage.setItem(CUSTOM_SOUND_KEY, reader.result);
              localStorage.setItem(CUSTOM_SOUND_NAME_KEY, file.name);
              localStorage.setItem(SOUND_TONE_KEY, 'custom');
              state.settings.notifTone = 'custom';
              saveState();
              syncSoundToneUI();
              playGentleChime('custom');
              showToast(state.lang === 'zh' ? '自定义提示音已保存 🎵' : '내 알림음이 저장되었어요 🎵');
            } catch (_) {
              showToast(state.lang === 'zh' ? '文件过大，请换更短的音频' : '파일 용량이 커서 저장할 수 없어요. 더 짧은 소리를 올려주세요.');
            }
          };
          reader.readAsDataURL(file);
          e.target.value = '';
        });
        document.getElementById('removeCustomSoundBtn')?.addEventListener('click', () => {
          localStorage.removeItem(CUSTOM_SOUND_KEY);
          localStorage.removeItem(CUSTOM_SOUND_NAME_KEY);
          if (localStorage.getItem(SOUND_TONE_KEY) === 'custom') {
            localStorage.setItem(SOUND_TONE_KEY, 'chime');
            state.settings.notifTone = 'chime';
            saveState();
          }
          syncSoundToneUI();
          showToast(state.lang === 'zh' ? '已恢复默认提示音 🔔' : '기본 알림음으로 돌아갔어요 🔔');
        });
        syncSoundToneUI();

        // ==================== Plus 1.3: 3-MODE ICON ART STYLE ENGINE (PASTEL / LINE / EMOJI) ====================
        const ICON_STYLE_KEY = 'chanwan_icon_style_v1';
        const ICON_PACKS = {
          pastel: {
            home: '<svg style="width:22px;height:22px;" viewBox="0 0 24 24" fill="none"><path d="M4.5 10.5L12 4l7.5 6.5V19.5a1.5 1.5 0 0 1-1.5 1.5H6a1.5 1.5 0 0 1-1.5-1.5v-9z" fill="#e9d8fd" stroke="#5b3d8a" stroke-width="1.6" stroke-linejoin="round"/><path d="M2.5 11.2L12 3l9.5 8.2" stroke="#8b5cf6" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><rect x="9.5" y="13.5" width="5" height="7.5" rx="1.5" fill="#f9c6d9" stroke="#5b3d8a" stroke-width="1.4"/></svg>',
            chat: '<svg style="width:22px;height:22px;" viewBox="0 0 24 24" fill="none"><path d="M20.5 11.5c0 4.4-3.8 8-8.5 8-1.3 0-2.6-.3-3.7-.8L3.5 20l1.3-4.1c-.8-1.2-1.3-2.7-1.3-4.4 0-4.4 3.8-8 8.5-8s8.5 3.6 8.5 8z" fill="#fce1ec" stroke="#5b3d8a" stroke-width="1.6" stroke-linejoin="round"/><circle cx="9" cy="11.5" r="1.2" fill="#8b5cf6"/><circle cx="12" cy="11.5" r="1.2" fill="#e879a9"/><circle cx="15" cy="11.5" r="1.2" fill="#8b5cf6"/></svg>',
            study: '<svg style="width:22px;height:22px;" viewBox="0 0 24 24" fill="none"><path d="M5 4.5A2.5 2.5 0 0 1 7.5 2H19v18H7.5A2.5 2.5 0 0 0 5 22V4.5z" fill="#ddd6fe" stroke="#5b3d8a" stroke-width="1.6" stroke-linejoin="round"/><path d="M5 19.5A2.5 2.5 0 0 1 7.5 17H19v4H7.5A2.5 2.5 0 0 1 5 19.5z" fill="#fef3c7" stroke="#5b3d8a" stroke-width="1.5"/><path d="M9 7h6M9 10.5h4.5" stroke="#7c3aed" stroke-width="1.6" stroke-linecap="round"/></svg>',
            space: '<svg style="width:22px;height:22px;" viewBox="0 0 24 24" fill="none"><path d="M12 20.5s-7-4.5-8.6-8.6C2.2 8.8 4.4 5.5 7.5 5.5c1.9 0 3.4 1 4.5 2.4 1.1-1.4 2.6-2.4 4.5-2.4 3.1 0 5.3 3.3 4.1 6.4-1.6 4.1-8.6 8.6-8.6 8.6z" fill="#f9a8d4" stroke="#5b3d8a" stroke-width="1.6" stroke-linejoin="round"/><circle cx="8.2" cy="9.4" r="1.3" fill="#fff" opacity="0.85"/></svg>',
            settings: '<svg style="width:22px;height:22px;" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="8.5" fill="#ede9fe" stroke="#5b3d8a" stroke-width="1.6" stroke-dasharray="3.2 2.2"/><circle cx="12" cy="12" r="3.6" fill="#fde68a" stroke="#5b3d8a" stroke-width="1.6"/></svg>',
            voice: '<svg style="width:20px;height:20px;color:var(--accent-royal);" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="9.2" fill="var(--accent-royal-soft)" stroke="currentColor" stroke-width="1.65"/><path d="M7.5 10.5v3M10.5 8v8M13.5 6.8v10.4M16.5 9.5v5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
            mic: '<svg style="width:18px;height:18px;color:var(--accent-royal);" viewBox="0 0 24 24" fill="none"><rect x="8.2" y="2.8" width="6.6" height="10.8" rx="3.3" fill="var(--accent-royal-soft)" stroke="currentColor" stroke-width="1.75"/><path d="M5.5 10.5a6 6 0 0 0 12 0M11.5 16.8v3.7M8.5 20.5h6" stroke="currentColor" stroke-width="1.75" stroke-linecap="round"/><path d="M18.8 3.2l.65 1.5 1.5.65-1.5.65-.65 1.5-.65-1.5-1.5-.65 1.5-.65.65-1.5z" fill="#ec4899"/></svg>',
            smile: '<svg style="width:20px;height:20px;" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="9" fill="#fef08a" stroke="#5b3d8a" stroke-width="1.6"/><path d="M8.5 14.2s1.3 2.1 3.5 2.1 3.5-2.1 3.5-2.1" stroke="#5b3d8a" stroke-width="1.6" stroke-linecap="round"/><circle cx="9" cy="10" r="1.1" fill="#5b3d8a"/><circle cx="15" cy="10" r="1.1" fill="#5b3d8a"/><circle cx="7.2" cy="12.6" r="1.2" fill="#f9a8d4" opacity="0.8"/><circle cx="16.8" cy="12.6" r="1.2" fill="#f9a8d4" opacity="0.8"/></svg>',
            plus: '<svg style="width:20px;height:20px;" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="9" fill="#ddd6fe" stroke="#5b3d8a" stroke-width="1.6"/><path d="M12 8v8M8 12h8" stroke="#6d28d9" stroke-width="2" stroke-linecap="round"/></svg>',
            camera: '<svg style="width:26px;height:26px;" viewBox="0 0 24 24" fill="none"><path d="M22 18.5a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V8.5a2 2 0 0 1 2-2h3.5l1.8-2.5h5.4l1.8 2.5H20a2 2 0 0 1 2 2v10z" fill="#e9d8fd" stroke="#5b3d8a" stroke-width="1.6" stroke-linejoin="round"/><circle cx="12" cy="13.2" r="3.6" fill="#fef3c7" stroke="#5b3d8a" stroke-width="1.6"/></svg>',
            gallery: '<svg style="width:26px;height:26px;" viewBox="0 0 24 24" fill="none"><rect x="3" y="3.5" width="18" height="17" rx="3" fill="#fce7f3" stroke="#5b3d8a" stroke-width="1.6"/><circle cx="8.5" cy="9" r="1.8" fill="#fde047" stroke="#5b3d8a" stroke-width="1.2"/><path d="M21 15.5l-4.8-4.5-6.2 6-2.5-2.2L3 18.5" fill="#c4b5fd" stroke="#5b3d8a" stroke-width="1.5" stroke-linejoin="round"/></svg>',
            speak: '<svg style="width:15px;height:15px;" viewBox="0 0 24 24" fill="none"><path d="M11 5L6 9H3v6h3l5 4V5z" fill="#e9d8fd" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/><path d="M15.5 8.5a5 5 0 0 1 0 7M18.5 6a8.5 8.5 0 0 1 0 12" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
            slow: '<svg style="width:15px;height:15px;" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="9" fill="#fef3c7" stroke="currentColor" stroke-width="1.7"/><path d="M12 7.5V12l3 2" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
            record: '<svg style="width:15px;height:15px;" viewBox="0 0 24 24" fill="none"><rect x="9" y="3" width="6" height="10.5" rx="3" fill="#f9c6d9" stroke="currentColor" stroke-width="1.7"/><path d="M5.5 10.5a6.5 6.5 0 0 0 13 0M12 17v3.5M9 20.5h6" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>',
            bell: '<svg style="width:18px;height:18px;" viewBox="0 0 24 24" fill="none"><path d="M18 8.5A6 6 0 0 0 6 8.5c0 6.5-2.5 8.5-2.5 8.5h17S18 15 18 8.5z" fill="#fef08a" stroke="#5b3d8a" stroke-width="1.6" stroke-linejoin="round"/><path d="M13.7 20.5a2 2 0 0 1-3.4 0" stroke="#5b3d8a" stroke-width="1.7" stroke-linecap="round"/></svg>',
            headerHeart: '<svg style="width:18px;height:18px;" viewBox="0 0 24 24" fill="none"><path d="M12 20s-6.8-4.4-8.4-8.3C2.4 8.7 4.5 5.5 7.6 5.5c1.9 0 3.4 1 4.4 2.4 1-1.4 2.5-2.4 4.4-2.4 3.1 0 5.2 3.2 4 6.2C18.8 15.6 12 20 12 20z" fill="#f9a8d4" stroke="#5b3d8a" stroke-width="1.6" stroke-linejoin="round"/></svg>',
            dday: '<svg style="width:16px;height:16px;" viewBox="0 0 24 24" fill="none"><path d="M12 20s-6.8-4.4-8.4-8.3C2.4 8.7 4.5 5.5 7.6 5.5c1.9 0 3.4 1 4.4 2.4 1-1.4 2.5-2.4 4.4-2.4 3.1 0 5.2 3.2 4 6.2C18.8 15.6 12 20 12 20z" fill="#f472b6" stroke="#5b3d8a" stroke-width="1.6"/><circle cx="8.5" cy="9.2" r="1.2" fill="#fff"/></svg>',
            heartbeat: '<svg style="width:28px;height:28px;" viewBox="0 0 24 24" fill="none"><path d="M12 20.5s-7.2-4.7-8.8-8.8C2 8.5 4.2 5 7.5 5c1.9 0 3.5 1 4.5 2.5C13 6 14.6 5 16.5 5c3.3 0 5.5 3.5 4.3 6.7-1.6 4.1-8.8 8.8-8.8 8.8z" fill="#f9a8d4" stroke="#5b3d8a" stroke-width="1.6" stroke-linejoin="round"/><path d="M7.5 12h2.2l1.2-2.5 2 5 1.3-2.5h2.3" stroke="#fff" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>',
            mission: '<svg style="width:28px;height:28px;" viewBox="0 0 24 24" fill="none"><rect x="3.5" y="3.5" width="17" height="17" rx="4" fill="#ddd6fe" stroke="#5b3d8a" stroke-width="1.6"/><circle cx="8.5" cy="8.5" r="1.3" fill="#7c3aed"/><circle cx="15.5" cy="8.5" r="1.3" fill="#ec4899"/><circle cx="12" cy="12" r="1.4" fill="#5b3d8a"/><circle cx="8.5" cy="15.5" r="1.3" fill="#ec4899"/><circle cx="15.5" cy="15.5" r="1.3" fill="#7c3aed"/></svg>',
            pin: '<svg style="width:13px;height:13px;" viewBox="0 0 24 24" fill="none"><path d="M12 21s-6-5.2-6-10.2A6 6 0 1 1 18 10.8C18 15.8 12 21 12 21z" fill="#f9c6d9" stroke="#5b3d8a" stroke-width="1.8"/><circle cx="12" cy="10.5" r="2" fill="#fff"/></svg>',
            edit: '<svg style="width:12px;height:12px;" viewBox="0 0 24 24" fill="none"><path d="M16.5 3.5l4 4L8 20H4v-4L16.5 3.5z" fill="#fef08a" stroke="#5b3d8a" stroke-width="1.8" stroke-linejoin="round"/></svg>',
            search: '<svg style="width:16px;height:16px;" viewBox="0 0 24 24" fill="none"><circle cx="11" cy="11" r="6.8" fill="#ede9fe" stroke="#5b3d8a" stroke-width="1.7"/><path d="M20.5 20.5l-4.2-4.2" stroke="#5b3d8a" stroke-width="1.9" stroke-linecap="round"/></svg>',
            archive: '<svg style="width:14px;height:14px;" viewBox="0 0 24 24" fill="none"><rect x="3" y="3.5" width="18" height="17" rx="3" fill="#fce7f3" stroke="#5b3d8a" stroke-width="1.7"/><circle cx="8.5" cy="9" r="1.5" fill="#fde047"/><path d="M21 15l-5-4.5L6 20" stroke="#5b3d8a" stroke-width="1.6"/></svg>',
            copy: '<svg style="width:14px;height:14px;" viewBox="0 0 24 24" fill="none"><rect x="9" y="9" width="11" height="11" rx="2" fill="#e9d8fd" stroke="#5b3d8a" stroke-width="1.8"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" stroke="#5b3d8a" stroke-width="1.8"/></svg>'
          },
          line: {
            home: '<svg class="lux-ico" viewBox="0 0 24 24"><path d="M3 10.5L12 3l9 7.5"/><path d="M5.5 9.5V20a1 1 0 0 0 1 1h4.5v-6h2v6h4.5a1 1 0 0 0 1-1V9.5"/></svg>',
            chat: '<svg class="lux-ico" viewBox="0 0 24 24"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg>',
            study: '<svg class="lux-ico" viewBox="0 0 24 24"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>',
            space: '<svg class="lux-ico" viewBox="0 0 24 24"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>',
            settings: '<svg class="lux-ico" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',
            voice: '<svg class="lux-ico" style="color:var(--accent-royal);" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M7.5 10.5v3M10.5 8v8M13.5 7v10M16.5 9.5v5"/></svg>',
            mic: '<svg class="lux-ico" style="width:17px;height:17px;color:var(--accent-royal);" viewBox="0 0 24 24"><rect x="8.5" y="2.5" width="6" height="11" rx="3"/><path d="M5.5 10.5a6 6 0 0 0 12 0"/><path d="M11.5 17v3.5"/><path d="M8.5 20.5h6"/><path d="M19 3.5v3M17.5 5h3"/></svg>',
            smile: '<svg class="lux-ico" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M8.5 14.5s1.3 2 3.5 2 3.5-2 3.5-2"/><circle cx="9" cy="10" r="0.8" fill="currentColor"/><circle cx="15" cy="10" r="0.8" fill="currentColor"/></svg>',
            plus: '<svg class="lux-ico" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 8v8"/><path d="M8 12h8"/></svg>',
            camera: '<svg class="lux-ico text-gold" style="width:24px;height:24px;" viewBox="0 0 24 24"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg>',
            gallery: '<svg class="lux-ico text-gold" style="width:24px;height:24px;" viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>',
            speak: '<svg class="lux-ico" style="width:15px;height:15px;" viewBox="0 0 24 24"><path d="M11 5L6 9H3v6h3l5 4V5z"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/></svg>',
            slow: '<svg class="lux-ico" style="width:15px;height:15px;" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7.5V12l3 2"/></svg>',
            record: '<svg class="lux-ico" style="width:15px;height:15px;" viewBox="0 0 24 24"><rect x="9" y="3" width="6" height="10.5" rx="3"/><path d="M5.5 10.5a6.5 6.5 0 0 0 13 0M12 17v3.5M9 20.5h6"/></svg>',
            bell: '<svg class="lux-ico" style="width:16px;height:16px;" viewBox="0 0 24 24"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>',
            headerHeart: '<svg class="lux-ico" style="width:16px;height:16px;" viewBox="0 0 24 24"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>',
            dday: '<svg class="lux-ico" style="width:14px;height:14px;" viewBox="0 0 24 24"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>',
            heartbeat: '<svg class="lux-ico text-gold" style="width:26px;height:26px;" viewBox="0 0 24 24"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>',
            mission: '<svg class="lux-ico text-gold" style="width:26px;height:26px;" viewBox="0 0 24 24"><rect x="3.5" y="3.5" width="17" height="17" rx="3.5"/><circle cx="8.5" cy="8.5" r="1" fill="currentColor"/><circle cx="15.5" cy="8.5" r="1" fill="currentColor"/><circle cx="12" cy="12" r="1" fill="currentColor"/><circle cx="8.5" cy="15.5" r="1" fill="currentColor"/><circle cx="15.5" cy="15.5" r="1" fill="currentColor"/></svg>',
            pin: '<svg class="lux-ico" style="width:12px;height:12px;" viewBox="0 0 24 24"><path d="M12 21s-6-5.2-6-10.2A6 6 0 1 1 18 10.8C18 15.8 12 21 12 21z"/><circle cx="12" cy="10.5" r="2"/></svg>',
            edit: '<svg class="lux-ico" style="width:12px;height:12px;" viewBox="0 0 24 24"><path d="M16.5 3.5l4 4L8 20H4v-4L16.5 3.5z"/></svg>',
            search: '<svg class="lux-ico" style="width:16px;height:16px;" viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.35-4.35"/></svg>',
            archive: '<svg class="lux-ico" style="width:14px;height:14px;" viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>',
            copy: '<svg class="lux-ico" style="width:14px;height:14px;" viewBox="0 0 24 24"><rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>'
          },
          gold: {
            home: '<svg style="width:22px;height:22px;" viewBox="0 0 24 24" fill="none"><path d="M4.5 10.5L12 4l7.5 6.5V19.5a1.5 1.5 0 0 1-1.5 1.5H6a1.5 1.5 0 0 1-1.5-1.5v-9z" fill="#f7e4bc" stroke="#9b7232" stroke-width="1.7" stroke-linejoin="round"/><rect x="9.5" y="13.5" width="5" height="7.5" rx="1.5" fill="#d9b46c" stroke="#9b7232" stroke-width="1.4"/></svg>',
            chat: '<svg style="width:22px;height:22px;" viewBox="0 0 24 24" fill="none"><path d="M20.5 11.5c0 4.4-3.8 8-8.5 8-1.3 0-2.6-.3-3.7-.8L3.5 20l1.3-4.1c-.8-1.2-1.3-2.7-1.3-4.4 0-4.4 3.8-8 8.5-8s8.5 3.6 8.5 8z" fill="#f7e4bc" stroke="#9b7232" stroke-width="1.7" stroke-linejoin="round"/><circle cx="9" cy="11.5" r="1.2" fill="#9b7232"/><circle cx="12" cy="11.5" r="1.2" fill="#7c3aed"/><circle cx="15" cy="11.5" r="1.2" fill="#9b7232"/></svg>',
            study: '<svg style="width:22px;height:22px;" viewBox="0 0 24 24" fill="none"><path d="M5 4.5A2.5 2.5 0 0 1 7.5 2H19v18H7.5A2.5 2.5 0 0 0 5 22V4.5z" fill="#f7e4bc" stroke="#9b7232" stroke-width="1.7" stroke-linejoin="round"/><path d="M9 7h6M9 10.5h4.5" stroke="#7c3aed" stroke-width="1.7" stroke-linecap="round"/></svg>',
            space: '<svg style="width:22px;height:22px;" viewBox="0 0 24 24" fill="none"><path d="M12 20.5s-7-4.5-8.6-8.6C2.2 8.8 4.4 5.5 7.5 5.5c1.9 0 3.4 1 4.5 2.4 1.1-1.4 2.6-2.4 4.5-2.4 3.1 0 5.3 3.3 4.1 6.4-1.6 4.1-8.6 8.6-8.6 8.6z" fill="#f3d69c" stroke="#9b7232" stroke-width="1.7" stroke-linejoin="round"/><circle cx="8.5" cy="9.5" r="1.2" fill="#fff"/></svg>',
            settings: '<svg style="width:22px;height:22px;" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="8.5" fill="#f7e4bc" stroke="#9b7232" stroke-width="1.7" stroke-dasharray="3.2 2.2"/><circle cx="12" cy="12" r="3.5" fill="#c89d52" stroke="#9b7232" stroke-width="1.6"/></svg>',
            voice: '<svg style="width:20px;height:20px;" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="9" fill="#f7e4bc" stroke="#9b7232" stroke-width="1.7"/><path d="M7.5 10.5v3M10.5 8v8M13.5 7v10M16.5 9.5v5" stroke="#9b7232" stroke-width="2" stroke-linecap="round"/></svg>',
            mic: '<svg style="width:18px;height:18px;" viewBox="0 0 24 24" fill="none"><rect x="8.2" y="2.8" width="6.6" height="10.8" rx="3.3" fill="#f3d69c" stroke="#9b7232" stroke-width="1.7"/><path d="M5.5 10.5a6 6 0 0 0 12 0M11.5 16.8v3.7M8.5 20.5h6" stroke="#9b7232" stroke-width="1.7" stroke-linecap="round"/><path d="M18.8 3.2l.65 1.5 1.5.65-1.5.65-.65 1.5-.65-1.5-1.5-.65 1.5-.65.65-1.5z" fill="#c89d52"/></svg>',
            smile: '<svg style="width:20px;height:20px;" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="9" fill="#f7e4bc" stroke="#9b7232" stroke-width="1.7"/><path d="M8.5 14.2s1.3 2.1 3.5 2.1 3.5-2.1 3.5-2.1" stroke="#9b7232" stroke-width="1.7" stroke-linecap="round"/><circle cx="9" cy="10" r="1.1" fill="#9b7232"/><circle cx="15" cy="10" r="1.1" fill="#9b7232"/></svg>',
            plus: '<svg style="width:20px;height:20px;" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="9" fill="#f3d69c" stroke="#9b7232" stroke-width="1.7"/><path d="M12 8v8M8 12h8" stroke="#9b7232" stroke-width="2" stroke-linecap="round"/></svg>',
            camera: '<svg style="width:26px;height:26px;" viewBox="0 0 24 24" fill="none"><path d="M22 18.5a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V8.5a2 2 0 0 1 2-2h3.5l1.8-2.5h5.4l1.8 2.5H20a2 2 0 0 1 2 2v10z" fill="#f7e4bc" stroke="#9b7232" stroke-width="1.7"/><circle cx="12" cy="13.2" r="3.6" fill="#d9b46c" stroke="#9b7232" stroke-width="1.6"/></svg>',
            gallery: '<svg style="width:26px;height:26px;" viewBox="0 0 24 24" fill="none"><rect x="3" y="3.5" width="18" height="17" rx="3" fill="#f7e4bc" stroke="#9b7232" stroke-width="1.7"/><circle cx="8.5" cy="9" r="1.8" fill="#c89d52"/><path d="M21 15.5l-4.8-4.5-6.2 6-2.5-2.2L3 18.5" fill="#e8cfa0" stroke="#9b7232" stroke-width="1.5"/></svg>',
            speak: '<svg style="width:15px;height:15px;" viewBox="0 0 24 24" fill="none"><path d="M11 5L6 9H3v6h3l5 4V5z" fill="#f3d69c" stroke="#9b7232" stroke-width="1.8" stroke-linejoin="round"/><path d="M15.5 8.5a5 5 0 0 1 0 7" stroke="#9b7232" stroke-width="1.8" stroke-linecap="round"/></svg>',
            slow: '<svg style="width:15px;height:15px;" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="9" fill="#f7e4bc" stroke="#9b7232" stroke-width="1.7"/><path d="M12 7.5V12l3 2" stroke="#9b7232" stroke-width="1.8" stroke-linecap="round"/></svg>',
            record: '<svg style="width:15px;height:15px;" viewBox="0 0 24 24" fill="none"><rect x="9" y="3" width="6" height="10.5" rx="3" fill="#f3d69c" stroke="#9b7232" stroke-width="1.7"/><path d="M5.5 10.5a6.5 6.5 0 0 0 13 0M12 17v3.5M9 20.5h6" stroke="#9b7232" stroke-width="1.7" stroke-linecap="round"/></svg>',
            bell: '<svg style="width:18px;height:18px;" viewBox="0 0 24 24" fill="none"><path d="M18 8.5A6 6 0 0 0 6 8.5c0 6.5-2.5 8.5-2.5 8.5h17S18 15 18 8.5z" fill="#f3d69c" stroke="#9b7232" stroke-width="1.7" stroke-linejoin="round"/><path d="M13.7 20.5a2 2 0 0 1-3.4 0" stroke="#9b7232" stroke-width="1.7" stroke-linecap="round"/></svg>',
            headerHeart: '<svg style="width:18px;height:18px;" viewBox="0 0 24 24" fill="none"><path d="M12 20s-6.8-4.4-8.4-8.3C2.4 8.7 4.5 5.5 7.6 5.5c1.9 0 3.4 1 4.4 2.4 1-1.4 2.5-2.4 4.4-2.4 3.1 0 5.2 3.2 4 6.2C18.8 15.6 12 20 12 20z" fill="#f3d69c" stroke="#9b7232" stroke-width="1.7" stroke-linejoin="round"/></svg>',
            dday: '<svg style="width:16px;height:16px;" viewBox="0 0 24 24" fill="none"><path d="M12 20s-6.8-4.4-8.4-8.3C2.4 8.7 4.5 5.5 7.6 5.5c1.9 0 3.4 1 4.4 2.4 1-1.4 2.5-2.4 4.4-2.4 3.1 0 5.2 3.2 4 6.2C18.8 15.6 12 20 12 20z" fill="#d9b46c" stroke="#9b7232" stroke-width="1.7"/></svg>',
            heartbeat: '<svg style="width:28px;height:28px;" viewBox="0 0 24 24" fill="none"><path d="M12 20.5s-7.2-4.7-8.8-8.8C2 8.5 4.2 5 7.5 5c1.9 0 3.5 1 4.5 2.5C13 6 14.6 5 16.5 5c3.3 0 5.5 3.5 4.3 6.7-1.6 4.1-8.8 8.8-8.8 8.8z" fill="#f3d69c" stroke="#9b7232" stroke-width="1.7" stroke-linejoin="round"/><path d="M7.5 12h2.2l1.2-2.5 2 5 1.3-2.5h2.3" stroke="#7c3aed" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>',
            mission: '<svg style="width:28px;height:28px;" viewBox="0 0 24 24" fill="none"><rect x="3.5" y="3.5" width="17" height="17" rx="4" fill="#f7e4bc" stroke="#9b7232" stroke-width="1.7"/><circle cx="8.5" cy="8.5" r="1.3" fill="#9b7232"/><circle cx="15.5" cy="8.5" r="1.3" fill="#7c3aed"/><circle cx="12" cy="12" r="1.4" fill="#9b7232"/><circle cx="8.5" cy="15.5" r="1.3" fill="#7c3aed"/><circle cx="15.5" cy="15.5" r="1.3" fill="#9b7232"/></svg>',
            pin: '<svg style="width:13px;height:13px;" viewBox="0 0 24 24" fill="none"><path d="M12 21s-6-5.2-6-10.2A6 6 0 1 1 18 10.8C18 15.8 12 21 12 21z" fill="#f3d69c" stroke="#9b7232" stroke-width="1.8"/><circle cx="12" cy="10.5" r="2" fill="#fff"/></svg>',
            edit: '<svg style="width:12px;height:12px;" viewBox="0 0 24 24" fill="none"><path d="M16.5 3.5l4 4L8 20H4v-4L16.5 3.5z" fill="#f3d69c" stroke="#9b7232" stroke-width="1.8" stroke-linejoin="round"/></svg>',
            search: '<svg style="width:16px;height:16px;" viewBox="0 0 24 24" fill="none"><circle cx="11" cy="11" r="6.8" fill="#f7e4bc" stroke="#9b7232" stroke-width="1.7"/><path d="M20.5 20.5l-4.2-4.2" stroke="#9b7232" stroke-width="1.9" stroke-linecap="round"/></svg>',
            archive: '<svg style="width:14px;height:14px;" viewBox="0 0 24 24" fill="none"><rect x="3" y="3.5" width="18" height="17" rx="3" fill="#f7e4bc" stroke="#9b7232" stroke-width="1.7"/><circle cx="8.5" cy="9" r="1.5" fill="#9b7232"/><path d="M21 15l-5-4.5L6 20" stroke="#9b7232" stroke-width="1.6"/></svg>',
            copy: '<svg style="width:14px;height:14px;" viewBox="0 0 24 24" fill="none"><rect x="9" y="9" width="11" height="11" rx="2" fill="#f3d69c" stroke="#9b7232" stroke-width="1.8"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" stroke="#9b7232" stroke-width="1.8"/></svg>'
          },
          emoji: {
            home: '<span class="text-lg leading-none">🏡</span>',
            chat: '<span class="text-lg leading-none">💌</span>',
            study: '<span class="text-lg leading-none">📖</span>',
            space: '<span class="text-lg leading-none">🌷</span>',
            settings: '<span class="text-lg leading-none">✨</span>',
            voice: '<svg style="width:20px;height:20px;color:var(--accent-royal);" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="9.2" fill="var(--accent-royal-soft)" stroke="currentColor" stroke-width="1.65"/><path d="M7.5 10.5v3M10.5 8v8M13.5 6.8v10.4M16.5 9.5v5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
            mic: '<svg style="width:18px;height:18px;color:var(--accent-royal);" viewBox="0 0 24 24" fill="none"><rect x="8.2" y="2.8" width="6.6" height="10.8" rx="3.3" fill="var(--accent-royal-soft)" stroke="currentColor" stroke-width="1.75"/><path d="M5.5 10.5a6 6 0 0 0 12 0M11.5 16.8v3.7M8.5 20.5h6" stroke="currentColor" stroke-width="1.75" stroke-linecap="round"/><path d="M18.8 3.2l.65 1.5 1.5.65-1.5.65-.65 1.5-.65-1.5-1.5-.65 1.5-.65.65-1.5z" fill="#ec4899"/></svg>',
            smile: '<span class="text-base leading-none">☺️</span>',
            plus: '<span class="text-base font-bold leading-none">＋</span>',
            camera: '<span class="text-2xl leading-none">📷</span>',
            gallery: '<span class="text-2xl leading-none">🎞️</span>',
            speak: '<span class="text-xs leading-none">🔈</span>',
            slow: '<span class="text-[10px] font-bold leading-none tracking-tight">0.7×</span>',
            record: '<span class="text-xs leading-none">🎙️</span>',
            bell: '<span class="text-sm leading-none">🔔</span>',
            headerHeart: '<span class="text-sm leading-none">🩷</span>',
            dday: '<span class="text-xs leading-none">🎀</span>',
            heartbeat: '<span class="text-2xl leading-none">🩷</span>',
            mission: '<span class="text-2xl leading-none">🪄</span>',
            pin: '<span class="text-[11px] leading-none">🧭</span>',
            edit: '<span class="text-[11px] leading-none">✒️</span>',
            search: '<span class="text-xs leading-none">🔎</span>',
            archive: '<span class="text-xs leading-none">🗂️</span>',
            copy: '<span class="text-xs leading-none">📑</span>'
          }
        };
        window.getAppIconHtml = function(key) {
          const m = localStorage.getItem(ICON_STYLE_KEY) || (state.settings && state.settings.iconStyle) || 'pastel';
          const pack = ICON_PACKS[m] || ICON_PACKS.pastel;
          return pack[key] || '';
        };
        // Plus 1.4: Universal App-Wide Emoji Mode Engine (Current Screens + Chinese/Korean Voice + All Written/Dynamic Content)
        function buildUiMiniSvg(kind, mode) {
          const isP = mode === 'pastel';
          const isG = mode === 'gold';
          const st = isP ? '#5b3d8a' : (isG ? '#9b7232' : 'currentColor');
          const fLav = isP ? '#e9d8fd' : (isG ? '#f7e4bc' : 'none');
          const fPink = isP ? '#f9c6d9' : (isG ? '#f3d69c' : 'none');
          const fGold = isP ? '#fef08a' : (isG ? '#e8c782' : 'none');
          const fBlue = isP ? '#dbeafe' : (isG ? '#f7e4bc' : 'none');
          const fMint = isP ? '#d1fae5' : (isG ? '#f3d69c' : 'none');
          const fRed = isP ? '#fecdd3' : (isG ? '#e8c782' : 'none');
          const w = 'viewBox="0 0 24 24" fill="none"';
          const map = {
            book: `<svg ${w}><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20V3H6.5A2.5 2.5 0 0 0 4 5.5v14z" fill="${fLav}" stroke="${st}" stroke-width="1.9" stroke-linejoin="round"/><path d="M8 7h8M8 11h6" stroke="${st}" stroke-width="1.7" stroke-linecap="round"/></svg>`,
            heart: `<svg ${w}><path d="M12 20.5s-7-4.5-8.6-8.6C2.2 8.8 4.4 5.5 7.5 5.5c1.9 0 3.4 1 4.5 2.4 1.1-1.4 2.6-2.4 4.5-2.4 3.1 0 5.3 3.3 4.1 6.4-1.6 4.1-8.6 8.6-8.6 8.6z" fill="${fPink}" stroke="${st}" stroke-width="1.9" stroke-linejoin="round"/></svg>`,
            kiss: `<svg ${w}><path d="M3 12c2.5-3.5 5.5-3.5 9-1 3.5-2.5 6.5-2.5 9 1-2.5 4.2-6 6-9 6s-6.5-1.8-9-6z" fill="${fPink}" stroke="${st}" stroke-width="1.8" stroke-linejoin="round"/><path d="M7 12.2c1.8.8 3.5.8 5 .3 1.5.5 3.2.5 5-.3" stroke="${st}" stroke-width="1.5" stroke-linecap="round"/></svg>`,
            sparkle: `<svg ${w}><path d="M12 3l2.4 6.6L21 12l-6.6 2.4L12 21l-2.4-6.6L3 12l6.6-2.4L12 3z" fill="${fGold}" stroke="${st}" stroke-width="1.8" stroke-linejoin="round"/></svg>`,
            star: `<svg ${w}><path d="M12 3l2.8 5.7 6.2.9-4.5 4.4 1.1 6.2L12 17.3 6.4 20.2l1.1-6.2L3 9.6l6.2-.9L12 3z" fill="${fGold}" stroke="${st}" stroke-width="1.8" stroke-linejoin="round"/></svg>`,
            crown: `<svg ${w}><path d="M3.5 18L5.5 7.5l4.5 4.2L12 6l2 5.7 4.5-4.2L20.5 18H3.5z" fill="${fGold}" stroke="${st}" stroke-width="1.8" stroke-linejoin="round"/><circle cx="12" cy="14.5" r="1.2" fill="${st}"/></svg>`,
            trophy: `<svg ${w}><path d="M7 4h10v6a5 5 0 0 1-10 0V4z" fill="${fGold}" stroke="${st}" stroke-width="1.8"/><path d="M7 6H4.5a2.5 2.5 0 0 0 2.5 3.5M17 6h2.5A2.5 2.5 0 0 1 17 9.5M12 15v4M8.5 19.5h7" stroke="${st}" stroke-width="1.8" stroke-linecap="round"/></svg>`,
            fire: `<svg ${w}><path d="M12.5 3c.5 3.5-2.5 5-2.5 7.8 0 1.4 1 2.2 2 2.2 1.8 0 2.5-1.8 2.5-3.3 2.5 1.7 4 4.2 4 6.8A6.5 6.5 0 0 1 5.5 16.5C5.5 11.5 9.2 7 12.5 3z" fill="${fRed}" stroke="${st}" stroke-width="1.8" stroke-linejoin="round"/></svg>`,
            bolt: `<svg ${w}><polygon points="13,2.5 5.5,13 11.5,13 10.5,21.5 18.5,11 12.5,11" fill="${fGold}" stroke="${st}" stroke-width="1.8" stroke-linejoin="round"/></svg>`,
            party: `<svg ${w}><path d="M4 20l4.5-11 6.5 6.5L4 20z" fill="${fPink}" stroke="${st}" stroke-width="1.8" stroke-linejoin="round"/><path d="M13 6l1.5-2.5M18 10l2.5-1M16.5 5.5l2-1.5" stroke="${st}" stroke-width="1.8" stroke-linecap="round"/></svg>`,
            sprout: `<svg ${w}><path d="M12 20v-8M12 12c0-4.5-3.5-7-7-6.5-.2 3.8 2.4 6.5 7 6.5zm0 0c0-4.5 3.5-7 7-6.5.2 3.8-2.4 6.5-7 6.5z" fill="${fMint}" stroke="${st}" stroke-width="1.8" stroke-linejoin="round"/></svg>`,
            flower: `<svg ${w}><circle cx="12" cy="7.5" r="3.2" fill="${fPink}" stroke="${st}" stroke-width="1.6"/><circle cx="7.5" cy="11.5" r="3.2" fill="${fPink}" stroke="${st}" stroke-width="1.6"/><circle cx="16.5" cy="11.5" r="3.2" fill="${fPink}" stroke="${st}" stroke-width="1.6"/><circle cx="9.5" cy="16" r="3.2" fill="${fPink}" stroke="${st}" stroke-width="1.6"/><circle cx="14.5" cy="16" r="3.2" fill="${fPink}" stroke="${st}" stroke-width="1.6"/><circle cx="12" cy="12" r="2.2" fill="${fGold}" stroke="${st}" stroke-width="1.4"/></svg>`,
            pen: `<svg ${w}><path d="M16.5 3.5l4 4L8 20H4v-4L16.5 3.5z" fill="${fGold}" stroke="${st}" stroke-width="1.9" stroke-linejoin="round"/></svg>`,
            mail: `<svg ${w}><rect x="3" y="5" width="18" height="14" rx="2.5" fill="${fPink}" stroke="${st}" stroke-width="1.9"/><path d="M3.5 6.5L12 13l8.5-6.5" stroke="${st}" stroke-width="1.8" stroke-linecap="round"/></svg>`,
            photo: `<svg ${w}><rect x="3" y="4" width="18" height="16" rx="3" fill="${fBlue}" stroke="${st}" stroke-width="1.9"/><circle cx="8.5" cy="9.5" r="1.6" fill="${isP ? '#f59e0b' : st}"/><path d="M21 15.5l-5-4.5L6 20" stroke="${st}" stroke-width="1.7"/></svg>`,
            speaker: `<svg ${w}><path d="M11 5.5L6.5 9.5H3.5v5h3L11 18.5V5.5z" fill="${fLav}" stroke="${st}" stroke-width="1.8" stroke-linejoin="round"/><path d="M15 9a4.5 4.5 0 0 1 0 6M17.8 6.5a8 8 0 0 1 0 11" stroke="${st}" stroke-width="1.8" stroke-linecap="round"/></svg>`,
            mute: `<svg ${w}><path d="M11 5.5L6.5 9.5H3.5v5h3L11 18.5V5.5z" fill="${fLav}" stroke="${st}" stroke-width="1.8" stroke-linejoin="round"/><path d="M15.5 9.5l5 5M20.5 9.5l-5 5" stroke="${st}" stroke-width="1.8" stroke-linecap="round"/></svg>`,
            turtle: `<svg ${w}><path d="M5 14a7 7 0 0 1 14 0H5z" fill="${fMint}" stroke="${st}" stroke-width="1.8" stroke-linejoin="round"/><circle cx="19.5" cy="12.5" r="2" fill="${fMint}" stroke="${st}" stroke-width="1.6"/><path d="M7.5 14v3.5M15.5 14v3.5" stroke="${st}" stroke-width="1.8" stroke-linecap="round"/></svg>`,
            headphone: `<svg ${w}><path d="M4 14a8 8 0 0 1 16 0" stroke="${st}" stroke-width="1.9" stroke-linecap="round"/><rect x="3" y="13" width="4" height="6.5" rx="2" fill="${fLav}" stroke="${st}" stroke-width="1.7"/><rect x="17" y="13" width="4" height="6.5" rx="2" fill="${fPink}" stroke="${st}" stroke-width="1.7"/></svg>`,
            mic: `<svg ${w}><rect x="9" y="3" width="6" height="10.5" rx="3" fill="${fPink}" stroke="${st}" stroke-width="1.9"/><path d="M5.5 10.5a6.5 6.5 0 0 0 13 0M12 17v4M9 21h6" stroke="${st}" stroke-width="1.8" stroke-linecap="round"/></svg>`,
            stop: `<svg ${w}><circle cx="12" cy="12" r="9" fill="${fRed}" stroke="${st}" stroke-width="1.8"/><rect x="8.6" y="8.6" width="6.8" height="6.8" rx="2" fill="${st}"/></svg>`,
            clock: `<svg ${w}><circle cx="12" cy="12" r="9" fill="${fLav}" stroke="${st}" stroke-width="1.9"/><path d="M12 7v5l3.5 2" stroke="${st}" stroke-width="1.8" stroke-linecap="round"/></svg>`,
            cal: `<svg ${w}><rect x="3" y="5" width="18" height="16" rx="3" fill="${fLav}" stroke="${st}" stroke-width="1.9"/><path d="M3 10h18M8 3v4M16 3v4" stroke="${st}" stroke-width="1.8" stroke-linecap="round"/></svg>`,
            gift: `<svg ${w}><rect x="3" y="8" width="18" height="13" rx="2.5" fill="${fPink}" stroke="${st}" stroke-width="1.9"/><path d="M12 8v13M3 12h18M12 8c-2-3-5-3-5-1s3 1 5 1zm0 0c2-3 5-3 5-1s-3 1-5 1z" stroke="${st}" stroke-width="1.7"/></svg>`,
            user: `<svg ${w}><circle cx="12" cy="8" r="4" fill="${fLav}" stroke="${st}" stroke-width="1.9"/><path d="M4.5 20a7.5 7.5 0 0 1 15 0" fill="${fPink}" stroke="${st}" stroke-width="1.9" stroke-linecap="round"/></svg>`,
            smile: `<svg ${w}><circle cx="12" cy="12" r="9" fill="${fGold}" stroke="${st}" stroke-width="1.8"/><path d="M8.5 14c1.2 1.8 2.4 2.4 3.5 2.4s2.3-.6 3.5-2.4" stroke="${st}" stroke-width="1.7" stroke-linecap="round"/><circle cx="9" cy="10" r="1.1" fill="${st}"/><circle cx="15" cy="10" r="1.1" fill="${st}"/></svg>`,
            sad: `<svg ${w}><circle cx="12" cy="12" r="9" fill="${fBlue}" stroke="${st}" stroke-width="1.8"/><path d="M8.5 16c1.2-1.4 2.4-1.8 3.5-1.8s2.3.4 3.5 1.8" stroke="${st}" stroke-width="1.7" stroke-linecap="round"/><circle cx="9" cy="10" r="1.1" fill="${st}"/><circle cx="15" cy="10" r="1.1" fill="${st}"/></svg>`,
            hand: `<svg ${w}><path d="M8 12V6.5a1.5 1.5 0 0 1 3 0V11m0-4.5a1.5 1.5 0 0 1 3 0V11m0-3.5a1.5 1.5 0 0 1 3 0V14a6 6 0 0 1-12 0v-3.5a1.5 1.5 0 0 1 3 0" fill="${fGold}" stroke="${st}" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
            palette: `<svg ${w}><path d="M12 3a9 9 0 0 0 0 18c1.5 0 2.6-.9 2.6-2.2 0-.6-.2-1.1-.6-1.5-.3-.4-.5-.8-.5-1.3 0-1.1.9-2 2-2H17a4 4 0 0 0 4-4c0-4-4-7-9-7z" fill="${fLav}" stroke="${st}" stroke-width="1.8" stroke-linejoin="round"/><circle cx="8" cy="10.5" r="1.2" fill="${isP ? '#ec4899' : st}"/><circle cx="11.2" cy="7.6" r="1.2" fill="${isP ? '#f59e0b' : st}"/><circle cx="15.2" cy="8.8" r="1.2" fill="${isP ? '#8b5cf6' : st}"/><circle cx="8.2" cy="14.6" r="1.2" fill="${isP ? '#10b981' : st}"/></svg>`,
            bell: `<svg ${w}><path d="M18 8.5A6 6 0 0 0 6 8.5c0 6.5-2.5 8.5-2.5 8.5h17S18 15 18 8.5z" fill="${fGold}" stroke="${st}" stroke-width="1.9" stroke-linejoin="round"/><path d="M13.7 20.5a2 2 0 0 1-3.4 0" stroke="${st}" stroke-width="1.8" stroke-linecap="round"/></svg>`,
            lock: `<svg ${w}><rect x="5" y="10.5" width="14" height="10" rx="2.5" fill="${fLav}" stroke="${st}" stroke-width="1.9"/><path d="M8 10.5V7.5a4 4 0 0 1 8 0v3" stroke="${st}" stroke-width="1.9"/></svg>`,
            unlock: `<svg ${w}><rect x="5" y="10.5" width="14" height="10" rx="2.5" fill="${fMint}" stroke="${st}" stroke-width="1.9"/><path d="M8 10.5V7.5a4 4 0 0 1 7.6-1.6" stroke="${st}" stroke-width="1.9" stroke-linecap="round"/></svg>`,
            shield: `<svg ${w}><path d="M12 3l7.5 3v6c0 4.5-3.2 7.8-7.5 9-4.3-1.2-7.5-4.5-7.5-9V6L12 3z" fill="${fMint}" stroke="${st}" stroke-width="1.9" stroke-linejoin="round"/></svg>`,
            tool: `<svg ${w}><path d="M14.7 6.3a4 4 0 0 0-5.4 5.4l-5.6 5.6a1.8 1.8 0 0 0 2.6 2.6l5.6-5.6a4 4 0 0 0 5.4-5.4l-2.3 2.3-2.6-2.6 2.3-2.3z" fill="${fGold}" stroke="${st}" stroke-width="1.8" stroke-linejoin="round"/></svg>`,
            dl: `<svg ${w}><path d="M12 4v11m0 0l-4-4m4 4l4-4M4 19h16" stroke="${st}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
            ul: `<svg ${w}><path d="M12 15V4m0 0l-4 4m4-4l4 4M4 19h16" stroke="${st}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
            music: `<svg ${w}><path d="M9 18V6l11-2v12" stroke="${st}" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/><circle cx="6.5" cy="18" r="2.5" fill="${fPink}" stroke="${st}" stroke-width="1.8"/><circle cx="17.5" cy="16" r="2.5" fill="${fLav}" stroke="${st}" stroke-width="1.8"/></svg>`,
            phone: `<svg ${w}><rect x="6" y="3" width="12" height="18" rx="2.5" fill="${fBlue}" stroke="${st}" stroke-width="1.9"/><circle cx="12" cy="17.5" r="1" fill="${st}"/></svg>`,
            game: `<svg ${w}><rect x="3" y="7" width="18" height="11" rx="4" fill="${fLav}" stroke="${st}" stroke-width="1.9"/><path d="M8 10.5v4M6 12.5h4" stroke="${st}" stroke-width="1.8" stroke-linecap="round"/><circle cx="15.5" cy="11.5" r="1" fill="${st}"/><circle cx="17.5" cy="13.5" r="1" fill="${st}"/></svg>`,
            pin: `<svg ${w}><path d="M12 21s-6-5.2-6-10.2A6 6 0 1 1 18 10.8C18 15.8 12 21 12 21z" fill="${fPink}" stroke="${st}" stroke-width="1.9"/><circle cx="12" cy="10.5" r="2" fill="${isP ? '#fff' : 'none'}" stroke="${st}" stroke-width="1.5"/></svg>`,
            sun: `<svg ${w}><circle cx="12" cy="12" r="5" fill="${fGold}" stroke="${st}" stroke-width="1.8"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M19.1 4.9L17 7M7 17l-2.1 2.1" stroke="${st}" stroke-width="1.7" stroke-linecap="round"/></svg>`,
            moon: `<svg ${w}><path d="M20 14.5A8.5 8.5 0 1 1 9.5 4a6.8 6.8 0 0 0 10.5 10.5z" fill="${fGold}" stroke="${st}" stroke-width="1.9" stroke-linejoin="round"/></svg>`,
            cloud: `<svg ${w}><path d="M7.5 18h9.5a4 4 0 0 0 .6-7.95A5.5 5.5 0 0 0 6.8 9.2 4.2 4.2 0 0 0 7.5 18z" fill="${fBlue}" stroke="${st}" stroke-width="1.8" stroke-linejoin="round"/></svg>`,
            folder: `<svg ${w}><path d="M3 7a2 2 0 0 1 2-2h4.5l2 2.5H19a2 2 0 0 1 2 2V18a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7z" fill="${fGold}" stroke="${st}" stroke-width="1.8" stroke-linejoin="round"/></svg>`,
            globe: `<svg ${w}><circle cx="12" cy="12" r="9" fill="${fBlue}" stroke="${st}" stroke-width="1.8"/><path d="M3 12h18M12 3a13 13 0 0 1 0 18M12 3a13 13 0 0 0 0 18" stroke="${st}" stroke-width="1.5"/></svg>`,
            cn: `<svg ${w}><rect x="2.5" y="4.5" width="19" height="15" rx="3.5" fill="${fRed}" stroke="${st}" stroke-width="1.7"/><text x="12" y="15.2" text-anchor="middle" font-size="8.5" font-weight="800" fill="${st}" font-family="sans-serif">中</text></svg>`,
            kr: `<svg ${w}><rect x="2.5" y="4.5" width="19" height="15" rx="3.5" fill="${fBlue}" stroke="${st}" stroke-width="1.7"/><text x="12" y="15.2" text-anchor="middle" font-size="8.5" font-weight="800" fill="${st}" font-family="sans-serif">한</text></svg>`,
            plane: `<svg ${w}><path d="M21 15v-2l-8-5V3.5a1.5 1.5 0 0 0-3 0V8l-8 5v2l8-2.5V18l-2.5 1.8V21l4-1 4 1v-1.2L13 18v-5.5L21 15z" fill="${fBlue}" stroke="${st}" stroke-width="1.6" stroke-linejoin="round"/></svg>`,
            food: `<svg ${w}><circle cx="12" cy="13" r="7.5" fill="${fPink}" stroke="${st}" stroke-width="1.8"/><path d="M8.5 13h7M10 9.5v7" stroke="${st}" stroke-width="1.6" stroke-linecap="round"/></svg>`,
            coffee: `<svg ${w}><path d="M5 9h10v6a4.5 4.5 0 0 1-4.5 4.5h-1A4.5 4.5 0 0 1 5 15V9z" fill="${fGold}" stroke="${st}" stroke-width="1.8"/><path d="M15 10.5h2a2 2 0 0 1 0 4h-2M8 5.5c0-1 .8-1.5.8-2.2M11.5 5.5c0-1 .8-1.5.8-2.2" stroke="${st}" stroke-width="1.6" stroke-linecap="round"/></svg>`,
            home: `<svg ${w}><path d="M4 10.5L12 4l8 6.5V19a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 4 19v-8.5z" fill="${fLav}" stroke="${st}" stroke-width="1.8" stroke-linejoin="round"/><rect x="9.5" y="13.5" width="5" height="7" rx="1.2" fill="${fPink}" stroke="${st}" stroke-width="1.4"/></svg>`,
            link: `<svg ${w}><path d="M10 13.5a4.5 4.5 0 0 0 6.4 0l2.4-2.4a4.5 4.5 0 0 0-6.4-6.4L11 6.1M14 10.5a4.5 4.5 0 0 0-6.4 0l-2.4 2.4a4.5 4.5 0 1 0 6.4 6.4l1.4-1.4" stroke="${st}" stroke-width="1.9" stroke-linecap="round"/></svg>`,
            search: `<svg ${w}><circle cx="11" cy="11" r="6.8" fill="${fLav}" stroke="${st}" stroke-width="1.8"/><path d="M20.5 20.5l-4.2-4.2" stroke="${st}" stroke-width="2" stroke-linecap="round"/></svg>`,
            target: `<svg ${w}><circle cx="12" cy="12" r="8.5" fill="${fPink}" stroke="${st}" stroke-width="1.8"/><circle cx="12" cy="12" r="4.5" fill="${isP ? '#fff' : 'none'}" stroke="${st}" stroke-width="1.7"/><circle cx="12" cy="12" r="1.5" fill="${st}"/></svg>`,
            pet: `<svg ${w}><circle cx="7.5" cy="9" r="2" fill="${fPink}" stroke="${st}" stroke-width="1.5"/><circle cx="16.5" cy="9" r="2" fill="${fPink}" stroke="${st}" stroke-width="1.5"/><circle cx="12" cy="6.8" r="2" fill="${fPink}" stroke="${st}" stroke-width="1.5"/><path d="M8 15.5c0-2.2 1.8-4 4-4s4 1.8 4 4c0 1.8-1.4 3-4 3s-4-1.2-4-3z" fill="${fLav}" stroke="${st}" stroke-width="1.7"/></svg>`,
            font: `<svg ${w}><path d="M5 19L10 5l5 14M6.8 14.5h6.4M16 12h4.5M18.2 9.5v6.5" stroke="${st}" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
            refresh: `<svg ${w}><path d="M20 12a8 8 0 1 1-2.3-5.6L20 8.5M20 4v4.5h-4.5" stroke="${st}" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
            play: `<svg ${w}><polygon points="7,5 19,12 7,19" fill="${fGold}" stroke="${st}" stroke-width="1.9" stroke-linejoin="round"/></svg>`,
            check: `<svg ${w}><circle cx="12" cy="12" r="9" fill="${fMint}" stroke="${st}" stroke-width="1.8"/><path d="M8 12.5l2.7 2.7 5.3-5.8" stroke="${st}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
            warn: `<svg ${w}><circle cx="12" cy="12" r="9" fill="${fRed}" stroke="${st}" stroke-width="1.8"/><path d="M12 7.5v5.2M12 16.2h.01" stroke="${st}" stroke-width="2" stroke-linecap="round"/></svg>`,
            bulb: `<svg ${w}><path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-3.5 10.9c.7.5 1 1.2 1 2.1h5c0-.9.3-1.6 1-2.1A6 6 0 0 0 12 3z" fill="${fGold}" stroke="${st}" stroke-width="1.8" stroke-linejoin="round"/></svg>`,
            gem: `<svg ${w}><polygon points="6,4 18,4 22,10 12,21 2,10" fill="${fLav}" stroke="${st}" stroke-width="1.8" stroke-linejoin="round"/></svg>`,
            trash: `<svg ${w}><path d="M4 7h16M9 7V4.5h6V7M6.5 7l1 12.5a1.5 1.5 0 0 0 1.5 1.5h6a1.5 1.5 0 0 0 1.5-1.5l1-12.5" fill="${fLav}" stroke="${st}" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
            reply: `<svg ${w}><path d="M9.5 7.5L4.5 12l5 4.5" stroke="${st}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M5 12h9a5 5 0 0 1 5 5v1.5" stroke="${st}" stroke-width="1.9" stroke-linecap="round"/></svg>`,
            hat: `<svg ${w}><path d="M6.5 16V7.5A1.5 1.5 0 0 1 8 6h8a1.5 1.5 0 0 1 1.5 1.5V16" fill="${fLav}" stroke="${st}" stroke-width="1.8" stroke-linejoin="round"/><path d="M3.5 16h17" stroke="${st}" stroke-width="2" stroke-linecap="round"/><path d="M6.5 13h11" stroke="${st}" stroke-width="1.6"/></svg>`,
            cross: `<svg ${w}><circle cx="12" cy="12" r="9" fill="${fRed}" stroke="${st}" stroke-width="1.8"/><path d="M8.8 8.8l6.4 6.4M15.2 8.8l-6.4 6.4" stroke="${st}" stroke-width="2" stroke-linecap="round"/></svg>`,
            starOutline: `<svg ${w}><path d="M12 3l2.8 5.7 6.2.9-4.5 4.4 1.1 6.2L12 17.3 6.4 20.2l1.1-6.2L3 9.6l6.2-.9L12 3z" fill="none" stroke="${st}" stroke-width="1.8" stroke-linejoin="round"/></svg>`,
            en: `<svg ${w}><rect x="2.5" y="4.5" width="19" height="15" rx="4" fill="${fBlue}" stroke="${st}" stroke-width="1.8"/><text x="12" y="15.2" text-anchor="middle" font-family="system-ui,sans-serif" font-size="9.2" font-weight="800" fill="${st}">EN</text></svg>`
          };
          return map[kind] || map.sparkle;
        }

        const EMOJI_TO_UI_KIND = {
          '📖':'book','📚':'book','📜':'book','📋':'book','🗂️':'book','📘':'book','📗':'book','📓':'book','📑':'book','🧾':'book',
          '💜':'heart','❤️':'heart','❤':'heart','💕':'heart','💓':'heart','💝':'heart','🩷':'heart','💘':'heart','💖':'heart','💗':'heart','💞':'heart','♥':'heart','💑':'heart','💏':'heart','🩵':'heart','🟣':'heart','🍑':'heart',
          '💋':'kiss','😘':'kiss',
          '✨':'sparkle','🔮':'sparkle','🫧':'sparkle','🪄':'sparkle','✦':'sparkle','🎩':'hat','🙇':'hat','🙇‍♂️':'hat','🙇‍♀️':'hat',
          '⭐':'star','🌟':'star','☆':'starOutline','❌':'cross',
          '👑':'crown',
          '🏆':'trophy','🥇':'trophy','🎖️':'trophy','🏅':'trophy',
          '🔥':'fire',
          '⚡':'bolt',
          '🎉':'party','🎊':'party','🎈':'party',
          '🌱':'sprout','🌿':'sprout','🍀':'sprout',
          '🌷':'flower','🌸':'flower','🪻':'flower','💐':'flower','🌹':'flower','🌻':'flower','🌺':'flower',
          '✏️':'pen','✏':'pen','🪶':'pen','📝':'pen','✒️':'pen','🖋️':'pen','🗒️':'pen',
          '💌':'mail','💬':'mail','💭':'mail','✉️':'mail','📩':'mail',
          '🖼️':'photo','🖼':'photo','📷':'photo','📸':'photo','🎞️':'photo','🎬':'photo','🎥':'photo',
          '🔊':'speaker','🔉':'speaker','🔈':'speaker','📢':'speaker','📣':'speaker',
          '🔇':'mute','🔕':'mute',
          '🐢':'turtle',
          '🎧':'headphone',
          '🎙️':'mic','🎙':'mic','🎤':'mic',
          '⏹️':'stop','⏹':'stop',
          '⏳':'clock','⏱️':'clock','⏰':'clock','🕘':'clock','⌚':'clock',
          '📅':'cal','📆':'cal',
          '🎟️':'gift','🎁':'gift','🎀':'gift','🛍️':'gift',
          '👤':'user','👥':'user','🧸':'user',
          '😊':'smile','🥰':'smile','☺️':'smile','😄':'smile','😁':'smile','😍':'smile','🤗':'smile','🥳':'smile','😉':'smile','😋':'smile','🙂':'smile','😜':'smile','😛':'smile','😝':'smile','😅':'smile','👨‍👩‍👧':'user','🚇':'pin','🏥':'home','🧴':'sparkle','⚖️':'game','⚖':'game','➕':'sparkle','🌊':'cloud','🌌':'moon','🎰':'game','👕':'gift','💆':'heart','💛':'heart','💫':'sparkle','💾':'folder','🙅':'hand','🥠':'star','🫙':'gift','✊':'hand','✋':'hand','🃏':'game',
          '🥺':'sad','😭':'sad','😢':'sad','😔':'sad','😞':'sad','😴':'sad','😡':'sad',
          '🙏':'hand','👍':'hand','👏':'hand','🙌':'hand','🤝':'hand','💪':'hand','🫶':'hand','👋':'hand','✌️':'hand',
          '🎨':'palette',
          '🔔':'bell','🎐':'bell',
          '🔒':'lock','🔐':'lock',
          '🔓':'unlock',
          '🛡️':'shield','🛡':'shield',
          '🛠️':'tool','🛠':'tool','⚙️':'tool','⚙':'tool','🔧':'tool',
          '📥':'dl','⬇️':'dl',
          '📤':'ul','⬆️':'ul',
          '🎵':'music','🎶':'music','🎹':'music','🎸':'music',
          '📱':'phone','📲':'phone','📞':'phone',
          '🎮':'game','🧩':'game','🎲':'game',
          '📌':'pin','📍':'pin','🔖':'pin','🧭':'pin',
          '☀️':'sun','☀':'sun',
          '🌙':'moon','🌛':'moon','🌃':'moon',
          '☁️':'cloud','☁':'cloud','🌤️':'cloud','⛅':'cloud','🌧️':'cloud','❄️':'cloud','🌈':'cloud',
          '📁':'folder','📂':'folder','📦':'folder',
          '🇨🇳':'cn','🇰🇷':'kr','🇬🇧':'en','🇺🇸':'en','🔤':'en','🗣️':'speaker','🗣':'speaker','★':'star',
          '🌐':'globe','🗺️':'globe',
          '✈️':'plane','✈':'plane',
          '🍽️':'food','🍜':'food','🍕':'food','🍔':'food','🍰':'food','🎂':'food','🍓':'food','🍑':'food','🍱':'food','🍲':'food',
          '☕':'coffee','🧋':'coffee','🍵':'coffee','🍺':'coffee','🍷':'coffee',
          '🏠':'home','🏡':'home','🏢':'home','🛏️':'home',
          '🔗':'link',
          '🔎':'search','🔍':'search',
          '🎯':'target',
          '🐾':'pet','🐶':'pet','🐱':'pet','🐰':'pet','🐻':'pet','🐷':'pet','🦋':'pet',
          '🔤':'font',
          '🔄':'refresh','🔁':'refresh','↩️':'reply','↩':'reply',
          '▶️':'play','▶':'play',
          '✅':'check','🟢':'check','✓':'check','☑️':'check',
          '🔴':'warn','🟡':'clock','⚠️':'warn','⚠':'warn','❗':'warn','❓':'warn',
          '💡':'bulb',
          '💎':'gem','💍':'gem',
          '🗑️':'trash','🗑':'trash'
        };

        const REFINED_EMOJI_SWAP = {
          '🏠':'🏡','💬':'💌','📚':'📖','💕':'🌷','⚙️':'✨','📱':'📲','🛡️':'🫧',
          '🛠️':'🪄','🎮':'🧩','📌':'🔖','✏️':'✒️','📝':'🗒️','🖼️':'🎞️','📸':'📷',
          '🔊':'🔈','🔔':'🎐','🔒':'🔐','👤':'🧸','🔤':'🖋️','🎨':'🎀','📥':'⬇️','📤':'⬆️','📜':'🧾'
        };

        const UNIVERSAL_EMOJI_RE = /(?:[\uD83C][\uDDE6-\uDDFF][\uD83C][\uDDE6-\uDDFF])|(?:(?:[\uD83C-\uDBFF][\uDC00-\uDFFF]|[\u2600-\u27BF\u231A-\u23FF\u2B50\u2B55\u2934\u2935\u25AA-\u25FE\u2194-\u21AA\u203C\u2049])(?:\uFE0F)?(?:\u200D(?:[\uD83C-\uDBFF][\uDC00-\uDFFF]|[\u2600-\u27BF])(?:\uFE0F)?)*)/g;
        const SKIP_EMOJI_TAGS = new Set(['SCRIPT', 'STYLE', 'TEXTAREA', 'INPUT', 'SELECT', 'OPTION', 'SVG', 'TITLE', 'NOSCRIPT', 'CODE', 'PRE']);
        let isTransformingEmojiDom = false;

        function renderSingleEmojiHtml(rawEmoji, mode) {
          const clean = String(rawEmoji || '');
          const noVs = clean.replace(/\uFE0F/g, '');
          if (mode === 'emoji') {
            return REFINED_EMOJI_SWAP[clean] || REFINED_EMOJI_SWAP[noVs] || clean;
          }
          const kind = EMOJI_TO_UI_KIND[clean] || EMOJI_TO_UI_KIND[noVs];
          if (kind) {
            return buildUiMiniSvg(kind, mode);
          }
          const fallbackCls = mode === 'line' ? 'cw-em-line' : (mode === 'gold' ? 'cw-em-gold' : 'cw-em-pastel');
          return `<span class="${fallbackCls}">${escapeHtml(clean)}</span>`;
        }

        function shouldSkipEmojiNode(node) {
          let el = node && node.nodeType === 1 ? node : (node && node.parentElement);
          while (el && el !== document.body) {
            if (SKIP_EMOJI_TAGS.has(el.tagName)) return true;
            if (el.id === 'chatStickerTray' || el.id === 'chatPlusDrawer' || el.id === 'cwUniversalEmojiWrap' || el.id === 'cwUniversalEmojiTray' || el.id === 'clockSuwon' || el.id === 'clockShanghai' || el.id === 'dateSuwon' || el.id === 'dateShanghai' || el.id === 'cloudSyncStatusText') return true;
            if (el.classList && (el.classList.contains('cw-ico-slot') || el.classList.contains('cw-ui-ico') || el.classList.contains('icon-style-btn') || el.classList.contains('cw-keep-native-emoji'))) return true;
            el = el.parentElement;
          }
          return false;
        }

        function transformEmojisInRoot(root, mode) {
          if (!root || isTransformingEmojiDom) return;
          const m = ICON_PACKS[mode] ? mode : (localStorage.getItem(ICON_STYLE_KEY) || (state.settings && state.settings.iconStyle) || 'pastel');
          // Fast-path: when native 'emoji' style is selected, zero SVG replacement needed!
          if (m === 'emoji' && root.dataset && root.dataset.cwEmojiFast === 'emoji') return;
          isTransformingEmojiDom = true;
          try {
            // 1. Update already-wrapped emoji spans in-place (instant mode switch!)
            if (root.nodeType === 1) {
              if (root.classList && root.classList.contains('cw-ui-ico') && root.dataset.origEmoji) {
                root.innerHTML = renderSingleEmojiHtml(root.dataset.origEmoji, m);
              }
              root.querySelectorAll('.cw-ui-ico[data-orig-emoji]').forEach(sp => {
                if (!shouldSkipEmojiNode(sp.parentElement)) {
                  sp.innerHTML = renderSingleEmojiHtml(sp.dataset.origEmoji, m);
                }
              });
            }

            // 2. Walk every text node under root and wrap raw emojis (start, middle, end, or multiple!)
            const textNodes = [];
            if (root.nodeType === 3) {
              if (root.nodeValue && UNIVERSAL_EMOJI_RE.test(root.nodeValue) && !shouldSkipEmojiNode(root)) {
                textNodes.push(root);
              }
              UNIVERSAL_EMOJI_RE.lastIndex = 0;
            } else if (root.nodeType === 1) {
              const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
              let tn;
              while ((tn = walker.nextNode())) {
                if (!tn.nodeValue || shouldSkipEmojiNode(tn)) continue;
                UNIVERSAL_EMOJI_RE.lastIndex = 0;
                if (UNIVERSAL_EMOJI_RE.test(tn.nodeValue)) {
                  textNodes.push(tn);
                }
              }
            }

            for (const tn of textNodes) {
              const txt = tn.nodeValue;
              if (!txt || !tn.parentNode) continue;
              UNIVERSAL_EMOJI_RE.lastIndex = 0;
              const frag = document.createDocumentFragment();
              let lastIdx = 0;
              let match;
              let replaced = false;
              while ((match = UNIVERSAL_EMOJI_RE.exec(txt)) !== null) {
                const em = match[0];
                if (match.index > lastIdx) {
                  frag.appendChild(document.createTextNode(txt.slice(lastIdx, match.index)));
                }
                const sp = document.createElement('span');
                sp.className = 'cw-ui-ico';
                sp.dataset.origEmoji = em;
                sp.innerHTML = renderSingleEmojiHtml(em, m);
                frag.appendChild(sp);
                lastIdx = match.index + em.length;
                replaced = true;
              }
              if (replaced) {
                if (lastIdx < txt.length) {
                  frag.appendChild(document.createTextNode(txt.slice(lastIdx)));
                }
                tn.parentNode.replaceChild(frag, tn);
              }
            }
          } finally {
            UNIVERSAL_EMOJI_RE.lastIndex = 0;
            isTransformingEmojiDom = false;
          }
        }

        function syncAllTabIconsToStyle(mode, targetRoot) {
          const m = ICON_PACKS[mode] ? mode : (localStorage.getItem(ICON_STYLE_KEY) || (state.settings && state.settings.iconStyle) || 'pastel');
          const root = targetRoot || document.body;
          if (root) transformEmojisInRoot(root, m);
        }
        window.syncAllTabIconsToStyle = syncAllTabIconsToStyle;
        window.__refreshIconSlots = function(rootEl) {
          const m = localStorage.getItem(ICON_STYLE_KEY) || (state.settings && state.settings.iconStyle) || 'pastel';
          const pack = ICON_PACKS[m] || ICON_PACKS.pastel;
          (rootEl || document).querySelectorAll('.cw-ico-slot[data-ico]').forEach(el => {
            const key = el.getAttribute('data-ico');
            if (pack[key]) el.innerHTML = pack[key];
          });
        };
        let __cwIconSyncTimer = null;
        window.scheduleIconSync = function(targetEl) {
          if (__cwIconSyncTimer) clearTimeout(__cwIconSyncTimer);
          __cwIconSyncTimer = setTimeout(() => {
            __cwIconSyncTimer = null;
            const m = localStorage.getItem(ICON_STYLE_KEY) || (state.settings && state.settings.iconStyle) || 'pastel';
            const root = targetEl || document.querySelector('.tab-panel.active') || document.body;
            window.__refreshIconSlots(document);
            syncAllTabIconsToStyle(m, document.querySelector('header'));
            if (root && root !== document.querySelector('header')) syncAllTabIconsToStyle(m, root);
          }, 24);
        };

        // Real-time MutationObserver: automatically applies active emoji mode to EVERY newly written/rendered screen, chat, diary, voice button, toast & modal!
        let emojiMutQueue = new Set();
        let emojiMutScheduled = false;
        if (typeof MutationObserver !== 'undefined' && document.body) {
          const emojiObserver = new MutationObserver((mutations) => {
            if (isTransformingEmojiDom) return;
            for (const mut of mutations) {
              if (mut.type === 'characterData' && mut.target) {
                if (!shouldSkipEmojiNode(mut.target)) emojiMutQueue.add(mut.target);
              } else if (mut.type === 'childList' && mut.addedNodes && mut.addedNodes.length) {
                mut.addedNodes.forEach(n => {
                  if ((n.nodeType === 1 || n.nodeType === 3) && !shouldSkipEmojiNode(n)) emojiMutQueue.add(n);
                });
              }
            }
            if (emojiMutQueue.size > 0 && !emojiMutScheduled) {
              emojiMutScheduled = true;
              const flushMut = () => {
                emojiMutScheduled = false;
                const modeNow = localStorage.getItem(ICON_STYLE_KEY) || (state.settings && state.settings.iconStyle) || 'pastel';
                const batch = Array.from(emojiMutQueue);
                emojiMutQueue.clear();
                batch.forEach(n => {
                  if (n && n.isConnected) transformEmojisInRoot(n, modeNow);
                });
              };
              setTimeout(flushMut, 45);
            }
          });
          // Disabled continuous document.body MutationObserver for buttery 60fps mobile tab switching!
        }

        function applyIconStyle(mode, silent) {
          const m = ICON_PACKS[mode] ? mode : 'pastel';
          localStorage.setItem(ICON_STYLE_KEY, m);
          if (typeof window.__renderHeaderLiveHeart === 'function') window.__renderHeaderLiveHeart(window.__lastLiveHeartStatus || 'ok', m);
          if (state.settings) state.settings.iconStyle = m;
          document.documentElement.setAttribute('data-iconstyle', m);
          document.querySelectorAll('.tab-panel').forEach(p => { delete p.dataset.cwIconSynced; });
          const pack = ICON_PACKS[m];
          document.querySelectorAll('.cw-ico-slot[data-ico]').forEach(el => {
            const key = el.getAttribute('data-ico');
            if (pack[key]) el.innerHTML = pack[key];
          });
          syncAllTabIconsToStyle(m);
          document.querySelectorAll('.icon-style-btn').forEach(btn => {
            const act = btn.getAttribute('data-istyle') === m;
            btn.style.borderColor = act ? 'var(--accent-royal)' : 'var(--border-subtle)';
            btn.style.background = act ? 'var(--accent-royal-soft)' : '';
          });
          if (!silent) {
            try { renderChat(); renderLearn(); } catch (_) {}
            syncAllTabIconsToStyle(m);
            saveState();
            const isZh = state.lang === 'zh';
            const names = {
              pastel: isZh ? '粉彩插画风 🎨' : '파스텔 그림체 🎨',
              line: isZh ? '极简线条风 ✨' : '미니멀 라인 ✨',
              gold: isZh ? '皇家鎏金风 👑' : '로얄 골드 👑',
              emoji: isZh ? '经典表情风 😊' : '감성 이모지 😊'
            };
            showToast(isZh ? `全应用图标与表情已切换为 ${names[m]}` : `앱 전체 이모티콘을 ${names[m]}(으)로 적용했어요!`);
          }
        }
        document.querySelectorAll('.icon-style-btn').forEach(btn => {
          btn.addEventListener('click', () => applyIconStyle(btn.getAttribute('data-istyle'), false));
        });
        applyIconStyle(localStorage.getItem(ICON_STYLE_KEY) || (state.settings && state.settings.iconStyle) || 'pastel', true);

        // Learn & Progress Reset
        const resetLearnBtnEl = document.getElementById('resetLearnProgressBtn');
        if (resetLearnBtnEl) {
          resetLearnBtnEl.addEventListener('click', () => {
            if (state.myRole !== 'suwan') {
              showToast(state.lang === 'zh' ? '仅限完(수완)模式下可重置学习进度 👑' : '한국어 학습 리셋은 수완(完) 모드에서만 가능해요 👑');
              return;
            }
            openConfirm(
              state.lang === 'zh' ? '重置韩语学习进度' : '한국어 학습 진행도 리셋',
              state.lang === 'zh' ? '确定将靖灿的累计 XP、等级、答对题数、连胜记录、表扬贴纸和复习笔记全部重置为 0 吗？' : '징찬이의 누적 XP, 레벨, 정답 횟수, 연속 정답, 칭찬 스티커, 복습 노트를 모두 0으로 초기화할까요?',
              () => {
                state.learn = { xp: 0, solved: 0, streak: 0, currentLevel: 'starter', quizIdx: 0, wrongNotes: [], solvedHistory: [], praiseStickers: [], studyLog: {}, todaySolvedCount: 0, todaySolvedDate: '', todayXp: 0, todayXpDate: '', spokenPhrases: [], resetAt: Date.now() };
                saveState(true); renderLearn(); renderHome();
                showToast(state.lang === 'zh' ? '学习进度已彻底重置为 0 🔄' : '한국어 학습 진행도가 초기화되었습니다 🔄');
              }
            );
          });
        }
        // Bind Suwan-only Praise Sticker buttons on Home
        document.querySelectorAll('.suwan-praise-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            awardPraiseStickerToJingchan(btn.getAttribute('data-praise-id'));