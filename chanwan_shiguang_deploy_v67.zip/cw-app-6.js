                  await saveVaultItemToCloudState(room, deriveDeterministicVaultKey('chat_voice', meta, cm.id), 'chat_voice', meta, normChatAud);
                }
              }
              await new Promise(r => setTimeout(r, 120));
            }
          } catch (_) {} finally {
            setTimeout(() => { __isStreamingVaultToPartner = false; }, 4000);
          }
        }
        window.__respondToPartnerVaultRequest = respondToPartnerVaultRequest;

        async function autoSyncVaultAndHistoryOnBoot() {
          try {
            const room = getSyncRoomCode();
            if (!room) return;
            const localAlbums = Array.isArray(state.albums) ? state.albums.filter(a => a && a.dataUrl) : [];
            const localVoices = Array.isArray(state.voiceLetters) ? state.voiceLetters.filter(v => v && v.audioUrl) : [];
            const localChatMedia = Array.isArray(state.chat?.messages)
              ? state.chat.messages.filter(m => m && (m.photoUrl || m.videoUrl || m.audioUrl))
              : [];
            const hasAv = !!(state.profile?.suwanAvatar || state.profile?.jingchanAvatar);

            // Step 0: Sync dedicated Cloud Study Vault (__learn_vault_v1) so Korean study progress never vanishes!
            await syncCloudLearnVault(room, false);

            // Step 0.5: Instant 1-Request Recent Media Pack pull & push!
            await pullRecentMediaPack(room, false);
            if (localAlbums.length > 0 || localVoices.length > 0 || localChatMedia.length > 0 || hasAv) {
              pushRecentMediaPack(room).catch(() => {});
            }
            // Step 1: Parallel Newest-First Vault Restore!
            const manifestItems = await fetchCloudVaultManifest(room);
            const pulledCount = await restoreVaultBatchParallel(room, manifestItems);
            if (pulledCount > 0) {
              persistMediaVaultsNow(true);
              flushIdbStateNow();
              saveState(false);
              try { renderAll(); updateVaultIndicators(); } catch (_) {}
              showToast(state.lang === 'zh'
                ? `☁️ 已自动从云端金库找回 ${pulledCount} 项相册照片/语音信 ✨`
                : `☁️ 클라우드 영구 금고에서 사진·음성편지 ${pulledCount}건을 자동 복구했어요 ✨`);
            }

            // Step 2: If our albums, voiceLetters, or Study XP are STILL empty, request real-time P2P sync from partner's phone/browser!
            if ((state.albums || []).length === 0 || (state.voiceLetters || []).length === 0 || Number(state.learn?.xp || 0) === 0) {
              requestPartnerVaultSync('boot_missing');
              if (localAlbums.length === 0 && localVoices.length === 0 && localChatMedia.length === 0 && !hasAv && !sessionStorage.getItem('cw_auto_deep_restore_v58')) {
                sessionStorage.setItem('cw_auto_deep_restore_v58', '1');
                await runFullCloudDataRestore(true);
              }
            }

            // Step 3: Per-item verified cloud upload for ANY local albums, voice letters, avatars, customVoices, or chat media not yet in couple_sync_state!
            // (Marks each item uploaded ONLY AFTER Supabase returns 200 OK — never loses items if offline in Qingdao!)
            const uploadedSet = getUploadedVaultSet();
            const manifestKeySet = new Set(manifestItems.map(x => x && x.key).filter(Boolean));
            const isAlreadyBackedUp = (vk) => uploadedSet.has(vk) && manifestKeySet.has(vk);

            if (localAlbums.length > 0 || localVoices.length > 0 || localChatMedia.length > 0 || hasAv) {
              await pushFullCloudSync();
            }
            for (const rk of ['suwan', 'jingchan']) {
              const avData = state.profile && state.profile[rk + 'Avatar'];
              const vk = deriveDeterministicVaultKey('avatar', { target: rk }, rk);
              if (avData && String(avData).startsWith('data:image/') && !isAlreadyBackedUp(vk)) {
                await saveVaultItemToCloudState(room, vk, 'avatar', { target: rk }, avData);
              }
            }
            for (const alb of localAlbums.slice(0, 80)) {
              const mKind = String(alb.mediaType || '').includes('video') ? 'album_video' : 'album_photo';
              const meta = { albumId: alb.id, authorRole: alb.authorRole || state.myRole || 'suwan', caption: alb.caption || '', translated: alb.translated || '', date: alb.date || '', category: alb.category || '' };
              const vk = deriveDeterministicVaultKey(mKind, meta, alb.id);
              if (!isAlreadyBackedUp(vk)) {
                await saveVaultItemToCloudState(room, vk, mKind, meta, alb.dataUrl);
                await sendEmqxMediaPaced(room, mKind, `boot_alb_${alb.id}`, meta, alb.dataUrl, Date.now());
              }
            }
            for (const vl of localVoices.slice(0, 50)) {
              const normAud = normalizeAudioDataUrl(vl.audioUrl);
              if (!normAud || !normAud.startsWith('data:audio/')) continue;
              const meta = { id: vl.id, sender: vl.sender || state.myRole || 'suwan', tag: vl.tag || '🎙️', note: vl.note || '', translated: vl.translated || '', date: vl.date || '', time: vl.time || '' };
              const vk = deriveDeterministicVaultKey('voice_letter', meta, vl.id);
              if (!isAlreadyBackedUp(vk)) {
                await saveVaultItemToCloudState(room, vk, 'voice_letter', meta, normAud);
                await sendEmqxMediaPaced(room, 'voice_letter', `boot_vl_${vl.id}`, meta, normAud, Date.now());
              }
            }
            for (const [phr, cvUrl] of Object.entries(state.customVoices || {})) {
              const normCv = normalizeAudioDataUrl(cvUrl);
              if (!normCv || !normCv.startsWith('data:audio/')) continue;
              const meta = { phrase: phr };
              const vk = deriveDeterministicVaultKey('custom_voice', meta, phr);
              if (!isAlreadyBackedUp(vk)) {
                await saveVaultItemToCloudState(room, vk, 'custom_voice', meta, normCv);
              }
            }
            for (const cm of localChatMedia.slice(-40)) {
              if (cm.photoUrl && String(cm.photoUrl).startsWith('data:image/')) {
                const meta = { msgId: cm.id, sender: cm.sender, time: cm.time, original: cm.original, translated: cm.translated, tgtLang: cm.tgtLang, category: cm.photoCat || '✨ 일상 순간' };
                const vk = deriveDeterministicVaultKey('chat_photo', meta, cm.id);
                if (!isAlreadyBackedUp(vk)) {
                  await saveVaultItemToCloudState(room, vk, 'chat_photo', meta, cm.photoUrl);
                }
              } else if (cm.audioUrl) {
                const normChatAud = normalizeAudioDataUrl(cm.audioUrl);
                if (normChatAud && normChatAud.startsWith('data:audio/')) {
                  const meta = { msgId: cm.id, sender: cm.sender, time: cm.time, original: cm.original, translated: cm.translated, tgtLang: cm.tgtLang };
                  const vk = deriveDeterministicVaultKey('chat_voice', meta, cm.id);
                  if (!isAlreadyBackedUp(vk)) {
                    await saveVaultItemToCloudState(room, vk, 'chat_voice', meta, normChatAud);
                  }
                }
              }
            }
          } catch (_) {}
        }

        // Boot Supabase Realtime + Postgres REST immediately!
        connectLiveSyncStream();
        setTimeout(() => { pullRecentMediaPack(getSyncRoomCode(), false).catch(() => {}); }, 350);
        setTimeout(() => {
          connectLiveSyncStream();
          flushSyncOutbox();
          recoverCustomVoicesFromCloud();
          autoSyncVaultAndHistoryOnBoot();
        }, 950);

        async function recoverCustomVoicesFromCloud() {
          try {
            const room = getSyncRoomCode();
            if (!room) return;
            const url = `${SUPABASE_URL}/rest/v1/couple_sync_events?room_id=eq.${encodeURIComponent(room)}&order=id.desc&limit=120`;
            const res = await fetchWithTimeout(url, { headers: sbHeaders() }, 8000);
            if (!res.ok) return;
            const rows = await res.json();
            if (!Array.isArray(rows)) return;
            let restored = 0;
            for (const r of rows) {
              const p = await e2eeUnwrapPayload(r && r.payload);
              if (p && p.v === 'pro2_media' && p.kind === 'custom_voice' && p.meta && p.meta.phrase && p.dataUrl) {
                if (!state.customVoices || typeof state.customVoices !== 'object') state.customVoices = {};
                if (!state.customVoices[p.meta.phrase]) {
                  state.customVoices[p.meta.phrase] = p.dataUrl; saveSuwanVoicesNow();
                  restored++;
                }
              }
            }
            if (restored > 0) {
              saveState(false);
              if (typeof renderLearn === 'function') renderLearn();
              if (typeof renderHome === 'function') renderHome();
              showToast(state.lang === 'zh' ? `🎙️ 已从云端自动恢复 ${restored} 条原声录音 💜` : `🎙️ 클라우드에서 더빙 목소리 ${restored}개를 자동 복구했어요 💜`);
            }
          } catch (_) {}
        }

        // Adaptive High-Speed Silent All-Server Refresh (3.5s in active CW Talk, 7s on other tabs/background!)
        if (livePollTimer) clearInterval(livePollTimer);
        let __bgPollTick = 0;
        livePollTimer = setInterval(() => {
          if (document.hidden) return;
          if (window.__isActivelyTyping && window.__isActivelyTyping()) return;
          if (typeof navigator !== 'undefined' && navigator.onLine === false) {
            updateLiveSyncIndicators(false, getSyncRoomCode());
            return;
          }
          __bgPollTick++;
          const inChat = !!document.getElementById('tab-translator')?.classList.contains('active');
          const wsHealthy = !!(emqxConnected && syncTransportMode === 'realtime');
          if (wsHealthy && (__bgPollTick % 2 === 1)) return;
          if (!inChat && (__bgPollTick % 2 === 0)) return;
          if (!emqxConnected) connectEmqxChinaDirect();
          pullCloudSync(false);
          if (loadSyncOutbox().length > 0) flushSyncOutbox();
        }, 4500);

        document.addEventListener('visibilitychange', () => {
          if (!document.hidden) {
            if (syncTransportMode !== 'realtime') connectLiveSyncStream();
            pullCloudSync(false);
            flushSyncOutbox();
          }
        });
        window.addEventListener('online', () => {
          connectLiveSyncStream();
          pullCloudSync(false);
          flushSyncOutbox();
        });
        window.addEventListener('offline', () => {
          syncTransportMode = 'offline';
          updateLiveSyncIndicators(false, getSyncRoomCode());
        });

        // ==================== Plus 1.3: MOBILE BACK GESTURE (SYSTEM BACK + LEFT-EDGE SWIPE) ====================
        const tabBackStack = ['home'];
        let __suppressHistoryPush = false;
        const origSwitchTabRef = switchTab;
        function closeTopOverlayIfAny() {
          const overlayIds = ['cwMicPermModal', 'cwChatBgModal', 'photoLightboxModal', 'chatVaultModal', 'patchNotesModal', 'cityModal', 'voiceRecorderModal', 'confirmModal'];
          for (const oid of overlayIds) {
            const el = document.getElementById(oid);
            if (el && !el.classList.contains('hidden')) { el.classList.add('hidden'); return true; }
          }
          const notifP = document.getElementById('notifPanel');
          if (notifP && !notifP.classList.contains('hidden')) { notifP.classList.add('hidden'); document.getElementById('notifBackdrop')?.classList.add('hidden'); return true; }
          const stTray = document.getElementById('chatStickerTray');
          if (stTray && !stTray.classList.contains('hidden')) { stTray.classList.add('hidden'); return true; }
          const plusD = document.getElementById('chatPlusDrawer');
          if (plusD && !plusD.classList.contains('hidden')) { plusD.classList.add('hidden'); if (typeof window.__syncChatPlusBtnIcon === 'function') window.__syncChatPlusBtnIcon(false); return true; }
          return false;
        }
        function handleAppBackGesture() {
          if (closeTopOverlayIfAny()) return true;
          const actEl = document.activeElement;
          if (actEl && (actEl.tagName === 'INPUT' || actEl.tagName === 'TEXTAREA' || actEl.isContentEditable)) {
            try { actEl.blur(); } catch (_) {}
            return true;
          }
          // Never auto-jump back to Home tab on accidental mobile back/popstate!
          return false;
        }
        try {
          if (!history.state || !history.state.cwInit) {
            history.replaceState({ cwInit: true, cwTab: 'home' }, '');
            history.pushState({ cwGuard: true, cwTab: 'home' }, '');
          }
        } catch (_) {}
        let lastBackWarnTs = 0;
        window.addEventListener('popstate', () => {
          // Only close open modals/trays/keyboard and re-arm history guard — NEVER jump to Home!
          closeTopOverlayIfAny();
          try { history.pushState({ cwGuard: true }, ''); } catch (_) {}
        });
        document.querySelectorAll('.dock-item[data-tab]').forEach(btn => {
          btn.addEventListener('click', () => {
            if (__suppressHistoryPush) return;
            const t = btn.getAttribute('data-tab') || 'home';
            if (tabBackStack[tabBackStack.length - 1] !== t) {
              tabBackStack.push(t);
              if (tabBackStack.length > 15) tabBackStack.shift();
              try { history.pushState({ cwTab: t }, ''); } catch (_) {}
            }
          });
        });

        // True 1:1 Dual-Panel Native ViewPager Swipe (Current + Next Tab Glide Together 1:1 With Your Finger!)
        (function setupHorizontalTabSwipe() {
          const SWIPE_TABS = ['home', 'learn', 'translator', 'diary', 'settings'];
          let sx = 0, sy = 0, st = 0, tracking = false, lockedAxis = '', animating = false;
          let activeEl = null, neighborEl = null, neighborDir = 0, curIdx = -1, lastDx = 0;

          function isHorizontallyScrollable(el) {
            let cur = el;
            while (cur && cur !== document.body) {
              if (cur.nodeType === 1) {
                const tag = cur.tagName;
                if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || tag === 'VIDEO' || tag === 'AUDIO') return true;
                if (cur.id === 'notifPanel' || cur.id === 'chatStickerTray' || cur.id === 'chatPlusDrawer' || cur.id === 'pinLockOverlay') return true;
                const cs = window.getComputedStyle(cur);
                if ((cs.overflowX === 'auto' || cs.overflowX === 'scroll') && cur.scrollWidth > cur.clientWidth + 8) return true;
              }
              cur = cur.parentElement;
            }
            return false;
          }
          function hasBlockingOverlay() {
            if (document.body.classList.contains('cw-kb-open')) return true;
            const ids = ['notifPanel', 'pinLockOverlay', 'photoLightboxModal', 'chatVaultModal', 'patchNotesModal', 'customMoodModal', 'cityPickerModal', 'confirmModal'];
            for (const id of ids) {
              const el = document.getElementById(id);
              if (el && !el.classList.contains('hidden')) return true;
            }
            return false;
          }
          function clearNeighborStyles(el) {
            if (!el) return;
            el.style.position = '';
            el.style.top = '';
            el.style.left = '';
            el.style.right = '';
            el.style.bottom = '';
            el.style.zIndex = '';
            el.style.background = '';
            el.style.overflow = '';
            el.style.pointerEvents = '';
            el.style.display = '';
            el.style.padding = '';
            el.style.gap = '';
            el.style.transform = '';
            el.style.transition = '';
            el.style.willChange = '';
          }
          function clearActiveStyles(el) {
            if (!el) return;
            el.style.transform = '';
            el.style.transition = '';
            el.style.willChange = '';
          }
          function mountNeighbor(dir) {
            // dir: -1 => swiping left (next tab on right), +1 => swiping right (prev tab on left)
            const nextIdx = dir < 0 ? curIdx + 1 : curIdx - 1;
            if (nextIdx < 0 || nextIdx >= SWIPE_TABS.length) return null;
            const nextTab = SWIPE_TABS[nextIdx];
            const el = document.getElementById('tab-' + nextTab);
            if (!el || el === activeEl) return null;
            // Ensure dirty neighbor renders quickly if empty
            if (window.__cwDirtyTabs && window.__cwDirtyTabs.has(nextTab)) {
              window.__cwDirtyTabs.delete(nextTab);
              try {
                if (nextTab === 'home') renderHome();
                else if (nextTab === 'translator') renderChat();
                else if (nextTab === 'learn') renderLearn();
                else if (nextTab === 'diary') { renderDiaryQaMemos(); renderBucketAndAlbum(); }
                else if (nextTab === 'settings') { renderSettings(); updateVaultIndicators(); }
              } catch (_) {}
            }
            const hdr = document.querySelector('header');
            const hdrH = hdr ? Math.round(hdr.getBoundingClientRect().bottom) : 64;
            el.style.position = 'fixed';
            el.style.top = hdrH + 'px';
            el.style.left = '0';
            el.style.right = '0';
            el.style.bottom = '60px';
            el.style.zIndex = '25';
            el.style.background = 'var(--bg-base)';
            el.style.overflow = 'hidden';
            el.style.pointerEvents = 'none';
            el.style.display = 'flex';
            el.style.flexDirection = 'column';
            el.style.padding = nextTab === 'translator' ? '0px' : '12px 14px';
            el.style.gap = nextTab === 'translator' ? '' : '14px';
            el.style.willChange = 'transform';
            el.style.transition = 'none';
            return el;
          }

          document.addEventListener('touchstart', (e) => {
            if (animating || !e.touches || e.touches.length !== 1) { tracking = false; return; }
            if (hasBlockingOverlay()) { tracking = false; return; }
            const t = e.touches[0];
            if (t.clientX < 18 || t.clientX > (window.innerWidth - 18)) { tracking = false; return; }
            if (isHorizontallyScrollable(e.target)) { tracking = false; return; }
            activeEl = document.querySelector('.tab-panel.active');
            if (!activeEl) { tracking = false; return; }
            const curTab = activeEl.id.replace('tab-', '');
            curIdx = curTab === 'anniversary' ? 0 : SWIPE_TABS.indexOf(curTab);
            if (curIdx === -1) { tracking = false; return; }
            sx = t.clientX;
            sy = t.clientY;
            st = Date.now();
            lastDx = 0;
            lockedAxis = '';
            neighborEl = null;
            neighborDir = 0;
            tracking = true;
          }, { passive: true });

          document.addEventListener('touchmove', (e) => {
            if (!tracking || !activeEl || !e.touches || e.touches.length !== 1) return;
            const t = e.touches[0];
            const dx = t.clientX - sx;
            const dy = t.clientY - sy;
            const adx = Math.abs(dx);
            const ady = Math.abs(dy);
            if (!lockedAxis) {
              if (adx < 10 && ady < 10) return;
              if (ady > adx * 0.85) {
                lockedAxis = 'y';
                tracking = false;
                return;
              }
              lockedAxis = 'x';
              activeEl.style.transition = 'none';
              activeEl.style.willChange = 'transform';
            }
            if (lockedAxis === 'x') {
              lastDx = dx;
              const vw = window.innerWidth || 390;
              const wantDir = dx < 0 ? -1 : 1;
              if (wantDir !== neighborDir) {
                if (neighborEl) clearNeighborStyles(neighborEl);
                neighborDir = wantDir;
                neighborEl = mountNeighbor(wantDir);
              }
              if (neighborEl) {
                // True 1:1 dual-panel tracking!
                const clampedDx = Math.max(-vw, Math.min(vw, dx));
                activeEl.style.transform = `translate3d(${clampedDx.toFixed(1)}px, 0, 0)`;
                const nPos = (wantDir < 0 ? vw : -vw) + clampedDx;
                neighborEl.style.transform = `translate3d(${nPos.toFixed(1)}px, 0, 0)`;
              } else {
                // Gentle rubber-band at first/last tab edge
                const edgeShift = Math.max(-48, Math.min(48, dx * 0.18));
                activeEl.style.transform = `translate3d(${edgeShift.toFixed(1)}px, 0, 0)`;
              }
            }
          }, { passive: true });

          function finishSwipe(commit) {
            const cur = activeEl;
            const nb = neighborEl;
            const dir = neighborDir;
            const vw = window.innerWidth || 390;
            const targetIdx = dir < 0 ? curIdx + 1 : curIdx - 1;
            const targetTab = (commit && nb && targetIdx >= 0 && targetIdx < SWIPE_TABS.length) ? SWIPE_TABS[targetIdx] : '';
            animating = true;
            const ease = 'transform 230ms cubic-bezier(0.22, 1, 0.36, 1)';
            if (cur) {
              cur.style.transition = ease;
              cur.style.transform = targetTab ? `translate3d(${dir < 0 ? -vw : vw}px, 0, 0)` : 'translate3d(0, 0, 0)';
            }
            if (nb) {
              nb.style.transition = ease;
              nb.style.transform = targetTab ? 'translate3d(0, 0, 0)' : `translate3d(${dir < 0 ? vw : -vw}px, 0, 0)`;
            }
            setTimeout(() => {
              clearActiveStyles(cur);
              clearNeighborStyles(nb);
              if (targetTab) switchTab(targetTab);
              activeEl = null;
              neighborEl = null;
              neighborDir = 0;
              animating = false;
            }, 235);
          }

          document.addEventListener('touchend', (e) => {
            if (!tracking) return;
            tracking = false;
            if (lockedAxis !== 'x' || !activeEl) return;
            const t = e.changedTouches && e.changedTouches[0];
            const dx = t ? (t.clientX - sx) : lastDx;
            const dt = Math.max(1, Date.now() - st);
            const vw = window.innerWidth || 390;
            const velocity = Math.abs(dx) / dt;
            const shouldCommit = !!neighborEl && (Math.abs(dx) >= vw * 0.22 || (Math.abs(dx) >= 34 && velocity >= 0.30));
            finishSwipe(shouldCommit);
          }, { passive: true });

          document.addEventListener('touchcancel', () => {
            if (tracking && lockedAxis === 'x') finishSwipe(false);
            tracking = false;
          }, { passive: true });
        })();

        // ==================== Plus 1.4: AUTO BUG-FIX & SYNC RECOVERY WATCHDOG ====================
        let autoHealFixCount = 0;
        function repairStateIntegrity() {
          try {
            if (state && state.startDate && state.startDate !== '2026-01-01' && !state.startDateUpdatedAt) state.startDateUpdatedAt = Date.now();
            if (state && state.cities) {
              if (state.cities.suwan && state.cities.suwan.name && state.cities.suwan.name !== '수원 · Suwon' && !state.cities.suwan.updatedAt) state.cities.suwan.updatedAt = Date.now();
              if (state.cities.jingchan && state.cities.jingchan.name && state.cities.jingchan.name !== '상하이 · 上海' && !state.cities.jingchan.updatedAt) state.cities.jingchan.updatedAt = Date.now();
            }
          } catch (_) {}
          let repaired = 0;
          if (!state || typeof state !== 'object') { state = {}; repaired++; }
          if (!state.settings || typeof state.settings !== 'object') { state.settings = {}; repaired++; }
          if (!state.chat || typeof state.chat !== 'object') { state.chat = { messages: [], qaAnswers: [], qaIdx: 0, activeSender: state.myRole || 'suwan' }; repaired++; }
          if (!Array.isArray(state.chat.messages)) { state.chat.messages = []; repaired++; }
          if (!Array.isArray(state.chat.qaAnswers)) { state.chat.qaAnswers = []; repaired++; }
          ['diaries', 'memos', 'buckets', 'capsules', 'coupons', 'anniversaries', 'schedules', 'albums', 'customPhrases', 'transHistory', 'customGifs', 'voiceLetters'].forEach(k => {
            if (!Array.isArray(state[k])) { state[k] = []; repaired++; }
          });
          if (!state.moods || typeof state.moods !== 'object') { state.moods = { suwan: '💜 보고 싶어', jingchan: '🌸 기분 최고' }; repaired++; }
          if (!state.cities || typeof state.cities !== 'object') { state.cities = { suwan: { name: '수원', tz: 'Asia/Seoul', flag: '🇰🇷' }, jingchan: { name: '상하이', tz: 'Asia/Shanghai', flag: '🇨🇳' } }; repaired++; }
          if (!state.settings.cloudSyncRoom) { state.settings.cloudSyncRoom = DEFAULT_COUPLE_ROOM; repaired++; }
          const seenMsg = new Set();
          const beforeLen = state.chat.messages.length;
          const delSetR = new Set(Array.isArray(state.deletedMsgIds) ? state.deletedMsgIds : []);
          state.chat.messages = sortChatMessagesStable(state.chat.messages.filter(m => {
            if (!m || !m.id || seenMsg.has(m.id) || delSetR.has(m.id)) return false;
            // Auto-clean weird phantom/corrupt voice messages that have no valid audio data
            const isBrokenVoice = (m.tone === '🎙️ 보이스 챗' || m.tone === '🎙️ 음성 메시지' || m.original === '🎙️ 음성 메시지' || m.original === '🎙️ 语音消息') && (!m.audioUrl || !String(m.audioUrl).startsWith('data:audio/'));
            if (isBrokenVoice) return false;
            seenMsg.add(m.id);
            return true;
          }));
          if (state.chat.messages.length !== beforeLen) repaired++;
          return repaired;
        }

        async function runAutoHealAndRepair(isManual = false) {
          const isZh = state.lang === 'zh';
          const badge = document.getElementById('autoHealBadge');
          const logEl = document.getElementById('autoHealLog');
          if (badge) {
            badge.textContent = isZh ? '🟡 修复中' : '🟡 점검 중';
            badge.style.background = 'var(--accent-royal-soft)';
            badge.style.color = 'var(--accent-royal)';
          }
          const fixedItems = repairStateIntegrity();
          if (fixedItems > 0) autoHealFixCount += fixedItems;

          let syncReconnected = false;
          try {
            if (isManual || !liveSyncSource || liveSyncSource.readyState !== 1) {
              connectLiveSyncStream();
              syncReconnected = true;
            }
            if (typeof pullCloudSync === 'function') await pullCloudSync(isManual);
            if (isManual && typeof pushFullCloudSync === 'function') await pushFullCloudSync();
          } catch (_) {}

          if (isManual) {
            try {
              const AC = window.AudioContext || window.webkitAudioContext;
              if (AC) { const c = new AC(); if (c.state === 'suspended') c.resume().catch(() => {}); }
            } catch (_) {}
            try {
              saveState(false);
              applyI18n();
              renderHome();
              renderChat();
              renderDiaryQaMemos();
              renderBucketAndAlbum();
              if (typeof renderCoupleCalendar === 'function') renderCoupleCalendar();
            } catch (_) {}
          }

          const tStr = new Date().toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
          if (badge) {
            badge.textContent = isZh ? '🟢 正常' : '🟢 정상';
            badge.style.background = 'rgba(16,185,129,0.14)';
            badge.style.color = '#059669';
          }
          if (logEl) {
            logEl.textContent = isZh
              ? `✅ 最近自检 ${tStr} · 数据完整 · 中韩同步${syncReconnected ? '已重连' : '在线'} · 累计自动修复 ${autoHealFixCount} 项`
              : `✅ 최근 점검 ${tStr} · 데이터 정상 · 한·중 동기화 ${syncReconnected ? '재연결 완료' : '연결 유지'} · 누적 복구 ${autoHealFixCount}건`;
          }
          if (isManual) {
            playGentleChime();
            showToast(isZh ? '🛠️ 自动修复与中韩实时同步重连完成！' : '🛠️ 버그 점검 및 한·중 실시간 동기화 복구 완료!');
          }
        }

        document.getElementById('runAutoHealBtn')?.addEventListener('click', () => runAutoHealAndRepair(true));
        setInterval(() => {
          if (document.hidden) return;
          try { if (localStorage.getItem('cw_auto_self_heal_v1') === '0') return; } catch (_) {}
          if (!liveSyncSource || liveSyncSource.readyState !== 1) {
            connectLiveSyncStream();
            if (typeof window.__runSilentAutoHeal === 'function') window.__runSilentAutoHeal('watchdog');
          }
        }, 45000);
        window.addEventListener('error', () => { try { repairStateIntegrity(); } catch (_) {} });
        window.addEventListener('unhandledrejection', () => { try { repairStateIntegrity(); } catch (_) {} });

        repairStateIntegrity();
        applyMyRole(state.myRole, true);

        // Auto-request browser notification permission immediately on launch + first-tap fallback (browser security requires 1 tap on Allow)
        let autoNotifAsked = false;
        function tryAutoRequestNotif() {
          if (autoNotifAsked) return;
          try {
            if ('Notification' in window && Notification.permission === 'default') {
              autoNotifAsked = true;
              Notification.requestPermission().then(() => { if (typeof updateSysNotifStatus === 'function') updateSysNotifStatus(); }).catch(() => { autoNotifAsked = false; });
            }
          } catch (_) { autoNotifAsked = false; }
        }
        setTimeout(tryAutoRequestNotif, 400);
        document.addEventListener('pointerdown', tryAutoRequestNotif, { once: true, passive: true });

        applyMyRole(state.myRole, true);
        applyLanguage(state.lang, true);
        // Preserve active or last-saved tab — NEVER force-jump back to Home!
        const __curOrSavedTab = (document.querySelector('.tab-panel.active')?.id?.replace('tab-', '')) || 'home';
        switchTab(document.getElementById('tab-' + __curOrSavedTab) ? __curOrSavedTab : 'home');
        applyTheme(state.theme, true);
        applyFont(state.font, true);
        applyDockFont(state.dockFont, true);
        applyFontSize(state.fontSize, true);
        window.__cwDirtyTabs = window.__cwDirtyTabs || new Set();
        const __bootTabNow = document.querySelector('.tab-panel.active')?.id?.replace('tab-', '') || 'home';
        ['home', 'learn', 'translator', 'diary', 'anniversary', 'settings'].forEach(t => {
          if (t !== __bootTabNow) window.__cwDirtyTabs.add(t);
        });
        if (__bootTabNow === 'home') renderHome();
        else if (__bootTabNow === 'translator') { renderChat(); renderTransHistory(); }
        else if (__bootTabNow === 'learn') renderLearn();
        else if (__bootTabNow === 'diary') { renderDiaryQaMemos(); renderBucketAndAlbum(); }
        else if (__bootTabNow === 'anniversary') renderAnniversary();
        else if (__bootTabNow === 'settings') { renderSettings(); updateVaultIndicators(); }
        renderNotifications();
        // Staggered idle pre-warm so Home/Study/Space/Setting swipe just as instantaneously as CW Talk!
        const __warmList = ['home', 'learn', 'translator', 'diary', 'settings'].filter(t => t !== __bootTabNow);
        __warmList.forEach((t, i) => {
          setTimeout(() => {
            if (!window.__cwDirtyTabs || !window.__cwDirtyTabs.has(t)) return;
            window.__cwDirtyTabs.delete(t);
            try {
              if (t === 'home') renderHome();
              else if (t === 'translator') { renderChat(); renderTransHistory(); }
              else if (t === 'learn') renderLearn();
              else if (t === 'diary') { renderDiaryQaMemos(); renderBucketAndAlbum(); }
              else if (t === 'settings') { renderSettings(); updateVaultIndicators(); }
              const pEl = document.getElementById('tab-' + t);
              const curMode = (localStorage.getItem('chanwan_icon_style_v1') || (state.settings && state.settings.iconStyle) || 'pastel') + ':' + (state.lang || 'ko');
              if (pEl && pEl.dataset.cwIconSynced !== curMode && typeof window.syncAllTabIconsToStyle === 'function') {
                window.syncAllTabIconsToStyle(null, pEl);
                pEl.dataset.cwIconSynced = curMode;
              }
            } catch (_) {}
          }, 320 + i * 260);
        });
      }


      /* ============================================================
         PLUS 1.6: WAKE/SLEEP, MEAL CHECK-IN, LAVENDER POT,
         COUPLE BALANCE GAME (30 Qs), KOREA-CHINA DATE STAMP MAP
         ============================================================ */
      const LAVENDER_STAGES = [
        { lv: 1, minXp: 0, ko: '🌱 라벤더 씨앗', zh: '🌱 薰衣草种子' },
        { lv: 2, minXp: 100, ko: '🌿 귀여운 새싹', zh: '🌿 嫩绿小芽' },
        { lv: 3, minXp: 250, ko: '🪴 쑥쑥 줄기', zh: '🪴 茁壮枝叶' },
        { lv: 4, minXp: 500, ko: '🌷 보라 꽃봉오리', zh: '🌷 紫色花苞' },
        { lv: 5, minXp: 900, ko: '🪻 만개 라벤더', zh: '🪻 盛开薰衣草' },
        { lv: 6, minXp: 1500, ko: '👑 황금빛 로얄 라벤더', zh: '👑 皇家金色薰衣草' }
      ];

      function getLavenderStageInfo(xp) {
        let cur = LAVENDER_STAGES[0];
        let next = LAVENDER_STAGES[1];
        for (let i = 0; i < LAVENDER_STAGES.length; i++) {
          if (xp >= LAVENDER_STAGES[i].minXp) {
            cur = LAVENDER_STAGES[i];
            next = LAVENDER_STAGES[i + 1] || null;
          }
        }
        return { cur, next };
      }

      function buildLavenderSvg(lv) {
        const pot = `
          <defs>
            <radialGradient id="cwHalo" cx="50%" cy="40%" r="52%">
              <stop offset="0%" stop-color="#f5d0fe" stop-opacity="0.58"/>
              <stop offset="65%" stop-color="#ddd6fe" stop-opacity="0.24"/>
              <stop offset="100%" stop-color="#ffffff" stop-opacity="0"/>
            </radialGradient>
            <linearGradient id="cwPotBody" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stop-color="#f5f0ff"/>
              <stop offset="52%" stop-color="#d8c7f7"/>
              <stop offset="100%" stop-color="#b192e8"/>
            </linearGradient>
            <linearGradient id="cwPotRim" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stop-color="#ffffff"/>
              <stop offset="100%" stop-color="#e9ddff"/>
            </linearGradient>
            <linearGradient id="cwLeaf" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stop-color="#86efac"/>
              <stop offset="100%" stop-color="#34d399"/>
            </linearGradient>
            <linearGradient id="cwBloom" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stop-color="#c084fc"/>
              <stop offset="100%" stop-color="#7c3aed"/>
            </linearGradient>
          </defs>
          <circle cx="60" cy="54" r="46" fill="url(#cwHalo)"/>
          <ellipse cx="60" cy="110" rx="26" ry="4" fill="#9b7ae2" opacity="0.18"/>
          <ellipse cx="60" cy="79" rx="24" ry="5" fill="#7c5b4b"/>
          <path d="M36 79 L42 106 Q60 112 78 106 L84 79 Z" fill="url(#cwPotBody)" stroke="#9b7ae2" stroke-width="1.1"/>
          <rect x="32" y="73" width="56" height="8.5" rx="4.2" fill="url(#cwPotRim)" stroke="#a78bfa" stroke-width="1.1"/>
          <path d="M40 89 Q60 94 80 89" fill="none" stroke="#f472b6" stroke-width="2" stroke-linecap="round" opacity="0.72"/>
          <circle cx="60" cy="92" r="5" fill="#fff5f7" stroke="#f472b6" stroke-width="1.2"/>
          <path d="M60 94.3 C57.6 92.5 57.6 90.2 59.1 90.2 C59.7 90.2 60 90.6 60 91 C60 90.6 60.3 90.2 60.9 90.2 C62.4 90.2 62.4 92.5 60 94.3 Z" fill="#ec4899"/>
        `;
        let plant = '';
        if (lv === 1) {
          plant = `
            <ellipse cx="60" cy="76.5" rx="9" ry="5" fill="#a78bfa"/>
            <ellipse cx="57.5" cy="75" rx="3" ry="1.8" fill="#ede9fe" opacity="0.85"/>
            <path d="M60 72 Q60 66 63 63" stroke="#6ee7b7" stroke-width="2" fill="none" stroke-linecap="round"/>
            <circle cx="43" cy="60" r="2" fill="#e9d5ff"/><circle cx="77" cy="56" r="1.8" fill="#fbcfe8"/>
          `;
        } else if (lv === 2) {
          plant = `
            <path d="M60 77 Q60 64 60 54" stroke="#10b981" stroke-width="2.6" fill="none" stroke-linecap="round"/>
            <path d="M60 59 C50 49 42 54 45 61 C49 66 56 64 60 59 Z" fill="url(#cwLeaf)"/>
            <path d="M60 56 C70 46 78 51 75 58 C71 63 64 61 60 56 Z" fill="url(#cwLeaf)"/>
            <circle cx="47" cy="46" r="2.2" fill="#ddd6fe"/><circle cx="74" cy="44" r="2" fill="#fbcfe8"/>
          `;
        } else if (lv === 3) {
          plant = `
            <path d="M60 77 Q55 58 49 42" stroke="#059669" stroke-width="2.4" fill="none" stroke-linecap="round"/>
            <path d="M60 77 Q60 54 60 36" stroke="#10b981" stroke-width="2.6" fill="none" stroke-linecap="round"/>
            <path d="M60 77 Q65 58 71 42" stroke="#059669" stroke-width="2.4" fill="none" stroke-linecap="round"/>
            <ellipse cx="47" cy="55" rx="8" ry="3.6" transform="rotate(-28 47 55)" fill="url(#cwLeaf)"/>
            <ellipse cx="73" cy="55" rx="8" ry="3.6" transform="rotate(28 73 55)" fill="url(#cwLeaf)"/>
            <ellipse cx="52" cy="66" rx="7" ry="3.2" transform="rotate(-22 52 66)" fill="#6ee7b7"/>
            <ellipse cx="68" cy="66" rx="7" ry="3.2" transform="rotate(22 68 66)" fill="#6ee7b7"/>
            <circle cx="60" cy="34" r="3" fill="#c4b5fd"/>
          `;
        } else if (lv === 4) {
          plant = `
            <path d="M60 77 Q53 56 46 35" stroke="#059669" stroke-width="2.3" fill="none" stroke-linecap="round"/>
            <path d="M60 77 Q60 52 60 28" stroke="#10b981" stroke-width="2.5" fill="none" stroke-linecap="round"/>
            <path d="M60 77 Q67 56 74 35" stroke="#059669" stroke-width="2.3" fill="none" stroke-linecap="round"/>
            <ellipse cx="48" cy="61" rx="8" ry="3.4" transform="rotate(-28 48 61)" fill="url(#cwLeaf)"/>
            <ellipse cx="72" cy="61" rx="8" ry="3.4" transform="rotate(28 72 61)" fill="url(#cwLeaf)"/>
            <ellipse cx="46" cy="35" rx="4.5" ry="7.5" transform="rotate(-10 46 35)" fill="url(#cwBloom)"/>
            <ellipse cx="60" cy="27" rx="5" ry="8.5" fill="url(#cwBloom)"/>
            <ellipse cx="74" cy="35" rx="4.5" ry="7.5" transform="rotate(10 74 35)" fill="url(#cwBloom)"/>
            <circle cx="46" cy="32" r="2.2" fill="#f3e8ff"/><circle cx="60" cy="24" r="2.5" fill="#f3e8ff"/><circle cx="74" cy="32" r="2.2" fill="#f3e8ff"/>
          `;
        } else {
          const spike = (x, y, rot) => `
            <g transform="translate(${x},${y}) rotate(${rot})">
              <ellipse cx="0" cy="0" rx="4.2" ry="9" fill="url(#cwBloom)"/>
              <circle cx="-2.4" cy="-3" r="2.3" fill="#c084fc"/>
              <circle cx="2.4" cy="-1.5" r="2.3" fill="#a855f7"/>
              <circle cx="-2" cy="2.5" r="2.2" fill="#d8b4fe"/>
              <circle cx="2" cy="3.5" r="2.2" fill="#c084fc"/>
              <circle cx="0" cy="-6.8" r="2.4" fill="#e9d5ff"/>
            </g>`;
          const crown = lv >= 6
            ? `<path d="M51 14 L54 9 L60 12.5 L66 9 L69 14 Z" fill="#fbbf24" stroke="#f59e0b" stroke-width="0.9"/><circle cx="30" cy="26" r="2.4" fill="#fde047"/><circle cx="90" cy="28" r="2.4" fill="#fde047"/>`
            : `<circle cx="32" cy="28" r="2.2" fill="#e9d5ff"/><circle cx="88" cy="30" r="2.2" fill="#fbcfe8"/>`;
          plant = `
            ${crown}
            <path d="M60 77 Q49 56 40 36" stroke="#059669" stroke-width="2.2" fill="none" stroke-linecap="round"/>
            <path d="M60 77 Q55 54 50 30" stroke="#10b981" stroke-width="2.3" fill="none" stroke-linecap="round"/>
            <path d="M60 77 Q60 50 60 25" stroke="#10b981" stroke-width="2.5" fill="none" stroke-linecap="round"/>
            <path d="M60 77 Q65 54 70 30" stroke="#10b981" stroke-width="2.3" fill="none" stroke-linecap="round"/>
            <path d="M60 77 Q71 56 80 36" stroke="#059669" stroke-width="2.2" fill="none" stroke-linecap="round"/>
            <ellipse cx="46" cy="65" rx="8.5" ry="3.3" transform="rotate(-26 46 65)" fill="url(#cwLeaf)"/>
            <ellipse cx="74" cy="65" rx="8.5" ry="3.3" transform="rotate(26 74 65)" fill="url(#cwLeaf)"/>
            ${spike(40, 35, -16)}
            ${spike(50, 29, -7)}
            ${spike(60, 24, 0)}
            ${spike(70, 29, 7)}
            ${spike(80, 35, 16)}
          `;
        }
        return `<svg viewBox="0 0 120 120" width="48" height="48" style="width:48px;height:48px;display:block;" xmlns="http://www.w3.org/2000/svg">${pot}${plant}</svg>`;
      }

      function addLavenderBonusXp(reasonKey, amount) {
        try {
          if (!state.lavender) state.lavender = JSON.parse(JSON.stringify(DEFAULT_STATE.lavender));
          if (!state.lavender.bonusLog) state.lavender.bonusLog = {};
          const today = getKstDateString();
          const role = state.myRole || 'suwan';
          const logKey = `${today}_${role}_${reasonKey}`;
          if (state.lavender.bonusLog[logKey]) return false;
          state.lavender.bonusLog[logKey] = true;
          // Prune old keys
          const keys = Object.keys(state.lavender.bonusLog);
          if (keys.length > 40) keys.slice(0, keys.length - 40).forEach(k => delete state.lavender.bonusLog[k]);
          state.lavender.xp = (Number(state.lavender.xp) || 0) + (Number(amount) || 5);
          state.lavender.updatedAt = Date.now();
          return true;
        } catch (_) { return false; }
      }

      function renderLavenderPot() {
        const wrap = document.getElementById('lavenderSvgWrap');
        if (!wrap) return;
        if (!state.lavender) state.lavender = JSON.parse(JSON.stringify(DEFAULT_STATE.lavender));
        const isZh = state.lang === 'zh';
        const xp = Number(state.lavender.xp || 0);
        const { cur, next } = getLavenderStageInfo(xp);
        const today = getKstDateString();
        const role = state.myRole || 'suwan';
        const swDone = state.lavender.lastWaterSuwan === today;
        const jcDone = state.lavender.lastWaterJingchan === today;
        const myDone = role === 'suwan' ? swDone : jcDone;

        const titleEl = document.getElementById('lavenderStageTitle');
        const xpBadge = document.getElementById('lavenderXpBadge');
        const nextLbl = document.getElementById('lavenderNextLabel');
        const pctLbl = document.getElementById('lavenderPctLabel');
        const barEl = document.getElementById('lavenderProgressBar');
        const partnerEl = document.getElementById('lavenderPartnerStatus');
        const waterBtn = document.getElementById('lavenderWaterBtn');

        if (titleEl) titleEl.textContent = `Lv.${cur.lv} ${isZh ? cur.zh : cur.ko}`;
        if (xpBadge) xpBadge.textContent = `${xp} XP`;
        wrap.innerHTML = buildLavenderSvg(cur.lv);

        let pct = 100;
        if (next) {
          const span = Math.max(1, next.minXp - cur.minXp);
          pct = Math.min(100, Math.max(0, Math.round(((xp - cur.minXp) / span) * 100)));
          const remain = Math.max(0, next.minXp - xp);
          if (nextLbl) nextLbl.textContent = isZh ? `距离下一阶段还差 ${remain} XP` : `다음 단계까지 ${remain} XP`;
        } else {
          if (nextLbl) nextLbl.textContent = isZh ? '✨ 已达最高阶段！继续浇水保持花香' : '✨ 최고 단계 달성! 매일 물주며 유지해요';
        }
        if (pctLbl) pctLbl.textContent = `${pct}%`;
        if (barEl) barEl.style.width = `${pct}%`;

        if (partnerEl) {
          partnerEl.innerHTML = `
            <span style="color: ${swDone ? '#059669' : 'var(--text-muted)'};">${isZh ? '完' : '수완'}${swDone ? '💧' : '·'}</span>
            <span style="color: ${jcDone ? '#059669' : 'var(--text-muted)'};">${isZh ? '靖灿' : '징찬'}${jcDone ? '💧' : '·'}</span>
          `;
        }
        if (waterBtn) {
          waterBtn.disabled = myDone;
          waterBtn.style.opacity = myDone ? '0.6' : '1';
          waterBtn.textContent = myDone
            ? (isZh ? '✅ 완료' : '✅ 완료')
            : (isZh ? '💧 浇水' : '💧 물주기');
        }
      }

      // ---- 2) Wake / Sleep 1-Tap Check-in ----
      function renderWakeSleepCards() {
        const isZh = state.lang === 'zh';
        const role = state.myRole || 'suwan';
        const today = getKstDateString();

        const fmtBadge = (obj) => {
          if (!obj || !obj.status || obj.date !== today) {
            return { text: isZh ? '✨ 今日待打卡' : '✨ 오늘 상태 대기', bg: 'var(--surface-2)', col: 'var(--text-muted)' };
          }
          if (obj.status === 'wake') {
            return { text: `☀️ ${obj.time || ''} ${isZh ? '已起床' : '기상'}`, bg: 'rgba(245,158,11,0.16)', col: '#b45309' };
          }
          return { text: `🌙 ${obj.time || ''} ${isZh ? '已入睡' : '취침'}`, bg: 'rgba(124,58,237,0.15)', col: 'var(--accent-royal)' };
        };

        const swB = fmtBadge(state.profile?.suwanSleep);
        const jcB = fmtBadge(state.profile?.jingchanSleep);
        const swBadgeEl = document.getElementById('suwanSleepBadge');
        const jcBadgeEl = document.getElementById('jingchanSleepBadge');
        if (swBadgeEl) { swBadgeEl.textContent = swB.text; swBadgeEl.style.background = swB.bg; swBadgeEl.style.color = swB.col; }
        if (jcBadgeEl) { jcBadgeEl.textContent = jcB.text; jcBadgeEl.style.background = jcB.bg; jcBadgeEl.style.color = jcB.col; }

        const swCtrl = document.getElementById('suwanSleepControls');
        const jcCtrl = document.getElementById('jingchanSleepControls');
        if (swCtrl) swCtrl.classList.toggle('hidden', role !== 'suwan');
        if (jcCtrl) jcCtrl.classList.toggle('hidden', role !== 'jingchan');

        const wTxt = isZh ? '☀️ 起床' : '☀️ 기상';
        const sTxt = isZh ? '🌙 晚安' : '🌙 취침';
        ['suwanWakeBtn', 'jingchanWakeBtn'].forEach(id => { const el = document.getElementById(id); if (el) el.textContent = wTxt; });
        ['suwanSleepBtn', 'jingchanSleepBtn'].forEach(id => { const el = document.getElementById(id); if (el) el.textContent = sTxt; });
      }

      function handleWakeSleepTap(targetRole, status) {
        const myRole = state.myRole || 'suwan';
        if (targetRole !== myRole) {
          showToast(state.lang === 'zh' ? '只能打卡自己的状态哦 🔒' : '본인 프로필에서만 체크인할 수 있어요 🔒');
          return;
        }
        const tz = targetRole === 'suwan' ? (state.cities?.suwan?.tz || 'Asia/Seoul') : (state.cities?.jingchan?.tz || 'Asia/Shanghai');
        let timeStr = '';
        try { timeStr = new Intl.DateTimeFormat('ko-KR', { timeZone: tz, hour: '2-digit', minute: '2-digit', hour12: false }).format(new Date()); }
        catch (_) { timeStr = getKstTimeShort(); }
        const key = targetRole === 'suwan' ? 'suwanSleep' : 'jingchanSleep';
        state.profile[key] = { status, time: timeStr, date: getKstDateString(), updatedAt: Date.now() };
        addLavenderBonusXp('sleep_' + status, 5);
        saveState(true);
        renderHome();
        const myName = targetRole === 'suwan' ? '수완(完)' : '靖灿(灿)';
        const isWake = status === 'wake';
        pushNotification(
          isWake ? '☀️' : '🌙',
          isWake ? `${myName}이 일어났어요!` : `${myName}이 자러 갔어요!`,
          isWake ? `${myName}起床啦！早安 ☀️` : `${myName}准备睡觉啦！晚安 🌙`,
          `${timeStr} ${isWake ? '좋은 하루 보내 💜' : '잘 자, 좋은 꿈 꿔 💜'}`,
          `${timeStr} ${isWake ? '今天也要开心哦 💜' : '晚安好梦 💜'}`,
          'home', '', 'post', false, targetRole
        );
        showToast(state.lang === 'zh'
          ? (isWake ? `☀️ 早安打卡完成 (${timeStr}) · 花盆 +5 XP` : `🌙 晚安打卡完成 (${timeStr}) · 花盆 +5 XP`)
          : (isWake ? `☀️ 기상 체크인 완료 (${timeStr}) · 화분 +5 XP` : `🌙 취침 체크인 완료 (${timeStr}) · 화분 +5 XP`));
      }

      // ---- 3) Daily Meal Check-in ----
      function ensureTodayMeals() {
        const today = getKstDateString();
        if (!state.meals || state.meals.date !== today) {
          state.meals = JSON.parse(JSON.stringify(DEFAULT_STATE.meals));
          state.meals.date = today;
        }
        return state.meals;
      }

      function renderMealCheckin() {}

      // ---- 4) Couple Balance Game (30 Bilingual Questions) ----
      const BALANCE_QUESTIONS = [
        { id: 'bq01', catKo: '💘 장거리 연애', catZh: '💘 异地恋', qKo: '연락 스타일은?', qZh: '更喜欢哪种联系频率？', aKo: '매일 5분 영상통화', aZh: '每天5分钟视频通话', bKo: '주말에 2시간 푹 통화', bZh: '周末畅聊2小时' },
        { id: 'bq02', catKo: '✈️ 한·중 데이트', catZh: '✈️ 中韩约会', qKo: '다음 만남 첫 코스!', qZh: '下次见面第一站去哪？', aKo: '수원 화성 야경 산책', aZh: '水原华城夜景散步', bKo: '상하이 와이탄 야경', bZh: '上海外滩看夜景' },
        { id: 'bq03', catKo: '🍽️ 야식 취향', catZh: '🍽️ 宵夜偏好', qKo: '밤 11시 야식 픽은?', qZh: '晚上11点宵夜选哪个？', aKo: '바삭한 한국 치킨 🍗', aZh: '香脆韩式炸鸡 🍗', bKo: '얼얼한 마라탕·훠궈 🍲', bZh: '热辣麻辣烫/火锅 🍲' },
        { id: 'bq04', catKo: '💑 애정 표현', catZh: '💑 表达爱意', qKo: '더 설레는 애정 표현은?', qZh: '更让你心动的表达是？', aKo: '하루 종일 사랑해 폭격', aZh: '一整天不停说我爱你', bKo: '말없이 꽉 안아주기', bZh: '默默紧紧抱住你' },
        { id: 'bq05', catKo: '🧳 여행 스타일', catZh: '🧳 旅行风格', qKo: '둘이 떠나는 여행은?', qZh: '两个人的旅行风格？', aKo: '분 단위 완벽 계획형', aZh: '精细完美的攻略派', bKo: '발길 닿는 대로 즉흥형', bZh: '随性浪漫的自由派' },
        { id: 'bq06', catKo: '☕ 카페 데이트', catZh: '☕ 咖啡约会', qKo: '함께 마실 음료는?', qZh: '一起喝什么？', aKo: '아이스 아메리카노', aZh: '冰美式咖啡', bKo: '달콤한 버블 밀크티', bZh: '甜甜的珍珠奶茶' },
        { id: 'bq07', catKo: '🎬 집 데이트', catZh: '🎬 宅家约会', qKo: '비 오는 주말에는?', qZh: '下雨的周末怎么过？', aKo: '이불 속 영화 정주행', aZh: '窝在被窝里刷电影', bKo: '같이 요리해서 홈파티', bZh: '一起做饭开居家派对' },
        { id: 'bq08', catKo: '📸 사진 스타일', catZh: '📸 拍照风格', qKo: '커플 사진 남길 때!', qZh: '拍情侣照时更喜欢？', aKo: '다정한 거울 셀카', aZh: '甜蜜的对镜自拍', bKo: '자연스러운 스냅 사진', bZh: '自然的抓拍瞬间' },
        { id: 'bq09', catKo: '🎁 기념일 선물', catZh: '🎁 纪念日礼物', qKo: '더 감동적인 선물은?', qZh: '更感动的礼物是？', aKo: '정성 가득 손편지', aZh: '满含真心的手写信', bKo: '평소 갖고 싶던 깜짝 선물', bZh: '心仪已久的惊喜礼物' },
        { id: 'bq10', catKo: '🌅 시간대', catZh: '🌅 作息习惯', qKo: '나는 어느 쪽?', qZh: '你更偏向哪种作息？', aKo: '상쾌한 아침형 인간', aZh: '清爽的早起星人', bKo: '감성 충만 새벽형 인간', bZh: '浪漫的夜猫子星人' },
        { id: 'bq11', catKo: '🎡 놀이공원', catZh: '🎡 游乐园', qKo: '상하이 디즈니랜드에서!', qZh: '去上海迪士尼的话！', aKo: '스릴 만점 롤러코스터', aZh: '刺激过山车冲冲冲', bKo: '퍼레이드 & 불꽃놀이 힐링', bZh: '看花车巡游和烟花秀' },
        { id: 'bq12', catKo: '🌸 계절 취향', catZh: '🌸 季节喜好', qKo: '가장 좋아하는 데이트 계절?', qZh: '最喜欢哪个季节约会？', aKo: '벚꽃 흩날리는 봄 🌸', aZh: '樱花飘落的春天 🌸', bKo: '첫눈 내리는 겨울 ❄️', bZh: '飘着初雪的冬天 ❄️' },
        { id: 'bq13', catKo: '🐶 반려동물', catZh: '🐶 萌宠选择', qKo: '나중에 같이 키운다면?', qZh: '以后一起养宠物的话？', aKo: '애교쟁이 강아지 🐶', aZh: '粘人小狗狗 🐶', bKo: '도도한 고양이 🐱', bZh: '高冷小猫咪 🐱' },
        { id: 'bq14', catKo: '💬 싸웠을 때', catZh: '💬 吵架和好', qKo: '살짝 토라졌을 때 화해법은?', qZh: '闹小脾气时怎么哄？', aKo: '바로 전화해서 풀기', aZh: '马上打电话哄好', bKo: '잠시 생각 후 진심 장문 톡', bZh: '冷静后发真诚小作文' },
        { id: 'bq15', catKo: '🍰 디저트', catZh: '🍰 甜品控', qKo: '밥 먹고 후식은?', qZh: '饭后甜品选哪个？', aKo: '생크림 딸기 케이크 🍰', aZh: '草莓奶油蛋糕 🍰', bKo: '쫀득한 젤라또 아이스크림 🍨', bZh: '绵密意式冰淇淋 🍨' },
        { id: 'bq16', catKo: '🌊 휴양지', catZh: '🌊 度假地', qKo: '1주일 휴가가 생긴다면?', qZh: '如果有一周假期？', aKo: '에메랄드빛 제주 바다 🌊', aZh: '蔚蓝的济州岛海边 🌊', bKo: '조용한 숲속 온천 리조트 🌲', bZh: '安静的森林温泉度假村 🌲' },
        { id: 'bq17', catKo: '🎵 음악 취향', catZh: '🎵 听歌氛围', qKo: '드라이브할 때 틀고 싶은 곡은?', qZh: '自驾兜风时想听什么歌？', aKo: '잔잔한 감성 발라드', aZh: '温柔抒情慢歌', bKo: '신나는 케이팝 댄스곡', bZh: '欢快动感的K-POP' },
        { id: 'bq18', catKo: '👕 커플룩', catZh: '👕 情侣装', qKo: '데이트할 때 커플룩은?', qZh: '约会穿情侣装喜欢？', aKo: '똑같은 디자인 트윈룩', aZh: '一模一样的同款', bKo: '색감만 맞춘 시밀러룩', bZh: '同色系搭配呼应' },
        { id: 'bq19', catKo: '🍜 면 요리', catZh: '🍜 面食对决', qKo: '오늘 점심 메뉴는?', qZh: '今天午饭吃哪碗面？', aKo: '얼큰한 짬뽕 / 라면', aZh: '热辣海鲜面 / 拉面', bKo: '고소한 파스타 / 우동', bZh: '浓郁意面 / 乌冬面' },
        { id: 'bq20', catKo: '💬 말투', catZh: '💬 聊天语气', qKo: '상대방의 더 귀여운 모습은?', qZh: '对方哪种样子更可爱？', aKo: '애교 폭발 말랑말랑 모드', aZh: '疯狂撒娇软萌模式', bKo: '장난기 가득 틱틱 모드', bZh: '爱开玩笑斗嘴模式' },
        { id: 'bq21', catKo: '🏠 미래 드림하우스', catZh: '🏠 梦想之家', qKo: '둘이 살 집을 고른다면?', qZh: '选以后一起住的家？', aKo: '시티뷰 통창 고층 아파트', aZh: '落地窗夜景高层公寓', bKo: '정원이 있는 아늑한 주택', bZh: '带小花园的温馨洋房' },
        { id: 'bq22', catKo: '📱 알림', catZh: '📱 手机习惯', qKo: '메시지 답장 스타일은?', qZh: '回消息的习惯是？', aKo: '보이면 1초 만에 칼답', aZh: '看到立刻秒回', bKo: '할 일 끝내고 길게 정성 답장', bZh: '忙完后认真回长消息' },
        { id: 'bq23', catKo: '🎥 영화 장르', catZh: '🎥 电影类型', qKo: '심야 영화 한 편 고른다면?', qZh: '午夜场电影选哪部？', aKo: '달달한 로맨틱 코미디', aZh: '甜甜的浪漫爱情喜剧', bKo: '손에 땀 쥐는 스릴러·액션', bZh: '扣人心弦的悬疑动作片' },
        { id: 'bq24', catKo: '🌅 산책 시간', catZh: '🌅 散步时光', qKo: '손잡고 걷고 싶은 시간은?', qZh: '最想牵手散步的时刻？', aKo: '노을 지는 황금빛 저녁', aZh: '夕阳西下的金色傍晚', bKo: '별빛 반짝이는 한밤중', bZh: '星光闪烁的安静夜晚' },
        { id: 'bq25', catKo: '🎂 생일 파티', catZh: '🎂 生日派对', qKo: '내 생일을 보낸다면?', qZh: '过生日更想要哪种？', aKo: '둘만의 프라이빗 레스토랑', aZh: '两个人的私密烛光晚餐', bKo: '직접 차려주는 깜짝 집밥', bZh: '亲手做的爱心生日餐' },
        { id: 'bq26', catKo: '🛋️ 주말 아침', catZh: '🛋️ 周末早晨', qKo: '꿀 같은 휴일 아침엔?', qZh: '甜蜜的周末早上？', aKo: '11시까지 푹 늦잠 자기', aZh: '一起睡懒觉到11点', bKo: '일찍 일어나 브런치 데이트', bZh: '早起去吃精致早午餐' },
        { id: 'bq27', catKo: '🎤 노래방', catZh: '🎤 KTV约会', qKo: '노래방 가면 나는?', qZh: '去KTV时你是哪种？', aKo: '마이크 독점 열창 타입', aZh: '麦霸深情献唱型', bKo: '탬버린 흔들며 응원 타입', bZh: '摇铃鼓捧场鼓掌型' },
        { id: 'bq28', catKo: '✈️ 비행기 좌석', catZh: '✈️ 飞机选座', qKo: '같이 비행기 탈 때!', qZh: '一起坐飞机时选哪边？', aKo: '구름 보는 창가 자리 ☁️', aZh: '看云海的靠窗座 ☁️', bKo: '편하게 움직이는 복도 자리', bZh: '方便走动的过道座' },
        { id: 'bq29', catKo: '💌 호칭', catZh: '💌 专属称呼', qKo: '더 듣고 싶은 애칭은?', qZh: '更想听对方叫你什么？', aKo: '자기야 / 宝贝', aZh: '亲爱的 / 宝贝', bKo: '이름 다정하게 부르기', bZh: '温柔地叫我的名字' },
        { id: 'bq30', catKo: '✨ 타임머신', catZh: '✨ 时光机', qKo: '타임머신이 있다면?', qZh: '如果有时光机想去？', aKo: '처음 만났던 설레는 날로', aZh: '回到初次心动的那天', bKo: '10년 뒤 행복한 우리 보러', bZh: '去看看10年后幸福的我们' }
      ];

      function renderBalanceGame() {
        if (typeof syncBalancePokeBtnLabel === 'function') syncBalancePokeBtnLabel();
        const card = document.getElementById('balanceQuestionCard');
        if (!card) return;
        if (!state.balanceGame) state.balanceGame = { currentIdx: 0, answers: {}, updatedAt: 0 };
        if (!state.balanceGame.answers) state.balanceGame.answers = {};
        const isZh = state.lang === 'zh';
        const role = state.myRole || 'suwan';
        const partnerRole = role === 'suwan' ? 'jingchan' : 'suwan';

        const idx = ((Number(state.balanceGame.currentIdx) || 0) % BALANCE_QUESTIONS.length + BALANCE_QUESTIONS.length) % BALANCE_QUESTIONS.length;
        state.balanceGame.currentIdx = idx;
        const q = BALANCE_QUESTIONS[idx];
        const ans = state.balanceGame.answers[q.id] || { suwan: '', jingchan: '' };
        const myPick = ans[role] || '';
        const partnerPick = ans[partnerRole] || '';
        const bothDone = !!(ans.suwan && ans.jingchan);

        // Compute match stats
        let completed = 0, matched = 0;
        const historyItems = [];
        BALANCE_QUESTIONS.forEach((item, i) => {
          const a = state.balanceGame.answers[item.id];
          if (a && a.suwan && a.jingchan) {
            completed++;
            const same = a.suwan === a.jingchan;
            if (same) matched++;
            historyItems.push({ item, i, a, same });
          }
        });
        const rate = completed ? Math.round((matched / completed) * 100) : null;

        const tagEl = document.getElementById('balanceTag');
        const matchEl = document.getElementById('balanceMatchTitle');
        const qNumEl = document.getElementById('balanceQNum');
        const qCatEl = document.getElementById('balanceQCat');
        const qP = document.getElementById('balanceQTitlePrimary');
        const qS = document.getElementById('balanceQTitleSecondary');
        const optABtn = document.getElementById('balanceOptABtn');
        const optBBtn = document.getElementById('balanceOptBBtn');

        if (tagEl) tagEl.textContent = isZh ? '⚖️ 情侣二选一 · 双方隐藏选择 & 默契率' : '⚖️ 커플 밸런스 게임 · 동시 선택 & 일치율';
        if (matchEl) matchEl.textContent = isZh
          ? `💕 我们的默契率 ${rate !== null ? rate + '%' : '—%'} (${completed}/${BALANCE_QUESTIONS.length}题已完成)`
          : `💕 우리 일치율 ${rate !== null ? rate + '%' : '—%'} (${completed}/${BALANCE_QUESTIONS.length}개 완료)`;
        if (qNumEl) qNumEl.textContent = `Q${idx + 1} / ${BALANCE_QUESTIONS.length}`;
        if (qCatEl) qCatEl.textContent = isZh ? q.catZh : q.catKo;
        if (qP) qP.textContent = isZh ? q.qZh : q.qKo;
        if (qS) qS.textContent = isZh ? q.qKo : q.qZh;

        document.getElementById('balanceOptAPrimary').textContent = isZh ? q.aZh : q.aKo;
        document.getElementById('balanceOptASecondary').textContent = isZh ? q.aKo : q.aZh;
        document.getElementById('balanceOptBPrimary').textContent = isZh ? q.bZh : q.bKo;
        document.getElementById('balanceOptBSecondary').textContent = isZh ? q.bKo : q.bZh;

        const badgeFor = (opt) => {
          if (bothDone) {
            const who = [];
            if (ans.suwan === opt) who.push(isZh ? '完' : '수완');
            if (ans.jingchan === opt) who.push(isZh ? '靖灿' : '징찬');
            return who.length ? `✅ ${who.join(' · ')}` : '';
          }
          return myPick === opt ? (isZh ? '✅ 我的选择' : '✅ 내 선택') : '';
        };
        document.getElementById('balanceOptABadge').textContent = badgeFor('A');
        document.getElementById('balanceOptBBadge').textContent = badgeFor('B');

        if (optABtn) optABtn.style.borderColor = myPick === 'A' ? 'var(--accent-royal)' : 'var(--border-subtle)';
        if (optBBtn) optBBtn.style.borderColor = myPick === 'B' ? '#db2777' : 'var(--border-subtle)';

        const statusEl = document.getElementById('balanceStatusBanner');
        if (statusEl) {
          if (bothDone) {
            const isSame = ans.suwan === ans.jingchan;
            statusEl.style.background = isSame ? 'rgba(16,185,129,0.14)' : 'rgba(244,114,182,0.14)';
            statusEl.style.color = isSame ? '#059669' : '#be185d';
            statusEl.textContent = isSame
              ? (isZh ? `💜 默契满分！两人都选了 ${ans.suwan}！` : `💜 천생연분 일치! 둘 다 ${ans.suwan}을(를) 골랐어요!`)
              : (isZh ? `😆 不一样也很可爱！(完: ${ans.suwan} / 靖灿: ${ans.jingchan})` : `😆 달라도 귀여운 우리! (수완: ${ans.suwan} / 징찬: ${ans.jingchan})`);
          } else if (myPick && !partnerPick) {
            statusEl.style.background = 'var(--accent-royal-soft)';
            statusEl.style.color = 'var(--accent-royal)';
            statusEl.textContent = isZh ? '🔒 你已选择完毕！等对方选好后立刻揭晓结果~' : '🔒 내 선택 완료! 상대방이 고르면 바로 결과가 공개돼요~';
          } else if (!myPick && partnerPick) {
            statusEl.style.background = 'rgba(245,158,11,0.15)';
            statusEl.style.color = '#b45309';
            statusEl.textContent = isZh ? '💌 对方已经选好啦！你一选就能马上看到答案！' : '💌 상대방이 이미 골랐어요! 나도 고르면 바로 공개돼요!';
          } else {
            statusEl.style.background = 'var(--surface-2)';
            statusEl.style.color = 'var(--text-secondary)';
            statusEl.textContent = isZh ? '👆 秘密选择 A 或 B，双方都选后揭晓答案' : '👆 A 또는 B를 비밀리에 골라보세요! 둘 다 고르면 공개돼요';
          }
        }

        const histTitle = document.getElementById('balanceHistoryTitle');
        const histCnt = document.getElementById('balanceHistoryCount');
        const histList = document.getElementById('balanceHistoryList');
        if (histTitle) histTitle.textContent = isZh ? '📜 已揭晓的默契记录' : '📜 공개된 밸런스 기록';
        if (histCnt) histCnt.textContent = isZh ? `${historyItems.length}题` : `${historyItems.length}개`;
        if (histList) {
          if (!historyItems.length) {
            histList.innerHTML = `<div class="text-xs text-mut text-center py-3">${isZh ? '还没有双方都完成的题目哦，快来测测默契吧！' : '아직 둘 다 완료한 질문이 없어요. 첫 문제를 골라보세요!'}</div>`;
          } else {
            histList.innerHTML = historyItems.slice().reverse().map(h => `
              <button type="button" class="balance-jump-btn royal-subcard w-full rounded-2xl p-3 text-left flex items-center justify-between gap-2 hover:border-purple-400 transition" data-bq-idx="${h.i}">
                <div class="min-w-0 flex-1">
                  <div class="text-xs font-bold truncate">${escapeHtml(isZh ? h.item.qZh : h.item.qKo)}</div>
                  <div class="text-[10.5px] text-sec truncate mt-0.5">${isZh ? '完' : '수완'}: ${h.a.suwan} · ${isZh ? '靖灿' : '징찬'}: ${h.a.jingchan}</div>
                </div>
                <span class="text-[10.5px] font-bold px-2 py-0.5 rounded-full shrink-0" style="background: ${h.same ? 'rgba(16,185,129,0.14)' : 'rgba(244,114,182,0.14)'}; color: ${h.same ? '#059669' : '#be185d'};">${h.same ? (isZh ? '💜 一致' : '💜 일치') : (isZh ? '😆 不同' : '😆 다름')}</span>
              </button>
            `).join('');
            histList.querySelectorAll('.balance-jump-btn').forEach(b => {
              b.addEventListener('click', () => {
                state.balanceGame.currentIdx = Number(b.getAttribute('data-bq-idx')) || 0;
                renderBalanceGame();
              });
            });
          }
        }
      }

      function syncBalancePokeBtnLabel() {
        const pokeBtn = document.getElementById('balancePokeBtn');
        if (!pokeBtn) return;
        const isZh = state.lang === 'zh';
        const partnerName = (state.myRole === 'jingchan') ? (isZh ? '秀完' : '수완님') : (isZh ? '靖灿' : '징찬님');
        pokeBtn.textContent = isZh ? `👉 戳一戳${partnerName}来做这题` : `👉 ${partnerName} 콕 찌르기 (알림 보내기)`;
      }

      let __lastBalancePokeTs = 0;
      function pokePartnerBalanceGame() {
        const now = Date.now();
        const isZh = state.lang === 'zh';
        if (now - __lastBalancePokeTs < 5000) {
          showToast(isZh ? '⏳ 刚刚戳过了，5秒后再试哦' : '⏳ 방금 콕 찔렀어요! 5초 뒤에 다시 눌러주세요');
          return;
        }
        __lastBalancePokeTs = now;
        const idx = ((Number(state.balanceGame?.currentIdx) || 0) % BALANCE_QUESTIONS.length + BALANCE_QUESTIONS.length) % BALANCE_QUESTIONS.length;
        const q = BALANCE_QUESTIONS[idx] || BALANCE_QUESTIONS[0];
        const myRole = state.myRole || 'suwan';
        const partnerRole = myRole === 'suwan' ? 'jingchan' : 'suwan';
        const koMsg = `👉 징찬님이 콕 찔렀어요! Q${idx + 1} 「${q.qKo}」 같이 골라요`;
        const zhMsg = `👉 秀完戳了你一下！快来选第${idx + 1}题「${q.qZh}」吧`;
        try {
          if (typeof sendPartnerNativePush === 'function') {
            sendPartnerNativePush('밸런스 게임 콕 찌르기', partnerRole === 'jingchan' ? zhMsg : koMsg);
          }
        } catch (_) {}
        try {
          pushNotification('👉', '밸런스 게임 콕 찌르기', '默契游戏戳一戳', koMsg, zhMsg, 'diary', 'balance', 'balance', false, myRole);
          saveState(true);
        } catch (_) {}
        showToast(isZh ? '👉 已戳一戳对方，发送了横幅通知！' : '👉 상대방을 콕 찔러 알림 배너를 보냈어요!');
      }
      window.__pokePartnerBalanceGame = pokePartnerBalanceGame;
      const __bPokeEl = document.getElementById('balancePokeBtn');
      if (__bPokeEl && !__bPokeEl.dataset.cwBound) {
        __bPokeEl.dataset.cwBound = '1';
        __bPokeEl.addEventListener('click', pokePartnerBalanceGame);
      }

      function pickBalanceOption(opt) {
        if (!state.balanceGame) state.balanceGame = { currentIdx: 0, answers: {}, updatedAt: 0 };
        if (!state.balanceGame.answers) state.balanceGame.answers = {};
        const idx = Number(state.balanceGame.currentIdx || 0);
        const q = BALANCE_QUESTIONS[idx];
        if (!q) return;
        const role = state.myRole || 'suwan';
        const partnerRole = role === 'suwan' ? 'jingchan' : 'suwan';
        const cur = state.balanceGame.answers[q.id] || { suwan: '', jingchan: '', updatedAt: 0 };
        cur[role] = opt;
        cur.updatedAt = Date.now();
        state.balanceGame.answers[q.id] = cur;
        state.balanceGame.updatedAt = Date.now();
        addLavenderBonusXp('balance', 5);
        const bothDone = !!(cur.suwan && cur.jingchan);
        const same = bothDone && cur.suwan === cur.jingchan;
        const koPush = bothDone
          ? (same ? `💜 Q${idx + 1} 마음이 똑같아요! 둘 다 ${opt} 선택` : `😆 Q${idx + 1} 서로 다른 걸 골랐어요! 결과 확인해보세요`)
          : `⚖️ 징찬님이 Q${idx + 1} 「${q.qKo}」을 골랐어요! 내 답도 선택해보세요`;
        const zhPush = bothDone
          ? (same ? `💜 第${idx + 1}题心有灵犀！我们都选了 ${opt}` : `😆 第${idx + 1}题我们选得不一样，快来看看吧！`)
          : `⚖️ 秀完刚选了第${idx + 1}题「${q.qZh}」，快来选你的答案吧！`;
        try {
          if (typeof sendPartnerNativePush === 'function') {
            sendPartnerNativePush('밸런스 게임', partnerRole === 'jingchan' ? zhPush : koPush);
          }
          pushNotification('⚖️', '밸런스 게임 알림', '默契游戏提醒', koPush, zhPush, 'diary', 'balance', 'balance', false, role);
        } catch (_) {}
        saveState(true);
        renderBalanceGame();
        renderLavenderPot();
        showToast(state.lang === 'zh' ? `⚖️ 已选择 ${opt} 并通知对方！` : `⚖️ ${opt} 선택 완료 · 상대방에게 알림을 보냈어요!`);
      }

      // ---- 5) Korea <-> China Date Stamp Map ----
      const DEFAULT_DATE_SPOTS = [
        { id: 'dm_kr_1', country: 'kr', cityKo: '수원', cityZh: '水原', ko: '수원 화성 야경 산책', zh: '水原华城夜景散步', emoji: '🏯' },
        { id: 'dm_kr_2', country: 'kr', cityKo: '서울', cityZh: '首尔', ko: '남산타워 사랑의 자물쇠', zh: '南山塔挂爱情锁', emoji: '🗼' },
        { id: 'dm_kr_3', country: 'kr', cityKo: '서울', cityZh: '首尔', ko: '한강 피크닉 & 라면 먹기', zh: '汉江野餐吃拉面', emoji: '🧺' },
        { id: 'dm_kr_4', country: 'kr', cityKo: '부산', cityZh: '釜山', ko: '해운대 해변열차 & 광안리 야경', zh: '海云台海边列车与广安里夜景', emoji: '🌊' },
        { id: 'dm_kr_5', country: 'kr', cityKo: '제주', cityZh: '济州', ko: '제주도 감귤 카페 & 노을 드라이브', zh: '济州岛橘子咖啡与日落兜风', emoji: '🍊' },
        { id: 'dm_cn_1', country: 'cn', cityKo: '상하이', cityZh: '上海', ko: '와이탄 야경 산책 & 유람선', zh: '外滩夜景散步与游船', emoji: '🌃' },
        { id: 'dm_cn_2', country: 'cn', cityKo: '상하이', cityZh: '上海', ko: '상하이 디즈니랜드 불꽃놀이', zh: '上海迪士尼城堡烟花秀', emoji: '🎆' },
        { id: 'dm_cn_3', country: 'cn', cityKo: '상하이', cityZh: '上海', ko: '우캉루 감성 카페 & 커플 스냅', zh: '武康路浪漫咖啡与情侣街拍', emoji: '☕' },
        { id: 'dm_cn_4', country: 'cn', cityKo: '항저우', cityZh: '杭州', ko: '서호 유람선 & 연꽃 산책', zh: '西湖游船与湖畔漫步', emoji: '🪷' },
        { id: 'dm_cn_5', country: 'cn', cityKo: '베이징', cityZh: '北京', ko: '만리장성 커플 인증샷', zh: '万里长城情侣打卡照', emoji: '🧱' }
      ];

      function renderDateStampMap() {
        const grid = document.getElementById('datemapGrid');
        if (!grid) return;
        if (!state.dateStamps) state.dateStamps = JSON.parse(JSON.stringify(DEFAULT_STATE.dateStamps));
        const isZh = state.lang === 'zh';
        const filter = state.dateStamps.filter || 'all';
        const delSet = new Set(state.dateStamps.deletedIds || []);
        const stamps = state.dateStamps.stamps || {};
        const custom = (state.dateStamps.customSpots || []).filter(s => s && !delSet.has(s.id));
        const allSpots = [...custom, ...DEFAULT_DATE_SPOTS];

        let stampedCount = 0;
        allSpots.forEach(sp => { if (stamps[sp.id] && stamps[sp.id].done) stampedCount++; });
        const pct = allSpots.length ? Math.round((stampedCount / allSpots.length) * 100) : 0;

        const tagEl = document.getElementById('datemapTag');
        const titleEl = document.getElementById('datemapTitle');
        const barEl = document.getElementById('datemapProgressBar');
        const inpEl = document.getElementById('datemapSpotInput');
        const addBtn = document.getElementById('datemapAddBtn');

        if (tagEl) tagEl.textContent = isZh ? '🗺️ 韩国 ↔ 中国 情侣约会印章板' : '🗺️ 한국 ↔ 중국 커플 데이트 도장판';
        if (titleEl) titleEl.textContent = isZh
          ? `💮 我们一起盖下的印章 ${stampedCount} / ${allSpots.length}`
          : `💮 우리가 함께 찍은 도장 ${stampedCount} / ${allSpots.length}`;
        if (barEl) barEl.style.width = `${pct}%`;
        if (inpEl) inpEl.placeholder = isZh ? '添加想去的约会地 (自动中韩翻译)...' : '가고 싶은 데이트 장소 추가 (자동 한·중 번역)...';
        if (addBtn) addBtn.textContent = isZh ? '+ 添加地点' : '+ 장소 추가';

        document.querySelectorAll('.datemap-filter-btn').forEach(b => {
          const f = b.getAttribute('data-dm-filter');
          const act = f === filter;
          b.className = `datemap-filter-btn ${act ? 'btn-royal' : 'btn-ghost'} px-2.5 py-1 rounded-full text-[11px] font-semibold whitespace-nowrap`;
          if (f === 'all') b.textContent = isZh ? '全部' : '전체';
          if (f === 'kr') b.textContent = isZh ? '🇰🇷 韩国' : '🇰🇷 한국';
          if (f === 'cn') b.textContent = isZh ? '🇨🇳 中国' : '🇨🇳 중국';
        });

        const visible = allSpots.filter(sp => filter === 'all' || sp.country === filter);
        grid.innerHTML = visible.map(sp => {
          const st = stamps[sp.id] || { done: false, date: '' };
          const isCustom = !sp.id.startsWith('dm_kr_') && !sp.id.startsWith('dm_cn_');
          const flag = sp.country === 'cn' ? '🇨🇳' : '🇰🇷';
          const city = isZh ? (sp.cityZh || sp.cityKo || '') : (sp.cityKo || sp.cityZh || '');
          const primary = isZh ? (sp.zh || sp.ko) : (sp.ko || sp.zh);
          const secondary = isZh ? (sp.ko || '') : (sp.zh || '');
          return `
            <div class="royal-card rounded-3xl p-4 space-y-2.5 relative overflow-hidden flex flex-col justify-between" style="${st.done ? 'border-color: rgba(225,29,72,0.38);' : ''}">
              <div class="flex items-start justify-between gap-2">
                <div class="min-w-0 flex-1">
                  <div class="flex items-center gap-1.5 text-[10.5px] text-sec font-semibold">
                    <span>${flag}</span>
                    <span>${escapeHtml(city || (sp.country === 'cn' ? (isZh ? '中国' : '중국') : (isZh ? '韩国' : '한국')))}</span>
                  </div>
                  <div class="text-sm font-bold leading-snug mt-0.5 break-words">${sp.emoji || '📍'} ${escapeHtml(primary)}</div>
                  ${secondary && secondary !== primary ? `<div class="text-[11px] text-sec mt-0.5 break-words">${escapeHtml(secondary)}</div>` : ''}
                </div>
                ${st.done ? `<div class="cw-stamp-seal px-2 py-1 rounded-xl text-[10px] font-extrabold shrink-0 text-center leading-tight">💮 ${isZh ? '已打卡' : '방문완료'}<br/><span class="text-[9px] font-semibold">${escapeHtml(st.date || '')}</span></div>` : ''}
              </div>
              <div class="flex items-center justify-between gap-2 pt-1.5 border-t" style="border-color: var(--border-subtle);">
                <button type="button" class="datemap-stamp-btn ${st.done ? 'btn-ghost' : 'btn-royal'} px-3 py-1.5 rounded-full text-[11px] font-bold whitespace-nowrap" data-dm-id="${sp.id}">
                  ${st.done ? (isZh ? '↩️ 取消印章' : '↩️ 도장 취소') : (isZh ? '💮 盖上印章 (+10 XP)' : '💮 도장 찍기 (+10 XP)')}
                </button>
                ${isCustom ? `<button type="button" class="datemap-del-btn text-[11px] text-mut hover:text-rose-500 px-2 py-1" data-dm-del="${sp.id}">${isZh ? '删除' : '삭제'}</button>` : '<span></span>'}
              </div>
            </div>
          `;
        }).join('');

        grid.querySelectorAll('.datemap-stamp-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            const sid = btn.getAttribute('data-dm-id');
            if (!state.dateStamps) state.dateStamps = JSON.parse(JSON.stringify(DEFAULT_STATE.dateStamps));
            if (!state.dateStamps.stamps) state.dateStamps.stamps = {};
            const cur = state.dateStamps.stamps[sid] || { done: false, date: '' };
            if (cur.done) {
              openConfirm(
                state.lang === 'zh' ? '取消这个约会印章吗？' : '이 데이트 도장을 취소할까요?',
                () => {
                  state.dateStamps.stamps[sid] = { done: false, date: '', updatedAt: Date.now() };
                  state.dateStamps.updatedAt = Date.now();
                  saveState(true);
                  renderDateStampMap();
                }
              );
            } else {
              state.dateStamps.stamps[sid] = { done: true, date: getKstDateString(), updatedAt: Date.now() };
              state.dateStamps.updatedAt = Date.now();
              addLavenderBonusXp('datemap_' + sid, 10);
              saveState(true);
              renderDateStampMap();
              renderLavenderPot();
              showToast(state.lang === 'zh' ? '💮 浪漫约会印章已盖下！花盆 +10 XP' : '💮 데이트 도장을 꾹 찍었어요! 화분 +10 XP');
            }
          });
        });

        grid.querySelectorAll('.datemap-del-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            const sid = btn.getAttribute('data-dm-del');
            openConfirm(
              state.lang === 'zh' ? '确定删除这个自定义约会地点吗？' : '직접 추가한 이 데이트 장소를 삭제할까요?',
              () => {
                state.dateStamps.customSpots = (state.dateStamps.customSpots || []).filter(x => x.id !== sid);
                if (!Array.isArray(state.dateStamps.deletedIds)) state.dateStamps.deletedIds = [];
                if (!state.dateStamps.deletedIds.includes(sid)) state.dateStamps.deletedIds.push(sid);
                state.dateStamps.updatedAt = Date.now();
                saveState(true);
                renderDateStampMap();
              }
            );
          });
        });
      }


      // ---- 6) Auto-Generated Couple Chat Phrasebook & Quiz (Speaker-Tagged) ----
      let cbActiveMode = 'book';
      let cbSpeakerFilter = 'all';
      let cbQuizState = { idx: 0, score: 0, answered: false };

      function extractChatLearningPairs() {
        const msgs = Array.isArray(state.chat?.messages) ? state.chat.messages : [];
        const seen = new Set();
        const out = [];
        for (let i = msgs.length - 1; i >= 0; i--) {
          const m = msgs[i];
          if (!m || !m.original || !m.translated) continue;
          const orig = String(m.original || '').trim();
          const tr = String(m.translated || '').trim();
          if (orig.length < 2 || tr.length < 2) continue;
          if (/^https?:\/\//i.test(orig) || /음성 메시지|语音消息|사진을 보냈어요|发来照片|동영상/.test(orig)) continue;
          const origLang = detectLanguage(orig);
          const ko = origLang === 'ko' ? orig : tr;
          const zh = origLang === 'ko' ? tr : orig;
          const key = ko.replace(/\s+/g, '').toLowerCase();
          if (!key || seen.has(key)) continue;
          seen.add(key);
          out.push({
            id: m.id || ('cb_' + i),
            ko,
            zh,
            pron: m.pronunciation || '',
            speaker: m.sender === 'jingchan' ? 'jingchan' : 'suwan',
            time: m.time || ''
          });
          if (out.length >= 120) break;
        }
        return out;
      }

      function renderChatLearnBook() {
        const bookList = document.getElementById('cbBookList');
        const quizWrap = document.getElementById('cbQuizWrap');
        const bookCtrl = document.getElementById('cbBookControls');
        if (!bookList || !quizWrap) return;

        const isZh = state.lang === 'zh';
        const allPairs = extractChatLearningPairs();

        const tagEl = document.getElementById('cbSubTag');
        const titleEl = document.getElementById('cbTitle');
        const cntEl = document.getElementById('cbCountLabel');
        if (tagEl) tagEl.textContent = isZh ? '💬 自动提取聊天真实句子学习' : '💬 메신저 대화 자동 추출 학습';
        if (titleEl) titleEl.textContent = isZh ? '📖 我们的聊天回话本 & 实战测验' : '📖 우리 대화 회화책 & 실전 퀴즈';

        document.querySelectorAll('.cb-mode-btn').forEach(b => {
          const mode = b.getAttribute('data-cb-mode');
          const act = mode === cbActiveMode;
          b.className = `cb-mode-btn ${act ? 'btn-royal' : 'btn-ghost'} px-3 py-1 rounded-full text-[11px] font-bold whitespace-nowrap`;
          b.textContent = mode === 'book' ? (isZh ? '📖 聊天课本' : '📖 회화책') : (isZh ? '🎯 聊天测验' : '🎯 퀴즈');
        });
        document.querySelectorAll('.cb-speaker-btn').forEach(b => {
          const sp = b.getAttribute('data-cb-sp');
          const act = sp === cbSpeakerFilter;
          b.className = `cb-speaker-btn ${act ? 'btn-royal' : 'btn-ghost'} px-2.5 py-1 rounded-full text-[10.5px] font-semibold whitespace-nowrap`;
          if (sp === 'all') b.textContent = isZh ? '全部' : '전체';
          if (sp === 'suwan') b.textContent = isZh ? '❤️ 完说的' : '❤️ 수완 발언';
          if (sp === 'jingchan') b.textContent = isZh ? '💜 靖灿说的' : '💜 징찬 발언';
        });

        const filtered = allPairs.filter(p => cbSpeakerFilter === 'all' || p.speaker === cbSpeakerFilter);
        if (cntEl) cntEl.textContent = isZh ? `共提取 ${filtered.length} 句真实对话` : `총 ${filtered.length}문장 자동 추출`;

        if (cbActiveMode === 'book') {
          if (bookCtrl) bookCtrl.classList.remove('hidden');
          bookList.classList.remove('hidden');
          quizWrap.classList.add('hidden');
          if (!filtered.length) {
            bookList.innerHTML = `<div class="royal-card rounded-3xl p-6 text-center text-xs text-mut">${isZh ? '还没有可提取的聊天句子哦～去 CW Talk 聊几句就会自动生成专属课本！💬' : '아직 추출할 메신저 대화가 없어요! CW Talk에서 대화를 나누면 자동으로 회화책이 쌓여요 💬'}</div>`;
            return;
          }
          bookList.innerHTML = filtered.map(p => {
            const isSw = p.speaker === 'suwan';
            const spLabel = isSw ? (isZh ? '❤️ 完 발언 · 完说的' : '❤️ 수완 발언') : (isZh ? '💜 靖灿说的' : '💜 징찬 발언');
            const spBg = isSw ? 'rgba(244,63,94,0.12)' : 'rgba(139,92,246,0.14)';
            const spCol = isSw ? '#e11d48' : '#7c3aed';
            return `
              <div class="royal-card rounded-2xl p-3.5 space-y-2">
                <div class="flex items-center justify-between gap-2">
                  <span class="text-[10px] font-bold px-2 py-0.5 rounded-full whitespace-nowrap" style="background: ${spBg}; color: ${spCol};">${spLabel}</span>
                  ${p.time ? `<span class="text-[10px] text-mut">${escapeHtml(p.time)}</span>` : ''}
                </div>
                <div class="space-y-1">
                  <div class="flex items-start justify-between gap-2">
                    <div class="text-sm font-bold leading-snug break-words flex-1 min-w-0">${escapeHtml(p.ko)}</div>
                    <div class="flex items-center gap-1 shrink-0">
                      ${(() => { const on = typeof window.__isProblemStarred === 'function' && window.__isProblemStarred(p.ko, p.zh); return `<button type="button" class="cw-star-prob-btn ${on ? 'btn-gold' : 'btn-ghost'} w-7 h-7 rounded-full flex items-center justify-center text-[11px] font-bold" data-q="${escapeHtml(p.ko)}" data-zh="${escapeHtml(p.zh)}" data-ans="${escapeHtml(p.ko)}" data-aud="${escapeHtml(p.ko)}" data-lvl="${isZh ? '聊天课本' : '우리 대화'}" title="즐겨찾기">${on ? '⭐' : '☆'}</button>`; })()}
                      <button type="button" class="speak-btn btn-royal w-7 h-7 rounded-full flex items-center justify-center text-[11px]" data-text="${escapeHtml(p.ko)}" data-lang="ko-KR" title="한국어 듣기">🔊</button>
                      <button type="button" class="speak-btn btn-ghost w-7 h-7 rounded-full flex items-center justify-center text-[11px]" data-text="${escapeHtml(p.ko)}" data-lang="ko-KR" data-slow="1" title="천천히 듣기">🐢</button>
                    </div>
                  </div>
                  <div class="flex items-center justify-between gap-2">
                    <div class="text-xs text-sec break-words flex-1 min-w-0">${escapeHtml(p.zh)}</div>
                    <button type="button" class="speak-btn btn-ghost px-2 py-0.5 rounded-full text-[10px] font-semibold shrink-0" data-text="${escapeHtml(p.zh)}" data-lang="zh-CN" title="중국어 듣기">🇨🇳🔊</button>
                  </div>
                  ${p.pron ? `<div class="text-[10.5px] text-mut break-words">${escapeHtml(p.pron)}</div>` : ''}
                </div>
              </div>
            `;
          }).join('');
        } else {
          if (bookCtrl) bookCtrl.classList.add('hidden');
          bookList.classList.add('hidden');
          quizWrap.classList.remove('hidden');
          renderChatAutoQuiz(allPairs);
        }
      }

      function renderChatAutoQuiz(allPairs) {
        const quizWrap = document.getElementById('cbQuizWrap');
        if (!quizWrap) return;
        const isZh = state.lang === 'zh';
        if (!allPairs.length) {
          quizWrap.innerHTML = `<div class="royal-card rounded-3xl p-6 text-center text-xs text-mut">${isZh ? '先去 CW Talk 聊几句，就会自动把我们的真实对话变成趣味测验哦！🎯' : 'CW Talk에서 대화를 조금 나누면 실제 대화로 퀴즈가 자동 출제돼요! 🎯'}</div>`;
          return;
        }
        const idx = ((cbQuizState.idx || 0) % allPairs.length + allPairs.length) % allPairs.length;
        cbQuizState.idx = idx;
        cbQuizState.answered = false;
        const target = allPairs[idx];
        const isSw = target.speaker === 'suwan';
        const spBadge = isSw
          ? (isZh ? '💬 ❤️ 完在聊天里说过的话' : '💬 ❤️ 수완의 실제 발언')
          : (isZh ? '💬 💜 靖灿在聊天里说过的话' : '💬 💜 징찬의 실제 발언');
        const spBg = isSw ? 'rgba(244,63,94,0.12)' : 'rgba(139,92,246,0.14)';
        const spCol = isSw ? '#e11d48' : '#7c3aed';

        // Ask Chinese -> pick Korean (for Jingchan/zh) or Korean -> pick Chinese (for Suwan/ko)
        const askZhPickKo = (state.myRole === 'jingchan' || isZh);
        const promptText = askZhPickKo ? target.zh : target.ko;
        const correctAns = askZhPickKo ? target.ko : target.zh;

        const fallbackPool = [
          { ko: '오늘 하루도 고생 많았어', zh: '今天也辛苦啦' },
          { ko: '지금 너무 보고 싶어', zh: '现在好想你呀' },
          { ko: '밥 꼭 챙겨 먹어', zh: '一定要好好吃饭' },
          { ko: '잘 자고 내일 연락해', zh: '晚安，明天联系哦' },
          { ko: '우리 빨리 만나고 싶다', zh: '好想快点见面呀' }
        ];
        const pool = [...allPairs, ...fallbackPool];
        const distractors = [];
        for (const item of pool) {
          const cand = askZhPickKo ? item.ko : item.zh;
          if (cand && cand !== correctAns && !distractors.includes(cand)) {
            distractors.push(cand);
            if (distractors.length >= 3) break;
          }
        }
        const choices = [correctAns, ...distractors].sort(() => Math.random() - 0.5);

        quizWrap.innerHTML = `
          <div class="royal-card rounded-3xl p-4 sm:p-5 space-y-3.5">
            <div class="flex items-center justify-between gap-2">
              <span class="text-[10.5px] font-bold px-2.5 py-0.5 rounded-full" style="background: ${spBg}; color: ${spCol};">${spBadge}</span>
              <span class="text-[11px] font-bold text-gold">${isZh ? '得分' : '정답'} ${cbQuizState.score} · #${idx + 1}/${allPairs.length}</span>
            </div>
            <div class="royal-subcard rounded-2xl p-4 text-center space-y-1.5">
              <div class="text-[10.5px] text-mut">${askZhPickKo ? (isZh ? '这句话用韩语怎么说？' : '이 중국어에 맞는 한국어 표현은?') : (isZh ? '这句韩语是什么意思？' : '이 한국어에 맞는 중국어 표현은?')}</div>
              <div class="text-base font-bold leading-snug break-words">${escapeHtml(promptText)}</div>
            </div>
            <div class="space-y-2" id="cbQuizOptions">
              ${choices.map((ch, ci) => `
                <button type="button" class="cb-quiz-opt royal-subcard hover:border-purple-400 w-full rounded-2xl px-3.5 py-2.5 text-left text-xs sm:text-sm font-semibold transition border" style="border-color: var(--border-subtle);" data-val="${escapeHtml(ch)}">
                  <span class="text-gold mr-1.5">${ci + 1}.</span>${escapeHtml(ch)}
                </button>
              `).join('')}
            </div>
            <div id="cbQuizFeedback" class="hidden rounded-2xl p-3 text-xs font-semibold text-center"></div>
            <div class="flex items-center justify-between gap-2 pt-1">
              <button type="button" class="speak-btn btn-ghost px-3 py-1.5 rounded-full text-xs font-semibold" data-text="${escapeHtml(target.ko)}" data-lang="ko-KR">🔊 ${isZh ? '听韩语发音' : '한국어 듣기'}</button>
              <button type="button" id="cbNextQuizBtn" class="btn-royal px-4 py-1.5 rounded-full text-xs font-bold">${isZh ? '下一题 →' : '다음 문제 →'}</button>
            </div>
          </div>
        `;

        quizWrap.querySelectorAll('.cb-quiz-opt').forEach(btn => {
          btn.addEventListener('click', () => {
            if (cbQuizState.answered) return;
            cbQuizState.answered = true;
            const picked = btn.getAttribute('data-val');
            const isOk = picked === correctAns;
            const fb = document.getElementById('cbQuizFeedback');
            quizWrap.querySelectorAll('.cb-quiz-opt').forEach(ob => {
              const v = ob.getAttribute('data-val');
              if (v === correctAns) { ob.style.borderColor = '#10b981'; ob.style.background = 'rgba(16,185,129,0.14)'; }
              else if (ob === btn && !isOk) { ob.style.borderColor = '#e11d48'; ob.style.background = 'rgba(244,63,94,0.12)'; }
            });
            if (isOk) {
              cbQuizState.score++;
              const isJcCb = canEarnJingchanXp();
              if (isJcCb && state.learn) {
                state.learn.xp = (Number(state.learn.xp) || 0) + 15;
                saveState(true);
                addLavenderBonusXp('chatquiz', 5);
              }
              if (fb) {
                fb.style.background = 'rgba(16,185,129,0.14)'; fb.style.color = '#059669';
                fb.textContent = isJcCb
                  ? (isZh ? '🎉 答对啦！+15 XP 💜' : '🎉 정답이에요! +15 XP 💜')
                  : (isZh ? '❤️ 答对啦！(完测试模式 · 不计入靖灿进度)' : '❤️ 정답이에요! (수완 테스트 모드 · 징찬 XP 미반영)');
                fb.classList.remove('hidden');
              }
            } else {
              if (fb) { fb.style.background = 'rgba(244,63,94,0.12)'; fb.style.color = '#e11d48'; fb.textContent = isZh ? `💡 正确答案：${correctAns}` : `💡 정답: ${correctAns}`; fb.classList.remove('hidden'); }
            }
          });
        });

        const nextBtn = document.getElementById('cbNextQuizBtn');
        if (nextBtn) nextBtn.addEventListener('click', () => { cbQuizState.idx++; renderChatAutoQuiz(allPairs); });
      }

      function bindPlus16Events() {
        // Wake / Sleep buttons
        const swW = document.getElementById('suwanWakeBtn');
        const swS = document.getElementById('suwanSleepBtn');
        const jcW = document.getElementById('jingchanWakeBtn');
        const jcS = document.getElementById('jingchanSleepBtn');
        if (swW) swW.addEventListener('click', () => handleWakeSleepTap('suwan', 'wake'));
        if (swS) swS.addEventListener('click', () => handleWakeSleepTap('suwan', 'sleep'));
        if (jcW) jcW.addEventListener('click', () => handleWakeSleepTap('jingchan', 'wake'));
        if (jcS) jcS.addEventListener('click', () => handleWakeSleepTap('jingchan', 'sleep'));

        // Lavender Pot Water button
        const waterBtn = document.getElementById('lavenderWaterBtn');
        if (waterBtn) {
          waterBtn.addEventListener('click', () => {
            if (!state.lavender) state.lavender = JSON.parse(JSON.stringify(DEFAULT_STATE.lavender));
            const today = getKstDateString();
            const role = state.myRole || 'suwan';
            const field = role === 'suwan' ? 'lastWaterSuwan' : 'lastWaterJingchan';
            if (state.lavender[field] === today) {
              showToast(state.lang === 'zh' ? '今天已经浇过水啦 💧' : '오늘은 이미 물을 줬어요 💧');
              return;
            }
            state.lavender[field] = today;
            state.lavender.xp = (Number(state.lavender.xp) || 0) + 15;
            state.lavender.totalWaters = (Number(state.lavender.totalWaters) || 0) + 1;
            state.lavender.updatedAt = Date.now();
            const svgWrap = document.getElementById('lavenderSvgWrap');
            if (svgWrap) {
              const drop = document.createElement('div');
              drop.textContent = '💧';
              drop.className = 'cw-water-anim absolute top-2 right-3 text-lg pointer-events-none';
              svgWrap.appendChild(drop);
              setTimeout(() => drop.remove(), 950);
            }
            saveState(true);
            renderLavenderPot();
            showToast(state.lang === 'zh' ? '💧 浇水成功！薰衣草 +15 XP 🪻' : '💧 라벤더에 물을 줬어요! +15 XP 🪻');
          });
        }

        // Balance Game controls
        const bPrev = document.getElementById('balancePrevBtn');
        const bNext = document.getElementById('balanceNextBtn');
        const bRand = document.getElementById('balanceRandBtn');
        const bOptA = document.getElementById('balanceOptABtn');
        const bOptB = document.getElementById('balanceOptBBtn');
        const ensureBg = () => { if (!state.balanceGame) state.balanceGame = { currentIdx: 0, answers: {}, updatedAt: 0 }; };
        if (bPrev) bPrev.addEventListener('click', () => { ensureBg(); state.balanceGame.currentIdx = (Number(state.balanceGame.currentIdx || 0) - 1 + BALANCE_QUESTIONS.length) % BALANCE_QUESTIONS.length; renderBalanceGame(); });
        if (bNext) bNext.addEventListener('click', () => { ensureBg(); state.balanceGame.currentIdx = (Number(state.balanceGame.currentIdx || 0) + 1) % BALANCE_QUESTIONS.length; renderBalanceGame(); });
        if (bRand) bRand.addEventListener('click', () => { ensureBg(); state.balanceGame.currentIdx = Math.floor(Math.random() * BALANCE_QUESTIONS.length); renderBalanceGame(); });
        if (bOptA) bOptA.addEventListener('click', () => pickBalanceOption('A'));
        if (bOptB) bOptB.addEventListener('click', () => pickBalanceOption('B'));

        // Date Stamp Map filter & add form
        document.querySelectorAll('.datemap-filter-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            if (!state.dateStamps) state.dateStamps = JSON.parse(JSON.stringify(DEFAULT_STATE.dateStamps));
            state.dateStamps.filter = btn.getAttribute('data-dm-filter') || 'all';
            renderDateStampMap();
          });
        });
        const dmForm = document.getElementById('datemapAddForm');
        if (dmForm) {
          dmForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const inp = document.getElementById('datemapSpotInput');
            const cSel = document.getElementById('datemapCountrySelect');
            const txt = (inp && inp.value || '').trim();
            if (!txt) return;
            const country = (cSel && cSel.value) || 'kr';
            let trTxt = '';
            try {
              const res = await _coreTranslate(txt, 'casual');
              if (res && res.translated) trTxt = res.translated;
            } catch (_) {}
            const isKo = detectLanguage(txt) === 'ko';
            const newSpot = {
              id: 'dm_custom_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
              country,
              cityKo: country === 'cn' ? '중국' : '한국',
              cityZh: country === 'cn' ? '中国' : '韩国',
              ko: isKo ? txt : (trTxt || txt),
              zh: isKo ? (trTxt || txt) : txt,
              emoji: '📍'
            };
            if (!state.dateStamps) state.dateStamps = JSON.parse(JSON.stringify(DEFAULT_STATE.dateStamps));
            if (!Array.isArray(state.dateStamps.customSpots)) state.dateStamps.customSpots = [];
            state.dateStamps.customSpots.unshift(newSpot);
            state.dateStamps.updatedAt = Date.now();
            if (inp) inp.value = '';
            saveState(true);
            renderDateStampMap();
            showToast(state.lang === 'zh' ? '🗺️ 已添加新的约会地点！' : '🗺️ 새 데이트 장소를 추가했어요!');
          });
        }
        document.querySelectorAll('.cb-mode-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            cbActiveMode = btn.getAttribute('data-cb-mode') || 'book';
            renderChatLearnBook();
          });
        });
        document.querySelectorAll('.cb-speaker-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            cbSpeakerFilter = btn.getAttribute('data-cb-sp') || 'all';
            renderChatLearnBook();
          });
        });
      }


      /* --- Unified 1-Tap Chat Voice Player & Auto-Play Engine --- */
      (function initChatVoicePlayer() {
        let activeAudio = null;
        let activeMsgId = '';
        let activeBtn = null;
        let unlocked = false;

        const resetBtnUi = (btn) => {
          if (!btn) return;
          const ico = btn.querySelector('.cw-v-ico');
          const lbl = btn.querySelector('.cw-v-lbl');
          const bar = btn.querySelector('.cw-v-bar');
          const tm = btn.querySelector('.cw-v-time');
          if (ico) ico.innerHTML = CW_MEDIA_SVG.play;
          if (lbl) lbl.textContent = state.lang === 'zh' ? '点击播放语音' : '눌러서 음성 듣기';
          if (bar) bar.style.width = '0%';
          if (tm && !tm.textContent.includes('/')) tm.innerHTML = CW_MEDIA_SVG.waveMini;
        };

        const unlockOnce = () => {
          if (unlocked) return;
          unlocked = true;
          try {
            if (!activeAudio) activeAudio = new Audio();
            activeAudio.setAttribute('playsinline', '');
            activeAudio.setAttribute('webkit-playsinline', '');
          } catch (_) {}
        };
        document.addEventListener('pointerdown', unlockOnce, { once: true, passive: true });

        window.__playChatVoiceMsg = function(msgId, audioUrl, btnEl, isAutoPlay) {
          if (!audioUrl) return;
          if (!activeAudio) {
            activeAudio = new Audio();
            activeAudio.setAttribute('playsinline', '');
            activeAudio.setAttribute('webkit-playsinline', '');
          }
          // Toggle pause if tapping the currently playing voice bubble
          if (!isAutoPlay && activeMsgId === msgId && !activeAudio.paused) {
            activeAudio.pause();
            resetBtnUi(activeBtn);
            activeMsgId = '';
            activeBtn = null;
            return;
          }
          if (activeBtn && activeBtn !== btnEl) resetBtnUi(activeBtn);
          try { activeAudio.pause(); } catch (_) {}
          activeMsgId = msgId;
          activeBtn = btnEl || document.querySelector(`.cw-voice-play-btn[data-msg-id="${msgId}"]`);
          activeAudio.src = audioUrl;
          activeAudio.currentTime = 0;

          const updateUiPlaying = () => {
            if (!activeBtn) return;
            const ico = activeBtn.querySelector('.cw-v-ico');
            const lbl = activeBtn.querySelector('.cw-v-lbl');
            if (ico) ico.innerHTML = CW_MEDIA_SVG.stop;
            if (lbl) lbl.textContent = state.lang === 'zh' ? '正在播放 · 点击停止' : '재생 중 · 눌러서 정지';
          };

          activeAudio.ontimeupdate = () => {
            if (!activeBtn || !activeAudio.duration || !Number.isFinite(activeAudio.duration)) return;
            const pct = Math.min(100, Math.round((activeAudio.currentTime / activeAudio.duration) * 100));
            const bar = activeBtn.querySelector('.cw-v-bar');
            const tm = activeBtn.querySelector('.cw-v-time');
            if (bar) bar.style.width = `${pct}%`;
            if (tm) {
              const s = Math.floor(activeAudio.currentTime);
              const tot = Math.max(1, Math.round(activeAudio.duration));
              tm.textContent = `${s}s/${tot}s`;
            }
          };
          activeAudio.onended = () => {
            resetBtnUi(activeBtn);
            activeMsgId = '';
            activeBtn = null;
          };
          activeAudio.onerror = () => {
            resetBtnUi(activeBtn);
            activeMsgId = '';
            activeBtn = null;
            if (!isAutoPlay) showToast(state.lang === 'zh' ? '语音播放失败，请重试' : '음성 재생에 실패했어요. 다시 눌러주세요');
          };

          const p = activeAudio.play();
          if (p && typeof p.then === 'function') {
            p.then(() => {
              updateUiPlaying();
            }).catch(() => {
              resetBtnUi(activeBtn);
              activeMsgId = '';
              if (isAutoPlay) {
                showToast(state.lang === 'zh' ? '🎙️ 收到新语音消息，点击气泡立即播放' : '🎙️ 새 음성 메시지가 도착했어요! 말풍선을 눌러 들으세요');
              }
            });
          } else {
            updateUiPlaying();
          }
        };
      })();


      (function initChatTapDismissKeyboard() {
        const listEl = document.getElementById('chatMessagesList');
        if (!listEl) return;
        let downX = 0, downY = 0;
        listEl.addEventListener('pointerdown', (e) => {
          downX = e.clientX || 0;
          downY = e.clientY || 0;
        }, { passive: true });
        listEl.addEventListener('click', (e) => {
          const dx = Math.abs((e.clientX || 0) - downX);
          const dy = Math.abs((e.clientY || 0) - downY);
          if (dx > 12 || dy > 12) return;
          if (e.target && e.target.closest('button, a, input, textarea, select, label, audio, video, .cw-msg-bubble')) return;
          const act = document.activeElement;
          if (act && (act.tagName === 'INPUT' || act.tagName === 'TEXTAREA' || act.isContentEditable)) {
            try { act.blur(); } catch (_) {}
          }
          const st = document.getElementById('chatStickerTray');
          if (st && !st.classList.contains('hidden')) st.classList.add('hidden');
          const pl = document.getElementById('chatPlusDrawer');
          if (pl && !pl.classList.contains('hidden')) { pl.classList.add('hidden'); if (typeof window.__syncChatPlusBtnIcon === 'function') window.__syncChatPlusBtnIcon(false); }
        });
      })();


      /* ============================================================
         PLUS 1.8 MODULE: Energy & Activity, Love Thermometer, Hold-to-Hug,
         TMI Book, Compliment Jar, Music Box (In-App Play), Food Roulette,
         Couple Fortune, Offline Sleep Sounds & Couple Mini Quiz
         ============================================================ */
      function formatEnergyLabel(lv, isZh) {
        const n = Number(lv || 100);
        if (n >= 90) return isZh ? '🔋 100% 满电' : '🔋 100% 풀충전';
        if (n >= 60) return isZh ? '⚡ 70% 还不错' : '⚡ 70% 괜찮아';
        if (n >= 25) return isZh ? '🪫 30% 有点累' : '🪫 30% 지쳤어';
        return isZh ? '🆘 10% 求抱抱' : '🆘 10% 안아줘';
      }

      function renderEnergyActivityCards() {
        const isZh = state.lang === 'zh';
        const myRole = state.myRole || 'suwan';
        if (!state.profile) state.profile = JSON.parse(JSON.stringify(DEFAULT_STATE.profile));

        ['suwan', 'jingchan'].forEach(role => {
          const eObj = state.profile[role + 'Energy'] || { level: 100, updatedAt: 0 };
          const lv = Math.max(10, Math.min(100, Number(eObj.level || 100)));
          const isMe = myRole === role;

          const eBadge = document.getElementById(role + 'EnergyBadge');
          const eBar = document.getElementById(role + 'EnergyBar');
          const ctrl = document.getElementById(role + 'EnergyControls');

          if (eBadge) {
            eBadge.textContent = formatEnergyLabel(lv, isZh);
            eBadge.style.color = lv <= 30 ? '#e11d48' : 'var(--accent-royal)';
          }
          if (eBar) {
            eBar.style.width = `${lv}%`;
            eBar.style.background = lv <= 30
              ? 'linear-gradient(90deg, #fb7185, #e11d48)'
              : (lv <= 70 ? 'linear-gradient(90deg, #fbbf24, #a78bfa)' : 'linear-gradient(90deg, #34d399, #a78bfa)');
          }
          if (ctrl) ctrl.classList.toggle('hidden', !isMe);
          document.querySelectorAll(`.energy-pick-btn[data-role="${role}"]`).forEach(btn => {
            const on = Number(btn.getAttribute('data-lv')) === lv;
            btn.className = `energy-pick-btn ${on ? 'btn-royal' : 'btn-ghost'} py-0.5 rounded-md text-[9.5px] font-bold`;
          });
        });
      }

      /* --- Love Thermometer (36.5°C -> 100.0°C) + Hold-to-Hug --- */
      function computeLoveThermometer() {
        const kst = getKstDateString();
        const msgsToday = (state.chat?.messages || []).filter(m => {
          if (!m || !m.ts) return false;
          try { return new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Seoul' }).format(new Date(m.ts)) === kst; }
          catch (_) { return false; }
        }).length;
        const heartsToday = (state.heartResetDate === kst ? Number(state.heartCount || 0) : 0);
        const hugsToday = (state.hugs && state.hugs.date === kst) ? Number(state.hugs.count || 0) : 0;
        const wakeCount = (state.profile?.suwanSleep?.date === kst ? 1 : 0) + (state.profile?.jingchanSleep?.date === kst ? 1 : 0);
        const waterCount = (state.lavender?.lastWaterSuwan === kst ? 1 : 0) + (state.lavender?.lastWaterJingchan === kst ? 1 : 0);
        const studyXpToday = (state.learn?.todayXpDate === kst ? Number(state.learn?.todayXp || 0) : 0);
        const jarToday = (state.complimentJar || []).filter(j => j && j.date === kst).length;

        let temp = 36.5;
        temp += Math.min(22, msgsToday * 1.5);
        temp += Math.min(12, heartsToday * 1.2);
        temp += Math.min(10, hugsToday * 2.5);
        temp += wakeCount * 4.5;
        temp += waterCount * 5.0;
        temp += Math.min(6.0, studyXpToday * 0.15);
        temp += Math.min(6.0, jarToday * 3.0);
        temp = Math.min(100.0, Math.round(temp * 10) / 10);
        return { temp, msgsToday, heartsToday, hugsToday, wakeCount };
      }

      function renderLoveThermometer() {
        const isZh = state.lang === 'zh';
        const info = computeLoveThermometer();
        const pct = Math.max(4, Math.min(100, Math.round(((info.temp - 36.5) / 63.5) * 100)));
        const titleEl = document.getElementById('loveTempTitle');
        const badgeEl = document.getElementById('loveTempBadge');
        const barEl = document.getElementById('loveTempBar');
        const valEl = document.getElementById('loveTempValue');
        const detEl = document.getElementById('loveTempDetail');
        const mercEl = document.getElementById('loveTempMercury');
        const hugBadge = document.getElementById('holdHugCountBadge');
        const hugLabel = document.getElementById('holdHugLabel');

        if (titleEl) titleEl.textContent = isZh ? '🌡️ 今日恋爱温度' : '🌡️ 오늘의 사랑 온도';
        if (valEl) valEl.textContent = `${info.temp.toFixed(1)}°C`;
        if (barEl) barEl.style.width = `${pct}%`;
        if (mercEl) {
          const h = Math.max(3, Math.round(4 + (pct / 100) * 11));
          mercEl.setAttribute('y', String(19 - h));
          mercEl.setAttribute('height', String(h));
        }
        let statusKo = '🫧 설렘 시작', statusZh = '🫧 心动升温';
        if (info.temp >= 90) { statusKo = '💘 100°C 끓는 사랑'; statusZh = '💘 沸腾热恋'; }
        else if (info.temp >= 72) { statusKo = '🔥 열정 만땅'; statusZh = '🔥 甜蜜爆表'; }
        else if (info.temp >= 52) { statusKo = '💕 달달한 하루'; statusZh = '💕 甜蜜日常'; }
        else if (info.temp >= 42) { statusKo = '🌸 포근한 온도'; statusZh = '🌸 温暖贴贴'; }
        if (badgeEl) badgeEl.textContent = isZh ? statusZh : statusKo;
        if (detEl) {
          detEl.textContent = isZh
            ? `聊天 ${info.msgsToday} · 心动 ${info.heartsToday} · 拥抱 ${info.hugsToday} · 打卡 ${info.wakeCount}/2`
            : `대화 ${info.msgsToday} · 하트 ${info.heartsToday} · 포옹 ${info.hugsToday} · 체크인 ${info.wakeCount}/2`;
        }
        if (hugBadge) hugBadge.textContent = isZh ? `今日 ${info.hugsToday}次` : `오늘 ${info.hugsToday}회`;
        if (hugLabel && !hugHolding) hugLabel.textContent = isZh ? '🫂 长按 1.5 秒发送拥抱' : '🫂 1.5초 꾹 눌러서 포옹 보내기';
      }

      let hugHolding = false;
      let hugRaf = null;
      let hugStartTs = 0;
      const HUG_HOLD_MS = 1500;

      function triggerSendHug() {
        const myRole = state.myRole || 'suwan';
        const kst = getKstDateString();
        const curCount = (state.hugs && state.hugs.date === kst) ? Number(state.hugs.count || 0) : 0;
        state.hugs = { count: curCount + 1, date: kst, lastBy: myRole, updatedAt: Date.now() };
        if (typeof addLavenderBonusXp === 'function') addLavenderBonusXp('hug_' + kst, 5);
        try { if (navigator.vibrate) navigator.vibrate([60, 40, 90]); } catch (_) {}
        saveState(true);
        renderLoveThermometer();
        showToast(state.lang === 'zh' ? '🫂 已把温暖的拥抱发给对方啦！(+2.5°C)' : '🫂 따뜻한 포옹을 상대방에게 보냈어요! (+2.5°C)');
      }

      /* --- Couple TMI Book (#diary-sub-tmi) --- */
      let activeTmiOwner = 'suwan';
      function renderTmiBook() {
        const isZh = state.lang === 'zh';
        if (!state.tmiBook) state.tmiBook = JSON.parse(JSON.stringify(DEFAULT_STATE.tmiBook));
        const rec = state.tmiBook[activeTmiOwner] || {};
        document.querySelectorAll('.tmi-owner-btn').forEach(b => {
          const on = b.getAttribute('data-owner') === activeTmiOwner;
          b.className = `tmi-owner-btn ${on ? 'btn-royal' : 'btn-ghost'} px-2.5 py-1 rounded-full text-[11px] font-bold`;
        });
        const map = [
          ['tmiLikeFood', 'likeFood'], ['tmiDislikeFood', 'dislikeFood'],
          ['tmiCafe', 'cafe'], ['tmiSize', 'size'],
          ['tmiColor', 'color'], ['tmiGift', 'gift'], ['tmiMemo', 'memo']
        ];
        map.forEach(([id, key]) => {
          const el = document.getElementById(id);
          if (el) el.value = rec[key] || '';
        });
        const tTitle = document.getElementById('tmiTitle');
        if (tTitle) tTitle.textContent = isZh ? '我们的 TMI · 喜好百科' : '우리 TMI · 취향 메모';
      }

      /* --- Compliment & Gratitude Glass Jar (#diary-sub-jar) --- */
      let activeJarTag = '💜 고마워';

      function renderSpaceRepliesHtml(kind, itemId, replies) {
        const isZh = state.lang === 'zh';
        const list = Array.isArray(replies) ? replies : [];
        const itemsHtml = list.map(r => `
          <div class="rounded-xl px-2.5 py-1.5 text-[11px]" style="background: var(--surface-2);">
            <div class="flex items-center justify-between gap-2">
              <span class="font-bold text-gold">${escapeHtml(r.author || (r.authorRole === 'jingchan' ? '💜 靖灿(灿)' : '❤️ 수완(完)'))}</span>
              <div class="flex items-center gap-1.5">
                <span class="text-[10px] text-mut">${escapeHtml(r.time || '')}</span>
                ${isMyAuthoredItem(r) ? `<button type="button" class="cw-del-space-reply-btn text-[10px] text-mut hover:text-rose-400" data-rkind="${escapeHtml(kind)}" data-pid="${escapeHtml(itemId)}" data-rid="${escapeHtml(r.id)}">✕</button>` : ''}
              </div>
            </div>
            <div class="text-sec break-words mt-0.5">${escapeHtml(r.text || '')}</div>
            ${r.translated && r.translated !== r.text ? `<div class="text-[10.5px] text-gold break-words">${escapeHtml(r.translated)}</div>` : ''}
          </div>
        `).join('');
        return `
          <div class="pt-2 mt-1.5 border-t space-y-1.5" style="border-color: var(--border-subtle);">
            ${itemsHtml ? `<div class="space-y-1">${itemsHtml}</div>` : ''}
            <form class="cw-space-reply-form flex items-center gap-1.5" data-rkind="${escapeHtml(kind)}" data-pid="${escapeHtml(itemId)}">
              <input type="text" class="cw-space-reply-input royal-input flex-1 min-w-0 rounded-full px-3 py-1 text-[11px]" placeholder="${isZh ? '💬 留一句回复（自动翻译）...' : '💬 답글 남기기 (자동 번역)...'}" />
              <button type="submit" class="btn-ghost px-2.5 py-1 rounded-full text-[11px] font-semibold shrink-0 whitespace-nowrap">${isZh ? '发送' : '등록'}</button>
            </form>
          </div>`;
      }
      if (!window.__cwSpaceReplyDelegated) {
        window.__cwSpaceReplyDelegated = true;
        document.addEventListener('submit', async (e) => {
          const form = e.target.closest('.cw-space-reply-form');
          if (!form) return;
          e.preventDefault();
          const kind = form.getAttribute('data-rkind');
          const pid = form.getAttribute('data-pid');
          const inp = form.querySelector('.cw-space-reply-input');
          const txt = (inp ? inp.value : '').trim();
          if (!txt) return;
          let target = null;
          if (kind === 'truthdare') target = ((state.truthDare && state.truthDare.history) || []).find(x => x && x.id === pid);
          else if (kind === 'jar') target = (state.complimentJar || []).find(x => x && x.id === pid);
          else if (kind === 'cquiz') target = (state.coupleQuizzes || []).find(x => x && x.id === pid);
          if (!target) return;
          if (!Array.isArray(target.replies)) target.replies = [];
          const myRole = state.myRole || 'suwan';
          const authorName = myRole === 'jingchan' ? '💜 靖灿(灿)' : '❤️ 수완(完)';
          const timeStr = new Date().toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' });
          const replyObj = { id: 'srp_' + Date.now() + '_' + Math.random().toString(36).slice(2, 5), author: authorName, authorRole: myRole, text: txt, translated: '', time: timeStr, ts: Date.now() };
          target.replies.push(replyObj);
          if (inp) inp.value = '';
          const rerender = () => {
            if (kind === 'truthdare' && typeof window.renderTruthDare === 'function') window.renderTruthDare();
            else if (kind === 'jar' && typeof renderComplimentJar === 'function') renderComplimentJar();
            else if (kind === 'cquiz' && typeof renderCoupleQuizzes === 'function') renderCoupleQuizzes();
          };
          saveState(true);
          rerender();
          try {
            const who = myRole === 'jingchan' ? '靖灿' : '수완';
            if (typeof sendPartnerNativePush === 'function') sendPartnerNativePush(`💬 ${who}님이 커플공간에 답글을 남겼어요`, txt);
          } catch (_) {}
          try {
            const res = await (typeof geminiTranslate === 'function' ? geminiTranslate(txt, 'lover') : null);
            if (res && res.translated && res.translated !== txt) {
              replyObj.translated = res.translated;
              saveState(true);
              rerender();
            }
          } catch (_) {}
        });
        document.addEventListener('click', (e) => {
          const delBtn = e.target.closest('.cw-del-space-reply-btn');
          if (!delBtn) return;
          const kind = delBtn.getAttribute('data-rkind');
          const pid = delBtn.getAttribute('data-pid');
          const rid = delBtn.getAttribute('data-rid');
          let target = null;
          if (kind === 'truthdare') target = ((state.truthDare && state.truthDare.history) || []).find(x => x && x.id === pid);
          else if (kind === 'jar') target = (state.complimentJar || []).find(x => x && x.id === pid);
          else if (kind === 'cquiz') target = (state.coupleQuizzes || []).find(x => x && x.id === pid);
          if (!target || !Array.isArray(target.replies)) return;
          target.replies = target.replies.filter(r => r && r.id !== rid);
          saveState(true);
          if (kind === 'truthdare' && typeof window.renderTruthDare === 'function') window.renderTruthDare();
          else if (kind === 'jar' && typeof renderComplimentJar === 'function') renderComplimentJar();
          else if (kind === 'cquiz' && typeof renderCoupleQuizzes === 'function') renderCoupleQuizzes();
        });
      }

      function renderComplimentJar() {
        const isZh = state.lang === 'zh';
        const list = Array.isArray(state.complimentJar) ? state.complimentJar : [];
        const badge = document.getElementById('jarCountBadge');
        const title = document.getElementById('jarTitle');
        const sub = document.getElementById('jarSubLabel');
        const shakeBtn = document.getElementById('jarShakeBtn');
        const svgWrap = document.getElementById('jarSvgWrap');
        const listEl = document.getElementById('jarNoteList');

        if (sub) sub.textContent = isZh ? '✨ 夸夸 · 感恩玻璃瓶' : '✨ 칭찬 · 고마움 유리병';
        if (title) title.textContent = isZh ? '🫙 装满爱意的小玻璃瓶' : '🫙 우리 마음을 담은 유리병';
        if (badge) badge.textContent = isZh ? `收藏 ${list.length} 张` : `${list.length}개 보관`;
        if (shakeBtn) shakeBtn.textContent = isZh ? '✨ 摇一摇随机抽取' : '✨ 유리병 흔들어 꺼내기';

        if (svgWrap) {
          const colors = ['#c084fc', '#f472b6', '#fbbf24', '#60a5fa', '#a78bfa', '#fb7185'];
          const shown = Math.min(12, list.length);
          let starsSvg = '';
          for (let i = 0; i < shown; i++) {
            const col = colors[i % colors.length];
            const cx = 26 + ((i * 19) % 40);
            const cy = 84 - Math.floor(i / 4) * 14 - ((i % 2) * 4);
            starsSvg += `<circle cx="${cx}" cy="${cy}" r="5.5" fill="${col}" opacity="0.9"/>`;
          }
          svgWrap.innerHTML = `<svg width="88" height="102" viewBox="0 0 88 102" fill="none" aria-hidden="true">
            <rect x="26" y="6" width="36" height="10" rx="4" fill="#d8b4fe" stroke="#8b5cf6" stroke-width="1.6"/>
            <rect x="22" y="16" width="44" height="6" rx="3" fill="#ede9fe" stroke="#8b5cf6" stroke-width="1.4"/>
            <path d="M24 22 C16 28 14 38 14 52 L14 82 C14 91 21 96 30 96 L58 96 C67 96 74 91 74 82 L74 52 C74 38 72 28 64 22 Z" fill="rgba(255,255,255,0.68)" stroke="#8b5cf6" stroke-width="1.8"/>
            ${starsSvg}
            <path d="M23 36 L23 76" stroke="rgba(255,255,255,0.85)" stroke-width="3" stroke-linecap="round"/>
          </svg>`;
        }

        if (listEl) {
          if (!list.length) {
            listEl.innerHTML = `<div class="royal-subcard rounded-2xl p-5 text-center text-xs text-mut">${isZh ? '还没有放进夸夸纸条哦，写下第一句感谢吧 ✨' : '아직 유리병이 비어 있어요. 첫 번째 칭찬 쪽지를 넣어보세요 ✨'}</div>`;
          } else {
            listEl.innerHTML = list.map(item => `
              <div class="royal-subcard rounded-2xl p-3.5 space-y-1.5">
                <div class="flex items-center justify-between gap-2 text-[11px]">
                  <div class="flex items-center gap-1.5 min-w-0">
                    <span class="font-bold px-2 py-0.5 rounded-full shrink-0" style="background: var(--accent-royal-soft); color: var(--accent-royal);">${escapeHtml(item.tag || '💜 고마워')}</span>
                    <span class="font-semibold text-sec truncate">${item.author === 'jingchan' ? '💜 靖灿(灿)' : '❤️ 수완(完)'}</span>
                  </div>
                  <div class="flex items-center gap-1.5 shrink-0">
                    <span class="text-[10px] text-mut">${escapeHtml(item.date || '')}</span>
                    ${/[a-zA-Z0-9가-힣\u4e00-\u9fff]/.test(String(item.text || '')) ? `<button type="button" class="cw-retrans-item-btn btn-ghost px-2 py-0.5 rounded-full text-[10px] font-semibold whitespace-nowrap" data-rtype="jar" data-rid="${escapeHtml(item.id)}">🔄 ${isZh ? '重译' : '재번역'}</button>` : ''}<button type="button" class="cw-share-chat-item-btn btn-ghost px-2 py-0.5 rounded-full text-[10px] font-semibold whitespace-nowrap" data-stype="jar" data-sid="${escapeHtml(item.id)}">💬 ${isZh ? '发聊天' : '톡 공유'}</button>
                    <button type="button" class="jar-del-btn text-[11px] text-mut hover:text-rose-500" data-jar-id="${escapeHtml(item.id)}">✕</button>
                  </div>
                </div>
                <div class="text-xs sm:text-sm font-semibold leading-relaxed break-words">${escapeHtml(item.text || '')}</div>
                ${item.translated ? `<div class="text-xs text-sec leading-relaxed break-words">${escapeHtml(item.translated)}</div>` : ''}
                ${renderSpaceRepliesHtml('jar', item.id, item.replies)}
              </div>
            `).join('');
            listEl.querySelectorAll('.jar-del-btn').forEach(btn => {
              btn.addEventListener('click', () => {
                const jid = btn.getAttribute('data-jar-id');
                openConfirm(
                  state.lang === 'zh' ? '删除这条纸条？' : '이 칭찬 쪽지를 지울까요?',
                  state.lang === 'zh' ? '删除后将从玻璃瓶中移除。' : '삭제하면 유리병에서 사라집니다.',
                  () => {
                    state.complimentJar = (state.complimentJar || []).filter(x => x.id !== jid);
                    saveState(true);
                    renderComplimentJar();
                    renderLoveThermometer();
                  }
                );
              });
            });
          }
        }
      }

      /* --- Food Roulette (#diary-sub-food) --- */
      const FOOD_DECK = [
        { cat: 'kr', e: '🍲', ko: '김치찌개 & 계란말이', zh: '泡菜锅 & 鸡蛋卷', tag: '든든한 집밥' },
        { cat: 'kr', e: '🥩', ko: '삼겹살 구이', zh: '烤五花肉', tag: '고기 최고' },
        { cat: 'kr', e: '🍗', ko: '양념·후라이드 치킨', zh: '韩式炸鸡', tag: '치맥 타임' },
        { cat: 'kr', e: '🥘', ko: '부대찌개', zh: '部队火锅', tag: '얼큰 따끈' },
        { cat: 'kr', e: '🍜', ko: '잔치국수 · 비빔국수', zh: '韩式拌面/汤面', tag: '호로록 한 그릇' },
        { cat: 'kr', e: '🍚', ko: '돌솥 비빔밥', zh: '石锅拌饭', tag: '건강 밸런스' },
        { cat: 'kr', e: '🥣', ko: '순두부찌개', zh: '嫩豆腐锅', tag: '부드럽고 칼칼' },
        { cat: 'kr', e: '🍱', ko: '제육볶음 정식', zh: '辣炒猪肉饭', tag: '밥도둑' },
        { cat: 'kr', e: '🥟', ko: '칼국수 & 만두', zh: '韩式刀削面 & 饺子', tag: '따뜻한 국물' },
        { cat: 'kr', e: '🍖', ko: '갈비찜', zh: '韩式炖排骨', tag: '특식 데이' },
        { cat: 'kr', e: '🐟', ko: '고등어구이 정식', zh: '烤青花鱼套餐', tag: '담백한 한 끼' },
        { cat: 'kr', e: '🍛', ko: '김치볶음밥', zh: '泡菜炒饭', tag: '실패 없는 맛' },
        { cat: 'cn', e: '🫕', ko: '마라탕', zh: '麻辣烫', tag: '중독적인 얼얼함' },
        { cat: 'cn', e: '🥘', ko: '마라샹궈', zh: '麻辣香锅', tag: '향긋한 볶음' },
        { cat: 'cn', e: '🔥', ko: '충칭·사천 훠궈', zh: '重庆/四川火锅', tag: '같이 먹고 싶어' },
        { cat: 'cn', e: '🥟', ko: '샤오롱바오 (소롱포)', zh: '小笼包', tag: '육즙 팡팡' },
        { cat: 'cn', e: '🍳', ko: '토마토 계란볶음', zh: '番茄炒蛋', tag: '부드러운 집밥' },
        { cat: 'cn', e: '🍖', ko: '꿔바로우 (동북 탕수육)', zh: '锅包肉', tag: '바삭 새콤달콤' },
        { cat: 'cn', e: '🍜', ko: '란저우 우육면', zh: '兰州牛肉面', tag: '진한 국물' },
        { cat: 'cn', e: '🍢', ko: '양꼬치 & 쯔란', zh: '羊肉串', tag: '향신료 매력' },
        { cat: 'cn', e: '🍚', ko: '양저우 볶음밥', zh: '扬州炒饭', tag: '고슬고슬' },
        { cat: 'cn', e: '🌶️', ko: '어향육사', zh: '鱼香肉丝', tag: '밥 비벼먹기 최고' },
        { cat: 'cn', e: '🦆', ko: '베이징 덕', zh: '北京烤鸭', tag: '특별한 날' },
        { cat: 'cn', e: '🥡', ko: '마파두부 덮밥', zh: '麻婆豆腐盖饭', tag: '매콤 고소' },
        { cat: 'night', e: '🍢', ko: '떡볶이 & 순대 · 튀김', zh: '辣炒年糕 & 炸物', tag: '야식 1티어' },
        { cat: 'night', e: '🍜', ko: '치즈 라면 & 김밥', zh: '芝士拉面 & 紫菜包饭', tag: '밤에 제일 맛있어' },
        { cat: 'night', e: '🍕', ko: '페퍼로니·고구마 피자', zh: '芝士披萨', tag: '달콤 짭짤' },
        { cat: 'night', e: '🌮', ko: '지엔빙 (중국식 크레페)', zh: '煎饼果子', tag: '바삭한 길거리 간식' },
        { cat: 'night', e: '🧋', ko: '밀크티 & 크로플', zh: '奶茶 & 可颂松饼', tag: '당 충전 필수' },
        { cat: 'night', e: '🍓', ko: '탕후루 & 과일 요거트', zh: '冰糖葫芦 & 水果酸奶', tag: '상큼 디저트' },
        { cat: 'night', e: '🍔', ko: '수제 버거 & 감자튀김', zh: '汉堡 & 薯条', tag: '간편하게 냠냠' },
        { cat: 'night', e: '🐙', ko: '타코야끼 & 어묵탕', zh: '章鱼小丸子 & 关东煮', tag: '따끈한 간식' },
        { cat: 'night', e: '🦞', ko: '마라롱샤 (가재 요리)', zh: '麻辣小龙虾', tag: '최강 야식' },
        { cat: 'night', e: '🥞', ko: '호떡 & 붕어빵', zh: '糖饼 & 鲷鱼烧', tag: '달달 포근' },
        { cat: 'night', e: '🥪', ko: '에그 샌드위치 & 커피', zh: '鸡蛋三明治 & 咖啡', tag: '가벼운 한 끼' },
        { cat: 'night', e: '🍨', ko: '망고 빙수 · 아이스크림', zh: '芒果冰沙 · 冰淇淋', tag: '시원 달콤' }
      ];
      let activeFoodCat = 'all';
      let lastPickedFood = null;
      let foodSpinning = false;

      function getFilteredFoodDeck() {
        const custom = (Array.isArray(state.customFoods) ? state.customFoods : []).map(x => ({
          cat: 'all', e: '🍽️', ko: x, zh: x, tag: state.lang === 'zh' ? '专属菜单' : '우리 커스텀'
        }));
        const base = activeFoodCat === 'all' ? FOOD_DECK.concat(custom) : FOOD_DECK.filter(f => f.cat === activeFoodCat);
        return base.length ? base : FOOD_DECK;
      }

      function renderFoodRouletteMeta() {
        const isZh = state.lang === 'zh';
        const deck = getFilteredFoodDeck();
        const cntEl = document.getElementById('foodDeckCount');
        const titleEl = document.getElementById('foodTitle');
        const subEl = document.getElementById('foodSubLabel');
        if (cntEl) cntEl.textContent = isZh ? `${deck.length} 道美食` : `${deck.length}개 메뉴`;
        if (titleEl) titleEl.textContent = isZh ? '今天吃什么？中韩美食转盘' : '오늘 뭐 먹지? 메뉴 룰렛';
        if (subEl) subEl.textContent = isZh ? '🍜 情侣美食决策器' : '🍜 한·중 커플 메뉴 결정기';
      }

      function spinFoodRoulette() {
        if (foodSpinning) return;
        const deck = getFilteredFoodDeck();
        foodSpinning = true;
        const spinBtn = document.getElementById('foodSpinBtn');
        const shareBtn = document.getElementById('foodShareBtn');
        if (spinBtn) spinBtn.disabled = true;
        let ticks = 0;
        const totalTicks = 16;
        const runTick = () => {
          const item = deck[Math.floor(Math.random() * deck.length)];
          document.getElementById('foodResultEmoji').textContent = item.e;
          document.getElementById('foodResultKo').textContent = item.ko;
          document.getElementById('foodResultZh').textContent = item.zh;
          document.getElementById('foodResultTag').textContent = `✨ ${item.tag}`;
          ticks++;
          if (ticks < totalTicks) {
            setTimeout(runTick, 55 + ticks * 14);
          } else {
            lastPickedFood = item;
            foodSpinning = false;
            if (spinBtn) spinBtn.disabled = false;
            if (shareBtn) shareBtn.classList.remove('hidden');
          }
        };
        runTick();
      }

      /* --- Couple Fortune & Lucky Color (#diary-sub-fortune) --- */
      const FORTUNE_COLORS = [
        { hex: '#a78bfa', ko: '라벤더 퍼플', zh: '薰衣草紫' },
        { hex: '#f472b6', ko: '로즈 핑크', zh: '玫瑰粉' },
        { hex: '#fbbf24', ko: '샴페인 골드', zh: '香槟金' },
        { hex: '#60a5fa', ko: '스카이 블루', zh: '晴空蓝' },
        { hex: '#34d399', ko: '민트 그린', zh: '薄荷绿' },
        { hex: '#fb7185', ko: '피치 코랄', zh: '蜜桃珊瑚' },
        { hex: '#c084fc', ko: '라일락', zh: '丁香紫' }
      ];
      const FORTUNE_TIPS = [
        { ko: '오늘은 사소한 사진 한 장이 둘의 하루를 환하게 밝혀줄 거예요. 지금 보이는 풍경을 공유해 보세요!', zh: '今天一张随手拍的照片就能点亮彼此的心情，快分享一下你眼前的风景吧！' },
        { ko: '짧은 음성 편지나 목소리 한 마디가 100마디 글보다 큰 힘이 되는 날이에요. "보고 싶어"라고 말해 보세요.', zh: '今天一句短短的语音比一百句文字更有力量，试着亲口说一声“好想你”吧。' },
        { ko: '서로의 끼니를 챙겨줄수록 애정운이 쑥쑥 올라가요! 메뉴 룰렛으로 오늘 저녁을 같이 골라볼까요?', zh: '今天越关心彼此有没有好好吃饭，恋爱运就越旺！一起用转盘选今晚吃什么吧？' },
        { ko: '사소한 칭찬 한 마디가 큰 감동으로 돌아오는 날이에요. 칭찬 유리병에 고마운 마음을 담아보세요.', zh: '一句小小的夸奖会带来大大的感动，去夸夸玻璃瓶里放一张暖心纸条吧。' },
        { ko: '멀리 있어도 마음이 유독 잘 통하는 텔레파시 데이! 미니 퀴즈나 밸런스 게임으로 궁합을 확인해 보세요.', zh: '今天是心灵特别相通的默契日！去小测验或默契问答测测合拍度吧。' },
        { ko: '밤에 잠들기 전 함께 수면 사운드를 켜두고 굿나잇 인사를 나누면 꿀잠 + 설렘 2배!', zh: '今晚睡前一起打开助眠白噪音互道晚安，好梦与甜蜜都会加倍哦！' }
      ];
      const COOKIE_LIST = [
        { ko: '💌 오늘 안에 상대방에게 "네가 있어서 든든해"라고 보내기!', zh: '💌 今天内给对方发一句“有你在真的很安心”！' },
        { ko: '📸 지금 내 주변에서 제일 예쁜 것 하나 찍어서 CW 톡에 보내기!', zh: '📸 拍一张现在身边最可爱的东西发到 CW 聊天里！' },
        { ko: '🫂 홈 화면 포옹 버튼 1.5초 꾹 눌러서 따뜻한 포옹 보내기!', zh: '🫂 去首页长按拥抱按钮1.5秒，发送温暖抱抱！' },
        { ko: '🫙 칭찬 유리병에 상대방의 장점 1가지 몰래 넣어두기!', zh: '🫙 偷偷往夸夸玻璃瓶里放一条对方的优点！' },
        { ko: '🌙 오늘 밤 자기 전 10초짜리 굿나잇 음성 편지 남기기!', zh: '🌙 今晚睡前录一条10秒的晚安语音信！' },
        { ko: '🗣️ 오늘 상대방 언어로 "사랑해" 직접 말해보기!', zh: '🗣️ 今天用对方的语言亲口说一次“我爱你”！' }
      ];

      function hashSeed(str) {
        let h = 2166136261;
        for (let i = 0; i < str.length; i++) {
          h ^= str.charCodeAt(i);
          h = Math.imul(h, 16777619);
        }
        return Math.abs(h);
      }

      function getTodayFortuneData() {
        const kst = getKstDateString();
        const seed = hashSeed('chanwan-fortune-' + kst);
        const score = 84 + (seed % 17);
        const color = FORTUNE_COLORS[seed % FORTUNE_COLORS.length];
        const tip = FORTUNE_TIPS[(seed >> 3) % FORTUNE_TIPS.length];
        const hour = 19 + (seed % 5);
        const min = (seed % 2) === 0 ? '00' : '30';
        const num = (seed % 9) + 1;
        return { kst, score, color, tip, time: `${hour}:${min}`, num };
      }

      function renderCoupleFortune() {
        const isZh = state.lang === 'zh';
        const f = getTodayFortuneData();
        const dEl = document.getElementById('fortuneDateLabel');
        const tEl = document.getElementById('fortuneTitle');
        const sEl = document.getElementById('fortuneScoreBadge');
        const dotEl = document.getElementById('fortuneColorDot');
        const cnameEl = document.getElementById('fortuneColorName');
        const timeEl = document.getElementById('fortuneTimeVal');
        const numEl = document.getElementById('fortuneNumVal');
        const mKo = document.getElementById('fortuneMsgKo');
        const mZh = document.getElementById('fortuneMsgZh');
        if (dEl) dEl.textContent = `🔮 ${f.kst} · ${isZh ? '今日情侣运势' : '오늘의 커플 운세'}`;
        if (tEl) tEl.textContent = isZh ? '灿完 今日爱情指数 & 幸运色' : '灿完 오늘의 애정 지수 & 행운 컬러';
        if (sEl) sEl.textContent = `${f.score}${isZh ? '分' : '점'} 💕`;
        if (dotEl) dotEl.style.background = f.color.hex;
        if (cnameEl) cnameEl.textContent = isZh ? f.color.zh : f.color.ko;
        if (timeEl) timeEl.textContent = f.time;
        if (numEl) numEl.textContent = String(f.num);
        if (mKo) mKo.textContent = f.tip.ko;
        if (mZh) mZh.textContent = f.tip.zh;
      }

      /* --- 100% Offline Web Audio Sleep Sounds (#diary-sub-sleep) --- */
      let sleepAudioCtx = null;
      let sleepGainNode = null;
      let sleepActiveNodes = [];
      let sleepActiveType = '';
      let sleepTimerMinutes = 30;
      let sleepEndAt = 0;
      let sleepCountdownInterval = null;

      function stopSleepSound(silent) {
        sleepActiveNodes.forEach(n => { try { if (n.stop) n.stop(); if (n.disconnect) n.disconnect(); } catch (_) {} });
        sleepActiveNodes = [];
        sleepActiveType = '';
        sleepEndAt = 0;
        if (sleepCountdownInterval) { clearInterval(sleepCountdownInterval); sleepCountdownInterval = null; }
        document.querySelectorAll('.sleep-snd-btn').forEach(b => { b.style.borderColor = ''; b.style.boxShadow = ''; });
        const st = document.getElementById('sleepSndStatus');
        if (st) st.textContent = state.lang === 'zh' ? '已停止' : '대기 중';
        if (!silent) showToast(state.lang === 'zh' ? '助眠声音已停止' : '수면 사운드를 멈췄어요');
      }

      function startSleepSound(type) {
        if (sleepActiveType === type) { stopSleepSound(false); return; }
        stopSleepSound(true);
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        if (!AudioCtx) { showToast(state.lang === 'zh' ? '当前浏览器不支持音频播放' : '이 브라우저는 오디오 재생을 지원하지 않습니다.'); return; }
        if (!sleepAudioCtx) sleepAudioCtx = new AudioCtx();
        if (sleepAudioCtx.state === 'suspended') sleepAudioCtx.resume();

        const volSlider = document.getElementById('sleepVolSlider');
        const vol = (Number(volSlider ? volSlider.value : 45) / 100) * 0.45;
        sleepGainNode = sleepAudioCtx.createGain();
        sleepGainNode.gain.setValueAtTime(0.001, sleepAudioCtx.currentTime);
        sleepGainNode.gain.linearRampToValueAtTime(vol, sleepAudioCtx.currentTime + 1.2);
        sleepGainNode.connect(sleepAudioCtx.destination);
        sleepActiveNodes.push(sleepGainNode);

        const sr = sleepAudioCtx.sampleRate;
        const len = sr * 4;
        const buf = sleepAudioCtx.createBuffer(1, len, sr);
        const data = buf.getChannelData(0);
        let b0 = 0, b1 = 0, lastOut = 0;
        for (let i = 0; i < len; i++) {
          const white = Math.random() * 2 - 1;
          if (type === 'rain') {
            b0 = 0.997 * b0 + white * 0.029;
            b1 = 0.985 * b1 + white * 0.032;
            data[i] = (b0 + b1 + white * 0.08) * 0.9;
          } else if (type === 'ocean' || type === 'night') {
            lastOut = (lastOut + 0.02 * white) / 1.02;
            data[i] = lastOut * 2.8;
          } else {
            lastOut = (lastOut + 0.03 * white) / 1.03;
            const crackle = Math.random() > 0.9985 ? (Math.random() * 0.9 - 0.45) : 0;
            data[i] = lastOut * 2.4 + crackle;
          }
        }
        const src = sleepAudioCtx.createBufferSource();
        src.buffer = buf;
        src.loop = true;
        const filter = sleepAudioCtx.createBiquadFilter();
        if (type === 'rain') { filter.type = 'bandpass'; filter.frequency.value = 1100; filter.Q.value = 0.55; }
        else if (type === 'ocean') { filter.type = 'lowpass'; filter.frequency.value = 420; }
        else if (type === 'fire') { filter.type = 'lowpass'; filter.frequency.value = 650; }
        else { filter.type = 'lowpass'; filter.frequency.value = 300; }

        src.connect(filter);
        filter.connect(sleepGainNode);
        sleepActiveNodes.push(src, filter);

        if (type === 'ocean') {
          const lfo = sleepAudioCtx.createOscillator();
          const lfoGain = sleepAudioCtx.createGain();
          lfo.frequency.value = 0.11;
          lfoGain.gain.value = 240;
          lfo.connect(lfoGain);
          lfoGain.connect(filter.frequency);
          lfo.start();
          sleepActiveNodes.push(lfo, lfoGain);
        }
        src.start();
        sleepActiveType = type;

        document.querySelectorAll('.sleep-snd-btn').forEach(b => {
          const on = b.getAttribute('data-sound') === type;
          b.style.borderColor = on ? 'var(--accent-royal)' : '';
          b.style.boxShadow = on ? '0 0 0 2px var(--accent-royal-soft)' : '';
        });

        const updateTimerStatus = () => {
          const st = document.getElementById('sleepSndStatus');
          if (!st) return;
          if (!sleepTimerMinutes) { st.textContent = state.lang === 'zh' ? '🎵 播放中 · 持续' : '🎵 재생 중 · 계속'; return; }
          const rem = Math.max(0, Math.ceil((sleepEndAt - Date.now()) / 1000));
          if (rem <= 0) { stopSleepSound(true); return; }
          st.textContent = `🎵 ${String(Math.floor(rem / 60)).padStart(2, '0')}:${String(rem % 60).padStart(2, '0')}`;
        };
        if (sleepTimerMinutes > 0) {
          sleepEndAt = Date.now() + sleepTimerMinutes * 60 * 1000;
          sleepCountdownInterval = setInterval(updateTimerStatus, 1000);
        }
        updateTimerStatus();
      }

      /* --- Couple Mini Quiz (#diary-sub-quiz) --- */
      const QUIZ_SAMPLES = [
        { q: '오늘 내가 제일 먹고 싶었던 음식은?', opts: ['마라탕', '삼겹살', '치킨'], ans: 0 },
        { q: '내가 가장 좋아하는 데이트 스타일은?', opts: ['맛집 탐방', '카페 수다', '야경 산책'], ans: 2 },
        { q: '내가 피곤할 때 제일 듣고 싶은 말은?', opts: ['오늘도 고생 많았어', '보고 싶어', '맛있는 거 먹자'], ans: 0 },
        { q: '다음에 만나면 제일 먼저 하고 싶은 건?', opts: ['꼬옥 안아주기', '같이 사진 찍기', '손잡고 걷기'], ans: 0 }
      ];

      function renderCoupleQuizzes() {
        const isZh = state.lang === 'zh';
        const myRole = state.myRole || 'suwan';
        const list = Array.isArray(state.coupleQuizzes) ? state.coupleQuizzes : [];
        const answered = list.filter(q => typeof q.pickedIdx === 'number');
        const correct = answered.filter(q => q.pickedIdx === q.answerIdx);
        const badge = document.getElementById('cquizScoreBadge');
        const listEl = document.getElementById('cquizList');
        if (badge) badge.textContent = isZh ? `答对 ${correct.length}/${answered.length}` : `정답 ${correct.length}/${answered.length}`;
        if (!listEl) return;
        if (!list.length) {
          listEl.innerHTML = `<div class="royal-subcard rounded-2xl p-5 text-center text-xs text-mut">${isZh ? '还没有题目，出第一道题考考对方吧 🎯' : '아직 등록된 퀴즈가 없어요. 상대방에게 첫 문제를 내보세요 🎯'}</div>`;
          return;
        }
        listEl.innerHTML = list.map(q => {
          const isMine = q.author === myRole;
          const isDone = typeof q.pickedIdx === 'number';
          const isHit = isDone && q.pickedIdx === q.answerIdx;
          const authorLabel = q.author === 'jingchan' ? '💜 靖灿(灿)' : '❤️ 수완(完)';
          return `
            <div class="royal-subcard rounded-2xl p-3.5 space-y-2.5">
              <div class="flex items-center justify-between gap-2 text-[11px]">
                <span class="font-bold" style="color: var(--accent-royal);">${authorLabel} ${isZh ? '出题' : '출제'} · ${escapeHtml(q.date || '')}</span>
                <div class="flex items-center gap-2">
                  ${isDone ? `<span class="font-bold px-2 py-0.5 rounded-full" style="background:${isHit ? 'rgba(16,185,129,0.15)' : 'rgba(244,63,94,0.14)'}; color:${isHit ? '#059669' : '#e11d48'};">${isHit ? (isZh ? '🎉 答对!' : '🎉 정답!') : (isZh ? '😅 差一点' : '😅 아쉽!')}</span>` : `<span class="text-mut">${isMine ? (isZh ? '等待对方回答' : '상대방 답변 대기') : (isZh ? '快来猜猜看!' : '정답을 골라봐요!')}</span>`}
                  <button type="button" class="cquiz-del-btn text-mut hover:text-rose-500" data-qid="${escapeHtml(q.id)}">✕</button>
                </div>
              </div>
              <div class="text-xs sm:text-sm font-bold leading-snug">Q. ${escapeHtml(q.question || '')}</div>
              <div class="grid grid-cols-1 sm:grid-cols-3 gap-1.5">
                ${(q.options || []).map((opt, idx) => {
                  let cls = 'btn-ghost';
                  if (isDone) {
                    if (idx === q.answerIdx) cls = 'btn-royal';
                    else if (idx === q.pickedIdx) cls = 'btn-ghost opacity-70';
                  }
                  const dis = (isDone || isMine) ? 'disabled' : '';
                  const mark = isDone && idx === q.answerIdx ? ' ✅' : (isDone && idx === q.pickedIdx && idx !== q.answerIdx ? ' ❌' : '');
                  return `<button type="button" class="cquiz-opt-btn ${cls} py-2 px-3 rounded-xl text-xs font-semibold text-left truncate" data-qid="${escapeHtml(q.id)}" data-idx="${idx}" ${dis}>${idx + 1}. ${escapeHtml(opt)}${mark}</button>`;
                }).join('')}
              </div>
              ${renderSpaceRepliesHtml('cquiz', q.id, q.replies)}
            </div>
          `;
        }).join('');

        listEl.querySelectorAll('.cquiz-opt-btn:not([disabled])').forEach(btn => {
          btn.addEventListener('click', () => {
            const qid = btn.getAttribute('data-qid');
            const idx = Number(btn.getAttribute('data-idx'));
            const q = (state.coupleQuizzes || []).find(x => x.id === qid);
            if (!q || typeof q.pickedIdx === 'number') return;
            q.pickedIdx = idx;
            q.answeredBy = state.myRole || 'suwan';
            q.answeredAt = Date.now();
            const hit = idx === q.answerIdx;
            if (hit && typeof addLavenderBonusXp === 'function') addLavenderBonusXp('cquiz_' + qid, 15);
            saveState(true);
            renderCoupleQuizzes();
            showToast(hit
              ? (state.lang === 'zh' ? '🎉 默契满分！答对啦 (+15 XP)' : '🎉 역시 날 제일 잘 알아! 정답 (+15 XP)')
              : (state.lang === 'zh' ? '😅 差一点点！记住正确选项哦' : '😅 아쉽다! 정답을 기억해 둬요'));
          });
        });
        listEl.querySelectorAll('.cquiz-del-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            const qid = btn.getAttribute('data-qid');
            openConfirm(
              state.lang === 'zh' ? '删除这道题？' : '이 퀴즈를 삭제할까요?',
              state.lang === 'zh' ? '删除后将从列表移除。' : '삭제하면 목록에서 사라집니다.',
              () => {
                state.coupleQuizzes = (state.coupleQuizzes || []).filter(x => x.id !== qid);
                saveState(true);
                renderCoupleQuizzes();
              }
            );
          });
        });
      }

      async function shareQuickMessageToChat(koText, zhText, toneLabel) {
        const myRole = state.myRole || 'suwan';
        const isSuwan = myRole === 'suwan';
        const msg = {
          id: uid(),
          ts: Date.now(),
          sender: myRole,
          deliveryStatus: 'sending',
          time: getKstTimeShort(),
          original: isSuwan ? koText : zhText,
          translated: isSuwan ? zhText : koText,
          pronunciation: '',
          tone: toneLabel || '💌 커플공간 공유',
          engine: 'Instant',
          tgtLang: isSuwan ? 'zh' : 'ko',
          accuracy: 100,
          reactions: []
        };
        if (!state.chat) state.chat = { messages: [], qaAnswers: [] };
        state.chat.messages.push(msg);
        saveState(true);
        renderChat();
        renderLoveThermometer();
        showToast(state.lang === 'zh' ? '已分享到 CW 聊天 💌' : 'CW 톡에 바로 공유했어요 💌');
        switchTab('translator');
        if (typeof switchTransSubtab === 'function') switchTransSubtab('messenger');
      }

      function bindPlus18Events() {
        // Energy pickers
        document.querySelectorAll('.energy-pick-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            const role = btn.getAttribute('data-role');
            const lv = Number(btn.getAttribute('data-lv') || 100);
            if ((state.myRole || 'suwan') !== role) return;
            state.profile[role + 'Energy'] = { level: lv, updatedAt: Date.now() };
            saveState(true);
            renderEnergyActivityCards();
            showToast(lv <= 30
              ? (state.lang === 'zh' ? '🪫 已更新低电量状态，对方会收到求抱抱提醒 💜' : '🪫 지친 상태를 공유했어요! 상대방에게 위로 알림이 가요 💜')
              : (state.lang === 'zh' ? '🔋 能量状态已更新' : '🔋 오늘의 에너지가 업데이트되었어요'));
          });
        });

        // Hold-to-Hug button
        const hugBtn = document.getElementById('holdHugBtn');
        ['holdHugBtn', 'heartbeatBtn'].forEach(bid => {
          const bEl = document.getElementById(bid);
          if (!bEl) return;
          bEl.addEventListener('contextmenu', (ev) => { ev.preventDefault(); ev.stopPropagation(); return false; });
          bEl.addEventListener('selectstart', (ev) => { ev.preventDefault(); return false; });
        });
        const hugFill = document.getElementById('holdHugFill');
        const hugLabel = document.getElementById('holdHugLabel');
        if (hugBtn && hugFill && hugLabel) {
          const cancelHold = () => {
            if (!hugHolding) return;
            hugHolding = false;
            if (hugRaf) cancelAnimationFrame(hugRaf);
            hugFill.style.width = '0%';
            hugLabel.textContent = state.lang === 'zh' ? '🫂 长按 1.5 秒发送拥抱' : '🫂 1.5초 꾹 눌러서 포옹 보내기';
          };
          const startHold = (e) => {
            if (e && e.cancelable) e.preventDefault();
            hugHolding = true;
            hugStartTs = performance.now();
            hugLabel.textContent = state.lang === 'zh' ? '🫂 正在积攒温暖...' : '🫂 포근한 마음 모으는 중...';
            const step = (now) => {
              if (!hugHolding) return;
              const pct = Math.min(100, ((now - hugStartTs) / HUG_HOLD_MS) * 100);
              hugFill.style.width = `${pct}%`;
              if (pct >= 100) {
                hugHolding = false;
                hugFill.style.width = '0%';
                triggerSendHug();
                hugLabel.textContent = state.lang === 'zh' ? '🫂 拥抱发送成功! 💜' : '🫂 포옹 전송 완료! 💜';
                setTimeout(() => renderLoveThermometer(), 1400);
                return;
              }
              hugRaf = requestAnimationFrame(step);
            };
            hugRaf = requestAnimationFrame(step);
          };
          hugBtn.addEventListener('pointerdown', startHold);
          hugBtn.addEventListener('pointerup', cancelHold);
          hugBtn.addEventListener('pointerleave', cancelHold);
          hugBtn.addEventListener('pointercancel', cancelHold);
        }

        // TMI Book bindings
        document.querySelectorAll('.tmi-owner-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            activeTmiOwner = btn.getAttribute('data-owner') || 'suwan';
            renderTmiBook();
          });
        });
        const tmiForm = document.getElementById('tmiForm');
        if (tmiForm) {
          tmiForm.addEventListener('submit', (e) => {
            e.preventDefault();
            if (!state.tmiBook) state.tmiBook = JSON.parse(JSON.stringify(DEFAULT_STATE.tmiBook));
            state.tmiBook[activeTmiOwner] = {
              likeFood: (document.getElementById('tmiLikeFood')?.value || '').trim(),
              dislikeFood: (document.getElementById('tmiDislikeFood')?.value || '').trim(),
              cafe: (document.getElementById('tmiCafe')?.value || '').trim(),
              size: (document.getElementById('tmiSize')?.value || '').trim(),
              color: (document.getElementById('tmiColor')?.value || '').trim(),
              gift: (document.getElementById('tmiGift')?.value || '').trim(),
              memo: (document.getElementById('tmiMemo')?.value || '').trim(),
              updatedAt: Date.now()
            };
            saveState(true);
            showToast(state.lang === 'zh' ? '📝 喜好百科已保存并同步！' : '📝 취향 사전이 저장·동기화되었어요!');
          });
        }

        // Compliment Jar bindings
        document.querySelectorAll('.jar-tag-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            activeJarTag = btn.getAttribute('data-tag') || '💜 고마워';
            document.querySelectorAll('.jar-tag-btn').forEach(b => {
              b.className = `jar-tag-btn ${b === btn ? 'btn-royal' : 'btn-ghost'} px-2.5 py-1 rounded-full text-[11px] font-semibold`;
            });
          });
        });
        const jarShakeBtn = document.getElementById('jarShakeBtn');
        if (jarShakeBtn) {
          jarShakeBtn.addEventListener('click', () => {
            const list = Array.isArray(state.complimentJar) ? state.complimentJar : [];
            const box = document.getElementById('jarSpotlightBox');
            if (!list.length) {
              if (box) box.innerHTML = `<div class="text-mut">${state.lang === 'zh' ? '玻璃瓶里还没有纸条，先写一条吧 ✨' : '아직 유리병에 쪽지가 없어요. 먼저 하나 넣어볼까요? ✨'}</div>`;
              return;
            }
            const pick = list[Math.floor(Math.random() * list.length)];
            if (box) {
              box.innerHTML = `
                <div class="text-[10.5px] font-bold mb-1" style="color: var(--accent-royal);">${escapeHtml(pick.tag || '💜 고마워')} · ${pick.author === 'jingchan' ? '💜 靖灿(灿)' : '❤️ 수완(完)'} (${escapeHtml(pick.date || '')})</div>
                <div class="text-xs sm:text-sm font-bold leading-relaxed">${escapeHtml(pick.text || '')}</div>
                ${pick.translated ? `<div class="text-xs text-sec mt-1">${escapeHtml(pick.translated)}</div>` : ''}
              `;
            }
          });
        }
        const jarForm = document.getElementById('jarAddForm');
        if (jarForm) {
          jarForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const inp = document.getElementById('jarNoteInput');
            const text = autoPrefixCoupleEmoji((inp ? inp.value : '').trim());
            if (!text) return;
            if (!Array.isArray(state.complimentJar)) state.complimentJar = [];
            const noteId = uid();
            const newItem = { id: noteId, author: state.myRole || 'suwan', tag: activeJarTag, text, translated: '', date: getKstDateString(), ts: Date.now() };
            state.complimentJar.unshift(newItem);
            if (inp) inp.value = '';
            if (typeof addLavenderBonusXp === 'function') addLavenderBonusXp('jar_' + getKstDateString(), 5);
            saveState(true);
            renderComplimentJar();
            renderLoveThermometer();
            showToast(state.lang === 'zh' ? '✨ 夸夸纸条已放进玻璃瓶！' : '✨ 칭찬 쪽지를 유리병에 담았어요!');
            if (typeof geminiTranslate === 'function' && /[a-zA-Z0-9가-힣\u4e00-\u9fff]/.test(text)) {
              geminiTranslate(text, 'lover').then(res => {
                if (res && res.translated && res.translated !== text) {
                  const found = (state.complimentJar || []).find(x => x && x.id === noteId);
                  if (found) {
                    found.translated = res.translated;
                    saveState(true);
                    renderComplimentJar();
                  }
                }
              }).catch(() => {});
            }
          });
        }

        // Food Roulette bindings
        document.querySelectorAll('.food-cat-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            activeFoodCat = btn.getAttribute('data-fcat') || 'all';
            document.querySelectorAll('.food-cat-btn').forEach(b => {
              b.className = `food-cat-btn ${b === btn ? 'btn-royal' : 'btn-ghost'} px-3 py-1.5 rounded-full text-xs font-semibold`;
            });
            renderFoodRouletteMeta();
          });
        });
        const spinBtn = document.getElementById('foodSpinBtn');
        if (spinBtn) spinBtn.addEventListener('click', spinFoodRoulette);
        const foodShareBtn = document.getElementById('foodShareBtn');
        if (foodShareBtn) {
          foodShareBtn.addEventListener('click', () => {
            if (!lastPickedFood) return;
            shareQuickMessageToChat(
              `🍜 오늘 뭐 먹지 룰렛 결과: ${lastPickedFood.e} ${lastPickedFood.ko}! 이거 어때?`,
              `🍜 今天吃什么转盘结果：${lastPickedFood.e} ${lastPickedFood.zh}！吃这个怎么样？`
            );
          });
        }
        const foodCustomForm = document.getElementById('foodCustomForm');
        if (foodCustomForm) {
          foodCustomForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const inp = document.getElementById('foodCustomInput');
            const vRaw = (inp ? inp.value : '').trim();
            if (!vRaw) return;
            const v = autoPrefixCoupleEmoji(vRaw);
            if (!Array.isArray(state.customFoods)) state.customFoods = [];
            if (!state.customFoods.includes(v)) state.customFoods.push(v);
            if (inp) inp.value = '';
            saveState(false);
            renderFoodRouletteMeta();
            showToast(state.lang === 'zh' ? `已添加 "${v}" 到转盘 🍜` : `"${v}" 메뉴를 룰렛에 추가했어요 🍜`);
          });
        }

        // Fortune bindings
        const cookieBtn = document.getElementById('cookieCrackBtn');
        if (cookieBtn) {
          cookieBtn.addEventListener('click', () => {
            const pick = COOKIE_LIST[Math.floor(Math.random() * COOKIE_LIST.length)];
            const box = document.getElementById('cookieMsgBox');
            if (box) box.innerHTML = `<div class="font-bold text-main">${escapeHtml(pick.ko)}</div><div class="text-sec mt-0.5">${escapeHtml(pick.zh)}</div>`;
          });
        }
        const fortuneShareBtn = document.getElementById('fortuneShareBtn');
        if (fortuneShareBtn) {
          fortuneShareBtn.addEventListener('click', () => {
            const f = getTodayFortuneData();
            shareQuickMessageToChat(
              `🔮 오늘 우리 커플 운세 ${f.score}점! 행운 컬러: ${f.color.ko} · 행운 시간: ${f.time} 💕`,
              `🔮 今日情侣运势 ${f.score}分！幸运色：${f.color.zh} · 幸运时间：${f.time} 💕`
            );
          });
        }

        // Sleep Sound bindings
        document.querySelectorAll('.sleep-snd-btn').forEach(btn => {
          btn.addEventListener('click', () => startSleepSound(btn.getAttribute('data-sound')));
        });
        const volSlider = document.getElementById('sleepVolSlider');
        if (volSlider) {
          volSlider.addEventListener('input', () => {
            const v = Number(volSlider.value || 45);
            const lbl = document.getElementById('sleepVolVal');
            if (lbl) lbl.textContent = `${v}%`;
            if (sleepGainNode && sleepAudioCtx) sleepGainNode.gain.setTargetAtTime((v / 100) * 0.45, sleepAudioCtx.currentTime, 0.08);
          });
        }
        document.querySelectorAll('.sleep-timer-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            sleepTimerMinutes = Number(btn.getAttribute('data-min') || 0);
            document.querySelectorAll('.sleep-timer-btn').forEach(b => {
              b.className = `sleep-timer-btn ${b === btn ? 'btn-royal' : 'btn-ghost'} px-2.5 py-1 rounded-full text-[11px] font-semibold`;
            });
            if (sleepActiveType) {
              if (sleepCountdownInterval) { clearInterval(sleepCountdownInterval); sleepCountdownInterval = null; }
              if (sleepTimerMinutes > 0) {
                sleepEndAt = Date.now() + sleepTimerMinutes * 60 * 1000;
                sleepCountdownInterval = setInterval(() => {
                  const st = document.getElementById('sleepSndStatus');
                  const rem = Math.max(0, Math.ceil((sleepEndAt - Date.now()) / 1000));
                  if (rem <= 0) { stopSleepSound(true); return; }
                  if (st) st.textContent = `🎵 ${String(Math.floor(rem / 60)).padStart(2, '0')}:${String(rem % 60).padStart(2, '0')}`;
                }, 1000);
              } else {
                const st = document.getElementById('sleepSndStatus');
                if (st) st.textContent = state.lang === 'zh' ? '🎵 播放中 · 持续' : '🎵 재생 중 · 계속';
              }
            }
          });
        });
        const sleepStopBtn = document.getElementById('sleepStopBtn');
        if (sleepStopBtn) sleepStopBtn.addEventListener('click', () => stopSleepSound(false));

        // Couple Mini Quiz bindings
        const sampleBtn = document.getElementById('cquizSampleBtn');
        if (sampleBtn) {
          sampleBtn.addEventListener('click', () => {
            const s = QUIZ_SAMPLES[Math.floor(Math.random() * QUIZ_SAMPLES.length)];
            document.getElementById('cquizQuestionInput').value = s.q;
            document.getElementById('cquizOpt0').value = s.opts[0];
            document.getElementById('cquizOpt1').value = s.opts[1];
            document.getElementById('cquizOpt2').value = s.opts[2];
            document.getElementById('cquizAnswerSelect').value = String(s.ans);
          });
        }
        const qForm = document.getElementById('cquizCreateForm');
        if (qForm) {
          qForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const q = (document.getElementById('cquizQuestionInput')?.value || '').trim();
            const o0 = (document.getElementById('cquizOpt0')?.value || '').trim();
            const o1 = (document.getElementById('cquizOpt1')?.value || '').trim();
            const o2 = (document.getElementById('cquizOpt2')?.value || '').trim();
            const ans = Number(document.getElementById('cquizAnswerSelect')?.value || 0);
            if (!q || !o0 || !o1 || !o2) return;
            if (!Array.isArray(state.coupleQuizzes)) state.coupleQuizzes = [];
            state.coupleQuizzes.unshift({
              id: uid(),
              author: state.myRole || 'suwan',
              question: q,
              options: [o0, o1, o2],
              answerIdx: ans,
              pickedIdx: null,
              answeredBy: '',
              answeredAt: 0,
              date: getKstDateString(),
              ts: Date.now()
            });
            qForm.reset();
            saveState(true);
            renderCoupleQuizzes();
            showToast(state.lang === 'zh' ? '💌 题目已发给对方啦！' : '💌 상대방에게 퀴즈를 출제했어요!');
          });
        }
      }


      /* --- Plus 1.9: Floating Jump-to-Bottom + Instant Focus/Pageshow Sync Recovery --- */
      (function initPlus19Enhancements() {
        const listEl = document.getElementById('chatMessagesList');
        const jumpBtn = document.getElementById('chatJumpBottomBtn');
        if (listEl && jumpBtn) {
          const checkScroll = () => {
            const distFromBottom = listEl.scrollHeight - listEl.scrollTop - listEl.clientHeight;
            jumpBtn.classList.toggle('hidden', distFromBottom < 160);
            jumpBtn.textContent = state.lang === 'zh' ? '↓ 最新消息' : '↓ 최신 메시지';
          };
          listEl.addEventListener('scroll', checkScroll, { passive: true });
          jumpBtn.addEventListener('click', () => {
            listEl.scrollTo({ top: listEl.scrollHeight, behavior: 'smooth' });
            jumpBtn.classList.add('hidden');
          });
        }
        // Instant wake-up sync on phone unlock / app resume (focus + pageshow)
        let lastResumeSyncTs = 0;
        const triggerInstantResumeSync = () => {
          const now = Date.now();
          if (now - lastResumeSyncTs < 2500) return;
          lastResumeSyncTs = now;
          if (typeof window.__pullCloudSync === 'function') window.__pullCloudSync(false);
        };
        const wakeAndSyncAll = () => {
          if (typeof window.__connectEmqxNow === 'function') window.__connectEmqxNow();
          triggerInstantResumeSync();
        };
        // Prime 4 v34: Auto-flush failed/stuck messages when LTE/Wi-Fi returns + Daily Anniversary Morning Banner
        const autoFlushFailedMessages = () => {
          try {
            if (typeof navigator !== 'undefined' && navigator.onLine === false) return;
            const msgs = state.chat && Array.isArray(state.chat.messages) ? state.chat.messages : [];
            const now = Date.now();
            let retried = 0;
            msgs.forEach(m => {
              if (!m) return;
              if (m.deliveryStatus === 'failed' || (m.deliveryStatus === 'sending' && m.ts && (now - Number(m.ts)) > 15000)) {
                m.deliveryStatus = 'sending';
                retried++;
              }
            });
            if (retried > 0) {
              if (typeof renderChat === 'function') renderChat();
              if (typeof flushSyncOutbox === 'function') flushSyncOutbox();
              if (typeof window.__pushFullCloudSync === 'function') window.__pushFullCloudSync();
            }
          } catch (_) {}
        };
        window.addEventListener('online', () => { wakeAndSyncAll(); autoFlushFailedMessages(); });
        setTimeout(autoFlushFailedMessages, 3500);

        const checkDailyAnniversaryPush = () => {
          try {
            const todayK = typeof getKstDateString === 'function' ? getKstDateString() : '';
            if (!todayK) return;
            const sentKey = 'cw_anniv_push_date_v1';
            if (localStorage.getItem(sentKey) === todayK) return;
            const mmdd = todayK.slice(5);
            const hits = [];
            (state.anniversaries || []).forEach(a => {
              if (a && a.date && String(a.date).slice(5) === mmdd) hits.push(a.title || a.name || '기념일');
            });
            const startStr = state.profile && state.profile.startDate;
            if (startStr) {
              const diffDays = Math.floor((new Date(todayK + 'T00:00:00+09:00') - new Date(startStr + 'T00:00:00+09:00')) / 86400000) + 1;
              if ([100, 200, 300, 365, 500, 730, 1000, 1500, 2000].includes(diffDays)) {
                hits.push(`D+${diffDays}`);
              }
            }
            if (!hits.length) return;
            localStorage.setItem(sentKey, todayK);
            const label = hits.join(' · ');
            const koMsg = `🎉 오늘은 특별한 날(${label})이에요! 서로에게 다정한 한마디를 남겨보세요 💜`;
            const zhMsg = `🎉 今天是特别的日子（${label}）！给彼此发一句甜甜的话吧 💜`;
            if (typeof pushNotification === 'function') {
              pushNotification('🎉', '오늘의 기념일 축하', '今日纪念日快乐', koMsg, zhMsg, 'diary', 'anniversary', 'anniversary', false, state.myRole || 'suwan');
            }
          } catch (_) {}
        };
        setTimeout(checkDailyAnniversaryPush, 4500);

        window.addEventListener('focus', () => { wakeAndSyncAll(); autoFlushFailedMessages(); });
        window.addEventListener('pageshow', wakeAndSyncAll);
        document.addEventListener('visibilitychange', () => { if (!document.hidden) wakeAndSyncAll(); });
      })();


      /* --- Plus 2.0: Header Day/Night Toggle & Study Problem Bookmarking (⭐) --- */
      (function initPlus20Features() {
        const hdrLiveBtn = document.getElementById('headerLiveSyncBtn');
        if (hdrLiveBtn) {
          hdrLiveBtn.addEventListener('click', () => {
            const dot = document.getElementById('headerLiveDot');
            if (dot) { dot.style.transform = 'scale(1.35)'; setTimeout(() => { dot.style.transform = 'scale(1)'; }, 260); }
            if (typeof window.__pullCloudSync === 'function') window.__pullCloudSync(true);
          });
        }

        const makeStarKey = (q, ans) => `${String(q || '').trim()}||${String(ans || '').trim()}`;

        window.__isProblemStarred = function(q, ans) {
          const list = Array.isArray(state.learn?.starredProblems) ? state.learn.starredProblems : [];
          const k = makeStarKey(q, ans);
          return list.some(x => x && makeStarKey(x.q, x.answer) === k);
        };

        window.__syncQuizStarBtnUi = function() {
          const btn = document.getElementById('quizStarBtn');
          const cur = window.__currentQuizForStar;
          if (!btn || !cur) return;
          const on = window.__isProblemStarred(cur.q, cur.answer);
          const isZh = state.lang === 'zh';
          btn.textContent = on ? (isZh ? '⭐ 已收藏' : '⭐ 찜됨') : (isZh ? '☆ 收藏' : '☆ 즐겨찾기');
          btn.className = `${on ? 'btn-gold' : 'btn-ghost'} px-2 py-0.5 rounded-full text-[10.5px] font-bold whitespace-nowrap`;
        };

        window.__toggleStarredProblem = function(item) {
          if (!item || (!item.q && !item.answer)) return;
          if (!state.learn) state.learn = JSON.parse(JSON.stringify(DEFAULT_STATE.learn));
          if (!Array.isArray(state.learn.starredProblems)) state.learn.starredProblems = [];
          const k = makeStarKey(item.q, item.answer);
          const idx = state.learn.starredProblems.findIndex(x => x && makeStarKey(x.q, x.answer) === k);
          const isZh = state.lang === 'zh';
          if (idx >= 0) {
            state.learn.starredProblems.splice(idx, 1);
            showToast(isZh ? '已取消收藏' : '즐겨찾기에서 뺐어요');
          } else {
            state.learn.starredProblems.unshift({
              id: uid(),
              q: item.q || '',
              zh: item.zh || '',
              answer: item.answer || '',
              audio: item.audio || '',
              level: item.level || (isZh ? '收藏题' : '학습 문제'),
              savedAt: Date.now()
            });
            if (state.learn.starredProblems.length > 80) state.learn.starredProblems.length = 80;
            showToast(isZh ? '⭐ 已收藏到复习笔记！' : '⭐ 복습노트 [즐겨찾기]에 담았어요!');
          }
          saveState(true);
          window.__syncQuizStarBtnUi();
          if (typeof renderWrongNotes === 'function') renderWrongNotes();
        };

        const qStarBtn = document.getElementById('quizStarBtn');
        if (qStarBtn) {
          qStarBtn.addEventListener('click', () => {
            if (window.__currentQuizForStar) window.__toggleStarredProblem(window.__currentQuizForStar);
          });
        }
        document.body.addEventListener('click', (e) => {
          const sb = e.target && e.target.closest('.cw-star-prob-btn');
          if (!sb) return;
          e.stopPropagation();
          if (typeof window.__toggleStarredProblem === 'function') {
            window.__toggleStarredProblem({
              q: sb.getAttribute('data-q') || '',
              zh: sb.getAttribute('data-zh') || '',
              answer: sb.getAttribute('data-ans') || '',
              audio: sb.getAttribute('data-aud') || '',
              level: sb.getAttribute('data-lvl') || ''
            });
            if (typeof renderLearn === 'function') renderLearn();
            if (typeof renderChatLearnBook === 'function') renderChatLearnBook();
          }
        });
      })();


      window.__renderHeaderLiveHeart = function(status, modeOverride) {
        const el = document.getElementById('headerLiveDot');
        if (!el) return;
        const st = status || window.__lastLiveHeartStatus || 'ok';
        const mode = modeOverride || localStorage.getItem('chanwan_icon_style_v1') || (state.settings && state.settings.iconStyle) || 'pastel';
        const col = st === 'offline' ? '#f43f5e' : (st === 'reconnecting' ? '#f59e0b' : '#10b981');
        const soft = st === 'offline' ? '#fda4af' : (st === 'reconnecting' ? '#fde68a' : '#6ee7b7');
        const glow = st === 'offline' ? 'rgba(244,63,94,0.38)' : (st === 'reconnecting' ? 'rgba(245,158,11,0.38)' : 'rgba(16,185,129,0.42)');

        if (mode === 'emoji') {
          const em = st === 'offline' ? '❤️‍🩹' : (st === 'reconnecting' ? '💛' : '💚');
          el.innerHTML = `<span style="font-size:16px;line-height:1;
">${em}</span>`;
        } else if (mode === 'line') {
          el.innerHTML = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="${col}" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" style="
"><path d="M12 20.5s-7.5-4.6-9.2-9.2C1.6 8 3.6 5 6.8 5c1.9 0 3.5 1 5.2 2.9C13.7 6 15.3 5 17.2 5c3.2 0 5.2 3 4 6.3-1.7 4.6-9.2 9.2-9.2 9.2z"/></svg>`;
        } else if (mode === 'gold') {
          el.innerHTML = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" style="
"><defs><linearGradient id="cwLiveG" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#fde68a"/><stop offset="55%" stop-color="${col}"/><stop offset="100%" stop-color="#d97706"/></linearGradient></defs><path d="M12 20.5s-7.5-4.6-9.2-9.2C1.6 8 3.6 5 6.8 5c1.9 0 3.5 1 5.2 2.9C13.7 6 15.3 5 17.2 5c3.2 0 5.2 3 4 6.3-1.7 4.6-9.2 9.2-9.2 9.2z" fill="url(#cwLiveG)" stroke="#fef3c7" stroke-width="1.2"/></svg>`;
        } else {
          // pastel mode (default)
          el.innerHTML = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" style="
"><defs><linearGradient id="cwLiveP" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="${soft}"/><stop offset="100%" stop-color="${col}"/></linearGradient></defs><path d="M12 20.5s-7.5-4.6-9.2-9.2C1.6 8 3.6 5 6.8 5c1.9 0 3.5 1 5.2 2.9C13.7 6 15.3 5 17.2 5c3.2 0 5.2 3 4 6.3-1.7 4.6-9.2 9.2-9.2 9.2z" fill="url(#cwLiveP)" stroke="#ffffff" stroke-width="1.3"/><circle cx="7.5" cy="9" r="1.4" fill="rgba(255,255,255,0.65)"/></svg>`;
        }
      };


      (function initHideNotifPreviewToggle() {
        const syncUi = () => {
          const on = !!(state.settings && state.settings.hideNotifPreview);
          const isZh = state.lang === 'zh';
          const btn = document.getElementById('toggleHideNotifPrevBtn');
          const tEl = document.getElementById('hideNotifPrevTitle');
          const dEl = document.getElementById('hideNotifPrevDesc');
          if (tEl) tEl.textContent = isZh ? '🔒 隐藏通知消息预览' : '🔒 알림 메시지 미리보기 끄기';
          if (dEl) dEl.textContent = isZh ? '开启后横幅只显示“收到一条新消息 💌”，保护隐私。' : '켜두면 상단 배너에 내용 대신 "새 메시지가 왔습니다 💌"만 떠요.';
          if (btn) {
            btn.textContent = on ? (isZh ? '🔒 已开启' : '🔒 ON') : 'OFF';
            btn.className = `${on ? 'btn-royal' : 'btn-ghost'} px-3 py-1.5 rounded-full text-xs font-bold shrink-0 whitespace-nowrap`;
          }
        };
        window.__syncHideNotifPrevUi = syncUi;
        const btn = document.getElementById('toggleHideNotifPrevBtn');
        if (btn) {
          btn.addEventListener('click', () => {
            if (!state.settings) state.settings = {};
            state.settings.hideNotifPreview = !state.settings.hideNotifPreview;
            saveState(false);
            syncUi();
            if (typeof renderNotifications === 'function') renderNotifications();
            showToast(state.settings.hideNotifPreview
              ? (state.lang === 'zh' ? '🔒 已隐藏通知内容预览' : '🔒 알림 미리보기를 껐어요 ("새 메시지가 왔습니다")')
              : (state.lang === 'zh' ? '💬 已恢复显示翻译消息预览' : '💬 알림에 내 언어 번역 미리보기를 켰어요'));
          });
        }
        setTimeout(syncUi, 150);
      })();

      async function init() {

        // 1-Tap Force Live Update & Automatic Stale-Cache Buster (Prime 4 · v67)
        const RUNNING_SW_VER = 'chanwan-sw-prime4-v67';
        async function forcePurgeCacheAndUpdate(manualClick) {
          try {
            if (manualClick) {
              showToast(state.lang === 'zh' ? '🔄 正在清理旧缓存并拉取最新版本...' : '🔄 이전 캐시를 비우고 최신 버전을 불러오는 중...');
            }
            if ('serviceWorker' in navigator) {
              const regs = await navigator.serviceWorker.getRegistrations();
              await Promise.all(regs.map(r => r.unregister().catch(() => {})));
            }
            if (typeof caches !== 'undefined' && caches.keys) {
              const keys = await caches.keys();
              await Promise.all(keys.map(k => caches.delete(k).catch(() => {})));
            }
          } catch (_) {}
          const base = location.origin + location.pathname;
          location.replace(base + '?v=' + Date.now());
        }
        window.__forcePurgeCacheAndUpdate = forcePurgeCacheAndUpdate;
        document.getElementById('forceAppUpdateBtn')?.addEventListener('click', () => forcePurgeCacheAndUpdate(true));
        document.getElementById('notifBellBtn')?.addEventListener('click', () => {
          setTimeout(() => {
            const panel = document.getElementById('notifPanel');
            if (panel && !panel.classList.contains('hidden') && Array.isArray(state.notifications)) {
              let changed = false;
              state.notifications.forEach(n => { if (n && n.unread) { n.unread = false; changed = true; } });
              if (changed) { saveState(false); if (typeof renderNotifications === 'function') renderNotifications(); }
            }
          }, 120);
        });
        if (location.protocol.startsWith('http')) {
          setTimeout(async () => {
            try {
              const r = await fetch('./sw.js?_cb=' + Date.now(), { cache: 'no-store' });
              if (r && r.ok) {
                const txt = await r.text();
                const m = txt.match(/SW_VER\s*=\s*['"]([^'"]+)['"]/);
                if (m && m[1] && m[1] !== RUNNING_SW_VER && !sessionStorage.getItem('cw_auto_up_' + m[1])) {
                  sessionStorage.setItem('cw_auto_up_' + m[1], '1');
                  const act = document.activeElement;
                  const typing = !!(act && (act.tagName === 'INPUT' || act.tagName === 'TEXTAREA') && String(act.value || '').trim().length > 0);
                  if (!typing) await forcePurgeCacheAndUpdate(false);
                }
              }
            } catch (_) {}
          }, 2200);
        }

        if ('serviceWorker' in navigator && location.protocol.startsWith('http')) {
          const hadInitialController = !!navigator.serviceWorker.controller;
          navigator.serviceWorker.register('./sw.js', { updateViaCache: 'none' }).then((reg) => {
            try {
              reg.update().catch(() => {});
              document.addEventListener('visibilitychange', () => {
                if (!document.hidden && reg && typeof reg.update === 'function') reg.update().catch(() => {});
              });
            } catch (_) {}
          }).catch(() => {});
          let __swReloadHandled = false;
          navigator.serviceWorker.addEventListener('controllerchange', () => {
            if (__swReloadHandled || !hadInitialController) return;
            __swReloadHandled = true;
            const act = document.activeElement;
            const isTypingNow = !!(act && (act.tagName === 'INPUT' || act.tagName === 'TEXTAREA') && String(act.value || '').trim().length > 0);
            if (!isTypingNow) {
              setTimeout(() => { try { window.location.reload(); } catch (_) {} }, 120);
            } else {
              try { showToast(state.lang === 'zh' ? '✨ 新版本已就绪，重开应用即刻生效！' : '✨ 새 버전 준비 완료! 창을 새로 열면 바로 반영돼요'); } catch (_) {}
            }
          });
          navigator.serviceWorker.addEventListener('message', (ev) => {
            const d = ev && ev.data;
            if (d && d.type === 'NOTIF_CLICK') {
              try { window.focus(); } catch (_) {}
              try { clearAllAppBadgesAndOsNotifs(); } catch (_) {}
              if ((d.tab || 'translator') === 'translator' && typeof window.__openChatFromNotification === 'function') {
                window.__openChatFromNotification(d.title || '', d.body || '', Date.now());
              } else {
                try { navigateToRoute(d.tab || 'translator', d.sub || ''); } catch (_) {}
                if (typeof window.__pullFastChatDeltaNow === 'function') window.__pullFastChatDeltaNow(false);