              }
            }
          });
        }
        window.addEventListener('offline', () => {
          try { showToast(state.lang === 'zh' ? '📡 当前处于离线状态，恢复网络后会自动同步' : '📡 오프라인 상태예요 · 연결되면 자동으로 동기화돼요'); } catch (_) {}
        });
        window.addEventListener('online', () => {
          try { showToast(state.lang === 'zh' ? '🟢 网络已恢复，正在自动同步最新记录 ✨' : '🟢 네트워크가 다시 연결되어 자동 동기화 중이에요 ✨'); } catch (_) {}
        });
        // Strict whitelist cleanup: remove any edge-injected host badge/iframe outside our app elements
        (function hideHostFloatingBadge() {
          const ALLOWED_TAGS = new Set(["HEADER", "MAIN", "NAV", "SCRIPT", "STYLE", "LINK", "NOSCRIPT"]);
          const ALLOWED_IDS = new Set([
            "liveNotifBanner", "notifBackdrop", "notifPanel", "avatarFileInput", "cityModal", "customMoodModal",
            "patchNotesModal", "chatVaultModal", "pinLockOverlay", "photoLightboxModal",
            "confirmModal", "toastBox", "cwUniversalEmojiWrap", "voiceRecorderModal", "speechPracticeModal", "makerModeDrawer", "autoNightNoticeModal", "cwMsgContextBackdrop", "cwMsgContextMenu", "cwChatBgModal", "cwMicPermModal"
          ]);
          const sweep = () => {
            try {
              Array.from(document.documentElement.children).forEach(el => {
                if (el && el.tagName !== "HEAD" && el.tagName !== "BODY") {
                  el.style.setProperty("display", "none", "important");
                  el.remove();
                }
              });
              Array.from(document.body.children).forEach(el => {
                if (el && String(el.className || '').includes('cw-')) return;
                if (!el) return;
                if (ALLOWED_TAGS.has(el.tagName)) return;
                if (el.id && ALLOWED_IDS.has(el.id)) return;
                if (el.tagName === "AUDIO" || el.tagName === "CANVAS" || el.tagName === "A") return;
                el.style.setProperty("display", "none", "important");
                el.remove();
              });
            } catch (_) {}
          };
          sweep();
          [200, 700, 1500, 3000, 6000].forEach(ms => setTimeout(sweep, ms));
          try {
            let __sweepRaf = 0;
            const schedSweep = () => {
              if (__sweepRaf) return;
              __sweepRaf = requestAnimationFrame(() => { __sweepRaf = 0; sweep(); });
            };
            const mo = new MutationObserver(schedSweep);
            mo.observe(document.documentElement, { childList: true });
            mo.observe(document.body, { childList: true });
            setTimeout(() => { try { mo.disconnect(); } catch (_) {} }, 6500);
          } catch (_) {}
        })();

        // 0ms Instant Home Paint: render D-Day, moods, clocks, schedules & theme synchronously from localStorage BEFORE waiting on heavy IndexedDB vaults!
        try {
          const fastRaw = localStorage.getItem(STORAGE_CORE_KEY);
          if (fastRaw) {
            const fastCore = JSON.parse(fastRaw);
            if (fastCore && typeof fastCore === 'object') {
              state = mergeWithDefaults(fastCore, null);
              try { applyTheme(state.theme, true); applyFont(state.font, true); applyLanguage(state.lang, true); } catch (_) {}
              try { renderHome(); updateClocks(); } catch (_) {}
            }
          }
        } catch (_) {}

        await loadState();
        // Auto-recover any messages left in 'sending' state if app closed mid-send
        try {
          let hasStaleSending = false;
          const nowBoot = Date.now();
          (state.chat?.messages || []).forEach(m => {
            if (m && m.deliveryStatus === 'sending' && (!m.ts || (nowBoot - Number(m.ts)) > 15000)) {
              m.deliveryStatus = 'failed';
              hasStaleSending = true;
            }
          });
          if (hasStaleSending) setTimeout(() => { if (typeof window.__pushCloudSyncDelta === 'function') window.__pushCloudSyncDelta(extractLightweightCore(state)); }, 2500);
        } catch (_) {}
        if (state.profile) {
          let cleanedMood = false;
          if (String(state.profile.suwanMood || '').includes('누워서 징찬 생각중')) { state.profile.suwanMood = '💜 보고 싶어 · 好想你'; cleanedMood = true; }
          if (String(state.profile.jingchanMood || '').includes('누워서 징찬 생각중')) { state.profile.jingchanMood = '🌸 기분 최고 · 心情超好'; cleanedMood = true; }
          try {
            const mg = JSON.parse(localStorage.getItem('cw_my_mood_guard_v1') || 'null');
            if (mg && mg.role && mg.mood && Number(mg.ts || 0) > Number(state.profile[mg.role + 'MoodUpdatedAt'] || 0)) {
              state.profile[mg.role + 'Mood'] = mg.mood;
              state.profile[mg.role + 'MoodUpdatedAt'] = Number(mg.ts);
              cleanedMood = true;
            }
          } catch (_) {}
          if (cleanedMood) saveState(true);
        }
        bindEvents();
        bindPlus16Events();
        bindPlus18Events();
        if (state.chat && state.chat.toneMode && typeof window.__syncToneButtonsUi === 'function') {
          window.__syncToneButtonsUi(state.chat.toneMode);
        }
        try { renderAll(); } catch (e) { console.error('renderAll err:', e); }
        // Defer secondary off-screen tabs so PWA opens instantly with zero startup freeze!
        setTimeout(() => {
          try {
            renderBalanceGame();
            renderDateStampMap();
            renderTmiBook();
            renderComplimentJar();
            renderCoupleFortune();
            renderFoodRouletteMeta();
            renderCoupleQuizzes();
            if (typeof renderChatLearnBook === 'function') renderChatLearnBook();
            if (typeof window.syncAllTabIconsToStyle === 'function') window.syncAllTabIconsToStyle();
          } catch (_) {}
        }, 120);
        updateClocks();
        setInterval(() => { if (document.hidden) return; const hp = document.getElementById('tab-home'); if (hp && hp.classList.contains('active')) updateClocks(); }, 1000);
        refreshBothCityWeathers();
      }

  
      /* ==================== PRIME 2: 3 REAL-TIME 2-PLAYER COUPLE GAMES ==================== */
      (function initPrime2Games() {
        // ---------- 1) Couple Drawing Quiz (Catchmind) ----------
        const canvas = document.getElementById('drawQuizCanvas');
        const ctx = canvas ? canvas.getContext('2d') : null;
        let brushColor = '#4c1d95', drawing = false, drawStrokes = [], curStroke = [];
        function redrawCanvas() {
          if (!ctx || !canvas) return;
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(0, 0, canvas.width, canvas.height);
          drawStrokes.forEach(st => {
            if (!st.pts || st.pts.length < 1) return;
            ctx.beginPath();
            ctx.strokeStyle = st.color;
            ctx.lineWidth = st.color === '#ffffff' ? 14 : 4;
            ctx.lineCap = 'round';
            ctx.lineJoin = 'round';
            ctx.moveTo(st.pts[0].x, st.pts[0].y);
            for (let i = 1; i < st.pts.length; i++) ctx.lineTo(st.pts[i].x, st.pts[i].y);
            ctx.stroke();
          });
        }
        if (canvas && ctx) {
          redrawCanvas();
          const getPt = (e) => {
            const rect = canvas.getBoundingClientRect();
            const srcEv = e.touches && e.touches[0] ? e.touches[0] : e;
            return {
              x: ((srcEv.clientX - rect.left) / rect.width) * canvas.width,
              y: ((srcEv.clientY - rect.top) / rect.height) * canvas.height
            };
          };
          const startDraw = (e) => {
            e.preventDefault();
            drawing = true;
            curStroke = { color: brushColor, pts: [getPt(e)] };
            drawStrokes.push(curStroke);
            redrawCanvas();
          };
          const moveDraw = (e) => {
            if (!drawing) return;
            e.preventDefault();
            curStroke.pts.push(getPt(e));
            redrawCanvas();
          };
          const endDraw = () => { drawing = false; };
          canvas.addEventListener('mousedown', startDraw);
          canvas.addEventListener('mousemove', moveDraw);
          window.addEventListener('mouseup', endDraw);
          canvas.addEventListener('touchstart', startDraw, { passive: false });
          canvas.addEventListener('touchmove', moveDraw, { passive: false });
          canvas.addEventListener('touchend', endDraw, { passive: true });
        }
        document.querySelectorAll('.draw-color-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            brushColor = btn.getAttribute('data-color') || '#4c1d95';
            document.querySelectorAll('.draw-color-btn').forEach(b => b.classList.toggle('border-purple-500', b === btn));
          });
        });
        document.getElementById('drawUndoBtn')?.addEventListener('click', () => { drawStrokes.pop(); redrawCanvas(); });
        document.getElementById('drawClearBtn')?.addEventListener('click', () => { drawStrokes = []; redrawCanvas(); });

        document.getElementById('drawSendQuizBtn')?.addEventListener('click', async () => {
          const isZh = state.lang === 'zh';
          const ansInp = document.getElementById('drawAnswerInput');
          const answer = (ansInp && ansInp.value || '').trim();
          if (!drawStrokes.length) { showToast(isZh ? '请先画点什么再出题 🎨' : '먼저 그림을 그려 주세요 🎨'); return; }
          if (!answer) { showToast(isZh ? '请输入这幅画的答案 ✏️' : '그림의 정답을 입력해 주세요 ✏️'); return; }
          const dataUrl = canvas.toDataURL('image/jpeg', 0.62);
          let answerTrans = '';
          try {
            const res = await geminiTranslate(answer, 'casual');
            if (res && res.translated) answerTrans = res.translated;
          } catch (_) {}
          const myR = state.myRole || 'suwan';
          if (!Array.isArray(state.drawQuizzes)) state.drawQuizzes = [];
          state.drawQuizzes.unshift({
            id: 'dq_' + Date.now(),
            authorRole: myR,
            imageUrl: dataUrl,
            answer,
            answerZh: /[\u4e00-\u9fff]/.test(answer) ? answer : (answerTrans || answer),
            answerKo: /[가-힣]/.test(answer) ? answer : (answerTrans || answer),
            ts: Date.now(),
            solvedAt: 0,
            solvedBy: '',
            guessText: ''
          });
          if (state.drawQuizzes.length > 25) state.drawQuizzes.length = 25;
          drawStrokes = [];
          redrawCanvas();
          if (ansInp) ansInp.value = '';
          saveState(true);
          renderDrawQuizzes();
          showToast(isZh ? '🎨 画作已发送！对方将收到猜画提醒' : '🎨 그림 퀴즈를 보냈어요! 상대방에게 알림이 가요');
        });

        window.renderDrawQuizzes = function renderDrawQuizzes() {
          const isZh = state.lang === 'zh';
          const tEl = document.getElementById('drawQuizTitle');
          const dEl = document.getElementById('drawQuizDesc');
          const sBtn = document.getElementById('drawSendQuizBtn');
          const inp = document.getElementById('drawAnswerInput');
          if (tEl) tEl.textContent = isZh ? '🎨 情侣你画我猜' : '🎨 커플 그림 퀴즈 (캐치마인드)';
          if (dEl) dEl.textContent = isZh ? '用手指画一幅画发给对方，对方会收到提醒并马上来猜答案！' : '손가락으로 그림을 그려 문제를 내면 상대방 폰에 알림이 가고 맞힐 수 있어요!';
          if (sBtn) sBtn.textContent = isZh ? '🎨 发送出题' : '🎨 출제하기';
          if (inp) inp.placeholder = isZh ? '输入答案（例：猫咪、炒年糕、爱你...）' : '정답 입력 (예: 고양이, 떡볶이, 사랑해...)';

          const listEl = document.getElementById('drawQuizList');
          if (!listEl) return;
          const items = Array.isArray(state.drawQuizzes) ? state.drawQuizzes : [];
          if (!items.length) {
            listEl.innerHTML = `<div class="royal-card rounded-2xl p-6 text-center text-xs text-mut">${isZh ? '还没有你画我猜记录，画第一幅考考对方吧 🎨' : '아직 그림 퀴즈가 없어요. 첫 그림을 그려 상대방에게 내보세요 🎨'}</div>`;
            return;
          }
          const myR = state.myRole || 'suwan';
          listEl.innerHTML = items.map(q => {
            const isMine = q.authorRole === myR;
            const authorNm = q.authorRole === 'suwan' ? (isZh ? '秀完画的' : '수완의 그림') : (isZh ? '靖灿画的' : '징찬의 그림');
            const dispAns = isZh ? (q.answerZh || q.answer) : (q.answerKo || q.answer);
            return `<div class="royal-card rounded-3xl p-3.5 space-y-2.5">
              <div class="flex items-center justify-between gap-2 text-xs">
                <span class="font-bold text-gold">🎨 ${escapeHtml(authorNm)}</span>
                <div class="flex items-center gap-1.5">
                  ${q.solvedAt ? `<span class="px-2 py-0.5 rounded-full text-[10px] font-bold" style="background:rgba(16,185,129,0.14);color:#059669;">✅ ${isZh ? '已猜对' : '정답 완료'}</span>` : `<span class="px-2 py-0.5 rounded-full text-[10px] font-semibold" style="background:var(--accent-royal-soft);color:var(--accent-royal);">❓ ${isZh ? '等待猜谜' : '정답 대기 중'}</span>`}
                  <button type="button" class="del-dq-btn text-mut hover:text-rose-500 text-xs px-1" data-id="${escapeHtml(q.id)}">🗑️</button>
                </div>
              </div>
              <img src="${q.imageUrl}" alt="drawing" class="w-full rounded-2xl border bg-white object-contain max-h-56" style="border-color: var(--border-subtle);" />
              ${q.solvedAt || isMine
                ? `<div class="text-xs font-semibold px-3 py-2 rounded-xl" style="background: var(--surface-2);">${isZh ? '答案：' : '정답: '} <span class="text-gold">${escapeHtml(dispAns)}</span>${q.answerKo && q.answerZh && q.answerKo !== q.answerZh ? ` <span class="text-mut">(${escapeHtml(isZh ? q.answerKo : q.answerZh)})</span>` : ''}</div>`
                : `<div class="flex items-center gap-1.5"><input type="text" class="dq-guess-inp royal-input flex-1 min-w-0 rounded-xl px-3 py-1.5 text-xs" data-id="${escapeHtml(q.id)}" placeholder="${isZh ? '输入你猜的答案...' : '정답을 입력해 보세요...'}" /><button type="button" class="dq-guess-btn btn-royal px-3 py-1.5 rounded-xl text-xs font-bold shrink-0" data-id="${escapeHtml(q.id)}">${isZh ? '提交' : '정답 확인'}</button><button type="button" class="dq-reveal-btn btn-ghost px-2.5 py-1.5 rounded-xl text-xs shrink-0" data-id="${escapeHtml(q.id)}">👀</button></div>`}
            </div>`;
          }).join('');
          listEl.querySelectorAll('.dq-guess-btn').forEach(btn => {
            btn.addEventListener('click', () => {
              const id = btn.getAttribute('data-id');
              const q = (state.drawQuizzes || []).find(x => x && x.id === id);
              const inpG = listEl.querySelector(`.dq-guess-inp[data-id="${id}"]`);
              const guess = (inpG && inpG.value || '').trim().toLowerCase().replace(/\s+/g, '');
              if (!q || !guess) return;
              const cands = [q.answer, q.answerKo, q.answerZh].filter(Boolean).map(s => String(s).toLowerCase().replace(/\s+/g, ''));
              const ok = cands.some(c => c === guess || (guess.length >= 2 && (c.includes(guess) || guess.includes(c))));
              if (ok) {
                q.solvedAt = Date.now();
                q.solvedBy = state.myRole || 'suwan';
                q.guessText = inpG.value.trim();
                if (typeof addLavenderBonusXp === 'function') addLavenderBonusXp('dq_' + id, 15);
                saveState(true);
                renderDrawQuizzes();
                showToast(isZh ? '🎉 猜对啦！太有默契了 (+15 XP)' : '🎉 정답이에요! 텔레파시 대박 (+15 XP)');
              } else {
                showToast(isZh ? '😅 差一点！再猜猜看吧' : '😅 아쉬워요! 다시 한 번 맞혀 보세요');
              }
            });
          });
          listEl.querySelectorAll('.dq-reveal-btn').forEach(btn => {
            btn.addEventListener('click', () => {
              const id = btn.getAttribute('data-id');
              const q = (state.drawQuizzes || []).find(x => x && x.id === id);
              if (!q) return;
              q.solvedAt = Date.now();
              q.solvedBy = state.myRole || 'suwan';
              saveState(true);
              renderDrawQuizzes();
            });
          });
          listEl.querySelectorAll('.del-dq-btn').forEach(btn => {
            btn.addEventListener('click', () => {
              const id = btn.getAttribute('data-id');
              openConfirm(isZh ? '删除画作' : '그림 퀴즈 삭제', isZh ? '确定要删除这幅画作吗？' : '이 그림 퀴즈를 삭제할까요?', () => {
                state.drawQuizzes = (state.drawQuizzes || []).filter(x => x && x.id !== id);
                saveState(true);
                renderDrawQuizzes();
              });
            });
          });
          if (typeof window.syncAllTabIconsToStyle === 'function') window.syncAllTabIconsToStyle(null, document.getElementById('diary-sub-drawquiz'));
        };

        // ---------- 2) Real-Time Rock-Paper-Scissors + Couple Wish Roulette ----------
        const RPS_WISHES = [
          { ko: '🎙️ 오늘 10초 애교 음성 메시지 보내기', zh: '🎙️ 今天发一条10秒撒娇语音' },
          { ko: '📸 지금 바로 귀여운 셀카 1장 보내기', zh: '📸 马上拍一张可爱自拍发过来' },
          { ko: '☀️ 내일 아침 다정한 모닝콜 해주기', zh: '☀️ 明早温柔叫起床服务' },
          { ko: '☕ 다음 만남 때 맛있는 커피 쏘기', zh: '☕ 下次见面请喝好喝的咖啡' },
          { ko: '💌 서로 좋은 점 3가지 진심으로 말해주기', zh: '💌 真诚说出对方的3个优点' },
          { ko: '💆 다음 데이트 때 10분 어깨 안마권', zh: '💆 下次约会享受10分钟肩颈按摩' },
          { ko: '🍜 다음 만남 메뉴 선택권 1회 획득', zh: '🍜 获得下次约会点菜决定权1次' },
          { ko: '💜 오늘 밤 잠들기 전 "사랑해" 녹음 보내기', zh: '💜 今晚睡前录一句「我爱你」' }
        ];
        const RPS_EMOJI = { rock: '✊', scissors: '✌️', paper: '✋' };
        function rpsWinner(s, j) {
          if (!s || !j) return '';
          if (s === j) return 'draw';
          if ((s === 'rock' && j === 'scissors') || (s === 'scissors' && j === 'paper') || (s === 'paper' && j === 'rock')) return 'suwan';
          return 'jingchan';
        }
        window.renderRpsGame = function renderRpsGame() {
          const isZh = state.lang === 'zh';
          if (!state.rpsGame) state.rpsGame = { round: 1, moves: { suwan: '', jingchan: '' }, score: { suwan: 0, jingchan: 0 }, wishKo: '', wishZh: '', updatedAt: 0 };
          const g = state.rpsGame;
          const myR = state.myRole || 'suwan';
          const pR = myR === 'suwan' ? 'jingchan' : 'suwan';
          const tEl = document.getElementById('rpsTitle');
          const dEl = document.getElementById('rpsDesc');
          const scEl = document.getElementById('rpsScoreBadge');
          const arena = document.getElementById('rpsArenaBox');
          const nextBtn = document.getElementById('rpsNextRoundBtn');
          if (tEl) tEl.textContent = isZh ? '✊✌️✋ 实时猜拳 & 情侣许愿' : '✊✌️✋ 실시간 가위바위보 & 소원권';
          if (dEl) dEl.textContent = isZh ? '各自秘密出拳，两人都选完瞬间揭晓胜负，赢家获得随机情侣许愿权！' : '각자 비밀로 고르면 둘 다 낸 순간 공개되고, 이긴 사람이 랜덤 커플 소원을 얻어요!';
          if (scEl) scEl.textContent = `${isZh ? '秀完' : '수완'} ${g.score?.suwan || 0} : ${g.score?.jingchan || 0} ${isZh ? '靖灿' : '징찬'}`;
          const myMove = g.moves?.[myR] || '';
          const pMove = g.moves?.[pR] || '';
          const bothDone = !!(myMove && pMove);
          if (nextBtn) {
            nextBtn.classList.toggle('hidden', !bothDone);
            nextBtn.textContent = isZh ? '🔄 开始下一局' : '🔄 다음 판 시작';
          }
          if (arena) {
            if (bothDone) {
              const w = rpsWinner(g.moves.suwan, g.moves.jingchan);
              const resTxt = w === 'draw'
                ? (isZh ? '🤝 平局！再来一局！' : '🤝 비겼어요! 한 판 더!')
                : (w === myR ? (isZh ? '🎉 你赢啦！获得情侣许愿权！' : '🎉 이겼어요! 커플 소원권 획득!') : (isZh ? '😆 对方赢啦！快实现TA的愿望吧' : '😆 상대방 승리! 소원을 들어주세요'));
              const wishTxt = isZh ? (g.wishZh || g.wishKo) : (g.wishKo || g.wishZh);
              arena.innerHTML = `
                <div class="text-[11px] text-mut font-semibold">${isZh ? `第 ${g.round} 局结果` : `${g.round}라운드 결과`}</div>
                <div class="flex items-center justify-center gap-6 py-1">
                  <div class="text-center"><div class="text-3xl cw-keep-native-emoji">${RPS_EMOJI[g.moves.suwan]}</div><div class="text-[11px] font-bold mt-1">${isZh ? '秀完' : '수완'}</div></div>
                  <div class="text-sm font-bold text-gold">VS</div>
                  <div class="text-center"><div class="text-3xl cw-keep-native-emoji">${RPS_EMOJI[g.moves.jingchan]}</div><div class="text-[11px] font-bold mt-1">${isZh ? '靖灿' : '징찬'}</div></div>
                </div>
                <div class="text-sm font-bold text-gold">${resTxt}</div>
                ${w !== 'draw' && wishTxt ? `<div class="rounded-xl px-3 py-2 text-xs font-semibold" style="background: var(--accent-royal-soft); color: var(--accent-royal);">${escapeHtml(wishTxt)}</div>` : ''}`;
            } else {
              arena.innerHTML = `
                <div class="text-[11px] text-mut font-semibold">${isZh ? `第 ${g.round} 局进行中` : `${g.round}라운드 진행 중`}</div>
                <div class="flex items-center justify-center gap-6 py-1">
                  <div class="text-center"><div class="text-2xl cw-keep-native-emoji">${g.moves?.suwan ? (myR === 'suwan' ? RPS_EMOJI[g.moves.suwan] : '🔒') : '❔'}</div><div class="text-[11px] font-bold mt-1">${isZh ? '秀完' : '수완'}</div></div>
                  <div class="text-xs font-bold text-mut">VS</div>
                  <div class="text-center"><div class="text-2xl cw-keep-native-emoji">${g.moves?.jingchan ? (myR === 'jingchan' ? RPS_EMOJI[g.moves.jingchan] : '🔒') : '❔'}</div><div class="text-[11px] font-bold mt-1">${isZh ? '靖灿' : '징찬'}</div></div>
                </div>
                <div class="text-xs font-semibold text-sec">${myMove ? (isZh ? '你已出拳！等待对方出拳中...' : '선택 완료! 상대방이 낼 때까지 비밀 유지 중...') : (pMove ? (isZh ? '对方已出拳！快选你的吧 👇' : '상대방이 먼저 냈어요! 아래에서 골라주세요 👇') : (isZh ? '在下面选择石头·剪刀·布 👇' : '아래에서 가위·바위·보를 선택해 주세요 👇'))}</div>`;
            }
          }
          document.querySelectorAll('.rps-pick-btn').forEach(btn => {
            const mv = btn.getAttribute('data-move');
            btn.style.borderColor = (myMove === mv) ? 'var(--accent-royal)' : '';
            btn.style.background = (myMove === mv) ? 'var(--accent-royal-soft)' : '';
          });
        };
        document.querySelectorAll('.rps-pick-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            if (!state.rpsGame) state.rpsGame = { round: 1, moves: { suwan: '', jingchan: '' }, score: { suwan: 0, jingchan: 0 }, wishKo: '', wishZh: '', updatedAt: 0 };
            const g = state.rpsGame;
            const myR = state.myRole || 'suwan';
            if (g.moves?.suwan && g.moves?.jingchan) return;
            if (!g.moves) g.moves = { suwan: '', jingchan: '' };
            g.moves[myR] = btn.getAttribute('data-move');
            g.updatedAt = Date.now();
            if (g.moves.suwan && g.moves.jingchan) {
              const w = rpsWinner(g.moves.suwan, g.moves.jingchan);
              if (w === 'suwan' || w === 'jingchan') {
                if (!g.score) g.score = { suwan: 0, jingchan: 0 };
                g.score[w] = (g.score[w] || 0) + 1;
                const pick = RPS_WISHES[Math.floor(Math.random() * RPS_WISHES.length)];
                g.wishKo = pick.ko;
                g.wishZh = pick.zh;
              }
            }
            saveState(true);
            renderRpsGame();
          });
        });
        document.getElementById('rpsNextRoundBtn')?.addEventListener('click', () => {
          if (!state.rpsGame) return;
          state.rpsGame.round = (state.rpsGame.round || 1) + 1;
          state.rpsGame.moves = { suwan: '', jingchan: '' };
          state.rpsGame.wishKo = '';
          state.rpsGame.wishZh = '';
          state.rpsGame.updatedAt = Date.now();
          saveState(true);
          renderRpsGame();
        });

        // ---------- 3) Couple Truth or Dare Cards ----------
        const TD_CARDS = [
          { type: 'truth', ko: '나한테 가장 설렜던 순간은 언제야?', zh: '你对我最心动的一瞬间是什么时候？' },
          { type: 'truth', ko: '내 말투나 행동 중에 제일 귀여운 점 하나만 꼽아줘!', zh: '说出我说话或行为中最可爱的一个小习惯！' },
          { type: 'truth', ko: '다음에 만나면 제일 먼저 같이 하고 싶은 일은?', zh: '下次见面你最想和我一起做的第一件事是什么？' },
          { type: 'truth', ko: '나랑 처음 만났을 때 솔직한 첫인상은 어땠어?', zh: '老实说，我们第一次见面时你对我的第一印象是什么？' },
          { type: 'truth', ko: '요즘 내 생각 제일 많이 나는 시간대는 언제야?', zh: '最近一天里你最想我的是哪个时间段？' },
          { type: 'truth', ko: '둘이 꼭 같이 가보고 싶은 여행지가 있다면?', zh: '如果只能选一个地方，你最想和我去哪里旅行？' },
          { type: 'truth', ko: '내가 해줬던 말 중에 아직도 기억나는 말은?', zh: '我说过的哪一句话你到现在还一直记着？' },
          { type: 'truth', ko: '나 몰래 서운했거나 고마웠던 적이 있어?', zh: '有没有哪次你偷偷觉得委屈或特别感动的时候？' },
          { type: 'dare', ko: '지금 바로 메신저로 애교 가득한 음성 메시지 1개 보내기 🎙️', zh: '现在马上在聊天室发一条甜甜的撒娇语音 🎙️' },
          { type: 'dare', ko: '지금 내 눈앞 풍경이나 셀카 1장 찍어서 보내기 📸', zh: '马上拍一张眼前的风景或自拍发给对方 📸' },
          { type: 'dare', ko: '상대방 이름으로 2행시(또는 칭찬 3줄) 지어주기 💌', zh: '用对方的名字夸奖TA三句超级甜的话 💌' },
          { type: 'dare', ko: '홈 화면에서 1.5초 포옹 버튼 3번 연속 보내기 🫂', zh: '去首页连续发送3次1.5秒暖心抱抱 🫂' },
          { type: 'dare', ko: '상대방 언어로 "너무 보고 싶어 사랑해" 직접 말해서 녹음하기 💜', zh: '用对方的母语录一句「好想你，我爱你」发过去 💜' },
          { type: 'dare', ko: '칭찬 유리병에 오늘의 달달한 쪽지 1개 몰래 넣어두기 ✨', zh: '去夸夸玻璃瓶偷偷放一张今天的甜蜜纸条 ✨' }
        ];
        function drawTdCard(kind) {
          const pool = TD_CARDS.filter(c => c.type === kind);
          const pick = pool[Math.floor(Math.random() * pool.length)];
          if (!state.truthDare) state.truthDare = { activeCard: null, history: [], updatedAt: 0 };
          state.truthDare.activeCard = { ...pick, pickedBy: state.myRole || 'suwan', id: 'tdc_' + Date.now() };
          state.truthDare.updatedAt = Date.now();
          saveState(true);
          renderTruthDare();
        }
        document.getElementById('tdDrawTruthBtn')?.addEventListener('click', () => drawTdCard('truth'));
        document.getElementById('tdDrawDareBtn')?.addEventListener('click', () => drawTdCard('dare'));
        document.getElementById('tdSubmitAnsBtn')?.addEventListener('click', async () => {
          const isZh = state.lang === 'zh';
          const inp = document.getElementById('tdAnswerInput');
          const txt = (inp && inp.value || '').trim();
          if (!txt) return;
          if (!state.truthDare || !state.truthDare.activeCard) {
            showToast(isZh ? '请先抽一张真心话或大冒险卡片 🃏' : '먼저 진실이나 도전 카드를 뽑아 주세요 🃏');
            return;
          }
          let tr = '';
          try { const r = await geminiTranslate(txt, 'lover'); if (r && r.translated) tr = r.translated; } catch (_) {}
          if (!Array.isArray(state.truthDare.history)) state.truthDare.history = [];
          state.truthDare.history.unshift({
            id: 'tdh_' + Date.now(),
            authorRole: state.myRole || 'suwan',
            cardType: state.truthDare.activeCard.type,
            cardKo: state.truthDare.activeCard.ko,
            cardZh: state.truthDare.activeCard.zh,
            text: txt,
            translated: tr,
            time: getKstTimeShort()
          });
          if (state.truthDare.history.length > 40) state.truthDare.history.length = 40;
          if (inp) inp.value = '';
          saveState(true);
          renderTruthDare();
          showToast(isZh ? '🃏 回答已保存并通知对方啦！' : '🃏 답변이 등록되어 상대방에게 알림이 갔어요!');
        });
        window.renderTruthDare = function renderTruthDare() {
          const isZh = state.lang === 'zh';
          const tEl = document.getElementById('tdTitle');
          const dEl = document.getElementById('tdDesc');
          const bT = document.getElementById('tdDrawTruthBtn');
          const bD = document.getElementById('tdDrawDareBtn');
          const inp = document.getElementById('tdAnswerInput');
          const sub = document.getElementById('tdSubmitAnsBtn');
          if (tEl) tEl.textContent = isZh ? '🃏 情侣真心话大冒险' : '🃏 커플 진실 혹은 도전';
          if (dEl) dEl.textContent = isZh ? '抽取甜蜜真心话或可爱大冒险卡片，一起回答互动吧！' : '달달한 진실 질문이나 귀여운 미션 카드를 뽑아 서로 답하고 공유해 보세요!';
          if (bT) bT.textContent = isZh ? '💜 抽真心话' : '💜 진실 뽑기';
          if (bD) bD.textContent = isZh ? '🔥 抽大冒险' : '🔥 도전 뽑기';
          if (inp) inp.placeholder = isZh ? '写下你的回答或完成打卡...' : '내 답변이나 미션 완료 한마디 적기...';
          if (sub) sub.textContent = isZh ? '💌 提交' : '💌 등록';

          const box = document.getElementById('tdActiveCardBox');
          const histEl = document.getElementById('tdHistoryList');
          const td = state.truthDare || { activeCard: null, history: [] };
          if (box) {
            if (!td.activeCard) {
              box.innerHTML = `<div class="text-center text-xs text-mut py-3">${isZh ? '点上方按钮抽一张今天的心动卡片吧 🃏' : '위 버튼을 눌러 오늘의 진실·도전 카드를 뽑아 보세요 🃏'}</div>`;
            } else {
              const c = td.activeCard;
              const isDare = c.type === 'dare';
              box.innerHTML = `
                <div class="flex items-center justify-between gap-2">
                  <span class="px-2.5 py-0.5 rounded-full text-[10.5px] font-bold" style="background:${isDare ? 'rgba(244,63,94,0.14)' : 'var(--accent-royal-soft)'}; color:${isDare ? '#e11d48' : 'var(--accent-royal)'};">${isDare ? (isZh ? '🔥 大冒险' : '🔥 도전 미션') : (isZh ? '💜 真心话' : '💜 진실 질문')}</span>
                  <span class="text-[10px] text-mut">${c.pickedBy === 'suwan' ? (isZh ? '秀完抽的' : '수완이 뽑음') : (isZh ? '靖灿抽的' : '징찬이 뽑음')}</span>
                </div>
                <div class="text-sm font-bold leading-relaxed">${escapeHtml(isZh ? c.zh : c.ko)}</div>
                <div class="text-xs text-sec">${escapeHtml(isZh ? c.ko : c.zh)}</div>`;
            }
          }
          if (histEl) {
            const hList = Array.isArray(td.history) ? td.history : [];
            histEl.innerHTML = hList.map(item => {
              const who = item.authorRole === 'suwan' ? (isZh ? '秀完' : '수완') : (isZh ? '靖灿' : '징찬');
              return `<div class="royal-card rounded-2xl p-3 space-y-1">
                <div class="flex items-center justify-between text-[10.5px] text-mut">
                  <span class="font-bold text-gold">${item.cardType === 'dare' ? '🔥' : '💜'} ${escapeHtml(who)} · ${escapeHtml(item.time || '')}</span>
                  <div class="flex items-center gap-1.5 shrink-0"><button type="button" class="cw-retrans-item-btn btn-ghost px-2 py-0.5 rounded-full text-[10px] font-semibold whitespace-nowrap" data-rtype="truthdare" data-rid="${escapeHtml(item.id)}">🔄 ${isZh ? '重译' : '재번역'}</button><button type="button" class="cw-share-chat-item-btn btn-ghost px-2 py-0.5 rounded-full text-[10px] font-semibold whitespace-nowrap" data-stype="truthdare" data-sid="${escapeHtml(item.id)}">💬 ${isZh ? '发聊天' : '톡 공유'}</button><button type="button" class="del-td-btn hover:text-rose-500 px-1" data-id="${escapeHtml(item.id)}">🗑️</button></div>
                </div>
                <div class="text-[11px] text-mut">${escapeHtml(isZh ? (item.cardZh || item.cardKo) : (item.cardKo || item.cardZh))}</div>
                <div class="text-xs font-semibold">${escapeHtml(item.text)}</div>
                ${item.translated && item.translated !== item.text ? `<div class="text-[11.5px] text-gold">${escapeHtml(item.translated)}</div>` : ''}
                ${renderSpaceRepliesHtml('truthdare', item.id, item.replies)}
              </div>`;
            }).join('');
            histEl.querySelectorAll('.del-td-btn').forEach(btn => {
              btn.addEventListener('click', () => {
                const id = btn.getAttribute('data-id');
                openConfirm(isZh ? '删除记录' : '진실·도전 기록 삭제', isZh ? '确定要删除这条回答吗？' : '이 기록을 삭제할까요?', () => {
                  state.truthDare.history = (state.truthDare.history || []).filter(x => x && x.id !== id);
                  saveState(true);
                  renderTruthDare();
                });
              });
            });
          }
          if (typeof window.syncAllTabIconsToStyle === 'function') window.syncAllTabIconsToStyle(null, document.getElementById('diary-sub-truthdare'));
        };
      })();

    
      /* ==================== MESSENGER 3 ROOM THEMES (DEFAULT=APP THEME · WECHAT & KAKAO AUTO LIGHT/DARK) ==================== */
      (function initChatRoomThemes() {
        const KEY_RT = 'cw_chat_room_theme_v1';
        const btn = document.getElementById('chatRoomThemeBtn');
        const bar = document.getElementById('chatRoomThemeBar');
        const dot = document.getElementById('chatRoomThemeDot');
        const titleEl = document.getElementById('chatRoomThemeTitle');
        const listEl = document.getElementById('chatMessagesList');
        const msgBox = document.getElementById('trans-sub-messenger');

        const ROOM_THEMES = {
          default: {
            dot: 'var(--accent-royal)',
            ko: '기본 테마 (앱 테마 연동)', zh: '默认主题（跟随应用主题）',
            shortKo: '기본', shortZh: '默认',
            followAppTheme: true
          },
          wechat: {
            dot: '#3eb575',
            ko: '위챗 테마', zh: '微信主题',
            shortKo: '위챗', shortZh: '微信',
            light: {
              roomBg: '#ededed',
              mineBg: '#95ec69',
              mineText: '#111827', mineMuted: '#1f4d1a', minePill: 'rgba(0,0,0,0.08)', mineBorder: 'rgba(0,0,0,0.06)',
              ptBg: '#ffffff', ptText: '#111827', ptMuted: '#4b5563', ptBorder: 'rgba(0,0,0,0.06)'
            },
            dark: {
              roomBg: '#111111',
              mineBg: '#3eb575',
              mineText: '#08140d', mineMuted: '#103320', minePill: 'rgba(0,0,0,0.14)', mineBorder: 'rgba(0,0,0,0.12)',
              ptBg: '#2c2c2c', ptText: '#f3f4f6', ptMuted: '#b8bcc4', ptBorder: 'rgba(255,255,255,0.08)'
            }
          },
          kakao: {
            dot: '#fae100',
            ko: '카카오톡 테마', zh: 'Kakao主题',
            shortKo: '카카오톡', shortZh: 'Kakao',
            light: {
              roomBg: '#bacee0',
              mineBg: '#fee500',
              mineText: '#191919', mineMuted: '#4a4000', minePill: 'rgba(0,0,0,0.08)', mineBorder: 'rgba(0,0,0,0.07)',
              ptBg: '#ffffff', ptText: '#191919', ptMuted: '#525252', ptBorder: 'rgba(0,0,0,0.06)'
            },
            dark: {
              roomBg: '#121212',
              mineBg: '#fae100',
              mineText: '#191919', mineMuted: '#4a4000', minePill: 'rgba(0,0,0,0.11)', mineBorder: 'rgba(0,0,0,0.12)',
              ptBg: '#2b2b2b', ptText: '#f5f5f5', ptMuted: '#b5b5b5', ptBorder: 'rgba(255,255,255,0.08)'
            }
          }
        };

        function applyChatRoomTheme(id, silent) {
          const cleanId = ROOM_THEMES[id] ? id : 'default';
          const def = ROOM_THEMES[cleanId];
          const root = document.documentElement.style;
          const appTheme = document.documentElement.getAttribute('data-theme') || (state && state.theme) || 'pastel-royal';
          const isAppDark = DARK_THEME_IDS.has(appTheme);

          if (def.followAppTheme) {
            ['--chat-room-bg', '--bubble-suwan', '--bubble-mine-text', '--bubble-mine-muted', '--bubble-mine-pill-bg', '--bubble-mine-border', '--bubble-jingchan', '--bubble-jingchan-border'].forEach(v => root.removeProperty(v));
            root.setProperty('--bubble-jingchan-text', isAppDark ? 'var(--text-primary)' : 'var(--text-primary)');
            root.setProperty('--bubble-jingchan-muted', isAppDark ? 'var(--text-secondary)' : 'var(--text-secondary)');
            if (listEl) listEl.classList.remove('cw-room-themed');
            if (msgBox) msgBox.classList.remove('cw-messenger-dark-room');
          } else {
            const pal = isAppDark ? def.dark : def.light;
            root.setProperty('--chat-room-bg', pal.roomBg);
            root.setProperty('--bubble-suwan', pal.mineBg);
            root.setProperty('--bubble-mine-text', pal.mineText);
            root.setProperty('--bubble-mine-muted', pal.mineMuted);
            root.setProperty('--bubble-mine-pill-bg', pal.minePill);
            root.setProperty('--bubble-mine-border', pal.mineBorder);
            root.setProperty('--bubble-jingchan', pal.ptBg);
            root.setProperty('--bubble-jingchan-text', pal.ptText);
            root.setProperty('--bubble-jingchan-muted', pal.ptMuted);
            root.setProperty('--bubble-jingchan-border', pal.ptBorder);
            if (listEl) listEl.classList.add('cw-room-themed');
            if (msgBox) msgBox.classList.toggle('cw-messenger-dark-room', isAppDark);
          }

          if (dot) dot.style.background = def.dot;
          try { localStorage.setItem(KEY_RT, cleanId); } catch (_) {}
          const isZh = state && state.lang === 'zh';
          if (titleEl) titleEl.textContent = isZh ? '🎨 聊天室主题' : '🎨 대화방 테마';
          document.querySelectorAll('.cw-rtheme-btn').forEach(b => {
            const bid = b.getAttribute('data-rtheme');
            const act = bid === cleanId;
            b.className = `cw-rtheme-btn ${act ? 'btn-royal' : 'btn-ghost'} px-2.5 py-1 rounded-full text-[11px] font-bold inline-flex items-center gap-1 transition active:scale-95`;
            const lbl = b.querySelector('.cw-rt-lbl');
            if (lbl && ROOM_THEMES[bid]) lbl.textContent = isZh ? ROOM_THEMES[bid].shortZh : ROOM_THEMES[bid].shortKo;
          });
          if (!silent) {
            showToast(isZh ? `🎨 聊天室已切换为「${def.zh}」` : `🎨 대화방을 「${def.ko}」(으)로 바꿨어요!`);
          }
        }

        if (btn && bar) {
          btn.addEventListener('click', () => {
            const cur = (function(){ try { return localStorage.getItem(KEY_RT) || 'default'; } catch(_) { return 'default'; } })();
            applyChatRoomTheme(cur, true);
            bar.classList.toggle('hidden');
          });
        }
        document.querySelectorAll('.cw-rtheme-btn').forEach(b => {
          b.addEventListener('click', () => {
            applyChatRoomTheme(b.getAttribute('data-rtheme'), false);
            if (bar) bar.classList.add('hidden');
          });
        });

        let savedRt = 'default';
        try { savedRt = localStorage.getItem(KEY_RT) || 'default'; } catch (_) {}
        window.__syncPartnerBubbleForTheme = function() {
          let curRt = 'default';
          try { curRt = localStorage.getItem(KEY_RT) || 'default'; } catch (_) {}
          applyChatRoomTheme(curRt, true);
        };
        applyChatRoomTheme(savedRt, true);
      })();

      /* ==================== LIVE ONLINE PRESENCE (HOME PROFILE CARDS + MESSENGER HEADER) ==================== */
      (function initLivePresenceController() {
        const LAST_SEEN_KEY = 'cw_partner_last_seen_v1';
        function loadSavedLastSeen() {
          try {
            const raw = JSON.parse(localStorage.getItem(LAST_SEEN_KEY) || '{}');
            return {
              suwan: Number(raw.suwan || 0),
              jingchan: Number(raw.jingchan || 0)
            };
          } catch (_) { return { suwan: 0, jingchan: 0 }; }
        }
        window.__savePartnerLastSeen = function(role, ts) {
          if (!role || !ts) return;
          try {
            const cur = loadSavedLastSeen();
            if (Number(ts) > Number(cur[role] || 0)) {
              cur[role] = Number(ts);
              localStorage.setItem(LAST_SEEN_KEY, JSON.stringify(cur));
            }
          } catch (_) {}
        };
        const savedLs = loadSavedLastSeen();
        if (!window.__cwPartnerPresence) {
          window.__cwPartnerPresence = {
            suwan: { online: false, lastSeen: savedLs.suwan || 0 },
            jingchan: { online: false, lastSeen: savedLs.jingchan || 0 }
          };
        } else {
          if (!window.__cwPartnerPresence.suwan?.lastSeen && savedLs.suwan) window.__cwPartnerPresence.suwan.lastSeen = savedLs.suwan;
          if (!window.__cwPartnerPresence.jingchan?.lastSeen && savedLs.jingchan) window.__cwPartnerPresence.jingchan.lastSeen = savedLs.jingchan;
        }
        function formatPresenceState(role) {
          const isZh = state && state.lang === 'zh';
          const myR = (state && state.myRole) || 'suwan';
          if (role === myR && !document.hidden) {
            return { online: true, text: isZh ? '🟢 在线' : '🟢 접속 중' };
          }
          const info = window.__cwPartnerPresence[role] || { online: false, lastSeen: 0 };
          const serverLs = Number((state && state.profile && state.profile[role + 'LastSeen']) || 0);
          const bestLastSeen = Math.max(Number(info.lastSeen || 0), serverLs);
          const now = Date.now();
          if ((info.online && bestLastSeen && (now - bestLastSeen) < 26000) || (!info.explicitOffline && serverLs && (now - serverLs) < 35000)) {
            return { online: true, text: isZh ? '🟢 在线' : '🟢 접속 중' };
          }
          if (bestLastSeen && bestLastSeen > 0) {
            const mins = Math.max(0, Math.floor((now - bestLastSeen) / 60000));
            if (mins < 1) return { online: false, text: isZh ? '⚪ 刚刚在线' : '⚪ 방금 전 접속' };
            if (mins < 60) return { online: false, text: isZh ? `⚪ ${mins}分钟前` : `⚪ ${mins}분 전 접속` };
            const hrs = Math.floor(mins / 60);
            if (hrs < 24) return { online: false, text: isZh ? `⚪ ${hrs}小时前` : `⚪ ${hrs}시간 전` };
          }
          return { online: false, text: isZh ? '⚪ 离线' : '⚪ 오프라인' };
        }
        function applyPillStyle(el, st) {
          if (!el || !st) return;
          el.textContent = st.text;
          if (st.online) {
            el.style.background = 'rgba(16, 185, 129, 0.14)';
            el.style.color = '#059669';
          } else {
            el.style.background = 'var(--surface-2)';
            el.style.color = 'var(--text-muted)';
          }
        }
        function renderPresenceBadges() {
          try {
            const swEl = document.getElementById('presenceBadgeSuwan');
            const jcEl = document.getElementById('presenceBadgeJingchan');
            const chatEl = document.getElementById('chatPartnerPresenceBadge');
            const myR = (state && state.myRole) || 'suwan';
            const partnerR = myR === 'suwan' ? 'jingchan' : 'suwan';
            const swSt = formatPresenceState('suwan');
            const jcSt = formatPresenceState('jingchan');
            applyPillStyle(swEl, swSt);
            applyPillStyle(jcEl, jcSt);
            if (chatEl) {
              const pSt = partnerR === 'suwan' ? swSt : jcSt;
              const isZh = state && state.lang === 'zh';
              const pName = partnerR === 'suwan' ? (isZh ? '秀完' : '수완') : (isZh ? '靖灿' : '징찬');
              const label = pSt.online
                ? (isZh ? `🟢 ${pName}在线` : `🟢 ${pName} 접속 중`)
                : pSt.text;
              applyPillStyle(chatEl, { online: pSt.online, text: label });
            }
          } catch (_) {}
        }
        window.__renderPresenceBadges = renderPresenceBadges;

        let __lastServerSeenSyncTs = 0;
        function broadcastPresence(isOnline, needReply) {
          try {
            const effectiveOnline = !!isOnline && !document.hidden;
            const nowTs = Date.now();
            if (typeof window.__sendChatSignal === 'function') {
              window.__sendChatSignal('presence', { online: effectiveOnline, needReply: effectiveOnline && !!needReply, ts: nowTs });
            }
            // Persist real lastSeen timestamp ONLY after initial cloud pull finishes (never overwrite server before pulling!)
            if (window.__cwInitialPullDone && state && state.profile && (!effectiveOnline || (nowTs - __lastServerSeenSyncTs) >= 30000)) {
              const myR = state.myRole || 'suwan';
              const lsKey = myR + 'LastSeen';
              state.profile[lsKey] = nowTs;
              __lastServerSeenSyncTs = nowTs;
              if (typeof saveState === 'function') saveState(true);
            }
          } catch (_) {}
        }
        window.__broadcastPresenceNow = broadcastPresence;
        setTimeout(() => { renderPresenceBadges(); broadcastPresence(!document.hidden, true); }, 600);
        setInterval(() => {
          if (document.hidden) return;
          renderPresenceBadges();
          broadcastPresence(true, false);
        }, 10000);
        document.addEventListener('visibilitychange', () => {
          broadcastPresence(!document.hidden, !document.hidden);
          renderPresenceBadges();
        });
        window.addEventListener('focus', () => {
          if (!document.hidden) { broadcastPresence(true, true); renderPresenceBadges(); }
        });
        window.addEventListener('pagehide', () => broadcastPresence(false, false));
        window.addEventListener('beforeunload', () => broadcastPresence(false, false));
      })();

      (function bindThemeModeDrawers() {
        const pairs = [
          { btn: 'themeDrawerLightBtn', body: 'themeDrawerLightBody', chev: 'themeDrawerLightChevron' },
          { btn: 'themeDrawerDarkBtn',  body: 'themeDrawerDarkBody',  chev: 'themeDrawerDarkChevron' }
        ];
        pairs.forEach(p => {
          const b = document.getElementById(p.btn);
          const bd = document.getElementById(p.body);
          const ch = document.getElementById(p.chev);
          if (!b || !bd) return;
          b.addEventListener('click', () => {
            const willOpen = bd.classList.contains('hidden');
            // Accordion behavior: close the other drawer cleanly
            pairs.forEach(o => {
              const obd = document.getElementById(o.body);
              const och = document.getElementById(o.chev);
              if (obd) obd.classList.add('hidden');
              if (och) och.style.transform = '';
            });
            if (willOpen) {
              bd.classList.remove('hidden');
              if (ch) ch.style.transform = 'rotate(180deg)';
              if (typeof window.scheduleIconSync === 'function') window.scheduleIconSync(bd);
            }
          });
        });
      })();

      /* ==================== AUTO RANDOM DARK MODE AFTER 9 PM (LOCAL TIME PER PERSON) ==================== */
      (function initAutoNightRandomDarkMode() {
        const KEY_ENABLED = 'cw_auto_night_dark_enabled_v1';
        const KEY_LAST_DATE = 'cw_auto_night_dark_date_v1';
        const RANDOM_DARK_POOL = ['velvet-dusk', 'midnight-navy', 'rose-noir', 'midnight-black'];
        const toggleBtn = document.getElementById('autoNightDarkToggleBtn');

        function isEnabled() {
          try { return localStorage.getItem(KEY_ENABLED) !== '0'; } catch (_) { return true; }
        }
        function syncToggleUi() {
          if (!toggleBtn) return;
          const on = isEnabled();
          toggleBtn.textContent = on ? 'ON' : 'OFF';
          toggleBtn.className = `${on ? 'btn-royal' : 'btn-ghost'} px-3 py-1 rounded-full text-[11px] font-bold shrink-0 whitespace-nowrap`;
        }
        function getViewerLocalClockParts() {
          const myR = (state && state.myRole) || 'suwan';
          const tz = (state && state.cities && state.cities[myR] && state.cities[myR].tz)
            || (myR === 'jingchan' ? 'Asia/Shanghai' : 'Asia/Seoul');
          const now = new Date();
          try {
            const hourStr = new Intl.DateTimeFormat('en-GB', { timeZone: tz, hour: '2-digit', hour12: false }).format(now);
            const dateStr = new Intl.DateTimeFormat('en-CA', { timeZone: tz }).format(now);
            const hour = Number(hourStr) % 24;
            return { hour, dateStr, tz };
          } catch (_) {
            return { hour: now.getHours(), dateStr: now.toISOString().slice(0, 10), tz };
          }
        }
        function checkAndApplyNightDark(showNotice) {
          if (!isEnabled()) return;
          const { hour, dateStr } = getViewerLocalClockParts();
          // Trigger between 21:00 and 05:59 local time, once per night
          if (!(hour >= 21 || hour < 6)) return;
          const nightKey = hour < 6 ? `${dateStr}_pre6` : dateStr;
          let lastApplied = '';
          try { lastApplied = localStorage.getItem(KEY_LAST_DATE) || ''; } catch (_) {}
          if (lastApplied === nightKey) return;
          const pickId = RANDOM_DARK_POOL[Math.floor(Math.random() * RANDOM_DARK_POOL.length)];
          try { localStorage.setItem(KEY_LAST_DATE, nightKey); } catch (_) {}
          applyTheme(pickId, true);
          if (showNotice) {
            const isZh = state && state.lang === 'zh';
            const tObj = THEMES.find(t => t.id === pickId);
            const tName = tObj ? (isZh ? tObj.labelZh : tObj.labelKo) : pickId;
            const modal = document.getElementById('autoNightNoticeModal');
            const titleEl = document.getElementById('autoNightNoticeTitle');
            const bodyEl = document.getElementById('autoNightNoticeBody');
            const disBtn = document.getElementById('autoNightNoticeDisableBtn');
            const keepBtn = document.getElementById('autoNightNoticeKeepBtn');
            if (modal && titleEl && bodyEl) {
              titleEl.textContent = isZh ? '🌙 晚9点自动深色模式提示' : '🌙 밤 9시 자동 다크모드 안내';
              bodyEl.textContent = isZh
                ? `当地时间已过晚上 9 点，已自动切换为护眼深色主题「${tName}」。如果不习惯深色模式，可点击下方按钮立即关闭，或随时在「设置 → 主题模式 → 晚9点后自动随机深色模式」中设为 OFF（也可点右上角 ☀️ 随时切回浅色）。`
                : `현지 시간 밤 9시가 지나 눈이 편안한 다크 테마「${tName}」(으)로 자동 전환됐어요. 다크모드가 불편하시면 아래 버튼으로 바로 해제하거나, 언제든 [설정 → 디자인 모드 → 밤 9시 자동 다크모드]를 OFF로 끌 수 있어요(우측 상단 ☀️ 버튼으로도 바로 밝게 바꿀 수 있어요).`;
              if (disBtn) disBtn.textContent = isZh ? '☀️ 立即关闭并切回浅色' : '☀️ 해제하고 밝게 쓰기';
              if (keepBtn) keepBtn.textContent = isZh ? '💜 好的，继续使用' : '💜 그대로 쓸게요';
              modal.classList.remove('hidden');
            } else {
              showToast(isZh ? `🌙 已过晚上9点，自动切换为「${tName}」` : `🌙 밤 9시가 지나 「${tName}」(으)로 자동 전환됐어요`);
            }
          }
        }

        const closeNightModal = () => {
          const m = document.getElementById('autoNightNoticeModal');
          if (m) m.classList.add('hidden');
        };
        document.getElementById('autoNightNoticeCloseX')?.addEventListener('click', closeNightModal);
        document.getElementById('autoNightNoticeKeepBtn')?.addEventListener('click', closeNightModal);
        document.getElementById('autoNightNoticeModal')?.addEventListener('click', (e) => {
          if (e.target && e.target.id === 'autoNightNoticeModal') closeNightModal();
        });
        document.getElementById('autoNightNoticeDisableBtn')?.addEventListener('click', () => {
          try { localStorage.setItem(KEY_ENABLED, '0'); } catch (_) {}
          syncToggleUi();
          closeNightModal();
          const prevLight = (function(){ try { return localStorage.getItem('cw_last_light_theme') || 'pastel-royal'; } catch(_) { return 'pastel-royal'; } })();
          applyTheme(prevLight, true);
          showToast(state && state.lang === 'zh'
            ? '☀️ 已关闭自动深色模式并切回浅色主题'
            : '☀️ 자동 다크모드를 해제하고 라이트 테마로 돌아왔어요');
        });

        if (toggleBtn) {
          toggleBtn.addEventListener('click', () => {
            const nextOn = !isEnabled();
            try {
              localStorage.setItem(KEY_ENABLED, nextOn ? '1' : '0');
              if (nextOn) localStorage.removeItem(KEY_LAST_DATE);
            } catch (_) {}
            syncToggleUi();
            if (nextOn) checkAndApplyNightDark(true);
            else showToast(state.lang === 'zh' ? '已关闭晚9点自动深色模式' : '밤 9시 자동 다크모드를 껐어요');
          });
        }
        syncToggleUi();
        setTimeout(() => checkAndApplyNightDark(true), 900);
        setInterval(() => { if (!document.hidden) checkAndApplyNightDark(true); }, 60000);
        document.addEventListener('visibilitychange', () => { if (!document.hidden) checkAndApplyNightDark(true); });
      })();

      /* ==================== SELF-HEAL & AUTO ERROR MEMO CONTROLLER (PRIME 3) ==================== */
      (function initSelfHealAndErrorMemo() {
        const ERR_KEY = 'cw_auto_error_memo_v1';
        const pillEl = document.getElementById('selfHealStatusPill');
        const listEl = document.getElementById('autoErrorMemoList');
        const reportEl = document.getElementById('selfHealReportBox');
        const runBtn = document.getElementById('selfHealNowBtn');
        const copyBtn = document.getElementById('copyErrorMemoBtn');
        const clearBtn = document.getElementById('clearErrorMemoBtn');

        function loadErrLogs() {
          try {
            const arr = JSON.parse(localStorage.getItem(ERR_KEY) || '[]');
            return Array.isArray(arr) ? arr : [];
          } catch (_) { return []; }
        }
        function saveErrLogs(arr) {
          try { localStorage.setItem(ERR_KEY, JSON.stringify((arr || []).slice(0, 30))); } catch (_) {}
        }
        function recordAutoErrorMemo(source, msg, detail) {
          const cleanMsg = String(msg || 'Unknown error').trim().slice(0, 180);
          if (!cleanMsg || /ResizeObserver loop|Script error\.?$/i.test(cleanMsg)) return;
          const activeTab = document.querySelector('.tab-panel.active')?.id?.replace('tab-', '') || 'home';
          const logs = loadErrLogs();
          const nowStr = new Date().toLocaleString('ko-KR', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' });
          // Deduplicate consecutive identical errors
          if (logs[0] && logs[0].msg === cleanMsg && logs[0].tab === activeTab) {
            logs[0].count = (logs[0].count || 1) + 1;
            logs[0].time = nowStr;
          } else {
            logs.unshift({ time: nowStr, tab: activeTab, source: String(source || 'runtime'), msg: cleanMsg, detail: String(detail || '').slice(0, 140), count: 1 });
          }
          saveErrLogs(logs);
          renderErrorMemoUi();
        }
        window.__recordAutoErrorMemo = recordAutoErrorMemo;

        function renderErrorMemoUi() {
          const isZh = state && state.lang === 'zh';
          const logs = loadErrLogs();
          if (pillEl) {
            if (!logs.length) {
              pillEl.textContent = isZh ? '🟢 运行正常 · 0异常' : '🟢 정상 · 오류 0건';
              pillEl.style.background = 'rgba(16,185,129,0.14)';
              pillEl.style.color = '#059669';
            } else {
              pillEl.textContent = isZh ? `⚠️ 已自动记录 ${logs.length} 条` : `⚠️ 자동 메모 ${logs.length}건`;
              pillEl.style.background = 'rgba(245,158,11,0.16)';
              pillEl.style.color = '#d97706';
            }
          }
          if (listEl) {
            if (!logs.length) {
              listEl.innerHTML = `<div class="text-center py-2">${isZh ? '✨ 目前没有记录到未解决的程序异常。' : '✨ 현재 기록된 코드 오류가 없어요. 쾌적하게 실행 중이에요!'}</div>`;
            } else {
              listEl.innerHTML = logs.map((lg, idx) => `
                <div class="rounded-xl px-2.5 py-1.5" style="background: var(--surface-1); border: 1px solid var(--border-subtle);">
                  <div class="flex items-center justify-between gap-2 text-[10px] font-bold">
                    <span style="color: var(--accent-royal);">#${idx + 1} [${escapeHtml(lg.tab || 'app')}] ${escapeHtml(lg.source || 'error')}${lg.count > 1 ? ` ×${lg.count}` : ''}</span>
                    <span class="text-mut tabular-nums">${escapeHtml(lg.time || '')}</span>
                  </div>
                  <div class="text-[11px] text-main break-words mt-0.5">${escapeHtml(lg.msg || '')}</div>
                  ${lg.detail ? `<div class="text-[10px] text-mut break-words mt-0.5">${escapeHtml(lg.detail)}</div>` : ''}
                </div>
              `).join('');
            }
          }
        }
        window.__renderErrorMemoUi = renderErrorMemoUi;

        // Capture uncaught runtime errors & unhandled promise rejections automatically
        window.addEventListener('error', (ev) => {
          try {
            const loc = ev && ev.filename ? `${ev.filename.split('/').pop()}:${ev.lineno || 0}` : '';
            recordAutoErrorMemo('JS Error', ev?.message || 'Runtime error', loc);
          } catch (_) {}
        });
        window.addEventListener('unhandledrejection', (ev) => {
          try {
            const reason = ev && ev.reason ? (ev.reason.message || String(ev.reason)) : 'Promise rejected';
            if (/AbortError|Failed to fetch|NetworkError|Load failed/i.test(reason)) return;
            recordAutoErrorMemo('Async Error', reason, '');
          } catch (_) {}
        });

        // Smart In-App Layout & Spacing Auto-Correction (Zero-Clip Auto-Fit)
        function autoFixLayoutSpacing() {
          let adjusted = 0;
          try {
            // 1. Auto-fit any overflowing tab/subtab/category buttons so labels never clip on narrow screens or large fonts
            const targets = document.querySelectorAll('#coupleSubtabBar .diary-subtab:not(.hidden), .couple-cat-btn, .learn-subtab, .dock-item');
            targets.forEach(el => {
              if (!el || el.offsetParent === null) return;
              // Reset previous auto-fit first
              if (el.dataset.cwAutoFit) {
                el.style.removeProperty('font-size');
                el.style.removeProperty('letter-spacing');
                delete el.dataset.cwAutoFit;
              }
              if (el.scrollWidth > el.clientWidth + 2) {
                let fs = parseFloat(getComputedStyle(el).fontSize) || 11;
                let guard = 0;
                while (el.scrollWidth > el.clientWidth + 1 && fs > 9 && guard < 6) {
                  fs = Math.max(9, fs - 0.5);
                  el.style.setProperty('font-size', fs.toFixed(1) + 'px', 'important');
                  el.style.setProperty('letter-spacing', '-0.03em', 'important');
                  guard++;
                }
                el.dataset.cwAutoFit = '1';
                adjusted++;
              }
            });
            // 2. Clean stray keyboard padding on <main> if no input is currently focused
            const act = document.activeElement;
            const isTyping = act && (act.tagName === 'INPUT' || act.tagName === 'TEXTAREA');
            const mainEl = document.querySelector('main');
            if (!isTyping && mainEl && mainEl.style.paddingBottom && mainEl.style.paddingBottom.includes('vh')) {
              mainEl.style.removeProperty('padding-bottom');
              adjusted++;
            }
            // 3. Reset any accidental horizontal scroll offset
            if (window.scrollX > 0) { window.scrollTo(0, window.scrollY); adjusted++; }
          } catch (_) {}
          return adjusted;
        }
        window.__autoFixLayoutSpacing = autoFixLayoutSpacing;
        let __layoutFixTimer = null;
        const scheduleLayoutFix = () => {
          if (__layoutFixTimer) clearTimeout(__layoutFixTimer);
          __layoutFixTimer = setTimeout(() => { __layoutFixTimer = null; autoFixLayoutSpacing(); }, 180);
        };
        window.addEventListener('resize', scheduleLayoutFix);
        window.addEventListener('orientationchange', scheduleLayoutFix);
        setTimeout(autoFixLayoutSpacing, 700);

        // 1-Tap Self-Heal Everything Fixable Inside the App (Prime 3 v36: Full 8-Point Report + Forced Icon Reapply)
        if (runBtn) {
          runBtn.addEventListener('click', async () => {
            if (runBtn.dataset.busy === '1') return;
            runBtn.dataset.busy = '1';
            const isZh = state && state.lang === 'zh';
            const origBtnTxt = runBtn.textContent;
            runBtn.textContent = isZh ? '⚡ 正在快速自检...' : '⚡ 빠르게 점검 중...';
            if (reportEl) {
              reportEl.classList.remove('hidden');
              reportEl.innerHTML = `<div class="text-[11px] font-semibold opacity-80">${isZh ? '⚡ 正在执行全项自检与修复...' : '⚡ 자가 복구 점검을 진행하고 있어요...'}</div>`;
            }
            await new Promise(r => requestAnimationFrame(() => setTimeout(r, 0)));
            const rows = [];
            try {
              // 1. Data integrity
              if (typeof repairStateIntegrity === 'function') repairStateIntegrity();
              rows.push(isZh ? '1. ✅ 정상 · 数据结构完整性校验通过' : '1. ✅ 정상 · 데이터 구조 무결성 점검 완료');

              // 2. Messenger dedupe & stale sending recovery
              let dupMsg = 0, staleCnt = 0;
              if (state.chat && Array.isArray(state.chat.messages)) {
                const seenM = new Set();
                const beforeM = state.chat.messages.length;
                state.chat.messages = state.chat.messages.filter(m => {
                  if (!m || !m.id || seenM.has(m.id)) return false;
                  seenM.add(m.id);
                  if (m.deliveryStatus === 'sending' || m.deliveryStatus === 'failed') { m.deliveryStatus = (typeof navigator === 'undefined' || navigator.onLine !== false) ? 'sending' : 'failed'; staleCnt++; }
                  return true;
                });
                dupMsg = Math.max(0, beforeM - state.chat.messages.length);
              }
              rows.push((dupMsg > 0 || staleCnt > 0)
                ? (isZh ? `2. 🔧 修复 · 清理重复消息 ${dupMsg} 条 / 恢复卡住状态 ${staleCnt} 条` : `2. 🔧 복구 · 중복 메시지 ${dupMsg}건 정리 · 멈춘 전송 ${staleCnt}건 복구`)
                : (isZh ? '2. ✅ 正常 · 聊天消息无重复与卡顿' : '2. ✅ 정상 · 메신저 중복·멈춘 전송 없음'));

              // 3. Couple Space dedupe & structure check
              let csFixed = 0;
              ['diaries', 'memos', 'buckets', 'complimentJar', 'coupleQuizzes', 'coupons', 'schedules'].forEach(k => {
                if (!Array.isArray(state[k])) { state[k] = []; csFixed++; return; }
                const seen = new Set();
                const seenContent = new Set();
                const b = state[k].length;
                state[k] = state[k].filter(it => {
                  if (!it || typeof it !== 'object') return false;
                  if (it.id && seen.has(it.id)) return false;
                  if (it.id) seen.add(it.id);
                  if (k === 'diaries') {
                    const ck = `${it.date || ''}|${String(it.author || '').trim()}|${String(it.title || '').trim()}|${String(it.content || '').trim()}`;
                    if (seenContent.has(ck)) return false;
                    seenContent.add(ck);
                  }
                  return true;
                });
                csFixed += Math.max(0, b - state[k].length);
              });
              if (state.truthDare && Array.isArray(state.truthDare.history)) {
                const seenTd = new Set();
                const beforeTd = state.truthDare.history.length;
                state.truthDare.history = state.truthDare.history.filter(it => {
                  if (!it) return false;
                  const k = `${it.id || ''}|${it.authorRole || it.author || ''}|${String(it.text || '').trim()}`;
                  if (seenTd.has(k)) return false;
                  seenTd.add(k);
                  return true;
                });
                csFixed += Math.max(0, beforeTd - state.truthDare.history.length);
              }
              rows.push(csFixed > 0
                ? (isZh ? `3. 🔧 修复 · 情侣空间重复/异常记录整理 ${csFixed} 条` : `3. 🔧 복구 · 커플공간 중복·구조 정리 ${csFixed}건`)
                : (isZh ? '3. ✅ 正常 · 情侣空间记录完整无重复' : '3. ✅ 정상 · 커플공간(일기·메모·진실·도전 등) 정상'));

              // 4. Voices, Photo/Voice Vaults & Deleted Ghost Sweep
              let ghostAlbRemoved = 0;
              if (Array.isArray(state.albums) && Array.isArray(state.deletedAlbumIds) && state.deletedAlbumIds.length) {
                const delSetH = new Set(state.deletedAlbumIds);
                const beforeH = state.albums.length;
                state.albums = state.albums.filter(a => a && !delSetH.has(a.id));
                ghostAlbRemoved = Math.max(0, beforeH - state.albums.length);
              }
              // Run heavy IDB + cloud I/O asynchronously right after paint so the UI responds in 0ms!
              setTimeout(() => {
                try { if (typeof saveSuwanVoicesNow === 'function') saveSuwanVoicesNow(); } catch (_) {}
                try { if (typeof persistMediaVaultsNow === 'function') persistMediaVaultsNow(); } catch (_) {}
                try { if (typeof flushIdbStateNow === 'function') flushIdbStateNow(); } catch (_) {}
                try { saveState(true); } catch (_) {}
                try { if (typeof window.__connectEmqxNow === 'function') window.__connectEmqxNow(); } catch (_) {}
                try { if (typeof window.__flushSyncOutbox === 'function') window.__flushSyncOutbox(); } catch (_) {}
                try { if (typeof window.__pullCloudSync === 'function') window.__pullCloudSync(false); } catch (_) {}
                try { if (typeof window.__broadcastPresenceNow === 'function') window.__broadcastPresenceNow(true, true); } catch (_) {}
              }, 35);
              rows.push(ghostAlbRemoved > 0
                ? (isZh ? `4. 🔧 修复 · 永久金库已保存并清理残留已删照片 ${ghostAlbRemoved} 张` : `4. 🔧 복구 · 영구 금고 재저장 및 삭제된 사진 잔재 ${ghostAlbRemoved}건 정리`)
                : (isZh ? '4. ✅ 正常 · 照片/语音永久金库与全部数据已重新保存' : '4. ✅ 정상 · 사진·음성 영구 금고 및 전체 상태 재저장 완료'));

              // 5. EMQX China Direct + Outbox flush + Cloud pull + Presence (queued non-blocking above)
              rows.push(isZh ? '5. 🔧 同步 · EMQX直连重连·云端拉取·在线状态已刷新' : '5. 🔧 복구 · EMQX·미전송 재전송·클라우드·접속 상태 재동기화');

              // 6. Samsung/Android App Badge & Stray OS Notification Cleanup
              const unreadCnt = (state.notifications || []).filter(n => n && n.unread).length;
              let badgeCleared = false;
              if (unreadCnt === 0) {
                if (typeof clearAllAppBadgesAndOsNotifs === 'function') {
                  clearAllAppBadgesAndOsNotifs();
                  badgeCleared = true;
                } else if (navigator.clearAppBadge) {
                  try { await navigator.clearAppBadge(); badgeCleared = true; } catch (_) {}
                }
              }
              rows.push(badgeCleared
                ? (isZh ? '6. 🔧 修复 · 已强制清除桌面角标与残留系统通知' : '6. 🔧 복구 · 홈 화면 아이콘 배지 및 잔여 시스템 알림 초기화 완료')
                : (isZh ? `6. ✅ 正常 · 应用通知角标正常 (未读 ${unreadCnt})` : `6. ✅ 정상 · 앱 알림 배지 정상 (안 읽음 ${unreadCnt}건)`));

              // 7. Theme + Maker Mode + Forced Full-Screen Icon Style Re-apply
              applyTheme(state.theme, true);
              if (typeof window.__applyMakerLayout === 'function' && state.makerLayout) {
                window.__applyMakerLayout(state.makerLayout, true);
              }
              const savedIconMode = localStorage.getItem('chanwan_icon_style_v1') || (state.settings && state.settings.iconStyle) || 'pastel';
              if (typeof window.__refreshIconSlots === 'function') window.__refreshIconSlots(document);
              if (typeof autoResolvePendingTranslations === 'function') autoResolvePendingTranslations();
              try { renderChat(); renderHome(); renderNotifications(); } catch (_) {}
              rows.push(isZh ? `7. 🔧 刷新 · 主题·排版·待译消息与图标风格(${savedIconMode})已刷新` : `7. 🔧 복구 · 테마·배치·미번역 문구·아이콘(${savedIconMode}) 즉시 새로고침`);

              // 8. Layout & spacing auto-fit
              const fitCnt = autoFixLayoutSpacing();
              rows.push(fitCnt > 0
                ? (isZh ? `8. 🔧 修复 · 自动校准界面间距/防截断 ${fitCnt} 处` : `8. 🔧 복구 · 화면 간격·짤림 자동 보정 ${fitCnt}건`)
                : (isZh ? '8. ✅ 正常 · 界面间距与布局检测正常' : '8. ✅ 정상 · 화면 간격·넘침 점검 정상'));

              // 9. Cloud Missing Media & Deep Event Recovery (runs non-blocking so button finishes in 0ms without 15s stall!)
              window.__cwDeepDeltaRecovered = false;
              rows.push(isZh ? '9. 🔧 恢复 · 正在后台同步云端照片/视频/聊天记录（零卡顿）' : '9. 🔧 복구 · 서버 대화·사진·앨범·동영상 백그라운드 정밀 동기화 시작');
              setTimeout(async () => {
                try {
                  if (typeof window.__pullCloudSync === 'function') await window.__pullCloudSync(true);
                  if (staleCnt > 0 && typeof window.__pushFullCloudSync === 'function') await window.__pushFullCloudSync();
                  const r9 = document.getElementById('cwHealRow9');
                  if (r9) r9.textContent = isZh ? '9. ✅ 完成 · 云端照片/相册/视频/语音深度同步已完成' : '9. ✅ 완료 · 서버 대화·사진·앨범·동영상 전체 동기화 완료';
                } catch (_) {}
              }, 80);

              // 10. Stuck UI Drawers/Modals & Mood Guard Sync
              ['chatStickerTray', 'chatPlusDrawer', 'cwMicPermModal', 'cwChatBgModal'].forEach(id => document.getElementById(id)?.classList.add('hidden'));
              ['chatForm', 'cwQuickPhraseBar'].forEach(id => { const el = document.getElementById(id); if (el) { el.style.marginTop = ''; el.style.marginBottom = ''; el.style.transform = ''; } });
              if (typeof window.__syncChatKeyboardViewport === 'function') window.__syncChatKeyboardViewport();
              const curR = state.myRole || 'suwan';
              const curMood = curR === 'suwan' ? state.profile?.suwanMood : state.profile?.jingchanMood;
              if (curMood) {
                try { localStorage.setItem('cw_my_mood_guard_v1', JSON.stringify({ role: curR, mood: curMood, ts: Number(state.profile?.[curR + 'MoodUpdatedAt'] || Date.now()) })); } catch (_) {}
              }
              rows.push(isZh ? '10. ✅ 正常 · 悬浮弹窗重置与心情状态保护同步完成' : '10. ✅ 정상 · 꼬인 서랍·이모지창 정리 및 기분 보호 잠금 동기화 완료');
            } catch (err) {
              recordAutoErrorMemo('SelfHeal', err && err.message ? err.message : String(err), '');
            }
            if (reportEl) {
              reportEl.classList.remove('hidden');
              reportEl.innerHTML = `<div class="font-bold mb-1.5" style="color:#059669;">${isZh ? '✅ 应用内 10 项自检修复报告：' : '✅ 앱 자가 복구 10개 항목 점검 리포트:'}</div>` +
                rows.map((x, idx) => `<div ${idx === 8 ? 'id="cwHealRow9" ' : ''}class="py-0.5">${escapeHtml(x)}</div>`).join('');
            }
            runBtn.dataset.busy = '0';
            runBtn.textContent = origBtnTxt;
            renderErrorMemoUi();
            showToast(isZh ? '🛠️ 10项自检修复完成！' : '🛠️ 자가 복구 10개 항목 점검·복구가 완료됐어요!');
          });
        }

        if (copyBtn) {
          copyBtn.addEventListener('click', async () => {
            const isZh = state && state.lang === 'zh';
            const logs = loadErrLogs();
            const header = `[灿完时光 Prime 4 v45 오류 메모] role=${state.myRole || 'suwan'} | lang=${state.lang} | theme=${state.theme} | msgs=${(state.chat?.messages || []).length} | errors=${logs.length}`;
            const body = logs.length
              ? logs.map((l, i) => `${i + 1}. (${l.time}) [${l.tab}/${l.source}] ${l.msg} ${l.detail || ''} (x${l.count || 1})`).join('\n')
              : 'No errors logged.';
            const txt = header + '\n' + body;
            try {
              await navigator.clipboard.writeText(txt);
              showToast(isZh ? '📋 错误备忘已复制，发给我即可精准修复！' : '📋 오류 메모를 복사했어요! 저한테 그대로 붙여주시면 바로 고쳐드릴게요');
            } catch (_) {
              showToast(isZh ? '无法自动复制，请长按下方记录复制' : '자동 복사가 막혀 있어요. 아래 기록을 확인해 주세요');
            }
          });
        }

        if (clearBtn) {
          clearBtn.addEventListener('click', () => {
            saveErrLogs([]);
            if (reportEl) reportEl.classList.add('hidden');
            renderErrorMemoUi();
            showToast(state && state.lang === 'zh' ? '🗑️ 错误备忘已清空' : '🗑️ 오류 메모장을 비웠어요');
          });
        }

        setTimeout(renderErrorMemoUi, 400);
      })();

      /* ==================== UNIVERSAL RETRANSLATE FOR WRITTEN SPACE ITEMS (DIARY · MEMO · QA · JAR · TRUTHDARE) ==================== */
      document.addEventListener('click', async (ev) => {
        const btn = ev.target && ev.target.closest ? ev.target.closest('.cw-retrans-item-btn') : null;
        if (!btn || btn.disabled) return;
        ev.preventDefault();
        ev.stopPropagation();
        const rtype = btn.getAttribute('data-rtype') || '';
        const rid = btn.getAttribute('data-rid') || '';
        if (!rtype || !rid) return;
        const isZh = state && state.lang === 'zh';
        const origLabel = btn.textContent;
        btn.disabled = true;
        btn.textContent = isZh ? '翻译中...' : '재번역 중...';
        try {
          let updated = false;
          if (rtype === 'diary') {
            const item = (state.diaries || []).find(x => x && x.id === rid);
            if (item) {
              if (item.title && /[a-zA-Z0-9가-힣\u4e00-\u9fff]/.test(item.title)) {
                const rt = await translateWithAutoRetry(item.title, 'lover', 'Google');
                if (rt && rt.translated) { item.titleTranslated = rt.translated; updated = true; }
              }
              if (item.content && /[a-zA-Z0-9가-힣\u4e00-\u9fff]/.test(item.content)) {
                const rc = await translateWithAutoRetry(item.content, 'lover', 'Google');
                if (rc && rc.translated) {
                  item.translated = rc.translated;
                  if (rc.pronunciation) item.pronunciation = rc.pronunciation;
                  if (rc.nuance) item.nuance = rc.nuance;
                  updated = true;
                }
              }
              if (updated) { saveState(true); renderDiaryQaMemos(); }
            }
          } else if (rtype === 'memo') {
            const item = (state.memos || []).find(x => x && x.id === rid);
            if (item && item.text) {
              const res = await translateWithAutoRetry(item.text, 'lover', 'Google');
              if (res && res.translated) {
                item.translated = res.translated;
                if (res.pronunciation) item.pronunciation = res.pronunciation;
                updated = true;
                saveState(true); renderDiaryQaMemos();
              }
            }
          } else if (rtype === 'qa') {
            const item = (state.chat && Array.isArray(state.chat.qaAnswers) ? state.chat.qaAnswers : []).find(x => x && x.id === rid);
            if (item && item.original) {
              const res = await translateWithAutoRetry(item.original, 'lover', 'Google');
              if (res && res.translated) {
                item.translated = res.translated;
                if (res.pronunciation) item.pronunciation = res.pronunciation;
                if (res.nuance) item.nuance = res.nuance;
                updated = true;
                saveState(true); renderDiaryQaMemos();
              }
            }
          } else if (rtype === 'jar') {
            const item = (state.complimentJar || []).find(x => x && x.id === rid);
            if (item && item.text) {
              const res = await translateWithAutoRetry(item.text, 'lover', 'Google');
              if (res && res.translated) {
                item.translated = res.translated;
                updated = true;
                saveState(true);
                if (typeof renderComplimentJar === 'function') renderComplimentJar();
              }
            }
          } else if (rtype === 'truthdare') {
            const item = (state.truthDare && Array.isArray(state.truthDare.history) ? state.truthDare.history : []).find(x => x && x.id === rid);
            if (item && item.text) {
              const res = await translateWithAutoRetry(item.text, 'lover', 'Google');
              if (res && res.translated) {
                item.translated = res.translated;
                updated = true;
                saveState(true);
                if (typeof renderTruthDare === 'function') renderTruthDare();
              }
            }
          }
          if (updated) {
            showToast(isZh ? '✨ 3引擎重新翻译完成并已同步！' : '✨ 3중 엔진으로 정밀 재번역·동기화했어요!');
          } else {
            btn.disabled = false;
            btn.textContent = origLabel;
          }
        } catch (_) {
          btn.disabled = false;
          btn.textContent = origLabel;
        }
      });

      /* ==================== EASY TRANSLATION & GEMINI API KEY CONTROLLER ==================== */
      (function initTranslationSettingsCard() {
        const inp = document.getElementById('geminiApiKeyInput');
        const visBtn = document.getElementById('geminiKeyVisBtn');
        const saveBtn = document.getElementById('geminiKeySaveBtn');
        const testBtn = document.getElementById('geminiKeyTestBtn');
        const clearBtn = document.getElementById('geminiKeyClearBtn');
        const badge = document.getElementById('geminiKeyStatusBadge');
        const testBox = document.getElementById('geminiTestResultBox');

        function syncGeminiKeyUi() {
          const isZh = state && state.lang === 'zh';
          const key = (state && state.settings && state.settings.geminiApiKey || '').trim();
          const hasKey = key.length >= 15;
          if (inp && !inp.matches(':focus')) inp.value = key;
          if (clearBtn) clearBtn.classList.toggle('hidden', !hasKey);
          if (badge) {
            if (hasKey) {
              badge.textContent = isZh ? '🟢 Gemini AI 已启用' : '🟢 Gemini AI 활성';
              badge.style.background = 'rgba(16,185,129,0.14)';
              badge.style.color = '#059669';
            } else {
              badge.textContent = isZh ? '⚡ 免费三引擎并发' : '⚡ 무료 3중 병렬';
              badge.style.background = 'var(--accent-royal-soft)';
              badge.style.color = 'var(--accent-royal)';
            }
          }
          const homeBadge = document.getElementById('engineBadgeHome');
          if (homeBadge) homeBadge.textContent = hasKey ? 'Gemini AI' : (isZh ? '3引擎并发' : '3중 AI 번역');
        }
        window.__syncGeminiKeyUi = syncGeminiKeyUi;

        if (visBtn && inp) {
          visBtn.addEventListener('click', () => {
            inp.type = inp.type === 'password' ? 'text' : 'password';
          });
        }
        if (saveBtn && inp) {
          saveBtn.addEventListener('click', () => {
            const isZh = state && state.lang === 'zh';
            const val = (inp.value || '').trim();
            if (!val) {
              showToast(isZh ? '请先粘贴 Gemini API 密钥' : '먼저 Gemini API 키를 붙여넣어 주세요');
              return;
            }
            if (!state.settings) state.settings = {};
            state.settings.geminiApiKey = val;
            try {
              localStorage.setItem('cw_gemini_api_key_v1', val);
              localStorage.removeItem('cw_trans_fast_cache_v1');
              __cwTransCacheMem = {};
              __cwEngineSkipUntil.gemini = 0;
            } catch (_) {}
            inp.type = 'password';
            saveState(false);
            syncGeminiKeyUi();
            showToast(isZh ? '🔑 Gemini API 密钥已保存！点「测试翻译」确认吧' : '🔑 Gemini 키가 저장됐어요! [번역 테스트]를 눌러 확인해 보세요');
          });
        }
        if (clearBtn && inp) {
          clearBtn.addEventListener('click', () => {
            if (!state.settings) state.settings = {};
            state.settings.geminiApiKey = '';
            try { localStorage.removeItem('cw_gemini_api_key_v1'); __cwEngineSkipUntil.gemini = 0; } catch (_) {}
            inp.value = '';
            if (testBox) testBox.classList.add('hidden');
            saveState(false);
            syncGeminiKeyUi();
            showToast(state && state.lang === 'zh' ? '已恢复默认免费三引擎翻译' : '키를 해제하고 기본 무료 3중 번역으로 돌아왔어요');
          });
        }
        if (testBtn) {
          testBtn.addEventListener('click', async () => {
            const isZh = state && state.lang === 'zh';
            const sample = isZh ? '今天辛苦啦，好想你呀！' : '오늘 하루도 고생 많았어, 보고 싶어!';
            testBtn.disabled = true;
            if (testBox) {
              testBox.classList.remove('hidden');
              testBox.textContent = isZh ? '⏳ 正在测试翻译引擎...' : '⏳ 번역 엔진을 테스트하는 중...';
            }
            try {
              try { __cwEngineSkipUntil.gemini = 0; localStorage.removeItem('cw_trans_fast_cache_v1'); __cwTransCacheMem = {}; } catch (_) {}
              const res = await translateWithAutoRetry(sample, 'lover', '');
              if (testBox) {
                if (res && res.translated) {
                  const gWarn = (!String(res.engine || '').includes('Gemini') && window.__cwLastGeminiErr) ? `<div class="mt-0.5 text-[10px] text-rose-500">⚠️ Gemini 응답 참고: ${escapeHtml(window.__cwLastGeminiErr)}</div>` : '';
                  testBox.innerHTML = `<div class="font-bold" style="color:#059669;">✅ ${isZh ? '翻译正常' : '연결 성공'} (${escapeHtml(res.engine || 'AI')} · ${res.accuracy || 95}%)</div>${gWarn}<div class="mt-0.5 text-main">${escapeHtml(sample)} → <b>${escapeHtml(res.translated)}</b></div>${res.altTranslated ? `<div class="mt-0.5 text-mut">💡 ${isZh ? '参考译文' : '다른 번역'}: ${escapeHtml(res.altTranslated)}</div>` : ''}`;
                } else {
                  testBox.textContent = isZh ? '⚠️ 暂时无法连接翻译服务器，请稍后再试' : '⚠️ 번역 서버 응답이 지연되고 있어요. 잠시 후 다시 시도해 주세요';
                }
              }
            } catch (_) {
              if (testBox) testBox.textContent = isZh ? '⚠️ 测试失败，请检查密钥或网络' : '⚠️ 테스트에 실패했어요. API 키나 네트워크를 확인해 주세요';
            } finally {
              testBtn.disabled = false;
            }
          });
        }
        setTimeout(syncGeminiKeyUi, 500);
      })();

      /* ==================== SHARE COUPLE SPACE WRITTEN ITEMS DIRECTLY TO MESSENGER ==================== */
      document.addEventListener('click', async (ev) => {
        const btn = ev.target && ev.target.closest ? ev.target.closest('.cw-share-chat-item-btn') : null;
        if (!btn) return;
        ev.preventDefault();
        ev.stopPropagation();
        const stype = btn.getAttribute('data-stype') || '';
        const sid = btn.getAttribute('data-sid') || '';
        if (!stype || !sid) return;
        let koText = '', zhText = '', toneLbl = '💌 커플공간 공유';
        const pickPair = (orig, tr) => {
          const o = String(orig || '').trim();
          const t = String(tr || '').trim();
          const oIsZh = /[\u4e00-\u9fff]/.test(o) && !/[가-힣]/.test(o);
          return { ko: oIsZh ? (t || o) : o, zh: oIsZh ? o : (t || o) };
        };
        if (stype === 'diary') {
          const d = (state.diaries || []).find(x => x && x.id === sid);
          if (!d) return;
          const tp = pickPair(d.title, d.titleTranslated);
          const cp = pickPair(d.content, d.translated);
          koText = `🪶 [일기 공유] ${tp.ko ? tp.ko + ' — ' : ''}${cp.ko}`;
          zhText = `🪶 [日记分享] ${tp.zh ? tp.zh + ' — ' : ''}${cp.zh}`;
          toneLbl = '🪶 일기 공유';
        } else if (stype === 'memo') {
          const m = (state.memos || []).find(x => x && x.id === sid);
          if (!m) return;
          const p = pickPair(m.text, m.translated);
          koText = `📝 [메모 공유] ${p.ko}`;
          zhText = `📝 [备忘分享] ${p.zh}`;
          toneLbl = '📝 메모 공유';
        } else if (stype === 'qa') {
          const a = (state.chat?.qaAnswers || []).find(x => x && x.id === sid);
          if (!a) return;
          const p = pickPair(a.original, a.translated);
          koText = `💌 [커플 문답] ${p.ko}`;
          zhText = `💌 [情侣问答] ${p.zh}`;
          toneLbl = '💌 문답 공유';
        } else if (stype === 'jar') {
          const j = (state.complimentJar || []).find(x => x && x.id === sid);
          if (!j) return;
          const p = pickPair(j.text, j.translated);
          koText = `✨ [칭찬 유리병] ${p.ko}`;
          zhText = `✨ [夸夸玻璃瓶] ${p.zh}`;
          toneLbl = '✨ 칭찬병 공유';
        } else if (stype === 'truthdare') {
          const td = (state.truthDare?.history || []).find(x => x && x.id === sid);
          if (!td) return;
          const p = pickPair(td.text, td.translated);
          const qKo = td.cardKo ? `(${td.cardKo}) ` : '';
          const qZh = td.cardZh ? `(${td.cardZh}) ` : '';
          koText = `🃏 [진실·도전] ${qKo}${p.ko}`;
          zhText = `🃏 [真心话大冒险] ${qZh}${p.zh}`;
          toneLbl = '🃏 진실·도전 공유';
        }
        if (!koText && !zhText) return;
        await shareQuickMessageToChat(koText, zhText, toneLbl);
        setTimeout(() => {
          const ci = document.getElementById('chatInput');
          if (ci) ci.focus();
        }, 220);
      });

      init();
    })();
;
(function initPartnerIntentPolish() {
    if (window.__cwPartnerPolishReady) return;
    window.__cwPartnerPolishReady = true;
    const CACHE_KEY = 'cw_polish_cache_v2';

    function loadCache() { try { return JSON.parse(localStorage.getItem(CACHE_KEY) || '{}') || {}; } catch (_) { return {}; } }
    function saveCache(obj) {
      try {
        const ks = Object.keys(obj);
        if (ks.length > 150) ks.slice(0, ks.length - 120).forEach(k => delete obj[k]);
        localStorage.setItem(CACHE_KEY, JSON.stringify(obj));
      } catch (_) {}
    }
    function esc(s) {
      return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }
    async function fetchT(url, opts, ms) {
      const c = typeof AbortController !== 'undefined' ? new AbortController() : null;
      const t = c ? setTimeout(() => c.abort(), ms || 4800) : null;
      try { return await fetch(url, Object.assign({}, opts || {}, c ? { signal: c.signal } : {})); }
      finally { if (t) clearTimeout(t); }
    }

    async function analyzePartnerSentence(rawText, lang) {
      const clean = String(rawText || '').trim();
      if (!clean) return null;
      const ck = `${lang}|${clean}`;
      const cache = loadCache();
      if (cache[ck] && cache[ck].natural) return cache[ck];

      // 1. Gemini 2.5 Flash (uses saved API key from Settings for best nuance & intent understanding!)
      const gKey = (typeof window.__getActiveGeminiKey === 'function' ? window.__getActiveGeminiKey() : (localStorage.getItem('cw_gemini_api_key_v1') || '')).trim();
      if (gKey) {
        try {
          const stNow = window.__cwBridge && window.__cwBridge.getState ? window.__cwBridge.getState() : null;
          const readerIsZh = !!(stNow && (stNow.lang === 'zh' || stNow.myRole === 'jingchan'));
          const prompt = !readerIsZh
            ? (lang === 'ko'
              ? `중국인 연인(징찬)이 한국어를 배우며 보낸 메시지예요. 문법이나 어순이 어색할 수 있어요. 한국인 남자친구(수완)가 오해 없이 원래 의도를 단번에 이해할 수 있도록 JSON만 반환하세요(哥哥/오빠 호칭 유지): {"natural":"가장 자연스러운 한국어 문장","intent":"원래 말하려던 의도와 뉘앙스 풀이 (1~2문장, 부드럽게)","tip":"징찬에게 다정하게 알려줄 수 있는 짧은 한국어 표현 팁 (없으면 빈 문자열)"}. 원문: ${clean}`
              : `중국인 연인(징찬)이 중국어로 보낸 메시지예요. 한국인 남자친구(수완)가 직역이 아닌 실제 연인 간 속뜻과 다정한 뉘앙스까지 단번에 이해할 수 있도록 JSON만 반환하세요(哥哥는 반드시 '오빠'로 번역): {"natural":"가장 자연스럽고 다정한 한국어 뜻","intent":"중국어 표현의 속뜻·맥락·감정 풀이 (1~2문장)","tip":"원문에서 알아두면 좋은 핵심 중국어 표현 1가지 (없으면 빈 문자열)"}. 원문: ${clean}`)
            : (lang === 'zh'
              ? `韩国恋人(秀完)用中文发来的消息，可能语序或用词略微生硬。请帮中国女友(靖灿)一眼看懂原本意思，只返回严格 JSON: {"natural":"最自然的中文表达","intent":"原本想表达的意思和语气说明(1-2句)","tip":"可以温柔教给对方的一句地道中文(没有就留空)"}。原文: ${clean}`
              : `韩国恋人(秀完)用韩语发来的消息。请帮中国女友(靖灿)一眼看懂地道含义、语气和隐藏关心，只返回严格 JSON(오빠 必须译为哥哥): {"natural":"最自然温柔的中文意思","intent":"韩语表达的真实语气与语境解析(1-2句)","tip":"顺便学一个实用的韩语小表达(没有就留空)"}。原文: ${clean}`);
          const __discM = (() => { try { return (localStorage.getItem('cw_gemini_active_model_v1') || '').trim(); } catch (_) { return ''; } })();
          const __pModels = [];
          if (__discM) __pModels.push(__discM);
          ['gemini-3.5-flash-lite', 'gemini-3.8-flash', 'gemini-3.6-flash', 'gemini-2.5-flash-lite'].forEach(m => { if (!__pModels.includes(m)) __pModels.push(m); });
          let r = null;
          for (const __pm of __pModels) {
            try {
              r = await fetchT(
                `https://generativelanguage.googleapis.com/v1beta/models/${__pm}:generateContent?key=${encodeURIComponent(gKey)}`,
                {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({
                    contents: [{ parts: [{ text: prompt }] }],
                    generationConfig: { responseMimeType: 'application/json', maxOutputTokens: 260, thinkingConfig: /gemini-3\.5-flash-lite/i.test(__pm) ? { thinkingLevel: 'minimal' } : (/gemini-3\.[68]-flash/i.test(__pm) ? { thinkingLevel: 'low' } : { thinkingBudget: 0 }) }
                  })
                },
                4500
              );
              if (r && r.ok) { try { localStorage.setItem('cw_gemini_active_model_v1', __pm); } catch (_) {} break; }
              if (r && (r.status === 403 || r.status === 401)) break;
            } catch (_) { r = null; }
          }
          if (r && r.ok) {
            const j = await r.json();
            const txt = j?.candidates?.[0]?.content?.parts?.[0]?.text || '';
            const m = txt.match(/\{[\s\S]*\}/);
            if (m) {
              const parsed = JSON.parse(m[0]);
              if (parsed && parsed.natural) {
                const out = {
                  natural: String(parsed.natural).trim(),
                  intent: String(parsed.intent || '').trim(),
                  tip: String(parsed.tip || '').trim()
                };
                cache[ck] = out; saveCache(cache);
                return out;
              }
            }
          }
        } catch (_) {}
      }

      // 2. Free Fallback: Direct natural translation (cross-lang) or Round-trip reconstruction (same-lang)
      try {
        const stFb = window.__cwBridge && window.__cwBridge.getState ? window.__cwBridge.getState() : null;
        const readerIsZhFb = !!(stFb && (stFb.lang === 'zh' || stFb.myRole === 'jingchan'));
        const readerLang = readerIsZhFb ? 'zh-CN' : 'ko';
        const origIsReaderLang = (readerIsZhFb && lang === 'zh') || (!readerIsZhFb && lang === 'ko');
        if (!origIsReaderLang) {
          const rDirect = await fetchT(`https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${readerLang}&dt=t&q=${encodeURIComponent(clean)}`, {}, 3600);
          if (rDirect && rDirect.ok) {
            const dd = await rDirect.json();
            let trTxt = Array.isArray(dd?.[0]) ? dd[0].map(x => x?.[0] || '').join('').trim() : '';
            if (trTxt) {
              if (!readerIsZhFb && /哥哥|欧巴/.test(clean)) trTxt = trTxt.replace(/형님/g, '오빠').replace(/형아/g, '오빠');
              if (readerIsZhFb && /오빠/.test(clean)) trTxt = trTxt.replace(/我?弟弟|兄弟|老兄/g, '哥哥');
              const out = {
                natural: trTxt,
                intent: !readerIsZhFb
                  ? '중국어 원문의 의미를 한국어로 자연스럽게 풀어낸 뜻이에요. (설정에 Gemini 키가 있으면 속뜻·뉘앙스까지 더 정교하게 설명해 줘요)'
                  : '已将韩语原文自然转译为中文含义（配置 Gemini 密钥可获得更细腻的语境解析）。',
                tip: ''
              };
              cache[ck] = out; saveCache(cache);
              return out;
            }
          }
        } else {
          const midLang = lang === 'ko' ? 'zh-CN' : 'ko';
          const backLang = lang === 'ko' ? 'ko' : 'zh-CN';
          const r1 = await fetchT(`https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${midLang}&dt=t&q=${encodeURIComponent(clean)}`, {}, 3600);
          if (r1 && r1.ok) {
            const d1 = await r1.json();
            const midTxt = Array.isArray(d1?.[0]) ? d1[0].map(x => x?.[0] || '').join('').trim() : '';
            if (midTxt) {
              const r2 = await fetchT(`https://translate.googleapis.com/translate_a/single?client=gtx&sl=${midLang}&tl=${backLang}&dt=t&q=${encodeURIComponent(midTxt)}`, {}, 3600);
              if (r2 && r2.ok) {
                const d2 = await r2.json();
                const backTxt = Array.isArray(d2?.[0]) ? d2[0].map(x => x?.[0] || '').join('').trim() : '';
                if (backTxt) {
                  const out = {
                    natural: backTxt,
                    intent: lang === 'ko'
                      ? `중국어 의미(${midTxt}) 기준으로 자연스럽게 다시 풀어낸 문장이에요.`
                      : `结合韩语语义（${midTxt}）还原出的更自然表达。`,
                    tip: ''
                  };
                  cache[ck] = out; saveCache(cache);
                  return out;
                }
              }
            }
          }
        }
      } catch (_) {}
      return null;
    }

    document.addEventListener('click', async (e) => {
      const btn = e.target.closest('.cw-msg-polish-btn');
      if (!btn) return;
      e.stopPropagation();
      const msgId = btn.getAttribute('data-id');
      const orig = btn.getAttribute('data-orig') || '';
      const lang = btn.getAttribute('data-lang') || 'ko';
      const bubble = btn.closest('.cw-msg-bubble');
      const box = bubble ? bubble.querySelector('.cw-msg-polish-box') : null;
      if (!box) return;

      const st = window.__cwBridge && window.__cwBridge.getState ? window.__cwBridge.getState() : null;
      const isZh = !!(st && st.lang === 'zh');
      const msgObj = (st && st.chat && Array.isArray(st.chat.messages)) ? st.chat.messages.find(x => x.id === msgId) : null;

      if (!box.classList.contains('hidden') && box.dataset.loaded === '1') {
        box.classList.add('hidden');
        if (msgObj) msgObj.polishOpen = false;
        return;
      }
      box.classList.remove('hidden');
      const renderBox = (obj) => {
        box.dataset.loaded = '1';
        box.innerHTML = `
          <div>✨ <b>${isZh ? '自然表达' : '자연스러운 뜻'}:</b> ${esc(obj.natural)}</div>
          ${obj.intent ? `<div class="text-[10px] opacity-85">💬 ${esc(obj.intent)}</div>` : ''}
          ${obj.tip ? `<div class="text-[10px] opacity-80">💡 ${esc(obj.tip)}</div>` : ''}
        `;
        if (typeof window.syncAllTabIconsToStyle === 'function') window.syncAllTabIconsToStyle(null, box);
      };

      if (msgObj && msgObj.polishObj && msgObj.polishObj.natural) {
        msgObj.polishOpen = true;
        renderBox(msgObj.polishObj);
        return;
      }
      box.innerHTML = `<div class="opacity-80">⏳ ${isZh ? '正在分析自然语义...' : '원래 의도와 자연스러운 뜻 분석 중...'}</div>`;
      let res = await analyzePartnerSentence(orig, lang);
      if ((!res || !res.natural) && msgObj && (msgObj.translated || msgObj.altTranslated)) {
        const fbNat = msgObj.altTranslated || msgObj.translated;
        const fbInt = msgObj.nuance || (isZh ? '已结合当前翻译为您整理自然表达。' : '현재 번역과 문맥을 바탕으로 풀어낸 자연스러운 뜻이에요.');
        res = { natural: fbNat, intent: fbInt, tip: '' };
      }
      if (res && res.natural) {
        if (msgObj) { msgObj.polishObj = res; msgObj.polishOpen = true; }
        renderBox(res);
      } else {
        box.innerHTML = `<div class="opacity-80">⚠️ ${isZh ? '暂时无法解析，请稍后再试' : '뜻풀이를 불러오지 못했어요. 잠시 후 다시 눌러주세요'}</div>`;
      }
    });
  })();
;
(function initPartnerStatusPillOnly() {
    if (window.__cwQuickStatusReady) return;
    window.__cwQuickStatusReady = true;

    function syncPartnerStatusPill() {
      if (window.__isActivelyTyping && window.__isActivelyTyping()) return;
      const st = window.__cwBridge && window.__cwBridge.getState ? window.__cwBridge.getState() : null;
      if (!st || !st.profile) return;
      const isZh = st.lang === 'zh';
      const myRole = st.myRole || 'suwan';
      const partnerKey = myRole === 'suwan' ? 'jingchanMood' : 'suwanMood';
      const partnerVal = String(st.profile[partnerKey] || '');
      const pill = document.getElementById('chatPartnerStatusPill');
      if (pill) {
        const cleanPartner = partnerVal ? (isZh ? (partnerVal.split('·')[1] || partnerVal).trim() : partnerVal.split('·')[0].trim()) : '';
        if (pill.dataset.cwLastMood === cleanPartner) return;
        pill.dataset.cwLastMood = cleanPartner;
        if (cleanPartner) {
          pill.textContent = cleanPartner;
          pill.classList.remove('hidden');
          if (typeof window.syncAllTabIconsToStyle === 'function') window.syncAllTabIconsToStyle(null, pill);
        } else {
          pill.classList.add('hidden');
        }
      }
    }

    window.__syncQuickStatusUi = syncPartnerStatusPill;
    setTimeout(syncPartnerStatusPill, 400);
    setInterval(syncPartnerStatusPill, 8000);
    ['suwanMoodSelect', 'jingchanMoodSelect'].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.addEventListener('change', () => setTimeout(syncPartnerStatusPill, 60));
    });
  })();
;
(function initTwoSecondLongPressCopy() {
    if (window.__cwLongPressCopyReady) return;
    window.__cwLongPressCopyReady = true;

    let lpTimer = null;
    let startX = 0, startY = 0;
    let targetEl = null;

    function cancelLp() {
      if (lpTimer) { clearTimeout(lpTimer); lpTimer = null; }
      targetEl = null;
    }

    function extractCopyableText(el) {
      if (!el || el.nodeType !== 1) return '';
      // Skip interactive form inputs, buttons, nav docks, sliders, etc.
      if (el.closest('input, textarea, select, option, button, a, nav, header, .cw-emoji-drawer, #cwUniversalEmojiTray')) return '';
      // Find the tightest readable text block
      const candidate = el.closest('.cw-keep-native-emoji, .cw-nuance-detail, .cw-msg-polish-box, .nuance-box, .royal-subcard, .royal-card, p, h1, h2, h3, h4, div, span') || el;
      const clone = candidate.cloneNode(true);
      clone.querySelectorAll('button, svg, script, style').forEach(n => n.remove());
      const txt = String(clone.innerText || clone.textContent || '').replace(/\s+/g, ' ').trim();
      if (!txt || txt.length < 2 || txt.length > 1500) return '';
      return txt;
    }

    async function doCopyText(txt, el) {
      let ok = false;
      try {
        if (navigator.clipboard && navigator.clipboard.writeText) {
          await navigator.clipboard.writeText(txt);
          ok = true;
        }
      } catch (_) {}
      if (!ok) {
        try {
          const ta = document.createElement('textarea');
          ta.value = txt;
          ta.style.cssText = 'position:fixed;top:-9999px;left:-9999px;opacity:0;';
          document.body.appendChild(ta);
          ta.focus(); ta.select();
          ok = document.execCommand('copy');
          document.body.removeChild(ta);
        } catch (_) {}
      }
      if (ok) {
        try { if (navigator.vibrate) navigator.vibrate(45); } catch (_) {}
        if (el && el.style) {
          const prevOutline = el.style.outline;
          el.style.outline = '2px solid var(--accent-royal)';
          el.style.outlineOffset = '2px';
          setTimeout(() => { try { el.style.outline = prevOutline || ''; el.style.outlineOffset = ''; } catch (_) {} }, 550);
        }
        const st = window.__cwBridge && window.__cwBridge.getState ? window.__cwBridge.getState() : null;
        const isZh = !!(st && st.lang === 'zh');
        const preview = txt.length > 26 ? txt.slice(0, 26) + '…' : txt;
        if (window.__cwBridge && window.__cwBridge.showToast) {
          window.__cwBridge.showToast(isZh ? `📋 已自动复制：「${preview}」` : `📋 자동 복사 완료! "${preview}"`);
        }
      }
    }

    document.addEventListener('pointerdown', (e) => {
      if (e.button && e.button !== 0) return;
      cancelLp();
      const t = e.target;
      if (!t || t.tagName === 'TEXTAREA' || t.tagName === 'INPUT' || t.tagName === 'BUTTON') return;
      const txt = extractCopyableText(t);
      if (!txt) return;
      startX = e.clientX || 0;
      startY = e.clientY || 0;
      targetEl = e.target;
      lpTimer = setTimeout(() => {
        const el = targetEl;
        lpTimer = null;
        targetEl = null;
        doCopyText(txt, el);
      }, 2000);
    }, { passive: true });

    document.addEventListener('pointermove', (e) => {
      if (!lpTimer) return;
      const dx = Math.abs((e.clientX || 0) - startX);
      const dy = Math.abs((e.clientY || 0) - startY);
      if (dx > 10 || dy > 10) cancelLp();
    }, { passive: true });

    document.addEventListener('pointerup', cancelLp, { passive: true });
    document.addEventListener('pointercancel', cancelLp, { passive: true });
    document.addEventListener('scroll', cancelLp, { passive: true, capture: true });
  })();
;
(function initMakerModeController() {
    if (window.__cwMakerModeReady) return;
    window.__cwMakerModeReady = true;

    const MAKER_KEY = 'cw_maker_layout_v1';
    const DEFAULT_CARDS = ['profile', 'translator', 'missions', 'lovetemp', 'lavender', 'widgets', 'weekly'];
    const DEFAULT_STUDY = ['today', 'quiz', 'cheat', 'chatbook', 'review', 'games'];
    const DEFAULT_SPACE = ['record', 'memory', 'promise', 'play'];
    const DEFAULT_SPACESUBS = ['diary', 'qa', 'balance', 'tmi', 'album', 'voice', 'capsule', 'jar', 'calendar', 'bucket', 'datemap', 'coupon', 'anniv-jump', 'food', 'fortune', 'quiz', 'drawquiz', 'rps', 'truthdare'];
    const DEFAULT_SETTINGS = ['role', 'font', 'theme', 'icon', 'notif', 'ai', 'maker', 'heal', 'backup'];
    const DEFAULT_DOCK = ['home', 'learn', 'translator', 'diary', 'settings'];
    const SCOPE_DEFS = {
      home: {
        orderKey: 'cardOrder', hiddenKey: 'hiddenCards', defaults: DEFAULT_CARDS, canHide: true, lockHide: [],
        labels: {
          profile: { ko: '💑 커플 프로필·기분', zh: '💑 情侣主页·状态' },
          translator: { ko: '🌐 빠른 한·중 번역기', zh: '🌐 快捷中韩翻译' },
          missions: { ko: '💓 하트비트 · 포옹/미션', zh: '💓 心跳 · 抱抱/任务' },
          lovetemp: { ko: '🌡️ 우리 사랑 온도', zh: '🌡️ 我们的恋爱温度' },
          lavender: { ko: '🪴 라벤더 화분 키우기', zh: '🪴 薰衣草小盆栽' },
          widgets: { ko: '📚 오늘의 표현·학습 요약', zh: '📚 今日表达·学习打卡' },
          weekly: { ko: '📊 주간 커플 리포트', zh: '📊 本周情侣周报' }
        }
      },
      study: {
        orderKey: 'studyOrder', hiddenKey: 'hiddenStudy', defaults: DEFAULT_STUDY, canHide: true, lockHide: [],
        labels: {
          today: { ko: '🌷 오늘의 표현', zh: '🌷 今日表达' },
          quiz: { ko: '✏️ 단계별 퀴즈', zh: '✏️ 分级测验' },
          cheat: { ko: '📖 만능 회화책', zh: '📖 万能会话书' },
          chatbook: { ko: '💬 우리 대화', zh: '💬 聊天学韩语' },
          review: { ko: '📌 오답 노트', zh: '📌 错题复习本' },
          games: { ko: '🎮 미니게임', zh: '🎮 趣味小游戏' }
        }
      },
      space: {
        orderKey: 'spaceOrder', hiddenKey: 'hiddenSpace', defaults: DEFAULT_SPACE, canHide: true, lockHide: [],
        labels: {
          record: { ko: '📖 기록 (일기·문답·밸런스·취향)', zh: '📖 记录 (日记·问答·二选一)' },
          memory: { ko: '💌 추억 (앨범·음성·캡슐·칭찬병)', zh: '💌 回忆 (相册·语音·胶囊)' },
          promise: { ko: '✨ 약속 (캘린더·위시·데이트·쿠폰)', zh: '✨ 约定 (日历·心愿·约会)' },
          play: { ko: '🎲 놀이 (뭐먹지·운세·퀴즈·게임)', zh: '🎲 互动 (吃什么·运势·游戏)' }
        }
      },
      spacesubs: {
        orderKey: 'spaceSubsOrder', hiddenKey: 'hiddenSpaceSubs', defaults: DEFAULT_SPACESUBS, canHide: true, lockHide: [],
        labels: {
          diary: { ko: '🪶 일기·메모 (기록)', zh: '🪶 日记·备忘 (记录)' },
          qa: { ko: '💌 커플 문답 (기록)', zh: '💌 情侣问答 (记录)' },
          balance: { ko: '⚖️ 밸런스 게임 (기록)', zh: '⚖️ 二选一 (记录)' },
          tmi: { ko: '📝 취향사전 (기록)', zh: '📝 喜好百科 (记录)' },
          album: { ko: '🖼️ 커플 앨범 (추억)', zh: '🖼️ 情侣相册 (回忆)' },
          voice: { ko: '🎙️ 음성편지 (추억)', zh: '🎙️ 语音信箱 (回忆)' },
          capsule: { ko: '⏳ 타임캡슐 (추억)', zh: '⏳ 时间胶囊 (回忆)' },
          jar: { ko: '✨ 칭찬병 (추억)', zh: '✨ 夸夸瓶 (回忆)' },
          calendar: { ko: '📅 캘린더 (약속)', zh: '📅 日历 (约定)' },
          bucket: { ko: '🦋 위시리스트 (약속)', zh: '🦋 心愿单 (约定)' },
          datemap: { ko: '🗺️ 데이트 도장 (약속)', zh: '🗺️ 约会打卡 (约定)' },
          coupon: { ko: '🎟️ 애정 쿠폰 (약속)', zh: '🎟️ 爱心券 (约定)' },
          'anniv-jump': { ko: '💝 기념일 (약속)', zh: '💝 纪念日 (约定)' },
          food: { ko: '🍜 뭐먹지 룰렛 (놀이)', zh: '🍜 吃什么转盘 (互动)' },
          fortune: { ko: '🔮 커플 운세 (놀이)', zh: '🔮 情侣运势 (互动)' },
          quiz: { ko: '💌 미니퀴즈 (놀이)', zh: '💌 小测验 (互动)' },
          drawquiz: { ko: '🎨 그림퀴즈 (놀이)', zh: '🎨 你画我猜 (互动)' },
          rps: { ko: '✊ 가위바위보 (놀이)', zh: '✊ 石头剪刀布 (互动)' },
          truthdare: { ko: '🃏 진실·도전 (놀이)', zh: '🃏 真心话大冒险 (互动)' }
        }
      },
      settings: {
        orderKey: 'settingsOrder', hiddenKey: 'hiddenSettings', defaults: DEFAULT_SETTINGS, canHide: true, lockHide: ['maker'],
        labels: {
          role: { ko: '👤 내 프로필 모드 (수완/징찬)', zh: '👤 身份模式切换' },
          font: { ko: '🔤 글꼴 & 글자 크기', zh: '🔤 字体与字号' },
          theme: { ko: '🎨 디자인 테마 (9종)', zh: '🎨 主题配色 (9种)' },
          icon: { ko: '🖼️ 앱 아이콘 그림체', zh: '🖼️ 图标风格模式' },
          notif: { ko: '📱 알림·다운로드·중국 설정', zh: '📱 通知·安装·中国直连' },
          ai: { ko: '🌐 한·중 AI 번역 설정', zh: '🌐 中韩 AI 翻译设置' },
          maker: { ko: '📐 메이커 모드 (숨김 잠금)', zh: '📐 创客模式 (不可隐藏)' },
          heal: { ko: '🛠️ 앱 자가 복구 & 오류 메모', zh: '🛠️ 自愈修复与错误备忘' },
          backup: { ko: '🛡️ 안전 보관 & JSON 백업', zh: '🛡️ 安全保管与备份' }
        }
      },
      dock: {
        orderKey: 'dockOrder', hiddenKey: 'hiddenDock', defaults: DEFAULT_DOCK, canHide: false, lockHide: DEFAULT_DOCK,
        labels: {
          home: { ko: '🏠 Home (홈)', zh: '🏠 首页 (Home)' },
          learn: { ko: '📚 Study (공부)', zh: '📚 学习 (Study)' },
          translator: { ko: '💬 CW Talk (메신저)', zh: '💬 聊天 (CW Talk)' },
          diary: { ko: '💜 Space (커플공간)', zh: '💜 空间 (Space)' },
          settings: { ko: '⚙️ Setting (설정)', zh: '⚙️ 设置 (Setting)' }
        }
      }
    };
    let activeScope = 'home';
    const ACCENT_MAP = {
      lavender: { main: '#7c3aed', soft: 'rgba(124,58,237,0.13)', border: 'rgba(124,58,237,0.34)' },
      rose:     { main: '#e11d48', soft: 'rgba(225,29,72,0.13)',  border: 'rgba(225,29,72,0.34)' },
      sky:      { main: '#0284c7', soft: 'rgba(2,132,199,0.13)',  border: 'rgba(2,132,199,0.34)' },
      emerald:  { main: '#059669', soft: 'rgba(5,150,105,0.13)',  border: 'rgba(5,150,105,0.34)' },
      gold:     { main: '#d97706', soft: 'rgba(217,119,6,0.14)',  border: 'rgba(217,119,6,0.34)' }
    };
    const DEFAULT_MAKER = {
      cardGap: 14,
      pagePadX: 12,
      cardPad: 16,
      cardRadius: 24,
      fontScale: 100,
      bubbleRadius: 18,
      chatFontSize: 13.5,
      bubbleMaxW: 84,
      showToneBox: true,
      showPron: true,
      showAltTrans: true,
      centerControls: false,
      chatStatusAlign: 'left',
      showEnergy: false,
      accentOverride: 'default',
      shadowLevel: 1,
      borderWidth: 1,
      headerCompact: false,
      showDockLabels: true,
      cardOrder: [...DEFAULT_CARDS],
      hiddenCards: [],
      studyOrder: [...DEFAULT_STUDY],
      hiddenStudy: [],
      spaceOrder: [...DEFAULT_SPACE],
      hiddenSpace: [],
      spaceSubsOrder: [...DEFAULT_SPACESUBS],
      hiddenSpaceSubs: [],
      settingsOrder: [...DEFAULT_SETTINGS],
      hiddenSettings: [],
      dockOrder: [...DEFAULT_DOCK],
      hiddenDock: [],
      updatedAt: 0
    };
    const MAKER_PRESETS = {
      default: { cardGap: 14, pagePadX: 12, cardPad: 16, cardRadius: 24, fontScale: 100, bubbleRadius: 18, chatFontSize: 13.5, bubbleMaxW: 84, shadowLevel: 1, borderWidth: 1, headerCompact: false },
      compact: { cardGap: 10, pagePadX: 8,  cardPad: 12, cardRadius: 18, fontScale: 94,  bubbleRadius: 14, chatFontSize: 12.5, bubbleMaxW: 88, shadowLevel: 0, borderWidth: 1, headerCompact: true },
      airy:    { cardGap: 20, pagePadX: 18, cardPad: 20, cardRadius: 26, fontScale: 104, bubbleRadius: 22, chatFontSize: 14.5, bubbleMaxW: 82, shadowLevel: 2, borderWidth: 1, headerCompact: false },
      soft:    { cardGap: 16, pagePadX: 14, cardPad: 18, cardRadius: 30, fontScale: 100, bubbleRadius: 24, chatFontSize: 13.5, bubbleMaxW: 84, shadowLevel: 2, borderWidth: 1.5, headerCompact: false }
    };

    function sanitizeMaker(raw) {
      const src = (raw && typeof raw === 'object') ? raw : {};
      const cleanOrder = (arr, defs) => {
        const out = Array.isArray(arr) ? [...new Set(arr.filter(k => defs.includes(k)))] : [...defs];
        defs.forEach(k => { if (!out.includes(k)) out.push(k); });
        return out;
      };
      const cleanHidden = (arr, defs, locks) => Array.isArray(arr)
        ? [...new Set(arr.filter(k => defs.includes(k) && !(locks || []).includes(k)))]
        : [];
      const order = cleanOrder(src.cardOrder, DEFAULT_CARDS);
      const hidden = cleanHidden(src.hiddenCards, DEFAULT_CARDS, []);
      return {
        cardGap: Math.min(24, Math.max(8, Number(src.cardGap) || 14)),
        pagePadX: Math.min(24, Math.max(6, Number(src.pagePadX) || 12)),
        cardPad: Math.min(24, Math.max(10, Number(src.cardPad) || 16)),
        cardRadius: Math.min(32, Math.max(12, Number(src.cardRadius) || 24)),
        fontScale: Math.min(112, Math.max(90, Number(src.fontScale) || 100)),
        bubbleRadius: Math.min(26, Math.max(10, Number(src.bubbleRadius) || 18)),
        chatFontSize: Math.min(17, Math.max(12, Number(src.chatFontSize) || 13.5)),
        bubbleMaxW: Math.min(92, Math.max(74, Number(src.bubbleMaxW) || 84)),
        showToneBox: src.showToneBox !== false,
        showPron: src.showPron !== false,
        showAltTrans: src.showAltTrans !== false,
        centerControls: !!src.centerControls,
        chatStatusAlign: src.chatStatusAlign === 'center' ? 'center' : 'left',
        showEnergy: !!src.showEnergy,
        accentOverride: ACCENT_MAP[src.accentOverride] ? src.accentOverride : 'default',
        shadowLevel: [0, 1, 2].includes(Number(src.shadowLevel)) ? Number(src.shadowLevel) : 1,
        borderWidth: [1, 1.5, 2].includes(Number(src.borderWidth)) ? Number(src.borderWidth) : 1,
        headerCompact: !!src.headerCompact,
        showDockLabels: src.showDockLabels !== false,
        cardOrder: order,
        hiddenCards: hidden,
        studyOrder: cleanOrder(src.studyOrder, DEFAULT_STUDY),
        hiddenStudy: cleanHidden(src.hiddenStudy, DEFAULT_STUDY, []),
        spaceOrder: cleanOrder(src.spaceOrder, DEFAULT_SPACE),
        hiddenSpace: cleanHidden(src.hiddenSpace, DEFAULT_SPACE, []),
        spaceSubsOrder: cleanOrder(src.spaceSubsOrder, DEFAULT_SPACESUBS),
        hiddenSpaceSubs: cleanHidden(src.hiddenSpaceSubs, DEFAULT_SPACESUBS, []),
        settingsOrder: cleanOrder(src.settingsOrder, DEFAULT_SETTINGS),
        hiddenSettings: cleanHidden(src.hiddenSettings, DEFAULT_SETTINGS, ['maker']),
        dockOrder: cleanOrder(src.dockOrder, DEFAULT_DOCK),
        hiddenDock: [],
        updatedAt: Number(src.updatedAt || 0)
      };
    }

    function loadLocalMaker() {
      try {
        const saved = JSON.parse(localStorage.getItem(MAKER_KEY) || 'null');
        if (saved && typeof saved === 'object') return sanitizeMaker(saved);
      } catch (_) {}
      const st = window.__cwBridge && window.__cwBridge.getState ? window.__cwBridge.getState() : null;
      if (st && st.makerLayout) return sanitizeMaker(st.makerLayout);
      return sanitizeMaker(DEFAULT_MAKER);
    }

    let currentMaker = loadLocalMaker();

    function applyMakerLayout(cfg, skipSync) {
      currentMaker = sanitizeMaker(cfg);
      try { localStorage.setItem(MAKER_KEY, JSON.stringify(currentMaker)); } catch (_) {}
      const root = document.documentElement;
      const body = document.body;
      body.setAttribute('data-maker-active', '1');
      root.style.setProperty('--mk-card-gap', currentMaker.cardGap + 'px');
      root.style.setProperty('--mk-page-px', currentMaker.pagePadX + 'px');
      root.style.setProperty('--mk-card-pad', currentMaker.cardPad + 'px');
      root.style.setProperty('--mk-card-radius', currentMaker.cardRadius + 'px');
      root.style.setProperty('--mk-bubble-radius', currentMaker.bubbleRadius + 'px');
      root.style.setProperty('--mk-chat-fs', currentMaker.chatFontSize + 'px');
      root.style.setProperty('--mk-bubble-maxw', currentMaker.bubbleMaxW + '%');
      root.style.setProperty('--mk-border-w', currentMaker.borderWidth + 'px');
      root.style.fontSize = currentMaker.fontScale === 100 ? '' : (currentMaker.fontScale + '%');

      const acc = ACCENT_MAP[currentMaker.accentOverride];
      if (acc) {
        root.style.setProperty('--accent-royal', acc.main);
        root.style.setProperty('--accent-royal-soft', acc.soft);
        root.style.setProperty('--border-accent', acc.border);
      } else {
        root.style.removeProperty('--accent-royal');
        root.style.removeProperty('--accent-royal-soft');
        root.style.removeProperty('--border-accent');
      }

      body.setAttribute('data-maker-center', currentMaker.centerControls ? '1' : '0');
      body.setAttribute('data-maker-chat-align', currentMaker.chatStatusAlign);
      body.setAttribute('data-maker-energy', currentMaker.showEnergy ? '1' : '0');
      body.setAttribute('data-maker-tonebox', currentMaker.showToneBox ? '1' : '0');
      body.setAttribute('data-maker-pron', currentMaker.showPron ? '1' : '0');
      body.setAttribute('data-maker-alt', currentMaker.showAltTrans ? '1' : '0');
      body.setAttribute('data-maker-shadow', String(currentMaker.shadowLevel));
      body.setAttribute('data-maker-header-compact', currentMaker.headerCompact ? '1' : '0');
      body.setAttribute('data-maker-dock-labels', currentMaker.showDockLabels ? '1' : '0');

      const homeSec = document.getElementById('tab-home');
      if (homeSec) {
        currentMaker.cardOrder.forEach((key, idx) => {
          const el = homeSec.querySelector(`[data-home-card="${key}"]`);
          if (!el) return;
          el.style.order = String(idx + 1);
          el.style.display = currentMaker.hiddenCards.includes(key) ? 'none' : '';
        });
      }
      const studyGrid = document.getElementById('studySubtabGrid');
      if (studyGrid) {
        currentMaker.studyOrder.forEach((key, idx) => {
          const el = studyGrid.querySelector(`.learn-subtab[data-subtab="${key}"]`);
          if (!el) return;
          el.style.order = String(idx + 1);
          el.style.display = currentMaker.hiddenStudy.includes(key) ? 'none' : '';
        });
      }
      const diarySec = document.getElementById('tab-diary');
      if (diarySec) {
        currentMaker.spaceOrder.forEach((key, idx) => {
          const el = diarySec.querySelector(`.couple-cat-btn[data-couple-cat="${key}"]`);
          if (!el) return;
          el.style.order = String(idx + 1);
          el.style.display = currentMaker.hiddenSpace.includes(key) ? 'none' : '';
        });
        const subBar = document.getElementById('coupleSubtabBar');
        if (subBar) {
          currentMaker.spaceSubsOrder.forEach((key, idx) => {
            const el = subBar.querySelector(`.diary-subtab[data-subtab="${key}"]`);
            if (!el) return;
            el.style.order = String(idx + 1);
            if (currentMaker.hiddenSpaceSubs.includes(key)) el.setAttribute('data-mk-hidden', '1');
            else el.removeAttribute('data-mk-hidden');
          });
        }
      }
      const setSec = document.getElementById('tab-settings');
      if (setSec) {
        currentMaker.settingsOrder.forEach((key, idx) => {
          const el = setSec.querySelector(`[data-setting-card="${key}"]`);
          if (!el) return;
          el.style.order = String(idx + 1);
          el.style.display = (key !== 'maker' && currentMaker.hiddenSettings.includes(key)) ? 'none' : '';
        });
      }
      const dockGrid = document.querySelector('.dock-grid');
      if (dockGrid) {
        currentMaker.dockOrder.forEach((key, idx) => {
          const el = dockGrid.querySelector(`.dock-item[data-tab="${key}"]`);
          if (!el) return;
          el.style.order = String(idx + 1);
        });
      }

      syncMakerDrawerUi();

      if (!skipSync) {
        const st = window.__cwBridge && window.__cwBridge.getState ? window.__cwBridge.getState() : null;
        if (st) {
          currentMaker.updatedAt = Date.now();
          st.makerLayout = { ...currentMaker };
          try { localStorage.setItem(MAKER_KEY, JSON.stringify(currentMaker)); } catch (_) {}
          if (typeof window.__cwBridge.saveState === 'function') window.__cwBridge.saveState(true);
        }
      }
    }
    window.__applyMakerLayout = applyMakerLayout;

    function syncMakerDrawerUi() {
      const st = window.__cwBridge && window.__cwBridge.getState ? window.__cwBridge.getState() : null;
      const isZh = !!(st && st.lang === 'zh');
      const setVal = (id, v) => { const el = document.getElementById(id); if (el) el.value = v; };
      const setTxt = (id, t) => { const el = document.getElementById(id); if (el) el.textContent = t; };

      setTxt('makerDrawerTitle', isZh ? '创客模式全局实时编辑' : '메이커 모드 전체 편집');
      setTxt('makerDrawerResetBtn', isZh ? '🔄 默认值' : '🔄 기본값');
      setTxt('makerDrawerCloseBtn', isZh ? '完成 ✕' : '완료 ✕');
      setTxt('mkTabLayout', isZh ? '📐 排版' : '📐 배치');
      setTxt('mkTabChat', isZh ? '💬 聊天' : '💬 메신저');
      setTxt('mkTabStyle', isZh ? '🎨 风格' : '🎨 스타일');
      setTxt('mkTabHome', isZh ? '🗂️ 各页' : '🗂️ 탭배치');
      setTxt('mkScHome', isZh ? '🏠 首页' : '🏠 홈');
      setTxt('mkScStudy', isZh ? '📚 学习' : '📚 학습');
      setTxt('mkScSpace', isZh ? '💜 分类' : '💜 카테고리');
      setTxt('mkScSubs', isZh ? '🧩 子标签' : '🧩 하위탭');
      setTxt('mkScSet', isZh ? '⚙️ 设置' : '⚙️ 설정');
      setTxt('mkScDock', isZh ? '📌 底部' : '📌 하단바');
      setTxt('mkPreDef', isZh ? '✨ 默认' : '✨ 기본');
      setTxt('mkPreCmp', isZh ? '📱 紧凑' : '📱 컴팩트');
      setTxt('mkPreAir', isZh ? '🛋️ 宽松' : '🛋️ 넉넉');
      setTxt('mkPreSoft', isZh ? '🌸 圆润' : '🌸 감성');

      setTxt('mkLblGap', isZh ? '卡片间距' : '카드 사이 간격');
      setTxt('mkLblPadX', isZh ? '页面左右边距' : '화면 좌우 여백');
      setTxt('mkLblCardPad', isZh ? '卡片内边距' : '카드 안쪽 여백');
      setTxt('mkLblRadius', isZh ? '圆角大小' : '모서리 둥글기');
      setTxt('mkLblFontScale', isZh ? '全局字体比例' : '전체 글자 크기');
      setTxt('mkLblBubbleRad', isZh ? '气泡圆角' : '말풍선 둥글기');
      setTxt('mkLblChatFs', isZh ? '气泡字号' : '말풍선 글자 크기');
      setTxt('mkLblBubbleMaxW', isZh ? '气泡最大宽度' : '말풍선 최대 너비');
      setTxt('mkLblAccent', isZh ? '🎨 主题强调色' : '🎨 포인트 강조 색상');
      setTxt('mkLblHomeOrder', isZh ? '🗂️ 全应用各页卡片/菜单顺序与隐藏（自动同步）' : '🗂️ 전체 탭 카드·메뉴 순서 & 숨기기 (자동 동기화)');

      setVal('mkRangeGap', currentMaker.cardGap); setTxt('mkValGap', currentMaker.cardGap + 'px');
      setVal('mkRangePadX', currentMaker.pagePadX); setTxt('mkValPadX', currentMaker.pagePadX + 'px');
      setVal('mkRangeCardPad', currentMaker.cardPad); setTxt('mkValCardPad', currentMaker.cardPad + 'px');
      setVal('mkRangeRadius', currentMaker.cardRadius); setTxt('mkValRadius', currentMaker.cardRadius + 'px');
      setVal('mkRangeFontScale', currentMaker.fontScale); setTxt('mkValFontScale', currentMaker.fontScale + '%');
      setVal('mkRangeBubbleRad', currentMaker.bubbleRadius); setTxt('mkValBubbleRad', currentMaker.bubbleRadius + 'px');
      setVal('mkRangeChatFs', currentMaker.chatFontSize); setTxt('mkValChatFs', currentMaker.chatFontSize + 'px');
      setVal('mkRangeBubbleMaxW', currentMaker.bubbleMaxW); setTxt('mkValBubbleMaxW', currentMaker.bubbleMaxW + '%');

      setTxt('mkToggleToneBoxBtn', currentMaker.showToneBox ? (isZh ? '💬 语气解析: 显示' : '💬 말투 분석: 표시') : (isZh ? '💬 语气解析: 隐藏' : '💬 말투 분석: 숨김'));
      setTxt('mkTogglePronBtn', currentMaker.showPron ? (isZh ? '🔤 拼音发音: 显示' : '🔤 병음·발음: 표시') : (isZh ? '🔤 拼音发音: 隐藏' : '🔤 병음·발음: 숨김'));
      setTxt('mkToggleAltBtn', currentMaker.showAltTrans ? (isZh ? '💡 参考译文: 显示' : '💡 다른 번역: 표시') : (isZh ? '💡 参考译文: 隐藏' : '💡 다른 번역: 숨김'));
      setTxt('mkToggleChatAlignBtn', currentMaker.chatStatusAlign === 'center' ? (isZh ? '💬 状态栏: 居中' : '💬 상태바: 가운데') : (isZh ? '💬 状态栏: 居左' : '💬 상태바: 왼쪽'));

      const shMap = isZh ? ['无', '柔和', '立体'] : ['없음', '보통', '또렷하게'];
      setTxt('mkToggleShadowBtn', (isZh ? '✨ 卡片阴影: ' : '✨ 그림자: ') + shMap[currentMaker.shadowLevel]);
      setTxt('mkToggleBorderBtn', (isZh ? '🖼️ 边框粗细: ' : '🖼️ 테두리: ') + currentMaker.borderWidth + 'px');
      setTxt('mkToggleHeaderBtn', currentMaker.headerCompact ? (isZh ? '⬆️ 顶部栏: 紧凑' : '⬆️ 상단 헤더: 슬림') : (isZh ? '⬆️ 顶部栏: 标准' : '⬆️ 상단 헤더: 보통'));
      setTxt('mkToggleDockLblBtn', currentMaker.showDockLabels ? (isZh ? '📌 底部文字: 显示' : '📌 하단 탭 글자: 표시') : (isZh ? '📌 底部文字: 隐藏' : '📌 하단 탭 글자: 숨김'));
      setTxt('mkToggleCenterBtn', currentMaker.centerControls ? (isZh ? '🎯 按钮居中: ON' : '🎯 버튼 중앙정렬: ON') : (isZh ? '🎯 按钮居中: OFF' : '🎯 버튼 중앙정렬: OFF'));
      setTxt('mkToggleEnergyBtn', currentMaker.showEnergy ? (isZh ? '🔋 能量条: 显示' : '🔋 에너지 게이지: 표시') : (isZh ? '🔋 能量条: 隐藏' : '🔋 에너지 게이지: 숨김'));

      document.querySelectorAll('.mk-accent-btn').forEach(btn => {
        const isOn = btn.getAttribute('data-accent') === currentMaker.accentOverride;
        btn.style.outline = isOn ? '2px solid var(--accent-royal)' : '';
      });

      document.querySelectorAll('.mk-subscope-btn').forEach(b => {
        const on = b.getAttribute('data-scope') === activeScope;
        b.classList.toggle('btn-royal', on);
        b.classList.toggle('btn-ghost', !on);
      });
      const list = document.getElementById('mkHomeCardsList');
      const scDef = SCOPE_DEFS[activeScope] || SCOPE_DEFS.home;
      if (list && scDef) {
        const arr = currentMaker[scDef.orderKey] || scDef.defaults;
        const hid = currentMaker[scDef.hiddenKey] || [];
        list.innerHTML = arr.map((key, idx) => {
          const isHidden = hid.includes(key);
          const lockHide = !scDef.canHide || (scDef.lockHide || []).includes(key);
          const lblObj = scDef.labels[key];
          const lbl = lblObj ? (isZh ? lblObj.zh : lblObj.ko) : key;
          return `<div class="flex items-center justify-between gap-2 px-2.5 py-1.5 rounded-xl" style="background: var(--surface-2); opacity: ${isHidden ? '0.55' : '1'};">
            <span class="truncate font-semibold text-[11px]">${lbl}</span>
            <div class="flex items-center gap-1 shrink-0">
              <button type="button" class="mk-card-up btn-ghost px-1.5 py-0.5 rounded-lg text-[10px]" data-key="${key}" ${idx === 0 ? 'disabled style="opacity:0.35;"' : ''}>⬆️</button>
              <button type="button" class="mk-card-down btn-ghost px-1.5 py-0.5 rounded-lg text-[10px]" data-key="${key}" ${idx === arr.length - 1 ? 'disabled style="opacity:0.35;"' : ''}>⬇️</button>
              ${lockHide ? `<span class="px-1.5 py-0.5 text-[10px] opacity-45">🔒</span>` : `<button type="button" class="mk-card-vis btn-ghost px-1.5 py-0.5 rounded-lg text-[10px]" data-key="${key}">${isHidden ? '🙈' : '👁️'}</button>`}
            </div>
          </div>`;
        }).join('');
      }
    }

    const makerToast = (koMsg, zhMsg) => {
      try {
        const st = window.__cwBridge && window.__cwBridge.getState ? window.__cwBridge.getState() : null;
        const msg = (st && st.lang === 'zh') ? zhMsg : koMsg;
        if (window.__cwBridge && typeof window.__cwBridge.showToast === 'function') {
          window.__cwBridge.showToast(msg);
        }
      } catch (_) {}
    };

    const setDrawerOpen = (open) => {
      const dr = document.getElementById('makerModeDrawer');
      if (!dr) return;
      if (open) {
        dr.classList.remove('hidden');
        dr.style.display = 'block';
        try { syncMakerDrawerUi(); } catch (_) {}
      } else {
        dr.classList.add('hidden');
        dr.style.display = 'none';
      }
    };

    const doReset = () => {
      applyMakerLayout({ ...DEFAULT_MAKER, updatedAt: Date.now() }, false);
      makerToast('🔄 메이커 모드 기본값으로 복원했어요 (상대방 폰에도 자동 동기화됨)', '🔄 已恢复默认布局（已自动同步到对方手机）');
    };

    document.addEventListener('click', async (e) => {
      const tabBtn = e.target && e.target.closest('.mk-tab-btn');
      if (tabBtn) {
        const t = tabBtn.getAttribute('data-mk-tab');
        document.querySelectorAll('.mk-tab-btn').forEach(b => b.classList.toggle('active', b === tabBtn));
        const map = { layout: 'mkPanelLayout', chat: 'mkPanelChat', style: 'mkPanelStyle', home: 'mkPanelHome' };
        Object.keys(map).forEach(k => {
          const pnl = document.getElementById(map[k]);
          if (pnl) pnl.classList.toggle('hidden', k !== t);
        });
        return;
      }
      const presetBtn = e.target && e.target.closest('.mk-preset-btn');
      if (presetBtn) {
        const pk = presetBtn.getAttribute('data-preset');
        if (MAKER_PRESETS[pk]) {
          applyMakerLayout({ ...currentMaker, ...MAKER_PRESETS[pk] }, false);
          makerToast('✨ 프리셋 스타일을 적용했어요!', '✨ 已应用预设排版风格！');
        }
        return;
      }
      const accBtn = e.target && e.target.closest('.mk-accent-btn');
      if (accBtn) {
        const ak = accBtn.getAttribute('data-accent') || 'default';
        applyMakerLayout({ ...currentMaker, accentOverride: ak }, false);
        return;
      }
      if (e.target && e.target.closest('#openMakerModeBtn')) {
        const dr = document.getElementById('makerModeDrawer');
        const isCurrentlyHidden = !dr || dr.classList.contains('hidden') || dr.style.display === 'none';
        setDrawerOpen(isCurrentlyHidden);
        if (isCurrentlyHidden) makerToast('📐 메이커 모드 전체 편집 창을 열었어요', '📐 已打开创客模式全局编辑面板');
        return;
      }
      if (e.target && e.target.closest('#makerDrawerCloseBtn')) { setDrawerOpen(false); return; }
      if (e.target && (e.target.closest('#resetMakerLayoutBtn') || e.target.closest('#makerDrawerResetBtn'))) { doReset(); return; }
      if (e.target && e.target.closest('#mkToggleToneBoxBtn')) { applyMakerLayout({ ...currentMaker, showToneBox: !currentMaker.showToneBox }, false); return; }
      if (e.target && e.target.closest('#mkTogglePronBtn')) { applyMakerLayout({ ...currentMaker, showPron: !currentMaker.showPron }, false); return; }
      if (e.target && e.target.closest('#mkToggleAltBtn')) { applyMakerLayout({ ...currentMaker, showAltTrans: !currentMaker.showAltTrans }, false); return; }
      if (e.target && e.target.closest('#mkToggleChatAlignBtn')) { applyMakerLayout({ ...currentMaker, chatStatusAlign: currentMaker.chatStatusAlign === 'center' ? 'left' : 'center' }, false); return; }
      if (e.target && e.target.closest('#mkToggleShadowBtn')) { applyMakerLayout({ ...currentMaker, shadowLevel: (currentMaker.shadowLevel + 1) % 3 }, false); return; }
      if (e.target && e.target.closest('#mkToggleBorderBtn')) { const nextB = currentMaker.borderWidth === 1 ? 1.5 : (currentMaker.borderWidth === 1.5 ? 2 : 1); applyMakerLayout({ ...currentMaker, borderWidth: nextB }, false); return; }
      if (e.target && e.target.closest('#mkToggleHeaderBtn')) { applyMakerLayout({ ...currentMaker, headerCompact: !currentMaker.headerCompact }, false); return; }
      if (e.target && e.target.closest('#mkToggleDockLblBtn')) { applyMakerLayout({ ...currentMaker, showDockLabels: !currentMaker.showDockLabels }, false); return; }
      if (e.target && e.target.closest('#mkToggleCenterBtn')) { applyMakerLayout({ ...currentMaker, centerControls: !currentMaker.centerControls }, false); return; }
      if (e.target && e.target.closest('#mkToggleEnergyBtn')) { applyMakerLayout({ ...currentMaker, showEnergy: !currentMaker.showEnergy }, false); return; }

      const scBtn = e.target && e.target.closest('.mk-subscope-btn');
      if (scBtn) {
        const sc = scBtn.getAttribute('data-scope');
        if (SCOPE_DEFS[sc]) { activeScope = sc; syncMakerDrawerUi(); }
        return;
      }
      const up = e.target && e.target.closest('.mk-card-up');
      const down = e.target && e.target.closest('.mk-card-down');
      const vis = e.target && e.target.closest('.mk-card-vis');
      if (up || down || vis) {
        const scDef = SCOPE_DEFS[activeScope] || SCOPE_DEFS.home;
        const key = (up || down || vis).getAttribute('data-key');
        const order = [...(currentMaker[scDef.orderKey] || scDef.defaults)];
        const hidden = [...(currentMaker[scDef.hiddenKey] || [])];
        const idx = order.indexOf(key);
        if (up && idx > 0) { [order[idx - 1], order[idx]] = [order[idx], order[idx - 1]]; }
        if (down && idx >= 0 && idx < order.length - 1) { [order[idx + 1], order[idx]] = [order[idx], order[idx + 1]]; }
        if (vis && scDef.canHide && !(scDef.lockHide || []).includes(key)) {
          const hi = hidden.indexOf(key);
          if (hi >= 0) hidden.splice(hi, 1); else hidden.push(key);
        }
        applyMakerLayout({ ...currentMaker, [scDef.orderKey]: order, [scDef.hiddenKey]: hidden }, false);
      }
    });

    let syncDebTimer = null;
    const debouncedApply = (patch) => {
      applyMakerLayout({ ...currentMaker, ...patch }, true);
      if (syncDebTimer) clearTimeout(syncDebTimer);
      syncDebTimer = setTimeout(() => { applyMakerLayout(currentMaker, false); }, 450);
    };

    const bindRange = (id, field) => {
      const el = document.getElementById(id);
      if (el) el.addEventListener('input', () => debouncedApply({ [field]: Number(el.value) }));
    };
    bindRange('mkRangeGap', 'cardGap');
    bindRange('mkRangePadX', 'pagePadX');
    bindRange('mkRangeCardPad', 'cardPad');
    bindRange('mkRangeRadius', 'cardRadius');
    bindRange('mkRangeFontScale', 'fontScale');
    bindRange('mkRangeBubbleRad', 'bubbleRadius');
    bindRange('mkRangeChatFs', 'chatFontSize');
    bindRange('mkRangeBubbleMaxW', 'bubbleMaxW');

    // Apply immediately on boot (prefer newer of local vs state)
    setTimeout(() => {
      const st = window.__cwBridge && window.__cwBridge.getState ? window.__cwBridge.getState() : null;
      const stMaker = st && st.makerLayout ? sanitizeMaker(st.makerLayout) : null;
      const chosen = (stMaker && stMaker.updatedAt > currentMaker.updatedAt) ? stMaker : currentMaker;
      applyMakerLayout(chosen, true);
    }, 350);
  })();
;
(function initKeepKeyboardOnSend() {
    if (window.__cwKeepKbReady) return;
    window.__cwKeepKbReady = true;

    // Prevent tapping Send/Submit buttons from blurring the focused text input/textarea
    document.addEventListener('mousedown', (e) => {
      const btn = e.target && e.target.closest('button[type="submit"], #chatSendBtn');
      if (!btn) return;
      const form = btn.closest('form');
      if (!form || form.querySelector('input[type="file"]')) return;
      const active = document.activeElement;
      if (active && form.contains(active) && (active.tagName === 'INPUT' || active.tagName === 'TEXTAREA')) {
        e.preventDefault();
      }
    }, true);

    // Only keep focus on a text input after submit if that exact input WAS ALREADY focused before submit!
    document.addEventListener('submit', (e) => {
      const form = e.target;
      if (!form || form.tagName !== 'FORM') return;
      if (form.querySelector('input[type="file"]')) return;
      const textField = form.querySelector('#chatInput, textarea, input[type="text"], input:not([type])');
      if (!textField || document.activeElement !== textField) return;
      setTimeout(() => {
        try {
          if (textField.isConnected && textField.offsetParent !== null) {
            textField.focus({ preventScroll: true });
          }
        } catch (_) {}
      }, 20);
    }, true);
  })();
;
(function initV55Upgrades() {
      const __api = () => window.__cwApi || {};
      const __st = () => (__api().getState ? __api().getState() : null);
      const __save = (sync) => { if (__api().saveState) __api().saveState(sync); };
      const __renderChat = () => { if (__api().renderChat) __api().renderChat(); };
      const __toast = (m) => { if (__api().showToast) __api().showToast(m); };
      const __speak = (t, l, s) => { if (__api().speakText) __api().speakText(t, l, s); };
      const __esc = (s) => (__api().escapeHtml ? __api().escapeHtml(s) : String(s || ''));
      const __mediaUrl = (u, mime) => (__api().mediaUrl ? __api().mediaUrl(u, mime) : u);

      const BG_KEY = 'cw_chat_bg_v1';
      const BUBBLE_SIZE_KEY = 'cw_bubble_size_v1';
      function applyBubbleSize(sz) {
        const clean = (sz === 'sm' || sz === 'lg') ? sz : 'md';
        document.documentElement.setAttribute('data-bubblesize', clean);
        try { localStorage.setItem(BUBBLE_SIZE_KEY, clean); } catch (_) {}
        document.querySelectorAll('.cw-bubble-size-btn').forEach(b => {
          const isAct = b.getAttribute('data-bsize') === clean;
          b.className = 'cw-bubble-size-btn rounded-xl py-1.5 text-xs font-bold ' + (isAct ? 'btn-royal' : 'btn-ghost');
        });
      }
      try { applyBubbleSize(localStorage.getItem(BUBBLE_SIZE_KEY) || 'md'); } catch (_) {}
      document.querySelectorAll('.cw-bubble-size-btn').forEach(b => {
        b.addEventListener('click', () => applyBubbleSize(b.getAttribute('data-bsize')));
      });
      const PRESETS = {
        default: '',
        rose: 'linear-gradient(155deg, rgba(255,228,240,0.88) 0%, rgba(255,244,234,0.88) 55%, rgba(246,232,255,0.88) 100%)',
        lavender: 'linear-gradient(155deg, rgba(238,232,255,0.90) 0%, rgba(226,236,255,0.88) 55%, rgba(252,238,255,0.90) 100%)',
        starlight: 'radial-gradient(circle at 20% 20%, rgba(168,85,247,0.28), transparent 45%), radial-gradient(circle at 80% 75%, rgba(244,114,182,0.22), transparent 50%), linear-gradient(160deg, #17102a 0%, #261844 100%)'
      };

      function loadChatBgCfg() {
        try {
          const raw = localStorage.getItem(BG_KEY);
          if (raw) return JSON.parse(raw);
        } catch (_) {}
        return { preset: 'default', photo: '', alpha: 55 };
      }

      function applyChatBg(cfg) {
        const listEl = document.getElementById('chatMessagesList');
        if (!listEl) return;
        const c = cfg || loadChatBgCfg();
        const isDark = document.documentElement.getAttribute('data-dark') === '1' || document.documentElement.getAttribute('data-theme') === 'velvet-dusk';
        const veilAlpha = Math.max(0.15, Math.min(0.88, (Number(c.alpha) || 55) / 100));
        const veilCol = isDark ? `rgba(18,13,31,${veilAlpha.toFixed(2)})` : `rgba(255,252,255,${veilAlpha.toFixed(2)})`;
        if (c.photo) {
          listEl.classList.add('cw-has-bg');
          listEl.style.backgroundImage = `linear-gradient(${veilCol}, ${veilCol}), url("${c.photo}")`;
        } else if (c.preset && PRESETS[c.preset]) {
          listEl.classList.add('cw-has-bg');
          listEl.style.backgroundImage = PRESETS[c.preset];
        } else {
          listEl.classList.remove('cw-has-bg');
          listEl.style.backgroundImage = '';
        }
      }
      window.__applyCwChatBg = applyChatBg;

      function syncChatBgModalLang() {
        const isZh = (__st() && __st().lang === 'zh');
        const setTxt = (id, ko, zh) => { const el = document.getElementById(id); if (el) el.textContent = isZh ? zh : ko; };
        setTxt('cwChatBgModalTitle', '채팅방 배경 꾸미기', '自定义聊天背景');
        setTxt('cwChatBgPresetLabel', '감성 배경 프리셋', '浪漫主题背景');
        setTxt('cwChatBgPickPhotoBtn', '📷 갤러리에서 커플 사진 선택', '📷 从相册选择情侣照片');
        setTxt('cwChatBgAlphaLabel', '배경 은은함 (글자 가독성)', '背景柔和度（文字更清晰）');
        setTxt('cwChatBgResetBtn', '초기화', '恢复默认');
        setTxt('cwChatBgDoneBtn', '적용 완료', '完成');
        setTxt('cwBubbleSizeLabel', '💬 말풍선 크기', '💬 气泡大小');
        document.querySelectorAll('.cw-bubble-size-btn').forEach(b => {
          const sz = b.getAttribute('data-bsize');
          if (sz === 'sm') b.textContent = isZh ? '紧凑' : '작게';
          else if (sz === 'md') b.textContent = isZh ? '标准' : '보통';
          else if (sz === 'lg') b.textContent = isZh ? '宽松' : '크게';
        });
        const presetMap = { default: ['기본', '默认'], rose: ['로즈', '玫瑰'], lavender: ['라벤더', '薰衣草'], starlight: ['별빛', '星夜'] };
        document.querySelectorAll('.cw-bg-preset-btn').forEach(b => {
          const p = b.getAttribute('data-preset');
          if (presetMap[p]) b.textContent = isZh ? presetMap[p][1] : presetMap[p][0];
        });
      }

      // 1) Chat Wallpaper Modal Wiring
      const openBgBtn = document.getElementById('openChatBgBtn');
      const bgModal = document.getElementById('cwChatBgModal');
      const closeBgBtn = document.getElementById('closeChatBgModalBtn');
      const doneBgBtn = document.getElementById('cwChatBgDoneBtn');
      const resetBgBtn = document.getElementById('cwChatBgResetBtn');
      const pickPhotoBtn = document.getElementById('cwChatBgPickPhotoBtn');
      const bgFileInput = document.getElementById('cwChatBgFileInput');
      const alphaSlider = document.getElementById('cwChatBgAlpha');
      const alphaVal = document.getElementById('cwChatBgAlphaVal');

      if (openBgBtn && bgModal) {
        const closeModal = () => bgModal.classList.add('hidden');
        openBgBtn.addEventListener('click', () => {
          syncChatBgModalLang();
          const cur = loadChatBgCfg();
          if (alphaSlider) alphaSlider.value = String(cur.alpha || 55);
          if (alphaVal) alphaVal.textContent = `${cur.alpha || 55}%`;
          bgModal.classList.remove('hidden');
        });
        if (closeBgBtn) closeBgBtn.addEventListener('click', closeModal);
        if (doneBgBtn) doneBgBtn.addEventListener('click', closeModal);
        bgModal.addEventListener('click', (e) => { if (e.target === bgModal) closeModal(); });

        bgModal.querySelectorAll('.cw-bg-preset-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            const p = btn.getAttribute('data-preset') || 'default';
            const next = { preset: p, photo: '', alpha: Number(alphaSlider?.value || 55) };
            try { localStorage.setItem(BG_KEY, JSON.stringify(next)); } catch (_) {}
            applyChatBg(next);
          });
        });

        if (pickPhotoBtn && bgFileInput) {
          pickPhotoBtn.addEventListener('click', () => bgFileInput.click());
          bgFileInput.addEventListener('change', async () => {
            const f = bgFileInput.files && bgFileInput.files[0];
            if (!f) return;
            try {
              const dUrl = __api().compressImageToDataUrl
                ? await __api().compressImageToDataUrl(f, 960)
                : await new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result || '')); r.onerror = rej; r.readAsDataURL(f); });
              const next = { preset: 'photo', photo: dUrl, alpha: Number(alphaSlider?.value || 55) };
              try { localStorage.setItem(BG_KEY, JSON.stringify(next)); } catch (_) {}
              applyChatBg(next);
              if (__api().showToast) __toast((__st()?.lang === 'zh') ? '🖼️ 聊天背景已更换 ✨' : '🖼️ 채팅방 배경이 적용됐어요 ✨');
            } catch (_) {}
            bgFileInput.value = '';
          });
        }

        if (alphaSlider) {
          alphaSlider.addEventListener('input', () => {
            const v = Number(alphaSlider.value || 55);
            if (alphaVal) alphaVal.textContent = `${v}%`;
            const cur = loadChatBgCfg();
            cur.alpha = v;
            try { localStorage.setItem(BG_KEY, JSON.stringify(cur)); } catch (_) {}
            applyChatBg(cur);
          });
        }

        if (resetBgBtn) {
          resetBgBtn.addEventListener('click', () => {
            const def = { preset: 'default', photo: '', alpha: 55 };
            try { localStorage.setItem(BG_KEY, JSON.stringify(def)); } catch (_) {}
            if (alphaSlider) alphaSlider.value = '55';
            if (alphaVal) alphaVal.textContent = '55%';
            applyChatBg(def);
          });
        }
      }

      // 2) Swipe-to-Reply on CW Talk Bubbles (smooth right swipe >= 46px)
      const listEl = document.getElementById('chatMessagesList');
      if (listEl) {
        const hintEl = document.createElement('div');
        hintEl.className = 'cw-swipe-hint';
        hintEl.textContent = '↩️';
        document.body.appendChild(hintEl);

        let sw = null;
        listEl.addEventListener('touchstart', (e) => {
          if (!e.touches || e.touches.length !== 1) return;
          const bubble = e.target && e.target.closest ? e.target.closest('.cw-msg-bubble') : null;
          if (!bubble) return;
          const mid = bubble.getAttribute('data-msg-id');
          if (!mid) return;
          const col = bubble.closest('.cw-msg-col') || bubble;
          sw = {
            mid,
            col,
            x0: e.touches[0].clientX,
            y0: e.touches[0].clientY,
            dx: 0,
            active: false,
            lockedVert: false
          };
        }, { passive: true });

        listEl.addEventListener('touchmove', (e) => {
          if (!sw || !e.touches || e.touches.length !== 1) return;
          const dx = e.touches[0].clientX - sw.x0;
          const dy = e.touches[0].clientY - sw.y0;
          if (!sw.active && !sw.lockedVert) {
            if (Math.abs(dy) > 12 && Math.abs(dy) > Math.abs(dx)) { sw.lockedVert = true; return; }
            if (dx > 14 && dx > Math.abs(dy) * 1.4) { sw.active = true; }
          }
          if (!sw.active) return;
          const clamped = Math.max(0, Math.min(64, dx));
          sw.dx = clamped;
          sw.col.style.transition = 'none';
          sw.col.style.transform = `translateX(${clamped}px)`;
          const rect = sw.col.getBoundingClientRect();
          hintEl.style.left = `${Math.max(10, rect.left - 34)}px`;
          hintEl.style.top = `${rect.top + rect.height / 2 - 15}px`;
          hintEl.style.opacity = clamped >= 46 ? '1' : String((clamped / 46).toFixed(2));
          hintEl.style.transform = clamped >= 46 ? 'scale(1)' : 'scale(0.8)';
        }, { passive: true });

        const finishSwipe = () => {
          if (!sw) return;
          const cur = sw;
          sw = null;
          hintEl.style.opacity = '0';
          hintEl.style.transform = 'scale(0.7)';
          cur.col.style.transition = 'transform 0.18s ease';
          cur.col.style.transform = '';
          if (cur.active && cur.dx >= 46 && (__st() && __st().chat && Array.isArray(__st().chat.messages))) {
            const target = (__st()?.chat?.messages || []).find(x => x && x.id === cur.mid);
            if (target) {
              try { if (navigator.vibrate) navigator.vibrate(18); } catch (_) {}
              window.__pendingChatReply = {
                id: target.id,
                author: target.sender === 'suwan' ? '수완(完)' : '靖灿(灿)',
                text: (target.original || '').slice(0, 60)
              };
              const bar = document.getElementById('chatReplyBar');
              const au = document.getElementById('chatReplyAuthor');
              const sn = document.getElementById('chatReplySnippet');
              if (au) au.textContent = `↩️ ${window.__pendingChatReply.author}`;
              if (sn) sn.textContent = window.__pendingChatReply.text;
              if (bar) bar.classList.remove('hidden');
              document.getElementById('chatInput')?.focus();
            }
          }
        };
        listEl.addEventListener('touchend', finishSwipe, { passive: true });
        listEl.addEventListener('touchcancel', finishSwipe, { passive: true });
      }

      // 3) Home Today's Couple Phrase Card
      const FALLBACK_PHRASES = [
        { ko: '오늘 하루도 고생 많았어, 보고 싶어!', zh: '今天辛苦啦，好想你呀！', toneKo: '다정한 응원', toneZh: '温柔鼓励' },
        { ko: '밥 꼭 챙겨 먹고 푹 쉬어 내 사랑', zh: '一定要按时吃饭，好好休息呀我的宝贝', toneKo: '다정한 챙김', toneZh: '暖心照顾' },
        { ko: '너 덕분에 오늘도 웃었어', zh: '多亏了你，今天也开心笑了', toneKo: '달콤한 고백', toneZh: '甜蜜告白' },
        { ko: '잘 자, 꿈에서 만나자', zh: '晚安，梦里见呀', toneKo: '포근한 인사', toneZh: '温柔晚安' },
        { ko: '지금 뭐 하고 있어? 목소리 듣고 싶다', zh: '现在在干嘛呀？好想听听你的声音', toneKo: '설레는 안부', toneZh: '思念问候' }
      ];
      let phraseIdx = 0;

      function getPhrasePool() {
        const pool = [];
        try {
          const msgs = ((__st() && __st().chat && Array.isArray(__st().chat.messages))) ? state.chat.messages : [];
          for (let i = msgs.length - 1; i >= 0 && pool.length < 24; i--) {
            const m = msgs[i];
            if (!m || !m.original || !m.translated) continue;
            const o = String(m.original).trim();
            const t = String(m.translated).trim();
            if (o.length < 3 || o.length > 65 || t.length < 2 || o === t) continue;
            if (/^https?:\/\/|사진을 보냈어요|동영상을 보냈어요|分享了|번역이 부정확|번역 중/.test(o + ' ' + t)) continue;
            const origIsZh = /[一-鿿]/.test(o) && !/[가-힣]/.test(o);
            pool.push({
              ko: origIsZh ? t : o,
              zh: origIsZh ? o : t,
              toneKo: m.tone || '우리 대화',
              toneZh: m.tone || '我们的对话'
            });
          }
        } catch (_) {}
        return pool.length ? pool : FALLBACK_PHRASES;
      }

      function renderHomeCouplePhrase(step) {
        const pool = getPhrasePool();
        if (step) phraseIdx = (phraseIdx + 1) % pool.length;
        else phraseIdx = phraseIdx % pool.length;
        const item = pool[phraseIdx] || FALLBACK_PHRASES[0];
        const isZh = (__st() && __st().lang === 'zh');
        const setTxt = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
        setTxt('homePhraseCardTitle', isZh ? '今日我们的对话表达' : '오늘의 우리 대화 표현');
        setTxt('homePhraseToneBadge', isZh ? (item.toneZh || '甜蜜表达') : (item.toneKo || '다정한 표현'));
        setTxt('homePhrasePrimary', isZh ? item.zh : item.ko);
        setTxt('homePhraseSecondary', isZh ? item.ko : item.zh);
        setTxt('homePhraseSpeakLbl', isZh ? '听韩语发音' : '중국어 듣기');
        setTxt('homePhraseNextLbl', isZh ? '换一句' : '다른 표현');
        window.__cwCurrentHomePhrase = item;
      }
      window.__renderHomeCouplePhrase = renderHomeCouplePhrase;

      document.getElementById('homePhraseNextBtn')?.addEventListener('click', () => renderHomeCouplePhrase(true));
      document.getElementById('homePhraseSpeakBtn')?.addEventListener('click', () => {
        const item = window.__cwCurrentHomePhrase || FALLBACK_PHRASES[0];
        const isZh = (__st() && __st().lang === 'zh');
        if (__api().speakText) {
          __speak(isZh ? item.ko : item.zh, isZh ? 'ko-KR' : 'zh-CN');
        }
      });

      // Boot & re-apply cleanly after state loads
      applyChatBg();
      renderHomeCouplePhrase(false);
      setTimeout(() => { applyChatBg(); renderHomeCouplePhrase(false); }, 900);
    })();
;
(function initV56DelightPack() {
      const __api = () => window.__cwApi || {};
      const __st = () => (__api().getState ? __api().getState() : null);
      const __save = (sync) => { if (__api().saveState) __api().saveState(sync); };
      const __renderChat = () => { if (__api().renderChat) __api().renderChat(); };
      const __toast = (m) => { if (__api().showToast) __api().showToast(m); };
      const __speak = (t, l, s) => { if (__api().speakText) __api().speakText(t, l, s); };
      const __esc = (s) => (__api().escapeHtml ? __api().escapeHtml(s) : String(s || ''));
      const __mediaUrl = (u, mime) => (__api().mediaUrl ? __api().mediaUrl(u, mime) : u);

      // 1) Romantic Keyword Particle Effect (lightweight 14-node CSS float)
      function triggerCoupleKeywordEffect(rawText) {
        const t = String(rawText || '').trim();
        if (!t) return;
        let emojis = null;
        if (/사랑해|사랑해요|我爱你|爱你|好爱你|love\s*you/i.test(t)) {
          emojis = ['❤️', '💖', '💗', '💜', '✨'];
        } else if (/보고\s*싶어|보고파|想你|好想你|miss\s*you/i.test(t)) {
          emojis = ['💜', '✨', '🌙', '💫', '🩷'];
        } else if (/생일|축하|기념일|生日快乐|纪念日|happy\s*birthday/i.test(t)) {
          emojis = ['🎉', '✨', '💖', '🎊', '🥳'];
        }
        if (!emojis) return;
        for (let i = 0; i < 14; i++) {
          const sp = document.createElement('span');
          sp.className = 'cw-fx-particle';
          sp.textContent = emojis[i % emojis.length];
          sp.style.left = `${8 + Math.random() * 84}%`;
          sp.style.setProperty('--dx', `${Math.round((Math.random() - 0.5) * 90)}px`);
          sp.style.setProperty('--rot', `${Math.round((Math.random() - 0.5) * 50)}deg`);
          sp.style.animationDelay = `${(Math.random() * 0.45).toFixed(2)}s`;
          document.body.appendChild(sp);
          setTimeout(() => sp.remove(), 2650);
        }
      }
      window.__triggerCoupleKeywordEffect = triggerCoupleKeywordEffect;

      const chatFormEl = document.getElementById('chatForm');
      if (chatFormEl) {
        chatFormEl.addEventListener('submit', () => {
          const inp = document.getElementById('chatInput');
          if (inp && inp.value) triggerCoupleKeywordEffect(inp.value);
        }, true);
      }

      // 2) Instagram DM-style Double-Tap Heart on Chat Bubbles
      const listEl = document.getElementById('chatMessagesList');
      if (listEl) {
        let lastTapId = '';
        let lastTapTs = 0;
        listEl.addEventListener('click', (e) => {
          const t = e.target;
          if (!t || !t.closest) return;
          if (t.closest('button, a, video, audio, input, textarea, .cw-zoom-photo')) return;
          const bubble = t.closest('.cw-msg-bubble');
          if (!bubble) return;
          const mid = bubble.getAttribute('data-msg-id');
          if (!mid) return;
          const now = Date.now();
          if (lastTapId === mid && (now - lastTapTs) < 330) {
            lastTapId = '';
            lastTapTs = 0;
            if ((__st() && __st().chat && Array.isArray(__st().chat.messages))) {
              const target = (__st()?.chat?.messages || []).find(x => x && x.id === mid);
              if (target) {
                if (!Array.isArray(target.reactions)) target.reactions = [];
                const idx = target.reactions.indexOf('❤️');
                if (idx >= 0) target.reactions.splice(idx, 1);
                else target.reactions.push('❤️');
                try { if (navigator.vibrate) navigator.vibrate(15); } catch (_) {}
                const pop = document.createElement('span');
                pop.className = 'cw-dbl-heart-pop';
                pop.textContent = '❤️';
                pop.style.left = `${e.clientX || (window.innerWidth / 2)}px`;
                pop.style.top = `${e.clientY || (window.innerHeight / 2)}px`;
                document.body.appendChild(pop);
                setTimeout(() => pop.remove(), 700);
                __save(true);
                __renderChat();
                if (typeof window.__sendChatSignal === 'function') {
                  window.__sendChatSignal('react', { msgId: mid, reactions: target.reactions });
                }
              }
            }
          } else {
            lastTapId = mid;
            lastTapTs = now;
          }
        });
      }

      // 3) Editable Quick Couple Phrase Bar above Chat Input
      const QP_KEY = 'cw_quick_phrases_v1';
      const DEF_QP_KO = ['밥 먹었어?', '지금 뭐해?', '보고 싶어 💜', '사랑해', '잘 자 🌙'];
      const DEF_QP_ZH = ['吃饭了吗？', '在干嘛呀？', '好想你 💜', '我爱你', '晚安 🌙'];

      function loadQuickPhrases() {
        const isZh = (__st() && __st().lang === 'zh');
        try {
          const saved = JSON.parse(localStorage.getItem(QP_KEY) || 'null');
          if (Array.isArray(saved) && saved.length) return saved;
        } catch (_) {}
        return isZh ? DEF_QP_ZH : DEF_QP_KO;
      }

      const QP_BUBBLE_ICO = '<svg viewBox="0 0 24 24" width="15" height="15" fill="none"><path d="M5 6.5h11.5a3.5 3.5 0 0 1 3.5 3.5v3a3.5 3.5 0 0 1-3.5 3.5H9.2L5.5 19v-2.5A3.5 3.5 0 0 1 3 13v-3a3.5 3.5 0 0 1 2-3.5z" fill="currentColor" fill-opacity="0.14" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/><path d="M8 11.5h5.5M8 14h3.2" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>';
      function renderQuickPhraseBar() {
        const bar = document.getElementById('cwQuickPhraseBar');
        if (!bar) return;
        const isZh = (__st() && __st().lang === 'zh');
        const items = loadQuickPhrases();
        bar.innerHTML = '';
        const track = document.createElement('div');
        track.className = 'cw-qp-scroll-track';
        items.forEach(txt => {
          const btn = document.createElement('button');
          btn.type = 'button';
          btn.className = 'cw-qp-chip active:scale-95';
          btn.textContent = txt;
          btn.addEventListener('click', () => {
            const inp = document.getElementById('chatInput');
            if (!inp) return;
            inp.value = txt;
            inp.dispatchEvent(new Event('input', { bubbles: true }));
            const form = document.getElementById('chatForm');
            if (form) form.dispatchEvent(new Event('submit', { cancelable: true, bubbles: true }));
          });
          track.appendChild(btn);
        });
        const editBtn = document.createElement('button');
        editBtn.type = 'button';
        editBtn.className = 'cw-qp-action-btn active:scale-95';
        editBtn.title = isZh ? '自定义快捷短语' : '빠른 메시지 편집';
        editBtn.innerHTML = `<svg viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg><span>${isZh ? '编辑' : '편집'}</span>`;
        editBtn.addEventListener('click', () => {
          const cur = loadQuickPhrases().join(', ');
          const ans = prompt(
            isZh ? '输入常用短语（用逗号分隔，留空恢复默认）' : '자주 쓰는 멘트를 쉼표(,)로 구분해 적어 주세요 (비우면 기본값)',
            cur
          );
          if (ans === null) return;
          const cleaned = ans.split(/[,，]/).map(s => s.trim()).filter(Boolean).slice(0, 10);
          try {
            if (cleaned.length) localStorage.setItem(QP_KEY, JSON.stringify(cleaned));
            else localStorage.removeItem(QP_KEY);
          } catch (_) {}
          renderQuickPhraseBar();
        });
        track.appendChild(editBtn);
        bar.appendChild(track);

        // Pinned 1-Tap Fold Button on Right Edge (always visible without horizontal scrolling!)
        const hideBtn = document.createElement('button');
        hideBtn.type = 'button';
        hideBtn.className = 'cw-qp-action-btn cw-qp-fold-btn active:scale-95';
        hideBtn.title = isZh ? '收起快捷短语栏' : '빠른 메시지 접기';
        hideBtn.innerHTML = `<span>${isZh ? '收起' : '접기'}</span><svg viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>`;
        hideBtn.addEventListener('pointerdown', (ev) => {
          if (ev.pointerType === 'mouse' && ev.button !== 0) return;
          ev.preventDefault();
          ev.stopPropagation();
          setQuickPhraseVisible(false);
        });
        hideBtn.addEventListener('click', (ev) => {
          ev.preventDefault();
          ev.stopPropagation();
          setQuickPhraseVisible(false);
        });
        bar.appendChild(hideBtn);
        applyQuickPhraseVisibility();
      }
      const QP_HIDE_KEY = 'cw_qp_hidden_v1';
      function isQuickPhraseHidden() {
        try { return localStorage.getItem(QP_HIDE_KEY) === '1'; } catch (_) { return false; }
      }
      function applyQuickPhraseVisibility() {
        const bar = document.getElementById('cwQuickPhraseBar');
        const tBtn = document.getElementById('cwQuickPhraseToggleBtn');
        const hidden = isQuickPhraseHidden();
        if (bar) bar.classList.toggle('cw-qp-collapsed', hidden);
        if (tBtn) {
          const isZh = (__st() && __st().lang === 'zh');
          tBtn.classList.toggle('cw-qp-on', !hidden);
          tBtn.classList.toggle('cw-qp-folded-pill', hidden);
          tBtn.innerHTML = hidden
            ? `<span class="inline-flex items-center gap-0.5 whitespace-nowrap"><span>${isZh ? '短语' : '멘트'}</span><svg viewBox="0 0 24 24" width="10" height="10" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="18 15 12 9 6 15"/></svg></span>`
            : QP_BUBBLE_ICO;
          tBtn.title = hidden
            ? (isZh ? '展开快捷短语栏' : '빠른 메시지 펼치기')
            : (isZh ? '收起快捷短语栏' : '빠른 메시지 접기');
        }
      }
      function setQuickPhraseVisible(visible) {
        try { localStorage.setItem(QP_HIDE_KEY, visible ? '0' : '1'); } catch (_) {}
        applyQuickPhraseVisibility();
      }
      const __qpToggleBtn = document.getElementById('cwQuickPhraseToggleBtn');
      if (__qpToggleBtn && !__qpToggleBtn.dataset.cwBound) {
        __qpToggleBtn.dataset.cwBound = '1';
        let __lastQpPtrTs = 0;
        __qpToggleBtn.addEventListener('pointerdown', (ev) => {
          if (ev.pointerType === 'mouse' && ev.button !== 0) return;
          ev.preventDefault();
          ev.stopPropagation();
          __lastQpPtrTs = Date.now();
          setQuickPhraseVisible(isQuickPhraseHidden());
        });
        __qpToggleBtn.addEventListener('click', (ev) => {
          ev.stopPropagation();
          if (Date.now() - __lastQpPtrTs < 450) { ev.preventDefault(); return; }
          setQuickPhraseVisible(isQuickPhraseHidden());
        });
      }
      window.__renderQuickPhraseBar = renderQuickPhraseBar;
      window.__toggleQuickPhraseBar = () => setQuickPhraseVisible(isQuickPhraseHidden());
      renderQuickPhraseBar();
      setTimeout(() => { renderQuickPhraseBar(); }, 1000);
    })();
;
(function initV57Features() {
      const __api = () => window.__cwApi || {};
      const __st = () => (__api().getState ? __api().getState() : null);
      const __save = (sync) => { if (__api().saveState) __api().saveState(sync); };
      const __renderChat = () => { if (__api().renderChat) __api().renderChat(); };
      const __toast = (m) => { if (__api().showToast) __api().showToast(m); };
      const __speak = (t, l, s) => { if (__api().speakText) __api().speakText(t, l, s); };
      const __esc = (s) => (__api().escapeHtml ? __api().escapeHtml(s) : String(s || ''));
      const __mediaUrl = (u, mime) => (__api().mediaUrl ? __api().mediaUrl(u, mime) : u);

      // 2) Home Memory Time Machine Card
      let lastTmKey = '';
      function drawRandomMemory(userClicked) {
        const state = __st(); if (!state) return;
        const isZh = state.lang === 'zh';
        const setTxt = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
        setTxt('homeTmTitle', isZh ? '回忆时光机' : '추억 타임머신');
        setTxt('homeTmDrawLbl', isZh ? '抽取回忆' : '추억 꺼내기');

        const candidates = [];
        const albums = Array.isArray(state.albums) ? state.albums : [];
        albums.forEach(al => {
          const __aUrl = al && (al.dataUrl || al.url); if (__aUrl && !String(al.mediaType || '').includes('video')) {
            candidates.push({
              key: 'al_' + (al.id || al.date || Math.random()),
              date: al.date || (isZh ? '相册回忆' : '앨범 추억'),
              photo: __aUrl,
              main: al.caption || (isZh ? '我们一起珍藏的照片 💕' : '함께 간직한 소중한 사진 💕'),
              sub: al.category || ''
            });
          }
        });
        const msgs = Array.isArray(state.chat?.messages) ? state.chat.messages : [];
        msgs.forEach(m => {
          if (!m) return;
          const o = String(m.original || '').trim();
          const t = String(m.translated || '').trim();
          if (m.photoUrl) {
            candidates.push({
              key: 'mp_' + m.id,
              date: m.dateStr || m.time || (isZh ? '聊天照片' : '대화 사진'),
              photo: m.photoUrl,
              main: (!/사진을 보냈어요|分享了一张照片/.test(o) && o) ? o : (isZh ? '聊天中分享的瞬间 📷' : '대화 중 나눈 소중한 순간 📷'),
              sub: (!/사진을 보냈어요|分享了一张照片/.test(o) && t && t !== o) ? t : ''
            });
          } else if (o.length >= 4 && o.length <= 80 && t && t !== o && !/번역이 부정확|번역 중|동영상을 보냈어요|分享了一段视频/.test(o + ' ' + t)) {
            candidates.push({
              key: 'mt_' + m.id,
              date: m.dateStr || m.time || (isZh ? '那天的对话' : '그날의 대화'),
              photo: '',
              main: o,
              sub: t
            });
          }
        });

        const photoWrap = document.getElementById('homeTmPhotoWrap');
        const photoImg = document.getElementById('homeTmPhotoImg');
        if (!candidates.length) {
          setTxt('homeTmDateBadge', isZh ? '等待记录' : '추억 대기 중');
          setTxt('homeTmMainText', isZh ? '多聊天、多发照片后，时光机会随机翻出甜蜜回忆 ✨' : '대화와 사진이 쌓이면 타임머신이 랜덤으로 추억을 꺼내 줘요 ✨');
          setTxt('homeTmSubText', '');
          if (photoWrap) photoWrap.classList.add('hidden');
          return;
        }
        let pick = candidates[Math.floor(Math.random() * candidates.length)];
        if (candidates.length > 1 && pick.key === lastTmKey) {
          pick = candidates[(candidates.indexOf(pick) + 1) % candidates.length];
        }
        lastTmKey = pick.key;
        setTxt('homeTmDateBadge', pick.date);
        setTxt('homeTmMainText', pick.main);
        setTxt('homeTmSubText', pick.sub || '');
        if (pick.photo && photoWrap && photoImg) {
          photoImg.src = __mediaUrl(pick.photo);
          photoWrap.classList.remove('hidden');
        } else if (photoWrap) {
          photoWrap.classList.add('hidden');
        }
        if (userClicked && typeof window.__triggerCoupleKeywordEffect === 'function') {
          window.__triggerCoupleKeywordEffect('보고 싶어');
        }
      }
      window.__drawHomeTimeMachine = drawRandomMemory;

      document.getElementById('homeTmDrawBtn')?.addEventListener('click', () => drawRandomMemory(true));
      document.getElementById('homeTmPhotoImg')?.addEventListener('click', () => {
        const img = document.getElementById('homeTmPhotoImg');
        const lb = document.getElementById('photoLightboxModal');
        const lbImg = document.getElementById('lightboxImg');
        const lbVid = document.getElementById('lightboxVideo');
        if (img && img.src && lb && lbImg) {
          if (lbVid) { lbVid.pause?.(); lbVid.classList.add('hidden'); }
          lbImg.src = img.src;
          lbImg.classList.remove('hidden');
          lb.classList.remove('hidden');
        }
      });

      drawRandomMemory(false);
      setTimeout(() => { drawRandomMemory(false); }, 1100);
      
    })();