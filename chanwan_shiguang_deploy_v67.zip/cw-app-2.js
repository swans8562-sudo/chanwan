        // Populate Home Jingchan Study Check Card & Today's Expression Card
        try {
          const kstTodayStr = getKstDateString();
          const isZhUi = state.lang === 'zh';
          const todayCnt = state.learn.todaySolvedDate === kstTodayStr ? (state.learn.todaySolvedCount || 0) : 0;
          const studiedToday = todayCnt > 0;
          const rankInfo = getRankInfo(state.learn.xp || 0);
          const stTitle = document.getElementById('homeStudyStatusTitle');
          const stPill = document.getElementById('homeStudyStatusPill');
          const stMeta = document.getElementById('homeStudyMetaText');
          const stLast = document.getElementById('homeStudyLastTime');
          if (stTitle) stTitle.textContent = studiedToday
            ? (isZhUi ? `✅ 靖灿今天已打卡学习 (${todayCnt}题)` : `✅ 징찬이 오늘 공부했어요! (${todayCnt}문제)`)
            : (isZhUi ? '⏳ 靖灿今天还没开始学习哦' : '⏳ 징찬이 아직 오늘 공부 전이에요');
          if (stPill) {
            const goalMet = todayCnt >= DAILY_STUDY_GOAL;
            stPill.textContent = goalMet ? `🎉 ${todayCnt}/${DAILY_STUDY_GOAL}` : `${todayCnt} / ${DAILY_STUDY_GOAL}`;
            stPill.style.background = goalMet ? 'rgba(16, 185, 129, 0.18)' : (studiedToday ? 'rgba(124, 58, 237, 0.14)' : 'var(--accent-royal-soft)');
            stPill.style.color = goalMet ? '#059669' : 'var(--accent-royal)';
          }
          if (stMeta) stMeta.textContent = isZhUi
            ? `${rankInfo.label} · 累计 ${state.learn.xp || 0} XP · 连胜 ${state.learn.streak || 0}🔥`
            : `${rankInfo.label} · 누적 ${state.learn.xp || 0} XP · 연속 ${state.learn.streak || 0}🔥`;
          // Render Praise Stickers
          const praises = Array.isArray(state.learn.praiseStickers) ? state.learn.praiseStickers : [];
          const pTitle = document.getElementById('homePraiseTitle');
          const pBadges = document.getElementById('homePraiseBadges');
          const pBar = document.getElementById('suwanPraiseBar');
          const pBarLbl = document.getElementById('suwanPraiseBarLabel');
          if (pTitle) pTitle.textContent = isZhUi
            ? `⭐ 完送的表扬贴纸 (${praises.length}张)`
            : `⭐ 수완의 칭찬 스티커 (${praises.length}개)`;
          if (pBarLbl) pBarLbl.textContent = isZhUi
            ? '👑 完专属 · 赠送表扬贴纸 (+20 XP)'
            : '👑 수완 전용 · 칭찬 스티커 붙이기 (+20 XP)';
          if (pBar) pBar.classList.toggle('hidden', state.myRole !== 'suwan');
          if (pBadges) {
            if (!praises.length) {
              pBadges.innerHTML = `<span class="text-[10px] text-mut">${isZhUi ? '加油打卡！等待完送出第一张表扬贴纸 ✨' : '아직 받은 스티커가 없어요 · 수완이 칭찬 스티커를 붙여줄 수 있어요 ✨'}</span>`;
            } else {
              pBadges.innerHTML = praises.slice(0, 6).map(pr => `<span class="inline-flex items-center gap-0.5 px-2 py-0.5 rounded-full font-semibold" style="background: var(--accent-royal-soft); color: var(--accent-royal);">${escapeHtml(pr.icon || '⭐')} ${escapeHtml(isZhUi ? (pr.zh || pr.ko) : pr.ko)}</span>`).join('') + (praises.length > 6 ? `<span class="text-[10px] text-mut self-center">+${praises.length - 6}</span>` : '');
            }
          }
          const wkStrip = document.getElementById('homeStudyWeekStrip');
          if (wkStrip) {
            const log = (state.learn && state.learn.studyLog) || {};
            const baseDate = parseYmd(kstTodayStr);
            const daysHtml = [];
            for (let offset = 6; offset >= 0; offset--) {
              const dt = new Date(baseDate.getTime() - offset * 86400000);
              const ymd = dt.toISOString().slice(0, 10);
              const cnt = log[ymd] || (ymd === kstTodayStr ? todayCnt : 0);
              const dayNum = Number(ymd.slice(8, 10));
              const done = cnt > 0;
              daysHtml.push(`<div class="rounded-lg py-1 text-center text-[9.5px] font-semibold" style="background: ${done ? 'rgba(16,185,129,0.16)' : 'var(--surface-2)'}; color: ${done ? '#059669' : 'var(--text-muted)'};">${dayNum}<br/>${done ? '✓' : '·'}</div>`);
            }
            wkStrip.innerHTML = daysHtml.join('');
          }
          if (stLast) stLast.textContent = state.learn.lastStudyTime
            ? (isZhUi ? `最近学习：${state.learn.lastStudyTime}` : `마지막 공부: ${state.learn.lastStudyTime}`)
            : (isZhUi ? '暂无今日学习记录' : '아직 학습 기록이 없어요');

          const dSeed = parseYmd(kstTodayStr).getTime() / 86400000;
          const dEx = DAILY_CURRICULUM[Math.abs(Math.floor(dSeed)) % DAILY_CURRICULUM.length];
          if (dEx) {
            const koEl = document.getElementById('homeDailyKo');
            const zhEl = document.getElementById('homeDailyZh');
            const prEl = document.getElementById('homeDailyPron');
            const spBtn = document.getElementById('homeDailySpeakBtn');
            const slBtn = document.getElementById('homeDailySlowBtn');
            if (koEl) koEl.textContent = dEx.ko;
            if (zhEl) zhEl.textContent = dEx.zh;
            const zhSpBtn = document.getElementById('homeDailyZhSpeakBtn');
            if (zhSpBtn) zhSpBtn.setAttribute('data-text', dEx.zh);
            if (prEl) prEl.textContent = `[${dEx.pron}]`;
            if (spBtn) spBtn.setAttribute('data-text', dEx.ko);
            if (slBtn) slBtn.setAttribute('data-text', dEx.ko);
            const rcBtn = document.getElementById('homeDailyRecBtn');
            if (rcBtn) { rcBtn.setAttribute('data-text', dEx.ko); rcBtn.textContent = (state.customVoices && state.customVoices[dEx.ko]) ? '💜' : '🎙️'; }
            const vp = document.getElementById('homeDailyVoicePill');
            if (vp) {
              const hasV = !!(state.customVoices && state.customVoices[dEx.ko]);
              vp.classList.toggle('hidden', !hasV);
              vp.textContent = state.lang === 'zh' ? '🎧 秀完原声' : '🎧 수완 보이스';
            }
          }
        } catch (_) {}

        const todayHb = getKstDateString();
        if (!state.heartResetDate) state.heartResetDate = todayHb;
        const hbDaysPassed = diffDays(state.heartResetDate, todayHb);
        if (hbDaysPassed >= 3) {
          state.heartCount = 0;
          state.heartResetDate = todayHb;
        }
        const hbRemainDays = Math.max(1, 3 - Math.max(0, diffDays(state.heartResetDate, todayHb)));
        document.getElementById('heartbeatCountLabel').textContent = state.lang === 'zh'
          ? `心动 ${state.heartCount || 0} 次 · ${hbRemainDays}天后重置`
          : `하트비트 ${state.heartCount || 0}번 · ${hbRemainDays}일 후 초기화`;

        document.getElementById('cityFlagSuwan').textContent = c1.flag || '📍';
        document.getElementById('cityNameSuwan').textContent = c1.name;
        document.getElementById('cityFlagShanghai').textContent = c2.flag || '📍';
        document.getElementById('cityNameShanghai').textContent = c2.name;

        document.getElementById('suwanMoodCityLabel').textContent = state.lang === 'zh' ? '秀完' : '수완';
        document.getElementById('jingchanMoodCityLabel').textContent = state.lang === 'zh' ? '靖灿' : '징찬';
        document.getElementById('suwanMoodDisplay').textContent = formatMoodByLang(state.profile.suwanMood);
        document.getElementById('jingchanMoodDisplay').textContent = formatMoodByLang(state.profile.jingchanMood);
        populateMoodSelect('suwanMoodSelect', state.profile.suwanMood);
        populateMoodSelect('jingchanMoodSelect', state.profile.jingchanMood);
        const curRoleMood = state.myRole || 'suwan';
        const swSel = document.getElementById('suwanMoodSelect');
        const jcSel = document.getElementById('jingchanMoodSelect');
        const swEditBtn = document.getElementById('suwanCustomMoodBtn');
        const jcEditBtn = document.getElementById('jingchanCustomMoodBtn');
        if (swSel) { swSel.disabled = curRoleMood !== 'suwan'; swSel.classList.toggle('hidden', curRoleMood !== 'suwan'); }
        if (jcSel) { jcSel.disabled = curRoleMood !== 'jingchan'; jcSel.classList.toggle('hidden', curRoleMood !== 'jingchan'); }
        if (swEditBtn) swEditBtn.classList.toggle('hidden', curRoleMood !== 'suwan');
        if (jcEditBtn) jcEditBtn.classList.toggle('hidden', curRoleMood !== 'jingchan');

        document.getElementById('avatarSuwanInner').innerHTML = state.profile.suwanAvatar
          ? `<img src="${state.profile.suwanAvatar}" alt="수완" class="w-full h-full object-cover" />` : (state.lang === 'zh' ? '秀完' : '수완');
        if (typeof renderWakeSleepCards === 'function') renderWakeSleepCards();
        if (typeof renderEnergyActivityCards === 'function') renderEnergyActivityCards();
        if (typeof renderLoveThermometer === 'function') renderLoveThermometer();
        if (typeof renderMealCheckin === 'function') renderMealCheckin();
        if (typeof renderLavenderPot === 'function') renderLavenderPot();
        document.getElementById('avatarJingchanInner').innerHTML = state.profile.jingchanAvatar
          ? `<img src="${state.profile.jingchanAvatar}" alt="징찬" class="w-full h-full object-cover" />` : (state.lang === 'zh' ? '靖灿' : '징찬');

        const keySet = !!(state.settings && state.settings.geminiApiKey);
        const badgeLabel = keySet ? 'Gemini 3.5 Live' : 'Google Neural AI';
        document.getElementById('engineBadgeHome').textContent = badgeLabel;
        document.getElementById('engineBadgeStudio').textContent = badgeLabel;

        const feed = [];
        if (state.chat.messages.length) {
          const lastMsg = state.chat.messages[state.chat.messages.length - 1];
          feed.push({ icon: '💌', label: state.lang === 'zh' ? '最新聊天' : '최근 메신저', text: `${lastMsg.original} → ${lastMsg.translated}` });
        }
        if (state.diaries.length) {
          const lastD = state.diaries[0];
          feed.push({ icon: '🪶', label: `${state.lang === 'zh' ? '日记' : '일기'} (${lastD.author})`, text: lastD.title });
        }
        if ((state.capsules || []).length) {
          feed.push({ icon: '⏳', label: '타임캡슐 편지', text: `봉인된 비밀 편지 ${state.capsules.length}통 보관 중` });
        }
        const rank = getRankInfo(state.learn.xp || 0);
        feed.push({ icon: '🌸', label: state.lang === 'zh' ? '韩语学习进度' : '징찬 한국어 학습', text: `${rank.label} · ${state.learn.xp} XP · ${state.learn.solved}문제 정답` });

        const __hrf = document.getElementById('homeRecentFeed'); if (__hrf) __hrf.innerHTML = feed.map(item => `
          <div class="royal-subcard rounded-2xl px-3.5 py-2.5 flex items-center gap-3 min-w-0">
            <span class="text-base shrink-0">${item.icon}</span>
            <div class="min-w-0 flex-1">
              <div class="text-[11px] text-gold font-semibold truncate">${escapeHtml(item.label)}</div>
              <div class="text-xs text-sec truncate">${escapeHtml(item.text)}</div>
            </div>
          </div>
        `).join('');
        updateVaultIndicators();
      }

      function renderTransHistory() {
        const list = state.transHistory || [];
        const el = document.getElementById('transHistoryList');
        if (!el) return;
        el.innerHTML = list.length ? list.map(h => `
          <div class="royal-subcard rounded-2xl p-3 space-y-1.5">
            <div class="flex items-center justify-between gap-2 text-[10px]">
              <div class="flex items-center gap-1.5">
                <span class="font-bold px-2 py-0.5 rounded-full" style="background: ${h.author === 'jingchan' ? 'rgba(168,85,247,0.14); color: #7c3aed;' : 'rgba(244,63,94,0.12); color: #e11d48;'}">${h.author === 'jingchan' ? '💜 靖灿(灿)' : '❤️ 수완(完)'}</span>
                ${h.accuracy ? `<span class="font-bold px-1.5 py-0.5 rounded-full" style="background: ${h.accuracy >= 90 ? 'rgba(16,185,129,0.12)' : 'rgba(245,158,11,0.14)'}; color: ${h.accuracy >= 90 ? '#059669' : '#d97706'};">${state.lang === 'zh' ? '准确度' : '정확도'} ${h.accuracy}%</span>` : ''}
              </div>
              ${h.time ? `<span class="text-mut">${escapeHtml(h.time)}</span>` : ''}
            </div>
            <div class="flex items-start justify-between gap-2">
              <div class="min-w-0 flex-1">
                <div class="text-xs text-mut break-words">${escapeHtml(h.original)}</div>
                <div class="text-sm font-bold text-gold mt-0.5 break-words">${escapeHtml(h.translated)}</div>
              </div>
              <div class="flex gap-1 shrink-0">
                <button type="button" class="speak-btn btn-ghost w-7 h-7 rounded-full flex items-center justify-center text-[11px]" data-text="${escapeHtml(h.translated)}" data-lang="${h.tgtLang === 'zh' ? 'zh-CN' : 'ko-KR'}">🔊</button>
                <button type="button" class="copy-btn btn-ghost w-7 h-7 rounded-full flex items-center justify-center text-[11px]" data-text="${escapeHtml(h.translated)}">📋</button>
              </div>
            </div>
            ${h.nuance ? `<div class="text-[11px] text-sec leading-relaxed">💎 ${escapeHtml(h.nuance)}</div>` : ''}
          </div>
        `).join('') : `<div class="text-xs text-mut text-center py-5">최근 번역 기록이 없습니다. 위에서 문장을 번역해 보세요 ✨</div>`;
      }

      function renderLearn() {
        const kstToday = getKstDateString();
        const xp = state.learn.xp || 0;
        const rank = getRankInfo(xp);

        document.getElementById('learnDateBanner').textContent = `${kstToday} (KST) · ${state.lang === 'zh' ? '每日自动更新5级韩语题库' : '매일 5단계 한국어 문제 & 표현 자동 갱신'}`;
        document.getElementById('learnRankBadge').textContent = rank.label;
        document.getElementById('learnXpCount').textContent = `${xp} XP`;
        document.getElementById('learnStreakCount').textContent = `${state.learn.streak || 0}🔥`;
        document.getElementById('learnRankProgressLabel').textContent = rank.next;
        document.getElementById('learnSolvedCount').textContent = `${state.learn.solved || 0}${state.lang === 'zh' ? '题正确' : '문제 완료'}`;
        document.getElementById('learnRankBar').style.width = `${Math.max(4, rank.pct)}%`;
        const todayGoalCnt = state.learn.todaySolvedDate === kstToday ? (state.learn.todaySolvedCount || 0) : 0;
        const bmCount = Array.isArray(state.learn.bookmarks) ? state.learn.bookmarks.length : 0;
        const goalEl = document.getElementById('learnDailyGoalText');
        const bmEl = document.getElementById('learnBookmarkSummary');
        const todayXpNow = getTodayXpEarned();
        if (goalEl) goalEl.textContent = state.lang === 'zh'
          ? `🎯 今日目标: ${Math.min(DAILY_STUDY_GOAL, todayGoalCnt)}/${DAILY_STUDY_GOAL} 题 · ⚡ 今日XP: ${todayXpNow}/${DAILY_XP_CAP}`
          : `🎯 오늘 목표: ${Math.min(DAILY_STUDY_GOAL, todayGoalCnt)}/${DAILY_STUDY_GOAL}문제 · ⚡ 오늘 XP: ${todayXpNow}/${DAILY_XP_CAP}`;
        const vcCount = state.customVoices ? Object.keys(state.customVoices).length : 0;
        if (bmEl) bmEl.textContent = state.lang === 'zh' ? `⭐ 收藏 ${bmCount} 条 · 🎧 秀完原声 ${vcCount} 条` : `⭐ 즐겨찾기 ${bmCount}개 · 🎧 수완 보이스 ${vcCount}개`;
        const zeroBar = document.getElementById('learnZeroRecoverBar');
        if (zeroBar) {
          const isZeroLearn = (Number(state.learn?.xp || 0) === 0 && Number(state.learn?.solved || 0) === 0);
          zeroBar.classList.toggle('hidden', !isZeroLearn);
          if (isZeroLearn) {
            const isZhL = state.lang === 'zh';
            const hEl = document.getElementById('learnZeroRecoverHint');
            const cBtn = document.getElementById('learnCloudRecoverBtn');
            const bBtn = document.getElementById('learnBackupMergeBtn');
            if (hEl) hEl.textContent = isZhL ? '💡 学习记录为空？可从云端/对方手机或备份合并恢复' : '💡 학습 기록이 비었나요? 징찬 폰·서버 또는 백업에서 바로 합쳐요';
            if (cBtn) {
              cBtn.textContent = isZhL ? '☁️ 云端·对方手机恢复' : '☁️ 서버·징찬 폰 복구';
              if (!cBtn.dataset.bound) {
                cBtn.dataset.bound = '1';
                cBtn.addEventListener('click', () => {
                  if (typeof window.__runFullCloudDataRestore === 'function') window.__runFullCloudDataRestore(false);
                });
              }
            }
            if (bBtn) {
              bBtn.textContent = isZhL ? '📥 导入备份合并' : '📥 백업 파일 합치기';
              if (!bBtn.dataset.bound) {
                bBtn.dataset.bound = '1';
                bBtn.addEventListener('click', () => {
                  document.getElementById('importBackupInput')?.click();
                });
              }
            }
          }
        }

        // Build 12 daily phrases every day from DAILY_CURRICULUM + CHEAT_SHEET_72
        const dailyMasterPool = DAILY_CURRICULUM.concat(
          (typeof CHEAT_SHEET_72 !== 'undefined' ? CHEAT_SHEET_72 : []).map(c => ({
            ko: c.ko,
            zh: c.zh,
            pron: romanizeKoreanBasic(c.ko),
            nuance: c.nu || '실제 대화에서 자주 쓰이는 자연스러운 한국어 표현입니다.',
            nuanceZh: ''
          }))
        );
        const seed = parseYmd(kstToday).getTime() / 86400000;
        const startIdx = Math.abs(Math.floor(seed) * 12) % dailyMasterPool.length;
        const todays = Array.from({ length: 12 }, (_, offset) => dailyMasterPool[(startIdx + offset) % dailyMasterPool.length]);
        const spokenTodaySet = new Set(state.learn.spokenDoneDate === kstToday && Array.isArray(state.learn.spokenDoneList) ? state.learn.spokenDoneList : []);

        document.getElementById('dailyExpressionsList').innerHTML = todays.map((ex, i) => {
          const isSpokenOk = spokenTodaySet.has(ex.ko);
          return `
          <div class="royal-card rounded-3xl p-4 sm:p-5 space-y-2.5">
            <div class="flex items-start justify-between gap-2">
              <div class="min-w-0 flex-1">
                <span class="text-[10px] font-semibold text-champagne uppercase">Today's Phrase #${i + 1} / 12${isSpokenOk ? ' · ✅ 말하기 완료' : ''}</span>
                <h3 class="text-base sm:text-lg font-bold mt-0.5 leading-snug break-words">${escapeHtml(ex.ko)}</h3>
                <div class="flex items-center gap-1.5 mt-0.5">
                  <span class="text-sm text-sec break-words">${escapeHtml(ex.zh)}</span>
                  <button type="button" class="speak-btn btn-ghost px-2 py-0.5 rounded-full text-[10px] font-semibold shrink-0 whitespace-nowrap" data-text="${escapeHtml(ex.zh)}" data-lang="zh-CN" title="중국어 듣기">🇨🇳🔊</button>
                </div>
                <div class="text-[11px] text-mut mt-0.5 break-words">[발음] ${escapeHtml(ex.pron)}</div>
              </div>
              <div class="flex items-center gap-1.5 shrink-0">
                ${(() => { const on = typeof window.__isProblemStarred === 'function' && window.__isProblemStarred(ex.ko, ex.zh); return `<button type="button" class="cw-star-prob-btn ${on ? 'btn-gold' : 'btn-ghost'} w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold" data-q="${escapeHtml(ex.ko)}" data-zh="${escapeHtml(ex.zh)}" data-ans="${escapeHtml(ex.ko)}" data-aud="${escapeHtml(ex.ko)}" data-lvl="${state.lang === 'zh' ? '今日学习' : '오늘의 학습'}" title="즐겨찾기">${on ? '⭐' : '☆'}</button>`; })()}${suwanVoicePillHtml(ex.ko)}<button type="button" class="speak-btn btn-royal w-9 h-9 rounded-full flex items-center justify-center text-xs" data-text="${escapeHtml(ex.ko)}" data-lang="ko-KR" title="보통 속도 듣기">${window.getAppIconHtml ? window.getAppIconHtml('speak') : '🔈'}</button>
                <button type="button" class="speak-btn btn-ghost w-9 h-9 rounded-full flex items-center justify-center text-xs" data-text="${escapeHtml(ex.ko)}" data-lang="ko-KR" data-slow="1" title="천천히 듣기">${window.getAppIconHtml ? window.getAppIconHtml('slow') : '0.7×'}</button>
                <button type="button" class="rec-voice-btn ${state.customVoices && state.customVoices[ex.ko] ? 'btn-gold' : 'btn-ghost'} w-9 h-9 rounded-full flex items-center justify-center text-xs" data-text="${escapeHtml(ex.ko)}" title="내 목소리 녹음/재녹음">${state.customVoices && state.customVoices[ex.ko] ? '💜' : (window.getAppIconHtml ? window.getAppIconHtml('record') : '🎙️')}</button>
                ${state.customVoices && state.customVoices[ex.ko] ? `<button type="button" class="del-voice-btn btn-ghost w-7 h-7 rounded-full flex items-center justify-center text-[10px] text-rose-500" data-text="${escapeHtml(ex.ko)}" title="녹음 삭제">✕</button>` : ''}
              </div>
            </div>
            <div class="nuance-box rounded-xl p-3 text-xs text-sec leading-relaxed">
              <b class="text-gold">${state.lang === 'zh' ? '💎 语感与用法解析：' : '💎 뉘앙스 포인트:'}</b> ${escapeHtml(state.lang === 'zh' ? (ex.nuanceZh || localizeLearnNuanceZh(ex)) : ex.nuance)}
            </div>
            <div class="flex items-center justify-end">
              <button type="button" class="speech-check-btn ${isSpokenOk ? 'btn-ghost text-emerald-600' : 'btn-gold'} px-3 py-1.5 rounded-full text-[11px] font-semibold inline-flex items-center gap-1" data-ko="${escapeHtml(ex.ko)}" data-zh="${escapeHtml(ex.zh)}" data-pron="${escapeHtml(ex.pron)}">${isSpokenOk ? (state.lang === 'zh' ? '✅ 已跟读 (+15 XP)' : '✅ 따라 말하기 완료') : (state.lang === 'zh' ? '🎤 跟读语音打卡 (+15 XP)' : '🎤 따라 말하기 (+15 XP)')}</button>
            </div>
          </div>`;
        }).join('');

        renderQuiz();
        renderWrongNotes();
        renderCheatSheet();
        if (typeof window.syncAllTabIconsToStyle === 'function') window.syncAllTabIconsToStyle(null, document.getElementById('tab-learn'));
      }

      function renderQuiz() {
        const level = LEVEL_META[state.learn.currentLevel] ? state.learn.currentLevel : 'starter';
        const meta = LEVEL_META[level];
        const isZh = state.lang === 'zh';
        const counter = state.learn.quizIdx || 0;
        const q = getQuestionFor(level, counter);

        const curRank = getRankInfo(state.learn.xp || 0);
        const curLv = curRank.level || 1;
        // If Jingchan is on a locked level (e.g. after reset), fallback to starter
        const activeReqLv = QUIZ_LEVEL_UNLOCK[level] || 1;
        if (state.myRole === 'jingchan' && curLv < activeReqLv && level !== 'starter') {
          state.learn.currentLevel = 'starter';
        }
        document.querySelectorAll('.quiz-level-btn').forEach(btn => {
          const lvlKey = btn.getAttribute('data-level');
          const reqLv = QUIZ_LEVEL_UNLOCK[lvlKey] || 1;
          const locked = curLv < reqLv;
          const active = lvlKey === (state.learn.currentLevel || 'starter');
          const m = LEVEL_META[lvlKey];
          const baseLbl = m ? (isZh ? m.nameZh : m.nameKo) : btn.textContent;
          btn.textContent = locked ? `🔒 ${baseLbl} (Lv.${reqLv})` : baseLbl;
          btn.style.opacity = locked ? '0.62' : '1';
          btn.className = `quiz-level-btn ${active ? 'btn-gold' : 'btn-ghost'} px-3 py-1.5 rounded-full text-xs whitespace-nowrap`;
        });
        document.getElementById('quizModeBadge').textContent = isZh
          ? `${meta.badgeZh} (+${meta.xp} XP) · ${q.tagZh || q.tag || '实战题'}`
          : `${meta.badge} (+${meta.xp} XP) · ${q.tag || '실전 문제'}`;
        document.getElementById('quizQuestionCounter').textContent = isZh ? `第 #${counter + 1} 题` : `문제 #${counter + 1}`;
        window.__currentQuizForStar = {
          q: q.q || '',
          zh: q.zh || '',
          answer: (Array.isArray(q.options) && typeof q.a === 'number') ? (q.options[q.a] || '') : '',
          audio: q.audio || '',
          level: isZh ? meta.badgeZh : meta.badge
        };
        if (typeof window.__syncQuizStarBtnUi === 'function') window.__syncQuizStarBtnUi();

        document.getElementById('quizContainer').innerHTML = `
          <div class="flex items-start justify-between gap-3">
            <div class="space-y-1 min-w-0 flex-1">
              <div class="text-sm sm:text-base font-bold leading-snug break-words">${escapeHtml(q.q)}</div>
              <div class="flex items-center gap-1.5 flex-wrap">
                <span class="text-xs sm:text-sm font-semibold text-gold leading-snug break-words">🇨🇳 ${escapeHtml(q.zh)}</span>
                <button type="button" class="speak-btn btn-ghost px-2 py-0.5 rounded-full text-[10px] font-semibold shrink-0 whitespace-nowrap" data-text="${escapeHtml(q.zh)}" data-lang="zh-CN" title="중국어 듣기">🇨🇳🔊</button>
              </div>
            </div>
            ${q.audio ? `
              <div class="flex items-center gap-1 shrink-0">
                ${suwanVoicePillHtml(q.audio)}<button type="button" class="speak-btn btn-royal w-9 h-9 rounded-full flex items-center justify-center text-xs" data-text="${escapeHtml(q.audio)}" data-lang="ko-KR" title="보통 속도">🔊</button>
                <button type="button" class="speak-btn btn-ghost w-9 h-9 rounded-full flex items-center justify-center text-xs" data-text="${escapeHtml(q.audio)}" data-lang="ko-KR" data-slow="1" title="천천히 듣기">🐢</button>
              </div>` : ''}
          </div>
          ${(state.learn.quizInputMode === 'typing' && /[가-힣]/.test(String(q.audio || q.opts[q.ans] || ''))) ? `
            <div class="space-y-2.5 pt-1">
              <div class="text-[11px] text-sec">${isZh ? '⌨️ 请用韩语键盘直接输入对应的韩语表达（可忽略空格和标点）：' : '⌨️ 한국어 키보드로 정답 문장을 직접 입력해 보세요 (띄어쓰기·문장부호 자동 허용):'}</div>
              <div class="flex items-center gap-2">
                <input id="quizTypingInput" type="text" lang="ko" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" class="royal-input flex-1 min-w-0 rounded-2xl px-3.5 py-2.5 text-sm font-semibold" placeholder="${isZh ? '在这里输入韩语...' : '여기에 한국어로 타이핑...'}" />
                <button id="quizTypingSubmitBtn" type="button" class="btn-royal px-4 py-2.5 rounded-2xl text-xs font-bold whitespace-nowrap shrink-0">${isZh ? '提交' : '확인'}</button>
              </div>
              <div class="flex flex-wrap items-center justify-between gap-2">
                <div class="flex items-center gap-1.5">
                  <button id="quizTypingHintBtn" type="button" class="btn-ghost px-2.5 py-1 rounded-full text-[11px] font-semibold">💡 ${isZh ? '首字母提示' : '초성 힌트'}</button>
                  <button id="quizTypingRevealBtn" type="button" class="btn-ghost px-2.5 py-1 rounded-full text-[11px] font-semibold">👀 ${isZh ? '看答案' : '정답 보기'}</button>
                </div>
                <span id="quizTypingHintText" class="text-xs font-bold text-gold tracking-wider"></span>
              </div>
            </div>
          ` : `
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
              ${q.opts.map((opt, oi) => `
                <button type="button" class="quiz-opt-btn royal-subcard hover:border-purple-400 rounded-2xl p-3.5 text-left text-sm leading-snug break-words transition" data-opt="${oi}">
                  <span class="text-gold font-bold mr-1.5">${oi + 1}.</span>${escapeHtml(opt)}
                </button>
              `).join('')}
            </div>
          `}
          <div id="quizFeedback" class="hidden nuance-box rounded-2xl p-3.5 text-xs space-y-2"></div>
        `;

        // Sync Choice vs Korean Typing mode buttons
        const curQMode = state.learn.quizInputMode || 'choice';
        document.querySelectorAll('.quiz-input-mode-btn').forEach(mb => {
          const m = mb.getAttribute('data-qmode');
          const act = m === curQMode;
          mb.className = `quiz-input-mode-btn ${act ? 'btn-royal' : 'btn-ghost'} px-2 py-0.5 rounded-full text-[10px] font-bold whitespace-nowrap`;
          mb.textContent = m === 'typing' ? (isZh ? '⌨️ 打字' : '⌨️ 타자') : (isZh ? '🔘 选择' : '🔘 객관식');
          if (!mb.dataset.boundQmode) {
            mb.dataset.boundQmode = '1';
            mb.addEventListener('click', () => {
              state.learn.quizInputMode = m;
              saveState(false);
              renderQuiz();
            });
          }
        });

        let answered = false;
        const typingInp = document.getElementById('quizTypingInput');
        if (typingInp) {
          const targetKo = (/[가-힣]/.test(String(q.opts[q.ans] || '')) ? String(q.opts[q.ans]) : String(q.audio || '')).trim();
          const normKo = (s) => String(s || '').replace(/[\s?!.,~'"()（）「」『』·]/g, '').trim();
          const getChoseong = (str) => {
            const CHO = ['ㄱ','ㄲ','ㄴ','ㄷ','ㄸ','ㄹ','ㅁ','ㅂ','ㅃ','ㅅ','ㅆ','ㅇ','ㅈ','ㅉ','ㅊ','ㅋ','ㅌ','ㅍ','ㅎ'];
            return Array.from(String(str || '')).map(ch => {
              const code = ch.charCodeAt(0) - 0xAC00;
              if (code >= 0 && code <= 11171) return CHO[Math.floor(code / 588)];
              return ch;
            }).join('');
          };
          const hintBtn = document.getElementById('quizTypingHintBtn');
          const hintEl = document.getElementById('quizTypingHintText');
          const revealBtn = document.getElementById('quizTypingRevealBtn');
          const submitBtn = document.getElementById('quizTypingSubmitBtn');
          if (hintBtn && hintEl) {
            hintBtn.addEventListener('click', () => {
              hintEl.textContent = getChoseong(targetKo);
              typingInp.focus();
            });
          }
          const checkTypingAnswer = (forceReveal) => {
            if (answered) return;
            const val = typingInp.value.trim();
            if (!forceReveal && !val) { typingInp.focus(); return; }
            const isOk = !forceReveal && normKo(val) === normKo(targetKo);
            const fb = document.getElementById('quizFeedback');
            fb.classList.remove('hidden');
            const zhNote = q.expZh ? q.expZh : `🇨🇳 中文解析：正确答案是「${targetKo}」。原题意思：${q.zh}`;
            if (isOk) {
              answered = true;
              typingInp.style.borderColor = '#10b981';
              const isJcRole = canEarnJingchanXp();
              const earnedXp = (meta.xp || 20) + 5;
              if (isJcRole) {
                if (!Array.isArray(state.learn.solvedQIds)) state.learn.solvedQIds = [];
                if (q.qId && !state.learn.solvedQIds.includes(q.qId)) state.learn.solvedQIds.push(q.qId);
                recordJingchanStudyProgress(earnedXp);
                state.learn.streak = (state.learn.streak || 0) + 1;
                if (!Array.isArray(state.learn.solvedHistory)) state.learn.solvedHistory = [];
                state.learn.solvedHistory.unshift({ ko: targetKo, zh: q.zh, time: new Date().toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' }) });
                if (state.learn.solvedHistory.length > 50) state.learn.solvedHistory = state.learn.solvedHistory.slice(0, 50);
                saveState(true);
                renderLearnHeader();
              }
              fb.innerHTML = `<div class="font-bold text-emerald-600">🎉 ${isZh ? `打字完全正确！+${earnedXp} XP（含打字奖励 +5）` : `타자 정답이에요! +${earnedXp} XP (타자 보너스 +5)`}</div><div class="font-bold text-gold">🇰🇷 ${escapeHtml(targetKo)}</div><div class="text-sec leading-relaxed">${escapeHtml(zhNote)}</div>`;
              try { speakText(targetKo, 'ko-KR', false); } catch (_) {}
            } else if (forceReveal) {
              answered = true;
              typingInp.value = targetKo;
              fb.innerHTML = `<div class="font-bold text-gold">👀 ${isZh ? '参考答案：' : '정답: '}${escapeHtml(targetKo)}</div><div class="text-sec leading-relaxed">${escapeHtml(zhNote)}</div><div class="text-[11px] text-mut">${isZh ? '听听发音并试着下一题自己打出来吧 💪' : '발음을 듣고 다음 문제에서 직접 타이핑해 보세요 💪'}</div>`;
              try { speakText(targetKo, 'ko-KR', false); } catch (_) {}
            } else {
              typingInp.style.borderColor = '#e11d48';
              fb.innerHTML = `<div class="font-bold text-rose-500">😅 ${isZh ? '差一点点！再试一次或点「首字母提示」吧' : '아쉬워요! 다시 입력해 보거나 「초성 힌트」를 눌러보세요'}</div><div class="text-[11px] text-mut">${isZh ? '提示：' : '초성 힌트: '}<b>${escapeHtml(getChoseong(targetKo))}</b></div>`;
              typingInp.focus();
            }
            if (typeof window.syncAllTabIconsToStyle === 'function') window.syncAllTabIconsToStyle(null, fb);
          };
          if (submitBtn) submitBtn.addEventListener('click', () => checkTypingAnswer(false));
          if (revealBtn) revealBtn.addEventListener('click', () => checkTypingAnswer(true));
          typingInp.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.isComposing) checkTypingAnswer(false); });
          setTimeout(() => { if (typeof window.syncAllTabIconsToStyle === 'function') window.syncAllTabIconsToStyle(null, document.getElementById('learn-sub-quiz')); }, 20);
        }
        document.querySelectorAll('.quiz-opt-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            if (answered) return;
            answered = true;
            const chosen = Number(btn.getAttribute('data-opt'));
            const fb = document.getElementById('quizFeedback');
            fb.classList.remove('hidden');
            const ansText = q.opts[q.ans];
            const zhMeaningNote = q.expZh
              ? q.expZh
              : `🇨🇳 中文解析：正确答案是「${ansText}」${q.audio && q.audio !== ansText ? `（韩语：${q.audio}）` : ''}。原题意思：${q.zh}`;

            if (chosen === q.ans) {
              const isJcRole = canEarnJingchanXp();
              if (isJcRole) {
                if (!Array.isArray(state.learn.solvedQIds)) state.learn.solvedQIds = [];
                if (q.qId && !state.learn.solvedQIds.includes(q.qId)) state.learn.solvedQIds.push(q.qId);
                if (state.learn.solvedQIds.length >= MASTER_QUIZ_CATALOG.length) state.learn.solvedQIds = [];
                recordJingchanStudyProgress(meta.xp);
                state.learn.streak = (state.learn.streak || 0) + 1;
                if (!Array.isArray(state.learn.solvedHistory)) state.learn.solvedHistory = [];
                state.learn.solvedHistory.unshift({
                  id: `sh_${Date.now()}`,
                  date: getKstDateString(),
                  time: new Date().toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' }),
                  level: meta.nameKo,
                  levelZh: meta.nameZh,
                  q: q.q,
                  zh: q.zh || '',
                  answer: ansText,
                  audio: q.audio || ansText,
                  correct: true,
                  xp: meta.xp
                });
                if (state.learn.solvedHistory.length > 60) state.learn.solvedHistory.length = 60;
                saveState(true);
              }
              playNotifChime();
              if (q.audio) speakKorean(q.audio);
              renderLearn();
              renderHome();
              btn.style.borderColor = '#10b981';
              const winTitle = isJcRole
                ? `🎉 ${isZh ? `答对啦！获得 +${meta.xp} XP (${state.learn.streak}连胜🔥)` : `정답이에요! +${meta.xp} XP 획득 (${state.learn.streak}연속 정답🔥)`}`
                : `❤️ ${isZh ? '答对啦！(完测试模式 · 不计入靖灿经验值)' : '정답이에요! (수완 테스트 모드 · 징찬 XP 미반영)'}`;
              fb.innerHTML = `
                <div class="font-bold text-emerald-700">${winTitle}</div>
                <div class="text-xs font-semibold text-gold leading-relaxed">${escapeHtml(zhMeaningNote)}</div>
                ${isZh ? '' : `<div class="text-sec leading-relaxed">${escapeHtml(q.exp)}</div>`}
                <div class="flex flex-wrap gap-2 pt-1">
                  <button type="button" class="inline-next-quiz btn-royal px-4 py-1.5 rounded-full text-xs font-semibold">${isZh ? '下一道新题 →' : '다음 새 문제 풀기 →'}</button>
                  ${q.audio ? `<button type="button" class="speak-btn btn-ghost px-3 py-1.5 rounded-full text-xs" data-text="${escapeHtml(q.audio)}" data-lang="ko-KR">🔊 ${isZh ? '再听一遍' : '발음 듣기'}</button>` : ''}
                </div>
              `;
              if (isJcRole) {
                pushNotification('🌸', `징찬 한국어 ${meta.nameKo} 정답! (+${meta.xp} XP)`, `靖灿韩语${meta.nameZh}答对！(+${meta.xp} XP)`, `${state.learn.streak}연속 정답 달성 🔥`, `已达${state.learn.streak}连胜 🔥`, 'learn', 'quiz', 'post', true, 'jingchan');
              }
            } else {
              const isJcWrong = canEarnJingchanXp();
              if (isJcWrong) {
                state.learn.streak = 0;
                if (!Array.isArray(state.learn.wrongNotes)) state.learn.wrongNotes = [];
                if (!state.learn.wrongNotes.some(w => w.q === q.q)) {
                  state.learn.wrongNotes.unshift({ id: `wr_${Date.now()}`, level: isZh ? meta.badgeZh : meta.badge, q: `${q.q} (${q.zh})`, answer: ansText, exp: `${zhMeaningNote} / ${q.exp}`, audio: q.audio || '' });
                }
                if (!Array.isArray(state.learn.solvedHistory)) state.learn.solvedHistory = [];
                state.learn.solvedHistory.unshift({
                  id: `sh_${Date.now()}`,
                  date: getKstDateString(),
                  time: new Date().toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' }),
                  level: meta.nameKo,
                  levelZh: meta.nameZh,
                  q: q.q,
                  zh: q.zh || '',
                  answer: ansText,
                  audio: q.audio || ansText,
                  correct: false,
                  xp: 0
                });
                if (state.learn.solvedHistory.length > 60) state.learn.solvedHistory.length = 60;
                saveState(true);
                document.getElementById('learnStreakCount').textContent = `0🔥`;
                renderWrongNotes();
              }
              btn.style.borderColor = '#f43f5e';
              fb.innerHTML = `
                <div class="font-bold text-rose-500">${isZh ? '差一点哦！已自动存入错题本 📌' : '아쉬워요! 오답 복습 노트에 자동 저장했어요 📌'}</div>
                <div class="text-xs font-semibold text-gold leading-relaxed">${escapeHtml(zhMeaningNote)}</div>
                ${isZh ? '' : `<div class="text-sec leading-relaxed">${escapeHtml(q.exp)}</div>`}
                <div class="flex flex-wrap gap-2 pt-1">
                  <button type="button" class="inline-next-quiz btn-royal px-4 py-1.5 rounded-full text-xs font-semibold">${isZh ? '下一道新题 →' : '다음 새 문제 풀기 →'}</button>
                  ${q.audio ? `<button type="button" class="speak-btn btn-ghost px-3 py-1.5 rounded-full text-xs" data-text="${escapeHtml(q.audio)}" data-lang="ko-KR">🔊 ${isZh ? '听正确发音' : '정답 발음 듣기'}</button>` : ''}
                </div>
              `;
            }

            if (window.__quizAutoNextTimer) { clearTimeout(window.__quizAutoNextTimer); window.__quizAutoNextTimer = null; }
            const goNextQuizNow = () => {
              if (window.__quizAutoNextTimer) { clearTimeout(window.__quizAutoNextTimer); window.__quizAutoNextTimer = null; }
              state.learn.quizIdx = (state.learn.quizIdx || 0) + 1;
              saveState();
              renderQuiz();
            };
            const autoHintDiv = document.createElement('div');
            autoHintDiv.className = 'text-[10.5px] text-mut pt-0.5';
            autoHintDiv.textContent = isZh ? '⏱️ 2.5秒后自动进入下一题...' : '⏱️ 2.5초 후 다음 문제로 자동 넘어가요...';
            fb.appendChild(autoHintDiv);
            window.__quizAutoNextTimer = setTimeout(goNextQuizNow, 2500);
            const nextInline = fb.querySelector('.inline-next-quiz');
            if (nextInline) nextInline.addEventListener('click', goNextQuizNow);
            if (typeof window.syncAllTabIconsToStyle === 'function') window.syncAllTabIconsToStyle(null, fb);
          });
        });
        if (typeof window.syncAllTabIconsToStyle === 'function') window.syncAllTabIconsToStyle(null, document.getElementById('learn-sub-quiz') || document.getElementById('tab-learn'));
      }

      function renderWrongNotes() {
        const list = state.learn.wrongNotes || [];
        const el = document.getElementById('wrongNotesList');
        if (!el) return;
        const pickLangAudio = (obj) => {
          const hasKo = (s) => /[가-힣]/.test(String(s || ''));
          const hasZh = (s) => /[\u4e00-\u9fff]/.test(String(s || ''));
          const koCandidates = [obj.audio, obj.answer, obj.ko, obj.q].filter(s => s && hasKo(s));
          const zhCandidates = [obj.zh, obj.q, obj.answer, obj.exp].filter(s => s && hasZh(s));
          const cleanSpeak = (s, lang) => {
            let txt = String(s || '').replace(/[「」『』""''\[\]()]/g, ' ').trim();
            if (lang === 'zh') {
              const zhChunks = txt.match(/[\u4e00-\u9fff0-9，。！？、\s]+/g);
              if (zhChunks) txt = zhChunks.join(' ').trim();
            } else {
              const koChunks = txt.match(/[가-힣0-9,\.!\?\s]+/g);
              if (koChunks) txt = koChunks.join(' ').trim();
            }
            return txt.slice(0, 90);
          };
          return {
            ko: koCandidates.length ? cleanSpeak(koCandidates[0], 'ko') : '',
            zh: zhCandidates.length ? cleanSpeak(zhCandidates[0], 'zh') : ''
          };
        };
        el.innerHTML = list.length ? list.map(w => {
          const aud = pickLangAudio(w);
          return `
          <div class="royal-subcard rounded-2xl p-3.5 space-y-1.5">
            <div class="flex items-center justify-between gap-2">
              <span class="text-[10px] px-2 py-0.5 rounded-full text-gold font-semibold" style="background: var(--accent-royal-soft);">${escapeHtml(w.level)}</span>
              <div class="flex items-center gap-1.5 shrink-0">
                ${(() => { const on = typeof window.__isProblemStarred === 'function' && window.__isProblemStarred(w.q, w.answer); return `<button type="button" class="cw-star-prob-btn ${on ? 'btn-gold' : 'btn-ghost'} px-1.5 py-0.5 rounded-full text-[10.5px] font-bold" data-q="${escapeHtml(w.q || '')}" data-zh="${escapeHtml(w.zh || '')}" data-ans="${escapeHtml(w.answer || '')}" data-aud="${escapeHtml(w.audio || aud.ko || '')}" data-lvl="${escapeHtml(w.level || '오답노트')}" title="즐겨찾기">${on ? '⭐' : '☆'}</button>`; })()}
                ${aud.ko ? `<button type="button" class="speak-btn btn-ghost px-2 py-0.5 rounded-full text-[10.5px] font-bold whitespace-nowrap" data-text="${escapeHtml(aud.ko)}" data-lang="ko-KR" title="한국어 듣기">🇰🇷 🔊</button>` : ''}
                ${aud.zh ? `<button type="button" class="speak-btn btn-ghost px-2 py-0.5 rounded-full text-[10.5px] font-bold whitespace-nowrap" data-text="${escapeHtml(aud.zh)}" data-lang="zh-CN" title="중국어 듣기">🇨🇳 🔊</button>` : ''}
                <button type="button" class="del-wrong-btn text-xs text-mut hover:text-emerald-500 whitespace-nowrap" data-id="${escapeHtml(w.id)}">복습 완료 ✓</button>
              </div>
            </div>
            <div class="text-xs font-bold leading-snug">${escapeHtml(w.q)}</div>
            <div class="text-xs text-gold font-semibold">정답: ${escapeHtml(w.answer)}</div>
            <div class="text-[11px] text-sec leading-relaxed">${escapeHtml(w.exp)}</div>
          </div>`;
        }).join('') : `<div class="text-xs text-mut text-center py-6">틀린 문제가 없습니다 ✨</div>`;

        el.querySelectorAll('.del-wrong-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            const wid = btn.getAttribute('data-id');
            openConfirm(
              state.lang === 'zh' ? '删除错题记录' : '오답 기록 삭제',
              state.lang === 'zh' ? '确定要删除这条错题记录吗？' : '이 오답 기록을 삭제할까요?',
              () => {
                state.learn.wrongNotes = (state.learn.wrongNotes || []).filter(x => x.id !== wid);
                saveState(true); renderWrongNotes();
              }
            );
          });
        });

        // Render Shared Jingchan Study Review Notebook (Separated Wrong / Reviewed / Correct + Counts + Retry Quiz!)
        const revEl = document.getElementById('sharedReviewList');
        const revBadge = document.getElementById('sharedReviewCountBadge');
        const revTitle = document.getElementById('sharedReviewTitle');
        const revDesc = document.getElementById('sharedReviewDesc');
        const isZhUi = state.lang === 'zh';
        const hist = Array.isArray(state.learn.solvedHistory) ? state.learn.solvedHistory : [];
        const starredItems = Array.isArray(state.learn.starredProblems) ? state.learn.starredProblems : [];
        const wrongItems = hist.filter(h => h && !h.correct);
        const reviewedItems = hist.filter(h => h && h.correct && h.reviewedDone);
        const correctOnlyItems = hist.filter(h => h && h.correct && !h.reviewedDone);
        const activeFilter = window.__reviewNoteFilter || 'all';
        const retryingId = window.__reviewRetryingId || '';

        if (revTitle) revTitle.textContent = isZhUi ? '靖灿复习笔记（错题 · 复习完成 · 答对分类）' : '징찬 복습노트 (오답 · 복습완료 · 정답 구분)';
        if (revDesc) revDesc.textContent = isZhUi ? '点击错题上的「🔁 重做」答对后会自动转为「🏅 复习完成」哦！' : '틀린 문제의「🔁 다시 풀기」를 맞히면 정답으로 바뀌며「🏅 복습 완료」로 따로 표시돼요.';
        if (revBadge) revBadge.textContent = isZhUi ? `共 ${hist.length}题` : `총 ${hist.length}문제`;

        const buildRetryOptions = (targetItem) => {
          const ans = String(targetItem.answer || '').trim();
          const ansIsZh = /[\u4e00-\u9fff]/.test(ans) && !/[가-힣]/.test(ans);
          const pool = [];
          (typeof CHEAT_SHEET_72 !== 'undefined' ? CHEAT_SHEET_72 : []).forEach(p => {
            const cand = ansIsZh ? p.zh : p.ko;
            if (cand && cand !== ans && !pool.includes(cand)) pool.push(cand);
          });
          hist.forEach(h => {
            const cand = String(h && h.answer || '').trim();
            if (cand && cand !== ans && !pool.includes(cand)) pool.push(cand);
          });
          const distractors = pool.sort(() => Math.random() - 0.5).slice(0, 3);
          return [ans, ...distractors].sort(() => Math.random() - 0.5);
        };

        const renderReviewCard = (item) => {
          const a = pickLangAudio(item);
          const isRetrying = retryingId === item.id && !item.correct;
          const badgeHtml = !item.correct
            ? `<span class="px-2 py-0.5 rounded-full font-bold shrink-0" style="background: rgba(244,63,94,0.14); color: #e11d48;">${isZhUi ? '❌ 错题' : '❌ 틀림'}</span>`
            : (item.reviewedDone
                ? `<span class="px-2 py-0.5 rounded-full font-bold shrink-0" style="background: rgba(139,92,246,0.16); color: #7c3aed;">${isZhUi ? '🏅 复习完成' : '🏅 복습 완료'}</span>`
                : `<span class="px-2 py-0.5 rounded-full font-bold shrink-0" style="background: rgba(16,185,129,0.14); color: #059669;">${isZhUi ? '✅ 答对' : '✅ 정답'}</span>`);
          const cardBorder = !item.correct
            ? 'border-left: 3px solid #f43f5e;'
            : (item.reviewedDone ? 'border-left: 3px solid #8b5cf6;' : 'border-left: 3px solid #10b981;');
          const retryBoxHtml = isRetrying ? `
            <div class="mt-2 pt-2 border-t space-y-1.5" style="border-color: var(--border-subtle);">
              <div class="text-[11px] font-bold" style="color: var(--accent-royal);">${isZhUi ? '🎯 请选择正确答案：' : '🎯 정답을 다시 골라보세요:'}</div>
              <div class="grid grid-cols-1 gap-1.5">
                ${buildRetryOptions(item).map(opt => `<button type="button" class="rev-retry-opt btn-ghost py-2 px-3 rounded-xl text-xs font-semibold text-left break-words" data-id="${escapeHtml(item.id)}" data-opt="${escapeHtml(opt)}">${escapeHtml(opt)}</button>`).join('')}
              </div>
            </div>` : '';
          return `
            <div class="royal-subcard rounded-2xl p-3 space-y-1.5" style="${cardBorder}">
              <div class="flex items-center justify-between gap-1.5 text-[10px]">
                <div class="flex items-center gap-1.5 min-w-0">
                  ${badgeHtml}
                  <span class="text-gold font-semibold truncate">${escapeHtml(isZhUi ? (item.levelZh || item.level) : item.level)}</span>
                </div>
                <div class="flex items-center gap-1 shrink-0">
                  ${(() => { const stOn = typeof window.__isProblemStarred === 'function' && window.__isProblemStarred(item.q, item.answer); return `<button type="button" class="rev-star-btn btn-ghost px-1.5 py-0.5 rounded-full text-[10.5px] font-bold" data-q="${escapeHtml(item.q || '')}" data-zh="${escapeHtml(item.zh || '')}" data-ans="${escapeHtml(item.answer || '')}" data-aud="${escapeHtml(item.audio || '')}" data-lvl="${escapeHtml(item.level || '')}" title="즐겨찾기">${stOn ? '⭐' : '☆'}</button>`; })()}
                  ${a.ko ? `<button type="button" class="speak-btn btn-ghost px-1.5 py-0.5 rounded-full text-[10px] font-bold whitespace-nowrap" data-text="${escapeHtml(a.ko)}" data-lang="ko-KR">🇰🇷 🔊</button>` : ''}
                  ${a.zh ? `<button type="button" class="speak-btn btn-ghost px-1.5 py-0.5 rounded-full text-[10px] font-bold whitespace-nowrap" data-text="${escapeHtml(a.zh)}" data-lang="zh-CN">🇨🇳 🔊</button>` : ''}
                </div>
              </div>
              <div class="text-xs font-bold leading-snug break-words">${escapeHtml(item.q || '')}</div>
              ${item.zh ? `<div class="text-[11px] text-sec break-words">${escapeHtml(item.zh)}</div>` : ''}
              <div class="flex items-center justify-between gap-2 pt-0.5">
                <div class="text-[11px] font-semibold text-gold break-words">${isRetrying ? (isZhUi ? '🔒 答题中...' : '🔒 문제 푸는 중...') : `${isZhUi ? '正确答案：' : '정답: '}${escapeHtml(item.answer || '')}${item.xp ? ` (+${item.xp} XP)` : ''}`}</div>
                ${!item.correct ? `<button type="button" class="rev-retry-start-btn btn-royal px-2.5 py-1 rounded-full text-[10.5px] font-bold whitespace-nowrap shrink-0" data-id="${escapeHtml(item.id)}">${isRetrying ? (isZhUi ? '닫기' : '닫기') : (isZhUi ? '🔁 重做' : '🔁 다시 풀기')}</button>` : ''}
              </div>
              ${retryBoxHtml}
            </div>`;
        };

        if (revEl) {
          const renderStarredCard = (sItem) => {
            const a = pickLangAudio(sItem);
            return `
              <div class="royal-subcard rounded-2xl p-3 space-y-1.5" style="border-left: 3px solid #f59e0b;">
                <div class="flex items-center justify-between gap-1.5 text-[10px]">
                  <div class="flex items-center gap-1.5 min-w-0">
                    <span class="px-2 py-0.5 rounded-full font-bold shrink-0" style="background: rgba(245,158,11,0.16); color: #b45309;">⭐ ${isZhUi ? '收藏' : '즐겨찾기'}</span>
                    <span class="text-gold font-semibold truncate">${escapeHtml(sItem.level || '')}</span>
                  </div>
                  <div class="flex items-center gap-1 shrink-0">
                    ${a.ko ? `<button type="button" class="speak-btn btn-ghost px-1.5 py-0.5 rounded-full text-[10px] font-bold whitespace-nowrap" data-text="${escapeHtml(a.ko)}" data-lang="ko-KR">🇰🇷 🔊</button>` : ''}
                    ${a.zh ? `<button type="button" class="speak-btn btn-ghost px-1.5 py-0.5 rounded-full text-[10px] font-bold whitespace-nowrap" data-text="${escapeHtml(a.zh)}" data-lang="zh-CN">🇨🇳 🔊</button>` : ''}
                    <button type="button" class="rev-star-btn btn-ghost px-1.5 py-0.5 rounded-full text-[10.5px] font-bold" data-q="${escapeHtml(sItem.q || '')}" data-zh="${escapeHtml(sItem.zh || '')}" data-ans="${escapeHtml(sItem.answer || '')}" data-aud="${escapeHtml(sItem.audio || '')}" data-lvl="${escapeHtml(sItem.level || '')}" title="즐겨찾기 해제">⭐</button>
                  </div>
                </div>
                <div class="text-xs font-bold leading-snug break-words">${escapeHtml(sItem.q || '')}</div>
                ${sItem.zh ? `<div class="text-[11px] text-sec break-words">${escapeHtml(sItem.zh)}</div>` : ''}
                ${sItem.answer ? `<div class="text-[11px] font-semibold text-gold break-words">${isZhUi ? '正确答案：' : '정답: '}${escapeHtml(sItem.answer)}</div>` : ''}
              </div>`;
          };

          const filterBarHtml = `
            <div class="flex flex-wrap gap-1 pb-1">
              <button type="button" class="rev-filter-btn ${activeFilter === 'all' ? 'btn-royal' : 'btn-ghost'} py-1.5 px-2.5 rounded-xl text-[10.5px] font-bold whitespace-nowrap" data-f="all">${isZhUi ? '全部' : '전체'} ${hist.length}</button>
              <button type="button" class="rev-filter-btn ${activeFilter === 'starred' ? 'btn-royal' : 'btn-ghost'} py-1.5 px-2.5 rounded-xl text-[10.5px] font-bold whitespace-nowrap" data-f="starred">⭐ ${isZhUi ? '收藏' : '즐겨찾기'} ${starredItems.length}</button>
              <button type="button" class="rev-filter-btn ${activeFilter === 'wrong' ? 'btn-royal' : 'btn-ghost'} py-1.5 px-2.5 rounded-xl text-[10.5px] font-bold whitespace-nowrap" data-f="wrong">❌ ${isZhUi ? '错题' : '틀림'} ${wrongItems.length}</button>
              <button type="button" class="rev-filter-btn ${activeFilter === 'reviewed' ? 'btn-royal' : 'btn-ghost'} py-1.5 px-2.5 rounded-xl text-[10.5px] font-bold whitespace-nowrap" data-f="reviewed">🏅 ${isZhUi ? '已复习' : '복습완료'} ${reviewedItems.length}</button>
              <button type="button" class="rev-filter-btn ${activeFilter === 'correct' ? 'btn-royal' : 'btn-ghost'} py-1.5 px-2.5 rounded-xl text-[10.5px] font-bold whitespace-nowrap" data-f="correct">✅ ${isZhUi ? '答对' : '정답'} ${correctOnlyItems.length}</button>
            </div>`;

          let bodyHtml = '';
          if (activeFilter === 'starred') {
            bodyHtml = starredItems.length ? starredItems.map(renderStarredCard).join('') : `<div class="text-xs text-mut text-center py-6">${isZhUi ? '还没有收藏题目哦，在测验或复习中点击 ☆ 即可收藏 ⭐' : '아직 즐겨찾기한 문제가 없어요. 퀴즈나 복습노트에서 ☆를 눌러 찜해 보세요 ⭐'}</div>`;
          } else if (!hist.length && !starredItems.length) {
            bodyHtml = `<div class="text-xs text-mut text-center py-6">${isZhUi ? '靖灿做完题目后，这里会自动同步显示复习记录 📖' : '징찬이가 문제를 풀면 여기에 풀이 복습 기록이 자동 공유돼요 📖'}</div>`;
          } else if (activeFilter === 'wrong') {
            bodyHtml = wrongItems.length ? wrongItems.map(renderReviewCard).join('') : `<div class="text-xs text-mut text-center py-5">${isZhUi ? '没有错题啦！太棒了 🎉' : '틀린 문제가 없어요! 최고예요 🎉'}</div>`;
          } else if (activeFilter === 'reviewed') {
            bodyHtml = reviewedItems.length ? reviewedItems.map(renderReviewCard).join('') : `<div class="text-xs text-mut text-center py-5">${isZhUi ? '还没有重新答对的复习完成题哦' : '아직 다시 풀어 완료한 복습 문제가 없어요'}</div>`;
          } else if (activeFilter === 'correct') {
            bodyHtml = correctOnlyItems.length ? correctOnlyItems.map(renderReviewCard).join('') : `<div class="text-xs text-mut text-center py-5">${isZhUi ? '暂无答对记录' : '정답 기록이 아직 없어요'}</div>`;
          } else {
            if (starredItems.length) {
              bodyHtml += `<div class="text-[11px] font-bold px-1 pt-1" style="color:#b45309;">⭐ ${isZhUi ? '收藏重点题' : '즐겨찾기 문제'} (${starredItems.length}${isZhUi ? '题' : '개'})</div>` + starredItems.map(renderStarredCard).join('');
            }
            if (wrongItems.length) {
              bodyHtml += `<div class="text-[11px] font-bold px-1 pt-2" style="color:#e11d48;">❌ ${isZhUi ? '错题待复习' : '틀린 문제'} (${wrongItems.length}${isZhUi ? '题' : '개'})</div>` + wrongItems.map(renderReviewCard).join('');
            }
            if (reviewedItems.length) {
              bodyHtml += `<div class="text-[11px] font-bold px-1 pt-2" style="color:#7c3aed;">🏅 ${isZhUi ? '复习完成（重做答对）' : '복습 완료 (다시 풀어 정답)'} (${reviewedItems.length}${isZhUi ? '题' : '개'})</div>` + reviewedItems.map(renderReviewCard).join('');
            }
            if (correctOnlyItems.length) {
              bodyHtml += `<div class="text-[11px] font-bold px-1 pt-2" style="color:#059669;">✅ ${isZhUi ? '一次答对' : '정답'} (${correctOnlyItems.length}${isZhUi ? '题' : '개'})</div>` + correctOnlyItems.map(renderReviewCard).join('');
            }
          }

          revEl.innerHTML = filterBarHtml + `<div class="space-y-2">${bodyHtml}</div>`;

          revEl.querySelectorAll('.rev-star-btn').forEach(btn => {
            btn.addEventListener('click', () => {
              if (typeof window.__toggleStarredProblem === 'function') {
                window.__toggleStarredProblem({
                  q: btn.getAttribute('data-q') || '',
                  zh: btn.getAttribute('data-zh') || '',
                  answer: btn.getAttribute('data-ans') || '',
                  audio: btn.getAttribute('data-aud') || '',
                  level: btn.getAttribute('data-lvl') || ''
                });
              }
            });
          });
          revEl.querySelectorAll('.rev-filter-btn').forEach(btn => {
            btn.addEventListener('click', () => {
              window.__reviewNoteFilter = btn.getAttribute('data-f') || 'all';
              renderWrongNotes();
            });
          });
          revEl.querySelectorAll('.rev-retry-start-btn').forEach(btn => {
            btn.addEventListener('click', () => {
              const id = btn.getAttribute('data-id');
              window.__reviewRetryingId = (window.__reviewRetryingId === id) ? '' : id;
              renderWrongNotes();
            });
          });
          revEl.querySelectorAll('.rev-retry-opt').forEach(btn => {
            btn.addEventListener('click', () => {
              const id = btn.getAttribute('data-id');
              const picked = btn.getAttribute('data-opt') || '';
              const target = (state.learn.solvedHistory || []).find(x => x && x.id === id);
              if (!target) return;
              if (picked.trim() === String(target.answer || '').trim()) {
                if (canEarnJingchanXp()) {
                  target.correct = true;
                  target.reviewedDone = true;
                  target.reviewedAt = Date.now();
                  state.learn.wrongNotes = (state.learn.wrongNotes || []).filter(w => w && w.q !== target.q && w.answer !== target.answer);
                  state.learn.xp = (state.learn.xp || 0) + 10;
                  const kst = getKstDateString();
                  if (state.learn.todayXpDate !== kst) { state.learn.todayXpDate = kst; state.learn.todayXp = 0; }
                  state.learn.todayXp = (state.learn.todayXp || 0) + 10;
                  if (typeof addLavenderBonusXp === 'function') addLavenderBonusXp('rev_' + id, 5);
                  saveState(true);
                  renderHome();
                }
                window.__reviewRetryingId = '';
                renderWrongNotes();
                showToast(canEarnJingchanXp()
                  ? (isZhUi ? '🎉 答对啦！已标记为「🏅 复习完成」(+10 XP)' : '🎉 정답이에요! 「🏅 복습 완료」로 바뀌었어요 (+10 XP)')
                  : (isZhUi ? '❤️ 答对啦！(完测试模式 · 不影响靖灿复习记录)' : '❤️ 정답이에요! (수완 테스트 모드 · 징찬 복습 기록 미반영)'));
              } else {
                btn.style.background = 'rgba(244,63,94,0.16)';
                btn.style.color = '#e11d48';
                showToast(isZhUi ? '😅 差一点！再试一次吧' : '😅 아쉬워요! 다시 한 번 골라보세요');
              }
            });
          });
        }
        if (typeof window.syncAllTabIconsToStyle === 'function') window.syncAllTabIconsToStyle(null, document.getElementById('learn-sub-wrong') || document.getElementById('tab-learn'));
      }

      function renderCheatSheet() {
        const keyword = (document.getElementById('cheatSearchInput').value || '').trim().toLowerCase();
        const cat = document.getElementById('cheatCategorySelect').value || 'all';
        const bms = Array.isArray(state.learn.bookmarks) ? state.learn.bookmarks : [];
        const bmSet = new Set(bms);
        const allPhrases = getAllCheatPhrases();
        const customCnt = Array.isArray(state.customPhrases) ? state.customPhrases.length : 0;
        const cpBadge = document.getElementById('customPhraseCountBadge');
        if (cpBadge) cpBadge.textContent = state.lang === 'zh' ? `${customCnt}条` : `${customCnt}개`;
        const filtered = allPhrases.filter(item => {
          const catOk = cat === 'all' || (cat === 'bookmarks' ? bmSet.has(item.ko) : item.cat === cat);
          const kwOk = !keyword || item.ko.toLowerCase().includes(keyword) || item.zh.toLowerCase().includes(keyword) || (item.nu || '').toLowerCase().includes(keyword);
          return catOk && kwOk;
        });
        document.getElementById('cheatCountLabel').textContent = `${filtered.length} / ${allPhrases.length} · 🔊 / 🐢`;
        const container = document.getElementById('cheatListContainer');
        if (!filtered.length) {
          container.innerHTML = `<div class="col-span-full royal-card rounded-2xl p-6 text-center text-xs text-mut">${state.lang === 'zh' ? '暂无匹配或收藏的表达，点卡片上的 ☆ 即可收藏 ⭐' : '검색 결과나 즐겨찾기한 표현이 없어요. 카드의 ☆를 눌러 즐겨찾기해 보세요 ⭐'}</div>`;
          return;
        }
        container.innerHTML = filtered.map((item, idx) => {
          const starred = bmSet.has(item.ko);
          return `
          <div class="royal-card rounded-2xl p-3.5 space-y-1.5">
            <div class="flex items-start justify-between gap-2">
              <div class="min-w-0">
                <span class="text-[10px] font-semibold text-gold">${escapeHtml(state.lang === 'zh' ? localizeLearnCatZh(item.cat) : item.cat)} · #${idx + 1}</span>${item.isCustom ? ` <button type="button" class="del-custom-phrase-btn text-[10px] text-rose-400 hover:text-rose-600 ml-1" data-id="${escapeHtml(item.id || '')}">✕</button>` : ''}
                <div class="text-sm font-bold mt-0.5 leading-snug break-words">${escapeHtml(item.ko)}</div>
                <div class="flex items-center gap-1.5 mt-0.5">
                  <span class="text-xs text-sec break-words">${escapeHtml(item.zh)}</span>
                  <button type="button" class="speak-btn btn-ghost px-1.5 py-0.5 rounded-full text-[10px] font-semibold shrink-0 whitespace-nowrap" data-text="${escapeHtml(item.zh)}" data-lang="zh-CN" title="중국어 듣기">🇨🇳🔊</button>
                </div>
              </div>
              <div class="flex items-center gap-1 shrink-0">
                <button type="button" class="bm-cheat-btn btn-ghost w-7 h-7 rounded-full flex items-center justify-center text-xs" data-ko="${escapeHtml(item.ko)}" title="즐겨찾기">${starred ? '⭐' : '☆'}</button>
                <button type="button" class="rec-voice-btn ${state.customVoices && state.customVoices[item.ko] ? 'btn-gold' : 'btn-ghost'} w-7 h-7 rounded-full flex items-center justify-center text-xs" data-text="${escapeHtml(item.ko)}" title="내 목소리 녹음">${state.customVoices && state.customVoices[item.ko] ? '💜' : (window.getAppIconHtml ? window.getAppIconHtml('record') : '🎙️')}</button>
                ${state.customVoices && state.customVoices[item.ko] ? `<button type="button" class="del-voice-btn btn-ghost w-7 h-7 rounded-full flex items-center justify-center text-[10px] text-rose-500" data-text="${escapeHtml(item.ko)}" title="녹음 삭제">✕</button>` : ''}
                ${suwanVoicePillHtml(item.ko)}<button type="button" class="speak-btn btn-ghost w-7 h-7 rounded-full flex items-center justify-center text-xs" data-text="${escapeHtml(item.ko)}" data-lang="ko-KR" title="보통 속도">${window.getAppIconHtml ? window.getAppIconHtml('speak') : '🔈'}</button>
                <button type="button" class="speak-btn btn-ghost w-7 h-7 rounded-full flex items-center justify-center text-xs" data-text="${escapeHtml(item.ko)}" data-lang="ko-KR" data-slow="1" title="천천히 듣기">${window.getAppIconHtml ? window.getAppIconHtml('slow') : '0.7×'}</button>
              </div>
            </div>
            <div class="flex items-center justify-between gap-2 pt-1.5 border-t" style="border-color: var(--border-subtle);">
              <div class="text-[11px] text-mut leading-relaxed min-w-0 flex-1">💡 ${escapeHtml(state.lang === 'zh' ? localizeLearnNuanceZh(item) : item.nu)}</div>
              <button type="button" class="speech-check-btn btn-gold px-2.5 py-1 rounded-full text-[10.5px] font-semibold shrink-0 whitespace-nowrap" data-ko="${escapeHtml(item.ko)}" data-zh="${escapeHtml(item.zh)}" data-pron="${escapeHtml(romanizeKoreanBasic(item.ko))}">${state.lang === 'zh' ? '🎤 跟读 +15XP' : '🎤 말하기 +15XP'}</button>
            </div>
          </div>`;
        }).join('');
        container.querySelectorAll('.bm-cheat-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            const k = btn.getAttribute('data-ko');
            if (!Array.isArray(state.learn.bookmarks)) state.learn.bookmarks = [];
            const i = state.learn.bookmarks.indexOf(k);
            if (i >= 0) state.learn.bookmarks.splice(i, 1);
            else state.learn.bookmarks.unshift(k);
            saveState();
            renderLearn();
          });
        });
      
        if (typeof window.syncAllTabIconsToStyle === 'function') window.syncAllTabIconsToStyle(null, document.getElementById('learn-sub-cheat') || document.getElementById('tab-learn'));
      }

      function renderAnniversary() {
        const today = getKstDateString();
        const startInp = document.getElementById('coupleStartDateInput');
        if (startInp) startInp.value = state.startDate || today;
        const customDateInp = document.getElementById('customAnnivDate');
        if (customDateInp && !customDateInp.value) customDateInp.value = today;
        const start = parseYmd(state.startDate || today);
        const isZh = state.lang === 'zh';
        document.getElementById('autoMilestonesGrid').innerHTML = [100, 200, 300, 365].map(d => {
          const ymd = new Date(start.getTime() + (d - 1) * 86400000).toISOString().slice(0, 10);
          const diff = diffDays(today, ymd);
          const titleLbl = d === 365 ? (isZh ? '1周年' : '1주년') : (isZh ? `${d}天` : `${d}일`);
          const ddayLbl = diff > 0 ? `D-${diff}` : (diff === 0 ? 'D-DAY 🎉' : (isZh ? `+${Math.abs(diff)}天` : `+${Math.abs(diff)}일`));
          return `
            <div class="royal-subcard rounded-2xl p-3 text-center">
              <div class="text-xs text-gold font-bold">${titleLbl}</div>
              <div class="text-sm font-bold mt-1 tabular-nums">${ddayLbl}</div>
              <div class="text-[11px] text-sec font-medium mt-0.5 tabular-nums">${ymd}</div>
            </div>
          `;
        }).join('');

        const listEl = document.getElementById('annivTimelineList');
        listEl.innerHTML = state.anniversaries.length ? state.anniversaries.map(a => {
          let calcDate = a.date;
          if (a.repeat) {
            const yr = today.slice(0, 4);
            let cand = `${yr}-${a.date.slice(5)}`;
            if (diffDays(today, cand) < 0) cand = `${Number(yr) + 1}-${a.date.slice(5)}`;
            calcDate = cand;
          }
          const diff = diffDays(today, calcDate);
          return `
            <div class="royal-subcard rounded-2xl p-3.5 flex items-center justify-between gap-3">
              <div class="min-w-0 flex-1">
                <div class="flex flex-wrap items-center gap-1.5">
                  <span class="text-sm font-bold break-words">${escapeHtml(a.title)}</span>
                  ${a.repeat ? `<span class="text-[10px] px-2 py-0.5 rounded-full text-gold shrink-0" style="background: var(--accent-royal-soft);">매년</span>` : ''}
                </div>
                <div class="text-xs text-mut mt-0.5">${escapeHtml(a.date)}</div>
              </div>
              <div class="flex items-center gap-2.5 shrink-0">
                <span class="text-sm font-bold text-gold whitespace-nowrap">${diff > 0 ? `D-${diff}` : (diff === 0 ? 'D-DAY 🎉' : `D+${Math.abs(diff)}`)}</span>
                <button type="button" class="del-anniv-btn text-xs text-mut hover:text-rose-400" data-id="${escapeHtml(a.id)}">✕</button>
              </div>
            </div>
          `;
        }).join('') : `<div class="text-xs text-mut text-center py-6">등록된 커스텀 기념일이 없습니다. 위에서 추가해 보세요 💍</div>`;

        document.querySelectorAll('.del-anniv-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            const aid = btn.getAttribute('data-id');
            openConfirm(
              state.lang === 'zh' ? '删除纪念日' : '기념일 삭제',
              state.lang === 'zh' ? '确定要删除这个纪念日吗？' : '이 기념일을 삭제할까요?',
              () => {
                state.anniversaries = state.anniversaries.filter(x => x.id !== aid);
                saveState(true); renderAnniversary();
              }
            );
          });
        });
      }

      function renderChatLinkEmbed(rawText, mine) {
        const str = String(rawText || '');
        const urlMatch = str.match(/https?:\/\/[^\s<>"']+/i);
        if (!urlMatch) return '';
        const url = urlMatch[0];
        const safeUrl = escapeHtml(url);
        const isZh = state.lang === 'zh';
        const linkCls = mine ? 'text-white/95 underline' : 'text-gold underline';

        // 1) YouTube (watch, youtu.be, shorts)
        const ytM = url.match(/(?:youtube\.com\/(?:watch\?v=|shorts\/|embed\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/i);
        if (ytM) {
          const ytId = ytM[1];
          return `
            <div class="mb-2 space-y-1.5">
              <div class="w-full overflow-hidden rounded-xl border border-white/30 bg-black/80" style="aspect-ratio: 16 / 9;">
                <iframe src="https://www.youtube.com/embed/${ytId}?cc_load_policy=1&cc_lang_pref=${isZh ? 'zh-Hans' : 'ko'}&hl=${isZh ? 'zh-CN' : 'ko'}" class="w-full h-full border-0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen loading="lazy"></iframe>
              </div>
              <a href="${safeUrl}" target="_blank" rel="noopener noreferrer" class="inline-flex items-center gap-1 text-[11px] font-semibold ${linkCls}">▶️ ${isZh ? '在 YouTube 打开 ↗' : 'YouTube에서 열기 ↗'}</a>
            </div>`;
        }

        // 2) Bilibili (BV video — works natively in China!)
        const biliM = url.match(/bilibili\.com\/video\/(BV[a-zA-Z0-9]+)/i);
        if (biliM) {
          const bvid = biliM[1];
          return `
            <div class="mb-2 space-y-1.5">
              <div class="w-full overflow-hidden rounded-xl border border-white/30 bg-black/80" style="aspect-ratio: 16 / 9;">
                <iframe src="https://player.bilibili.com/player.html?bvid=${bvid}&high_quality=1&autoplay=0" class="w-full h-full border-0" allowfullscreen loading="lazy" scrolling="no"></iframe>
              </div>
              <a href="${safeUrl}" target="_blank" rel="noopener noreferrer" class="inline-flex items-center gap-1 text-[11px] font-semibold ${linkCls}">📺 ${isZh ? '在哔哩哔哩打开 ↗' : 'Bilibili에서 열기 ↗'}</a>
            </div>`;
        }

        // 3) Direct MP4 / WebM / MOV video URL
        if (/\.(mp4|webm|mov|m4v)(\?.*)?$/i.test(url)) {
          return `
            <div class="mb-2 space-y-1">
              <video src="${safeUrl}" controls playsinline class="w-full max-w-[260px] rounded-xl border border-white/30 bg-black"></video>
              <a href="${safeUrl}" target="_blank" rel="noopener noreferrer" class="inline-flex items-center gap-1 text-[11px] font-semibold ${linkCls}">🎬 ${isZh ? '原链接打开 ↗' : '원본 동영상 열기 ↗'}</a>
            </div>`;
        }

        // 4) Douyin / TikTok / Xiaohongshu / Instagram / Any other shared video/web link
        let platformLabel = isZh ? '🔗 打开分享链接 ↗' : '🔗 공유 링크 바로 열기 ↗';
        if (/douyin\.com|iesdouyin\.com/i.test(url)) platformLabel = isZh ? '🎵 打开抖音视频 ↗' : '🎵 도우인(Douyin) 영상 보기 ↗';
        else if (/tiktok\.com/i.test(url)) platformLabel = isZh ? '🎵 打开 TikTok 视频 ↗' : '🎵 틱톡(TikTok) 영상 보기 ↗';
        else if (/xiaohongshu\.com|xhslink\.com/i.test(url)) platformLabel = isZh ? '📕 打开小红书视频 ↗' : '📕 샤오홍슈(小红书) 보기 ↗';
        else if (/instagram\.com/i.test(url)) platformLabel = isZh ? '📸 打开 Instagram ↗' : '📸 인스타그램 영상 보기 ↗';
        else if (/b23\.tv/i.test(url)) platformLabel = isZh ? '📺 打开哔哩哔哩短链 ↗' : '📺 Bilibili 영상 보기 ↗';

        return `
          <a href="${safeUrl}" target="_blank" rel="noopener noreferrer" class="mb-2 flex items-center justify-between gap-2 rounded-xl px-3 py-2 text-xs font-semibold border transition" style="background: ${mine ? 'rgba(255,255,255,0.16)' : 'var(--surface-2)'}; border-color: ${mine ? 'rgba(255,255,255,0.3)' : 'var(--border-accent)'}; color: ${mine ? '#ffffff' : 'var(--accent-royal)'};">
            <span class="truncate">${platformLabel}</span>
            <span class="shrink-0 opacity-80">↗</span>
          </a>`;
      }

      function isMyAuthoredItem(item) {
        if (!item) return false;
        const myRole = state.myRole || 'suwan';
        if (item.authorRole) return item.authorRole === myRole;
        if (item.sender) {
          const normS = (item.sender === 'jingchan' || String(item.sender).includes('靖灿')) ? 'jingchan' : 'suwan';
          return normS === myRole;
        }
        if (item.author) {
          const normA = (item.author === 'jingchan' || String(item.author).includes('靖灿') || String(item.author).includes('灿')) ? 'jingchan' : 'suwan';
          return normA === myRole;
        }
        return true;
      }

      function updateChatDeliveryBadgesInPlace() {
        const listEl = document.getElementById('chatMessagesList');
        if (!listEl) return false;
        const myR = state.myRole || 'suwan';
        const isZh = state.lang === 'zh';
        const msgMap = new Map((state.chat?.messages || []).filter(Boolean).map(m => [m.id, m]));
        let touched = 0;
        listEl.querySelectorAll('.cw-delivery-badge[data-msg-id]').forEach(el => {
          const mid = el.getAttribute('data-msg-id');
          const m = msgMap.get(mid);
          if (!m) return;
          const normS = (m.sender === 'jingchan' || String(m.sender || '').includes('靖灿')) ? 'jingchan' : 'suwan';
          if (normS !== myR) return;
          const dStat = m.deliveryStatus || 'sent';
          const wantState = m.readByPartner ? 'read' : dStat;
          if (el.dataset.cwBadgeState === wantState) return;
          let htmlStr = '';
          if (m.readByPartner) {
            htmlStr = `<span class="cw-delivery-badge inline-flex items-center gap-0.5 px-2 py-0.5 rounded-full font-bold" data-cw-badge-state="read" data-msg-id="${escapeHtml(m.id)}" style="background: rgba(244,114,182,0.16); color: #db2777;">💗 ${isZh ? '已读' : '읽음'}</span>`;
          } else if (dStat === 'sending') {
            htmlStr = `<span class="cw-delivery-badge inline-flex items-center gap-0.5 px-2 py-0.5 rounded-full font-semibold" data-cw-badge-state="sending" data-msg-id="${escapeHtml(m.id)}" style="background: rgba(245,158,11,0.14); color: #d97706;">⏳ ${isZh ? '发送中...' : '전송 중...'}</span>`;
          } else if (dStat === 'failed') {
            htmlStr = `<button type="button" class="cw-retry-send-btn cw-delivery-badge inline-flex items-center gap-0.5 px-2 py-0.5 rounded-full font-bold transition active:scale-95" data-cw-badge-state="failed" data-msg-id="${escapeHtml(m.id)}" style="background: rgba(244,63,94,0.14); color: #e11d48;">⚠️ ${isZh ? '发送失败 · 点此重发' : '전송 실패 · 눌러서 재전송'}</button>`;
          } else {
            htmlStr = `<span class="cw-delivery-badge inline-flex items-center gap-1" data-cw-badge-state="sent" data-msg-id="${escapeHtml(m.id)}"><span class="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-full font-bold" style="background: rgba(16,185,129,0.14); color: #059669;">✓ ${isZh ? '已发送' : '전송됨'}</span><span class="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-full font-semibold" style="background: var(--accent-royal-soft); color: var(--accent-royal); opacity: 0.88;">💌 ${isZh ? '未读' : '안 읽음'}</span></span>`;
          }
          const tmp = document.createElement('span');
          tmp.innerHTML = htmlStr;
          const nextEl = tmp.firstElementChild;
          if (nextEl) {
            if (dStat === 'failed') {
              nextEl.addEventListener('click', async () => {
                m.deliveryStatus = 'sending';
                updateChatDeliveryBadgesInPlace();
                if (typeof window.__connectEmqxNow === 'function') window.__connectEmqxNow();
                if (typeof window.__pushFullCloudSync === 'function') await window.__pushFullCloudSync();
              });
            }
            el.replaceWith(nextEl);
            touched++;
          }
        });
        return touched > 0;
      }
      window.__updateChatDeliveryBadgesInPlace = updateChatDeliveryBadgesInPlace;

      function renderChat() {
        const isSuwan = state.chat.activeSender === 'suwan';
        document.getElementById('senderSuwanBtn').className = `px-2.5 py-1 rounded-full text-xs font-semibold whitespace-nowrap ${isSuwan ? 'btn-gold' : 'btn-ghost'}`;
        document.getElementById('senderJingchanBtn').className = `px-2.5 py-1 rounded-full text-xs font-semibold whitespace-nowrap ${!isSuwan ? 'btn-gold' : 'btn-ghost'}`;

        const listEl = document.getElementById('chatMessagesList');
        const __cwHadMsgs = listEl && listEl.children.length > 0;
        const __cwPrevScrollTop = listEl ? listEl.scrollTop : 0;
        const __cwPrevDistBottom = listEl ? (listEl.scrollHeight - listEl.scrollTop - listEl.clientHeight) : 0;
        const __cwWasReadingOlder = __cwHadMsgs && listEl.clientHeight > 0 && __cwPrevDistBottom > 120;
        const qSearch = String(window.__chatSearchQuery || '').trim().toLowerCase();
        const allFilteredMsgs = qSearch
          ? state.chat.messages.filter(m =>
              String(m.original || '').toLowerCase().includes(qSearch) ||
              String(m.translated || '').toLowerCase().includes(qSearch) ||
              String(m.photoCat || '').toLowerCase().includes(qSearch))
          : state.chat.messages;
        if (!window.__chatVisibleLimit || window.__chatVisibleLimit < 30) window.__chatVisibleLimit = 30;
        const hiddenOlderCount = (!qSearch && allFilteredMsgs.length > window.__chatVisibleLimit)
          ? (allFilteredMsgs.length - window.__chatVisibleLimit)
          : 0;
        const visibleMsgs = hiddenOlderCount > 0 ? allFilteredMsgs.slice(-window.__chatVisibleLimit) : allFilteredMsgs;
        const cntEl = document.getElementById('chatSearchCount');
        if (cntEl) cntEl.textContent = qSearch ? `${allFilteredMsgs.length}${state.lang === 'zh' ? '条' : '건'}` : '';
        if (!visibleMsgs.length) {
          listEl.innerHTML = `<div class="text-xs text-mut text-center py-12">${qSearch ? (state.lang === 'zh' ? '没有找到匹配的聊天记录 🔎' : '검색 결과가 없어요 🔎') : (state.lang === 'zh' ? '还没有聊天记录，发第一条消息吧 ✨' : '작성된 대화가 없습니다. 첫 메시지를 보내보세요 ✨')}</div>`;
        } else {
          const viewerRoleTz = state.myRole || 'suwan';
          const viewerTz = (state.cities && state.cities[viewerRoleTz] && state.cities[viewerRoleTz].tz)
            || (viewerRoleTz === 'jingchan' ? 'Asia/Shanghai' : 'Asia/Seoul');
          const viewerLocale = state.lang === 'zh' ? 'zh-CN' : 'ko-KR';
          const __fmtKey = viewerTz + '|' + viewerLocale;
          if (!window.__cwChatFmtCache || window.__cwChatFmtCache.key !== __fmtKey) {
            window.__cwChatFmtCache = {
              key: __fmtKey,
              kstKeyFmt: new Intl.DateTimeFormat('en-CA', { timeZone: viewerTz }),
              prettyDateFmt: new Intl.DateTimeFormat(viewerLocale, { timeZone: viewerTz, year: 'numeric', month: 'long', day: 'numeric', weekday: 'short' }),
              msgTimeFmt: new Intl.DateTimeFormat(viewerLocale, { timeZone: viewerTz, hour: '2-digit', minute: '2-digit' })
            };
          }
          const { kstKeyFmt, prettyDateFmt, msgTimeFmt } = window.__cwChatFmtCache;
          const formatMsgLocalTime = (msgObj) => {
            if (!msgObj) return '';
            let epoch = Number(msgObj.ts || 0);
            if (!epoch && msgObj.id) {
              const em = String(msgObj.id).match(/(\d{13})/);
              if (em) epoch = Number(em[1]);
            }
            if (epoch > 1000000000000) {
              try { return msgTimeFmt.format(new Date(epoch)); } catch (_) {}
            }
            return String(msgObj.time || '');
          };
          const loadMoreHtml = hiddenOlderCount > 0
            ? `<div class="flex justify-center py-1.5"><button type="button" id="chatLoadOlderBtn" class="btn-ghost px-3.5 py-1.5 rounded-full text-[11px] font-semibold">${state.lang === 'zh' ? `⬆️ 加载更早的聊天记录 (还有 ${hiddenOlderCount} 条)` : `⬆️ 이전 대화 더 보기 (${hiddenOlderCount}개 남음)`}</button></div>`
            : '';
          let prevDateKey = '';
          let prevSenderKey = '';
          let prevTimeKey = '';
          listEl.innerHTML = loadMoreHtml + visibleMsgs.map(m => {
            const myRole = state.myRole || 'suwan';
            const normSender = (m.sender === 'jingchan' || String(m.sender || '').includes('靖灿')) ? 'jingchan' : 'suwan';
            const mine = normSender === myRole;
            let dateDividerHtml = '';
            let curDateKey = '';
            let msgEpoch = Number(m.ts || 0);
            if (!msgEpoch && m.id) {
              const em = String(m.id).match(/(\d{13})/);
              if (em) msgEpoch = Number(em[1]);
            }
            if (msgEpoch > 1000000000000) {
              try {
                const dObj = new Date(msgEpoch);
                curDateKey = kstKeyFmt.format(dObj);
                if (curDateKey && curDateKey !== prevDateKey) {
                  const prettyDate = prettyDateFmt.format(dObj);
                  dateDividerHtml = `<div class="flex items-center justify-center py-1.5"><span class="px-3 py-0.5 rounded-full text-[10px] font-semibold text-mut" style="background: var(--surface-2); border: 1px solid var(--border-subtle);">📅 ${escapeHtml(prettyDate)}</span></div>`;
                }
              } catch (_) {}
            }
            const localDisplayTime = formatMsgLocalTime(m);
            const isGroupedFollowup = !dateDividerHtml && prevSenderKey === normSender && prevTimeKey === localDisplayTime && curDateKey === prevDateKey;
            prevDateKey = curDateKey;
            prevSenderKey = normSender;
            prevTimeKey = localDisplayTime;

            const avSrc = (state.profile && state.profile[normSender + 'Avatar']) || (state.avatars && state.avatars[normSender]) || '';
            const senderDisplayName = normSender === 'suwan'
              ? (state.lang === 'zh' ? '秀完' : '수완')
              : (state.lang === 'zh' ? '靖灿' : '징찬');
            const senderFullBadge = normSender === 'suwan'
              ? (state.lang === 'zh' ? '秀完 (수완)' : '수완 · 完')
              : (state.lang === 'zh' ? '靖灿 (징찬)' : '징찬 · 靖灿');
            const avBg = normSender === 'suwan' ? 'linear-gradient(135deg, #8b5cf6, #c084fc)' : 'linear-gradient(135deg, #ec4899, #a855f7)';
            const avatarHtml = mine
              ? ''
              : `<div class="cw-chat-avatar" style="background: ${avBg};">${avSrc ? `<img src="${avSrc}" alt="${senderDisplayName}" loading="lazy" decoding="async" class="w-full h-full object-cover" />` : senderDisplayName}</div>`;
            const partnerNameHtml = mine
              ? ''
              : `<div class="text-[10.5px] font-bold px-1 pb-0.5 leading-none flex items-center gap-1" style="color: var(--accent-royal);">${escapeHtml(senderFullBadge)}</div>`;
            const hasMedia = !!(m.photoUrl || m.videoUrl || (Array.isArray(m.photoUrls) && m.photoUrls.length));
            const isAutoVoiceCap = !!(m.audioUrl && String(m.audioUrl).startsWith('data:audio/')) && /^(🎙️\s*)?(음성 메시지|语音消息)(\s*🎙️)?$/.test(String(m.original || '').trim());
            const isAutoMediaCaption = isAutoVoiceCap || (hasMedia && /^(🎞️ \[(움짤|动图)\]|사진( \d+장)?을 보냈어요 📷|동영상을 보냈어요 🎬|分享了(一张|\s*\d+\s*张)照片 📷|分享了一段视频 🎬)$/.test(String(m.original || '').trim()));
            const isMissingVideoBubble = !m.videoUrl && /^(동영상을 보냈어요 🎬|分享了一段视频 🎬)$/.test(String(m.original || '').trim());
            const isMissingPhotoBubble = !hasMedia && (/^(사진( \d+장)?을 보냈어요 📷|分享了(一张|\s*\d+\s*张)照片 📷)$/.test(String(m.original || '').trim()) || String(m.id || '').startsWith('msg_img_'));
            const showText = !isAutoMediaCaption && String(m.original || '').trim().length > 0;
            const isPureWcMsg = showText && !hasMedia && !m.sticker && typeof window.isPureWechatEmoticonMsg === 'function' && window.isPureWechatEmoticonMsg(String(m.original || '').trim());
            const isPurePunctMsg = showText && !hasMedia && !m.sticker && !isPureWcMsg && /^[?!.,~…·\-_:;'"()[\]{}+=/*\\|\s？！？。，、]+$/.test(String(m.original || '').trim());
            const isEmojiMsg = isPureWcMsg || (showText && !hasMedia && !m.sticker && !isPurePunctMsg && !/[a-zA-Z0-9가-힣ㄱ-ㅎㅏ-ㅣ\u4e00-\u9fff]/.test(String(m.original || '').trim()));
            const isPureLinkMsg = /^https?:\/\/\S+$/i.test(String(m.original || '').trim());
            const isVoiceBubble = !!(m.audioUrl && String(m.audioUrl).startsWith('data:audio/'));
            const isPendingTrans = !isPurePunctMsg && /^(⏳ 번역 중\.\.\.|⏳ 正在翻译\.\.\.)$/.test(String(m.translated || '').trim());
            const isFailedTrans = !isPendingTrans && showText && !isEmojiMsg && !isPurePunctMsg && !isPureLinkMsg && !isVoiceBubble && (!m.translated || m.translated === m.original || /^\[(中文|한국어)\]\s*/.test(String(m.translated || '')));
            const hasTrans = showText && !isEmojiMsg && !isPurePunctMsg && !isVoiceBubble && (isFailedTrans || !!(m.translated && m.translated !== m.original));
            const accVal = Number(m.accuracy) || (isFailedTrans ? 65 : (String(m.engine || '').includes('Gemini') || String(m.engine || '').includes('큐레이션') || String(m.engine || '').includes('사전') ? 96 : (String(m.engine || '').includes('Google') || String(m.engine || '').includes('Simply') ? 92 : 86)));
            const accColor = accVal >= 90 ? '#059669' : (accVal >= 80 ? '#d97706' : '#e11d48');
            const accBg = accVal >= 90 ? 'rgba(16,185,129,0.12)' : (accVal >= 80 ? 'rgba(245,158,11,0.14)' : 'rgba(244,63,94,0.14)');
            const accLabel = state.lang === 'zh' ? `准确度 ${accVal}%` : `정확도 ${accVal}%`;
            const retransLabel = state.lang === 'zh' ? (accVal < 85 || isFailedTrans ? '🔄 重新翻译' : '🔄 重译') : (accVal < 85 || isFailedTrans ? '🔄 다시 번역' : '🔄 재번역');
            const isGifMedia = !!(m.photoUrl && (String(m.photoUrl).startsWith('data:image/gif') || String(m.photoUrl).toLowerCase().includes('.gif') || /움짤|动图|gif/i.test(String(m.original || '') + ' ' + String(m.photoCat || ''))));
            const origLang = (/[一-鿿]/.test(String(m.original || '')) && !/[가-힣]/.test(String(m.original || ''))) ? 'zh-CN' : 'ko-KR';
            const dStat = m.deliveryStatus || 'sent';
            const readReceiptHtml = mine
              ? (m.readByPartner
                  ? `<span class="cw-delivery-badge inline-flex items-center gap-0.5 px-2 py-0.5 rounded-full font-bold" data-msg-id="${escapeHtml(m.id)}" style="background: rgba(244,114,182,0.16); color: #db2777;">💗 ${state.lang === 'zh' ? '已读' : '읽음'}</span>`
                  : (dStat === 'sending'
                      ? `<span class="cw-delivery-badge inline-flex items-center gap-0.5 px-2 py-0.5 rounded-full font-semibold" data-msg-id="${escapeHtml(m.id)}" style="background: rgba(245,158,11,0.14); color: #d97706;">⏳ ${state.lang === 'zh' ? '发送中...' : '전송 중...'}</span>`
                      : (dStat === 'failed'
                          ? `<button type="button" class="cw-retry-send-btn cw-delivery-badge inline-flex items-center gap-0.5 px-2 py-0.5 rounded-full font-bold transition active:scale-95" data-msg-id="${escapeHtml(m.id)}" style="background: rgba(244,63,94,0.14); color: #e11d48;">⚠️ ${state.lang === 'zh' ? '发送失败 · 点此重发' : '전송 실패 · 눌러서 재전송'}</button>`
                          : `<span class="cw-delivery-badge inline-flex items-center gap-1" data-msg-id="${escapeHtml(m.id)}"><span class="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-full font-bold" style="background: rgba(16,185,129,0.14); color: #059669;">✓ ${state.lang === 'zh' ? '已发送' : '전송됨'}</span><span class="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-full font-semibold" style="background: var(--accent-royal-soft); color: var(--accent-royal); opacity: 0.88;">💌 ${state.lang === 'zh' ? '未读' : '안 읽음'}</span></span>`)))
              : '';
            return `${dateDividerHtml}
              <div class="cw-msg-row ${mine ? 'mine' : 'partner'}">
                ${avatarHtml}
                <div class="cw-msg-col">
                  ${partnerNameHtml}
                  <!-- KakaoTalk Minimal Unified Message Bubble (Original + Translation in One Clean Card) -->
                  <div class="cw-msg-bubble rounded-2xl ${hasMedia && !showText ? 'p-1.5' : 'px-3.5 py-2.5'} space-y-1.5 border" data-msg-id="${escapeHtml(m.id)}" style="background: ${mine ? 'var(--bubble-suwan)' : 'var(--bubble-jingchan)'}; border-color: ${mine ? 'rgba(255,255,255,0.22)' : 'var(--border-subtle)'}; color: ${mine ? '#ffffff' : 'var(--text-primary)'};">
                    ${m.replyTo ? `<div class="rounded-lg px-2 py-1 text-[11px] border-l-2" style="background: ${mine ? 'rgba(255,255,255,0.14)' : 'var(--surface-2)'}; border-color: ${mine ? '#f9e6ff' : 'var(--accent-royal)'};"><div class="font-bold opacity-85">↩️ ${escapeHtml(m.replyTo.author || '')}</div><div class="truncate opacity-90 cw-keep-native-emoji">${escapeHtml(m.replyTo.text || '')}</div></div>` : ''}
                    ${isMissingVideoBubble ? `<button type="button" onclick="if(typeof window.__pullCloudSync==='function'){if(window.__cwApi&&window.__cwApi.showToast)window.__cwApi.showToast((window.__cwApi.getState&&window.__cwApi.getState()?.lang==='zh')?'🎬 正在从云端拉取视频...':'🎬 서버에서 동영상을 불러오는 중...');window.__pullCloudSync(true);}" class="w-full flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition active:scale-[0.98]" style="background:${mine ? 'rgba(255,255,255,0.2)' : 'var(--accent-royal-soft)'}; color:${mine ? '#ffffff' : 'var(--accent-royal)'};">🎬 ${state.lang === 'zh' ? '点击加载视频' : '동영상 불러오기'}</button>` : ''}
                    ${isMissingPhotoBubble ? `<button type="button" onclick="if(typeof window.__pullRecentMediaNow==='function')window.__pullRecentMediaNow(true);if(typeof window.__pullCloudSync==='function')window.__pullCloudSync(true);" class="w-full flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition active:scale-[0.98]" style="background:${mine ? 'rgba(255,255,255,0.2)' : 'var(--accent-royal-soft)'}; color:${mine ? '#ffffff' : 'var(--accent-royal)'};">📷 ${state.lang === 'zh' ? '正在同步照片 · 点此立即加载' : '사진 동기화 중 · 눌러서 바로 보기'}</button>` : ''}
                    ${m.sticker ? `<div class="flex justify-center py-0.5 cw-keep-native-emoji">${(Number.isInteger(m.stickerIdx) && m.stickerIdx < 28 && typeof getPastelStickerSvg === 'function') ? getPastelStickerSvg(m.stickerIdx, 62) : `<div class="text-5xl leading-none">${m.sticker}</div>`}</div>` : ''}
                    ${isVoiceBubble ? `<button type="button" class="cw-voice-play-btn w-full min-w-[175px] flex items-center gap-2.5 px-2.5 py-1.5 rounded-xl text-left transition active:scale-[0.98]" style="background:${mine ? 'rgba(255,255,255,0.18)' : 'var(--accent-royal-soft)'}; color:${mine ? '#ffffff' : 'var(--accent-royal)'};" data-msg-id="${escapeHtml(m.id)}"><span class="cw-v-ico w-7 h-7 rounded-full flex items-center justify-center shrink-0 transition" style="background:${mine ? 'rgba(255,255,255,0.28)' : 'var(--accent-royal)'}; color:#ffffff;">${CW_MEDIA_SVG.play}</span><div class="flex-1 min-w-0 space-y-1"><div class="flex items-center justify-between gap-2 text-[11px] font-bold"><span class="cw-v-lbl truncate">${state.lang === 'zh' ? '点击播放语音' : '눌러서 음성 듣기'}</span><span class="cw-v-time text-[10px] opacity-85 tabular-nums shrink-0 inline-flex items-center">${CW_MEDIA_SVG.waveMini}</span></div><div class="w-full h-1 rounded-full overflow-hidden" style="background:${mine ? 'rgba(255,255,255,0.25)' : 'rgba(139,92,246,0.2)'};"><div class="cw-v-bar h-full rounded-full transition-all duration-150" style="width:0%; background:${mine ? '#ffffff' : 'var(--accent-royal)'};"></div></div></div></button>` : ''}
                    ${Array.isArray(m.photoUrls) && m.photoUrls.length > 1
                      ? `<div class="${m.photoUrls.length === 2 ? 'cw-photo-grid-2' : 'cw-photo-grid-3'}">${m.photoUrls.map((u, uIdx) => `<button type="button" class="cw-photo-cell cw-zoom-photo" data-msg-id="${escapeHtml(m.id)}" data-idx="${uIdx}"><img src="${__cwMediaUrl(u)}" alt="photo" decoding="async" /></button>`).join('')}</div>`
                      : (m.videoUrl ? `<div class="cw-photo-single relative"><video src="${__cwMediaUrl(m.videoUrl, 'video/mp4')}" controls playsinline webkit-playsinline preload="metadata" class="w-full h-full object-cover bg-black/85"></video><div class="absolute top-1.5 right-1.5 flex items-center gap-1"><a href="${__cwMediaUrl(m.videoUrl, 'video/mp4')}" download="chanwan_video_${escapeHtml(m.id)}.mp4" class="px-1.5 py-0.5 rounded-md text-[10px] font-bold text-white" style="background: rgba(15,10,28,0.72);" title="저장">📥</a><button type="button" class="cw-zoom-video px-1.5 py-0.5 rounded-md text-[10px] font-bold text-white" style="background: rgba(15,10,28,0.72);" data-src="${__cwMediaUrl(m.videoUrl, 'video/mp4')}" title="전체화면">⛶</button></div></div>`
                        : (m.photoUrl ? `<button type="button" class="${isGifMedia ? 'cw-gif-single' : 'cw-photo-single'} cw-zoom-photo" data-msg-id="${escapeHtml(m.id)}" data-idx="0"><img src="${__cwMediaUrl(m.photoUrl)}" alt="photo" decoding="async" /></button>` : ''))}
                    ${showText ? renderChatLinkEmbed(m.original, mine) : ''}
                    ${showText ? `<div class="flex items-start justify-between gap-2"><div class="min-w-0 flex-1 cw-keep-native-emoji ${isEmojiMsg ? 'text-3xl leading-normal py-1 flex items-center justify-center flex-wrap gap-1 text-center' : (mine ? 'cw-orig-main text-[0.98rem] font-bold leading-snug break-words tracking-[-0.01em]' : 'cw-orig-sub text-[0.84rem] font-medium opacity-80 leading-snug break-words tracking-[-0.01em]')} ${m.sticker ? 'text-center font-bold text-xs' : ''}">${window.renderTextWithWechatEmoticons ? window.renderTextWithWechatEmoticons(escapeHtml(m.original), isPureWcMsg ? 42 : 22) : escapeHtml(m.original)}</div>${(!isEmojiMsg && !isPurePunctMsg && !isPureLinkMsg && !isVoiceBubble) ? `<button type="button" class="speak-btn opacity-65 hover:opacity-100 shrink-0 pt-0.5 inline-flex items-center" data-text="${escapeHtml(m.original)}" data-lang="${origLang}" title="${state.lang === 'zh' ? 'AI 原文朗读' : '원문 듣기'}"><svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/></svg></button>` : ''}</div>` : ''}
                    ${hasTrans ? `
                      <div class="pt-1.5 mt-1 space-y-1.5" style="border-top: 1px solid ${mine ? 'rgba(255,255,255,0.2)' : 'rgba(139,92,246,0.12)'};">
                        <div class="flex items-start justify-between gap-2">
                          <div class="min-w-0 flex-1">
                            <div class="${mine ? 'cw-trans-sub text-[0.85rem] font-medium' : 'cw-trans-main text-[0.98rem] font-bold'} leading-snug break-words cw-keep-native-emoji" style="opacity: ${mine ? '0.86' : '1'};">${isFailedTrans ? (state.lang === 'zh' ? '翻译准确度较低，请点重译' : '번역이 부정확해요 · 재번역을 눌러주세요') : (window.renderTextWithWechatEmoticons ? window.renderTextWithWechatEmoticons(escapeHtml((() => { let _t = String(m.translated || '').replace(/^\s*-\s+/, ''); if (/[\u4e00-\u9fff]/.test(_t) && !/[가-힣]/.test(_t)) { _t = _t.replace(/\s*ㅎ{3,}/g, /哈哈/.test(_t) ? '' : ' 哈哈哈').replace(/\s*ㅎ{2}/g, /嘿嘿|哈哈/.test(_t) ? '' : ' 嘿嘿').replace(/\s*ㅋ{2,}/g, /哈哈/.test(_t) ? '' : ' 哈哈').replace(/\s*[ㅠㅜ]{2,}/g, /呜呜/.test(_t) ? '' : ' 呜呜').replace(/[ㅎㅋㅠㅜ]+/g, '').trim(); } return _t; })()), 21) : escapeHtml(m.translated || ''))}</div>
                            ${(!isFailedTrans && m.altTranslated && m.altTranslated !== m.translated) ? `<div class="cw-alt-trans text-[11px] mt-1 leading-snug break-words" style="opacity: ${mine ? '0.82' : '0.76'};"><b>${state.lang === 'zh' ? '参考译文' : '다른 번역'}:</b> ${window.renderTextWithWechatEmoticons ? window.renderTextWithWechatEmoticons(escapeHtml(String(m.altTranslated || '').replace(/[ㅎㅋㅠㅜ]+/g, '').trim()), 18) : escapeHtml(String(m.altTranslated || '').replace(/[ㅎㅋㅠㅜ]+/g, '').trim())}</div>` : ''}
                          </div>
                          ${!isFailedTrans ? `<button type="button" class="speak-btn opacity-65 hover:opacity-100 shrink-0 pt-0.5 inline-flex items-center" data-text="${escapeHtml(m.translated)}" data-lang="${m.tgtLang === 'zh' ? 'zh-CN' : 'ko-KR'}" title="${state.lang === 'zh' ? '朗读译文' : '번역 듣기'}"><svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/></svg></button>` : ''}
                        </div>
                        <div class="flex items-center justify-between gap-2 text-[10px] pt-0.5 flex-wrap" style="opacity:0.94;">
                          <div class="flex items-center gap-1.5 flex-wrap">
                            ${(() => {
                              const sTone = typeof analyzeSmartCoupleTone === 'function' ? analyzeSmartCoupleTone(m.original, m.translated) : null;
                              let toneDisp = '';
                              if (state.lang === 'zh') {
                                if (m.toneZh && /[\u4e00-\u9fff]/.test(m.toneZh) && !/[가-힣]/.test(m.toneZh)) toneDisp = m.toneZh;
                                else if (m.tone && /[\u4e00-\u9fff]/.test(m.tone) && !/[가-힣]/.test(m.tone)) toneDisp = m.tone;
                                else if (m.tone) {
                                  const locT = localizeSavedToneOrNuance(m.tone, 'tone');
                                  toneDisp = (locT && locT !== '💜 甜蜜恋人语气') ? locT : (sTone ? sTone.toneZh : locT);
                                } else if (sTone) toneDisp = sTone.toneZh;
                              } else {
                                if (m.tone && /[가-힣]/.test(m.tone) && !/[\u4e00-\u9fff]/.test(m.tone)) toneDisp = m.tone;
                                else if (m.tone) {
                                  const locT = localizeSavedToneOrNuance(m.tone, 'tone');
                                  toneDisp = (locT && locT !== '💜 다정한 연인체') ? locT : (sTone ? sTone.toneKo : locT);
                                } else if (sTone) toneDisp = sTone.toneKo;
                              }
                              return toneDisp ? `<span class="${mine ? 'cw-mine-pill ' : ''}inline-flex items-center gap-0.5 font-semibold px-2 py-0.5 rounded-full" style="background: ${mine ? 'rgba(255,255,255,0.16)' : 'var(--accent-royal-soft)'}; color: ${mine ? '#ffffff' : 'var(--accent-royal)'};">${escapeHtml(toneDisp)}</span>` : '';
                            })()}
                            ${(showText && !isEmojiMsg && !isPurePunctMsg && !isPureLinkMsg) ? `<button type="button" class="cw-msg-polish-btn inline-flex items-center gap-0.5 font-semibold px-2 py-0.5 rounded-full transition" style="background: ${mine ? 'rgba(255,255,255,0.18)' : 'var(--accent-royal-soft)'}; color: ${mine ? '#ffffff' : 'var(--accent-royal)'};" data-id="${escapeHtml(m.id)}" data-orig="${escapeHtml(m.original || '')}" data-lang="${origLang === 'ko-KR' ? 'ko' : 'zh'}">✨ ${state.lang === 'zh' ? '意思解析' : '뜻풀이'}</button>` : ''}
                            ${m.editedAt ? `<span class="opacity-75 px-0.5">${state.lang === 'zh' ? '已编辑' : '수정됨'}</span>` : ''}
                          </div>
                          <div class="flex items-center gap-1.5 ml-auto shrink-0">
                            ${(isFailedTrans || (isPendingTrans && (Date.now() - Number(m.ts || 0)) > 3500)) ? `<button type="button" class="retrans-msg-btn inline-flex items-center gap-0.5 font-semibold px-2 py-0.5 rounded-full transition" style="background: ${mine ? 'rgba(255,255,255,0.2)' : 'var(--surface-2)'}; color: ${mine ? '#ffffff' : 'var(--text-secondary)'};" data-id="${escapeHtml(m.id)}">${retransLabel}</button>` : ''}
                            <button type="button" class="cw-toggle-detail-btn inline-flex items-center gap-0.5 font-semibold px-2 py-0.5 rounded-full transition" style="background: ${mine ? 'rgba(255,255,255,0.14)' : 'var(--surface-2)'}; color: ${mine ? '#ffffff' : 'var(--text-secondary)'};" data-id="${escapeHtml(m.id)}">🔎 ${state.lang === 'zh' ? '详情 ▾' : '상세 ▾'}</button>
                          </div>
                        </div>
                        <div id="msgDetail_${escapeHtml(m.id)}" class="hidden space-y-1.5 pt-1 text-[10px]" style="border-top: 1px solid ${mine ? 'rgba(255,255,255,0.14)' : 'var(--border-subtle)'};">
                          ${(!isFailedTrans && m.pronunciation && !/원어민.*발음|支持.*发音|支持原声朗读|오프라인\s*안전|离线安全/.test(m.pronunciation)) ? `<div class="cw-pron-line break-words opacity-85">${escapeHtml(m.pronunciation)}</div>` : ''}
                          ${(!isFailedTrans && (m.nuance || m.nuanceZh || m.tone)) ? (() => {
                            const smartLive = typeof analyzeSmartCoupleTone === 'function' ? analyzeSmartCoupleTone(m.original, m.translated) : null;
                            const rawN = String(m.nuance || '').trim();
                            const rawNZh = String(m.nuanceZh || '').trim();
                            const isOldBoilerplate = !rawN || /한국어 원문의 감정을 살려|자연스러운 중국어로 옮겼습니다|자연스러운 한국어로 옮겼습니다|서로의 일상을 편안하고 자연스럽게 나누는|彼此轻松自然分享日常|保留了韩语原文的情感温度|结合中文原文的亲切语境/.test(rawN);
                            let detailTxt = '';
                            if (state.lang === 'zh') {
                              if (rawNZh && /[\u4e00-\u9fff]/.test(rawNZh) && !/[가-힣]/.test(rawNZh)) {
                                detailTxt = rawNZh;
                              } else if (rawN && /[\u4e00-\u9fff]/.test(rawN) && !/[가-힣]/.test(rawN)) {
                                detailTxt = rawN;
                              } else if (smartLive) {
                                detailTxt = smartLive.nuanceZh;
                              } else if (rawN) {
                                detailTxt = localizeSavedToneOrNuance(rawN, 'nuance');
                              }
                            } else {
                              if (!isOldBoilerplate && rawN && /[가-힣]/.test(rawN) && !/[\u4e00-\u9fff]/.test(rawN)) {
                                detailTxt = rawN;
                              } else if (smartLive) {
                                detailTxt = smartLive.nuanceKo;
                              } else if (rawN) {
                                detailTxt = localizeSavedToneOrNuance(rawN, 'nuance');
                              }
                            }
                            if (!detailTxt || /서로의 일상을 편안하고 자연스럽게 나누는|彼此轻松自然分享日常/.test(detailTxt)) return '';
                            return `<div class="cw-nuance-detail rounded-lg px-2 py-1 leading-snug" style="background: ${mine ? 'rgba(255,255,255,0.12)' : 'rgba(139,92,246,0.08)'}; color: ${mine ? 'rgba(255,255,255,0.92)' : 'var(--text-secondary)'};"><b>${state.lang === 'zh' ? '语气解析' : '말투 분석'}:</b> ${escapeHtml(detailTxt)}</div>`;
                          })() : ''}
                          <div class="flex items-center justify-between gap-1.5">
                            <span class="${mine ? 'cw-mine-pill ' : ''}font-semibold px-1.5 py-0.5 rounded-full" style="background: ${mine ? 'rgba(255,255,255,0.16)' : accBg}; color: ${mine ? '#ffffff' : accColor};">${accLabel}</span>
                            <button type="button" class="retrans-msg-btn font-semibold px-2 py-0.5 rounded-full transition" style="background: ${mine ? 'rgba(255,255,255,0.16)' : 'var(--surface-2)'}; color: ${mine ? '#ffffff' : 'var(--text-secondary)'};" data-id="${escapeHtml(m.id)}">${retransLabel}</button>
                          </div>
                        </div>
                        <div class="cw-msg-polish-box ${m.polishOpen && m.polishObj ? '' : 'hidden'} rounded-lg px-2.5 py-1.5 text-[10.5px] leading-snug space-y-1" data-polish-box-id="${escapeHtml(m.id)}" style="background: rgba(16,185,129,0.09); border: 1px solid rgba(16,185,129,0.22); color: var(--text-primary);">
                          ${m.polishObj ? `<div><b>${state.lang === 'zh' ? '自然表达' : '자연스러운 뜻'}:</b> ${escapeHtml(m.polishObj.natural || '')}</div>${m.polishObj.intent ? `<div class="text-[10px] opacity-85">${escapeHtml(m.polishObj.intent)}</div>` : ''}${m.polishObj.tip ? `<div class="text-[10px] opacity-80">${escapeHtml(m.polishObj.tip)}</div>` : ''}` : ''}
                        </div>
                      </div>
                    ` : ''}
                  </div>
                  <!-- Inline Edit Box (Messenger Edit Feature) -->
                  <div id="editMsgBox_${escapeHtml(m.id)}" class="hidden mt-1.5 rounded-xl p-2 border space-y-1.5" style="background: var(--surface-elevated); border-color: var(--border-accent);">
                    <textarea id="editMsgTa_${escapeHtml(m.id)}" rows="2" class="royal-input w-full rounded-lg px-2.5 py-1.5 text-xs resize-none">${escapeHtml(m.original || '')}</textarea>
                    <div class="flex items-center justify-between gap-1.5">
                      <button type="button" class="edit-open-emoji-btn btn-ghost px-2.5 py-1 rounded-full text-[11px]" data-id="${escapeHtml(m.id)}" title="${state.lang === 'zh' ? '插入表情' : '앱 이모지 열기'}">😊</button>
                      <div class="flex items-center gap-1.5">
                        <button type="button" class="cancel-edit-msg-btn btn-ghost px-2.5 py-1 rounded-full text-[10px] font-semibold" data-id="${escapeHtml(m.id)}">${state.lang === 'zh' ? '取消' : '취소'}</button>
                        <button type="button" class="save-edit-msg-btn btn-royal px-2.5 py-1 rounded-full text-[10px] font-semibold" data-id="${escapeHtml(m.id)}">${state.lang === 'zh' ? '保存并重译' : '수정 완료'}</button>
                      </div>
                    </div>
                  </div>
                  <!-- Ultra-Clean Native Footer: ONLY Time + Read Receipt (Long-Press Bubble for Actions & Reactions!) -->
                  <div class="flex flex-nowrap items-center gap-1.5 text-[10px] text-mut mt-1 px-0.5 whitespace-nowrap">
                    <span class="tabular-nums opacity-80">${escapeHtml(localDisplayTime)}</span>
                    ${readReceiptHtml}
                  </div>
                  ${Array.isArray(m.reactions) && m.reactions.length ? `<div class="flex flex-wrap gap-1 mt-0.5 cw-keep-native-emoji">${m.reactions.map(em => `<button type="button" class="pick-react-btn text-xs px-1.5 py-0.5 rounded-full border hover:scale-105 active:scale-95 transition" style="background: var(--surface-1); border-color: var(--border-accent);" data-id="${escapeHtml(m.id)}" data-emoji="${em}">${em}</button>`).join('')}</div>` : ''}
                </div>
              </div>
            `;
          }).join('');
          const olderBtn = document.getElementById('chatLoadOlderBtn');
          if (olderBtn) {
            olderBtn.addEventListener('click', () => {
              const prevH = listEl.scrollHeight;
              window.__chatVisibleLimit = (window.__chatVisibleLimit || 45) + 45;
              renderChat();
              try { listEl.scrollTop = Math.max(0, listEl.scrollHeight - prevH); } catch (_) {}
            });
          }
          listEl.querySelectorAll('.cw-retry-send-btn').forEach(btn => {
            btn.addEventListener('click', async () => {
              const mid = btn.getAttribute('data-msg-id');
              const target = (state.chat.messages || []).find(x => x && x.id === mid);
              if (target) target.deliveryStatus = 'sending';
              renderChat();
              if (typeof window.__connectEmqxNow === 'function') window.__connectEmqxNow();
              if (typeof window.__pushFullCloudSync === 'function') await window.__pushFullCloudSync();
            });
          });
          if (typeof window.__refreshIconSlots === 'function') window.__refreshIconSlots(listEl);
          const __cwForceBot = !!window.__cwForceScrollBottom;
          window.__cwForceScrollBottom = false;
          if (typeof window.__cwPreserveChatScroll === 'number') {
            listEl.scrollTop = window.__cwPreserveChatScroll;
          } else if (__cwWasReadingOlder && !__cwForceBot) {
            listEl.scrollTop = __cwPrevScrollTop;
            requestAnimationFrame(() => { listEl.scrollTop = __cwPrevScrollTop; });
          } else if (typeof window.__scrollChatToBottom === 'function') {
            window.__scrollChatToBottom(false);
          } else {
            listEl.scrollTop = listEl.scrollHeight;
          }

          listEl.querySelectorAll('.cw-voice-play-btn').forEach(btn => {
            btn.addEventListener('click', (ev) => {
              ev.stopPropagation();
              const mid = btn.getAttribute('data-msg-id');
              const target = (state.chat.messages || []).find(x => x && x.id === mid);
              if (!target || !target.audioUrl) return;
              if (typeof window.__playChatVoiceMsg === 'function') window.__playChatVoiceMsg(mid, target.audioUrl, btn);
            });
          });
          listEl.querySelectorAll('.retrans-msg-btn').forEach(btn => {
            btn.addEventListener('click', async () => {
              const mid = btn.getAttribute('data-id');
              const target = state.chat.messages.find(x => x && x.id === mid);
              if (!target || !target.original) return;
              btn.disabled = true;
              btn.textContent = state.lang === 'zh' ? '翻译中...' : '재번역 중...';
              try {
                const savedScrollTop = listEl.scrollTop;
                const newRes = await translateWithAutoRetry(target.original, activeToneMode || 'lover', target.engine || 'Google');
                if (newRes && newRes.translated) {
                  target.translated = newRes.translated;
                  target.altTranslated = newRes.altTranslated || '';
                  target.pronunciation = newRes.pronunciation || target.pronunciation || '';
                  target.accuracy = Number(newRes.accuracy) || 90;
                  target.engine = newRes.engine || target.engine || '';
                  target.tgtLang = newRes.tgtLang || target.tgtLang || '';
                  if (newRes.tone) target.tone = newRes.tone;
                  if (newRes.toneZh) target.toneZh = newRes.toneZh;
                  if (newRes.nuance) target.nuance = newRes.nuance;
                  if (newRes.nuanceZh) target.nuanceZh = newRes.nuanceZh;
                  saveState(true);
                  if (typeof window.__sendChatSignal === 'function') {
                    window.__sendChatSignal('edit', { msgId: target.id, original: target.original, translated: target.translated, pronunciation: target.pronunciation, accuracy: target.accuracy, engine: target.engine });
                  }
                  window.__cwPreserveChatScroll = savedScrollTop;
                  renderChat();
                  listEl.scrollTop = savedScrollTop;
                  requestAnimationFrame(() => { listEl.scrollTop = savedScrollTop; window.__cwPreserveChatScroll = null; });
                  showToast(state.lang === 'zh' ? `✨ 多引擎精校完成 (准确度 ${target.accuracy}%)` : `✨ 다중 엔진 정밀 재번역 완료 (정확도 ${target.accuracy}%)`);
                }
              } catch (_) {
                btn.disabled = false;
              }
            });
          });
        if (typeof renderChatPinnedBanner === 'function') renderChatPinnedBanner();
        listEl.querySelectorAll('.pin-msg-btn').forEach(btn => {
            btn.addEventListener('click', () => {
              const target = state.chat.messages.find(x => x && x.id === btn.getAttribute('data-id'));
              if (!target) return;
              const isZh = state.lang === 'zh';
              const aLabel = target.sender === 'suwan' ? (isZh ? '完' : '수완') : (isZh ? '靖灿' : '징찬');
              state.chat.pinnedMsg = {
                id: target.id,
                authorRole: target.sender || 'suwan',
                author: aLabel,
                text: String(target.original || '').slice(0, 90),
                translated: String(target.translated || '').slice(0, 90),
                updatedAt: Date.now()
              };
              saveState(true);
              if (typeof renderChatPinnedBanner === 'function') renderChatPinnedBanner();
              showToast(isZh ? '📌 已置顶到聊天顶部公告！' : '📌 채팅방 상단 공지로 고정했어요!');
            });
          });
        listEl.querySelectorAll('.reply-msg-btn').forEach(btn => {
            btn.addEventListener('click', () => {
              const target = state.chat.messages.find(x => x && x.id === btn.getAttribute('data-id'));
              if (!target) return;
              window.__pendingChatReply = {
                id: target.id,
                author: target.sender === 'suwan' ? '수완(完)' : '靖灿(灿)',
                text: (target.original || '').slice(0, 60)
              };
              const bar = document.getElementById('chatReplyBar');
              const au = document.getElementById('chatReplyAuthor');
              const sn = document.getElementById('chatReplySnippet');
              if (au) au.textContent = `↩️ ${window.__pendingChatReply.author}`;
              if (sn) sn.textContent = window.__pendingChatReply.text;
              if (bar) bar.classList.remove('hidden');
              document.getElementById('chatInput')?.focus();
            });
          });
          listEl.querySelectorAll('.react-toggle-btn').forEach(btn => {
            btn.addEventListener('click', () => {
              const tid = btn.getAttribute('data-id');
              const pk = document.getElementById(`reactPicker_${tid}`);
              if (!pk) return;
              const willOpen = pk.classList.contains('hidden');
              listEl.querySelectorAll('[id^="reactPicker_"]').forEach(el => { if (el !== pk) el.classList.add('hidden'); });
              pk.classList.toggle('hidden', !willOpen);
            });
          });
          listEl.querySelectorAll('.react-more-btn').forEach(btn => {
            btn.addEventListener('click', (ev) => {
              ev.stopPropagation();
              const tid = btn.getAttribute('data-id');
              const moreEl = document.getElementById(`reactMore_${tid}`);
              if (!moreEl) return;
              const opening = moreEl.classList.contains('hidden');
              moreEl.classList.toggle('hidden', !opening);
              btn.textContent = opening ? '−' : '＋';
            });
          });
          listEl.querySelectorAll('.cw-toggle-detail-btn').forEach(btn => {
            btn.addEventListener('click', () => {
              const det = document.getElementById(`msgDetail_${btn.getAttribute('data-id')}`);
              if (!det) return;
              const openNow = det.classList.contains('hidden');
              det.classList.toggle('hidden', !openNow);
              btn.textContent = state.lang === 'zh' ? (openNow ? '🔎 收起 ▴' : '🔎 详情 ▾') : (openNow ? '🔎 접기 ▴' : '🔎 상세 ▾');
            });
          });
          listEl.querySelectorAll('.copy-toggle-btn').forEach(btn => {
            btn.addEventListener('click', () => {
              const tid = btn.getAttribute('data-id');
              const menu = document.getElementById(`copyMenu_${tid}`);
              if (!menu) return;
              const willOpen = menu.classList.contains('hidden');
              listEl.querySelectorAll('[id^="copyMenu_"]').forEach(el => { if (el !== menu) el.classList.add('hidden'); });
              menu.classList.toggle('hidden', !willOpen);
            });
          });
          listEl.querySelectorAll('.copy-pick-btn').forEach(btn => {
            btn.addEventListener('click', async () => {
              const mid = btn.getAttribute('data-id');
              const mode = btn.getAttribute('data-mode') || 'orig';
              const target = (state.chat?.messages || []).find(x => x && x.id === mid);
              if (!target) return;
              const txt = mode === 'trans' ? (target.translated || target.original || '')
                : (mode === 'both' ? `${target.original || ''}
${target.translated || ''}`.trim() : (target.original || ''));
              try {
                if (navigator.clipboard && navigator.clipboard.writeText) await navigator.clipboard.writeText(txt);
                else {
                  const ta = document.createElement('textarea'); ta.value = txt; ta.style.position = 'fixed'; ta.style.opacity = '0';
                  document.body.appendChild(ta); ta.select(); document.execCommand('copy'); ta.remove();
                }
                showToast(state.lang === 'zh' ? '📋 已复制到剪贴板' : '📋 클립보드에 복사했어요');
              } catch (_) {
                showToast(state.lang === 'zh' ? '复制失败' : '복사에 실패했어요');
              }
              document.getElementById(`copyMenu_${mid}`)?.classList.add('hidden');
            });
          });
          // Prime 3 v45: WeChat-Style Long-Press (0.42s) & Right-Click Floating Context Menu
          const closeMsgContextMenu = () => {
            document.getElementById('cwMsgContextBackdrop')?.classList.add('hidden');
            document.getElementById('cwMsgContextMenu')?.classList.add('hidden');
          };
          const openMsgContextMenu = (mid, anchorEl) => {
            const m = (state.chat?.messages || []).find(x => x && x.id === mid);
            const menu = document.getElementById('cwMsgContextMenu');
            const bd = document.getElementById('cwMsgContextBackdrop');
            if (!m || !menu || !bd) return;
            try { if (navigator.vibrate) navigator.vibrate(25); } catch (_) {}
            const isZh = state.lang === 'zh';
            const myR = state.myRole || 'suwan';
            const normS = (m.sender === 'jingchan' || String(m.sender || '').includes('靖灿')) ? 'jingchan' : 'suwan';
            const mine = normS === myR;
            const hasTxt = String(m.original || '').trim().length > 0;
            const hasTrans = !!(m.translated && m.translated !== m.original && !/^\[(中文|한국어)\]\s*/.test(String(m.translated)));
            const isPureLink = /^https?:\/\/\S+$/i.test(String(m.original || '').trim());
            const isVoice = !!(m.audioUrl && String(m.audioUrl).startsWith('data:audio/'));
            const topReacts = ['❤️', '🥰', '😘', '😂', '🥺', '👍'];
            const moreReacts = ['💜', '🫶', '🤗', '😍', '🥹', '😭', '😡', '😤', '😮', '🤔', '👏', '🙏', '🔥', '🎉', '✨', '💯', '🌙', '🍽️'];
            const acts = [];
            if (hasTxt) acts.push({ act: 'copy_orig', label: isZh ? '复制原文' : '원문 복사', svg: '<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>' });
            if (hasTrans) acts.push({ act: 'copy_trans', label: isZh ? '复制译文' : '번역 복사', svg: '<path d="M4 5h7M7 3v2M5 9c1 2 3 4 5 5M10 9c-1 2-3 4-5 5"/><path d="M13 19l4-10 4 10M14.5 16h5"/>' });
            acts.push({ act: 'reply', label: isZh ? '回复' : '답장', svg: '<polyline points="9 17 4 12 9 7"/><path d="M20 18v-2a4 4 0 0 0-4-4H4"/>' });
            acts.push({ act: 'pin', label: isZh ? '置顶' : '공지 고정', svg: '<path d="M12 17v5"/><path d="M9 10.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V7a1 1 0 0 1 1-1 2 2 0 0 0 0-4H8a2 2 0 0 0 0 4 1 1 0 0 1 1 1z"/>' });
            if (mine && hasTxt && !isPureLink && !isVoice) acts.push({ act: 'edit', label: isZh ? '编辑' : '수정', svg: '<path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/>' });
            if (mine) acts.push({ act: 'del', label: isZh ? '删除' : '삭제', danger: true, svg: '<polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/>' });

            menu.innerHTML = `
              <div class="flex items-center justify-between gap-0.5 pb-2 border-b" style="border-color: rgba(255,255,255,0.12);">
                ${topReacts.map(em => {
                  const active = Array.isArray(m.reactions) && m.reactions.includes(em);
                  return `<button type="button" class="ctx-react-btn text-lg w-9 h-9 rounded-full flex items-center justify-center hover:scale-115 active:scale-95 transition" style="${active ? 'background: rgba(168,85,247,0.38);' : ''}" data-emoji="${em}">${em}</button>`;
                }).join('')}
                <button type="button" id="ctxMoreReactBtn" class="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition active:scale-90" style="background: rgba(255,255,255,0.12); color: #e2e8f0;">＋</button>
              </div>
              <div id="ctxMoreReactGrid" class="hidden grid grid-cols-6 gap-0.5 py-2 border-b" style="border-color: rgba(255,255,255,0.12);">
                ${moreReacts.map(em => {
                  const active = Array.isArray(m.reactions) && m.reactions.includes(em);
                  return `<button type="button" class="ctx-react-btn text-base w-9 h-9 rounded-full flex items-center justify-center hover:scale-115 active:scale-95 transition" style="${active ? 'background: rgba(168,85,247,0.38);' : ''}" data-emoji="${em}">${em}</button>`;
                }).join('')}
              </div>
              <div class="grid ${acts.length <= 4 ? 'grid-cols-4' : 'grid-cols-3'} gap-1 pt-2">
                ${acts.map(a => `
                  <button type="button" class="ctx-act-btn flex flex-col items-center justify-center gap-1 py-2 px-1 rounded-xl hover:bg-white/10 active:scale-95 transition ${a.danger ? 'text-rose-400' : 'text-slate-100'}" data-act="${a.act}">
                    <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">${a.svg}</svg>
                    <span class="text-[10.5px] font-medium leading-none whitespace-nowrap">${a.label}</span>
                  </button>
                `).join('')}
              </div>
            `;
            bd.classList.remove('hidden');
            menu.classList.remove('hidden');
            // Position smartly above or below the pressed bubble
            const rect = anchorEl.getBoundingClientRect();
            const mw = Math.min(286, window.innerWidth - 20);
            const mh = menu.offsetHeight || 160;
            let left = mine ? (rect.right - mw) : rect.left;
            left = Math.max(10, Math.min(window.innerWidth - mw - 10, left));
            let top = rect.top - mh - 10;
            if (top < 64) top = Math.min(window.innerHeight - mh - 20, rect.bottom + 10);
            menu.style.left = `${Math.round(left)}px`;
            menu.style.top = `${Math.round(Math.max(16, top))}px`;

            menu.querySelector('#ctxMoreReactBtn')?.addEventListener('click', (ev) => {
              ev.stopPropagation();
              const g = menu.querySelector('#ctxMoreReactGrid');
              if (!g) return;
              const opening = g.classList.contains('hidden');
              g.classList.toggle('hidden', !opening);
              ev.currentTarget.textContent = opening ? '−' : '＋';
            });
            menu.querySelectorAll('.ctx-react-btn').forEach(b => {
              b.addEventListener('click', () => {
                const em = b.getAttribute('data-emoji');
                if (!Array.isArray(m.reactions)) m.reactions = [];
                const idx = m.reactions.indexOf(em);
                if (idx >= 0) m.reactions.splice(idx, 1);
                else m.reactions.push(em);
                saveState(true); renderChat();
                if (typeof window.__sendChatSignal === 'function') window.__sendChatSignal('react', { msgId: mid, reactions: m.reactions });
                closeMsgContextMenu();
              });
            });
            menu.querySelectorAll('.ctx-act-btn').forEach(b => {
              b.addEventListener('click', async () => {
                const act = b.getAttribute('data-act');
                closeMsgContextMenu();
                if (act === 'copy_orig' || act === 'copy_trans') {
                  const txt = act === 'copy_trans' ? (m.translated || m.original || '') : (m.original || '');
                  try {
                    if (navigator.clipboard && navigator.clipboard.writeText) await navigator.clipboard.writeText(txt);
                    else { const ta = document.createElement('textarea'); ta.value = txt; ta.style.position = 'fixed'; ta.style.opacity = '0'; document.body.appendChild(ta); ta.select(); document.execCommand('copy'); ta.remove(); }
                    showToast(isZh ? '📋 已复制到剪贴板' : '📋 클립보드에 복사했어요');
                  } catch (_) { showToast(isZh ? '复制失败' : '복사에 실패했어요'); }
                } else if (act === 'reply') {
                  window.__pendingChatReply = { id: m.id, author: m.sender === 'suwan' ? '수완' : '靖灿', text: m.original || m.translated || '' };
                  const rb = document.getElementById('chatReplyBar');
                  const ra = document.getElementById('chatReplyAuthor');
                  const rs = document.getElementById('chatReplySnippet');
                  if (ra) ra.textContent = `↩️ ${window.__pendingChatReply.author}${isZh ? ' 的消息' : '님에게 답장'}`;
                  if (rs) rs.textContent = window.__pendingChatReply.text;
                  if (rb) rb.classList.remove('hidden');
                  document.getElementById('chatInput')?.focus();
                } else if (act === 'pin') {
                  if (!state.chat) state.chat = {};
                  state.chat.pinnedMsg = { id: m.id, text: (m.original || m.translated || '').slice(0, 120), translated: (m.translated || '').slice(0, 120), author: m.sender === 'suwan' ? '수완' : '靖灿', updatedAt: Date.now() };
                  saveState(true); renderChat();
                  showToast(isZh ? '📌 已置顶到聊天顶部公告！' : '📌 채팅방 상단 공지로 고정했어요!');
                } else if (act === 'edit') {
                  const box = document.getElementById(`editMsgBox_${mid}`);
                  const ta = document.getElementById(`editMsgTa_${mid}`);
                  if (box) { box.classList.remove('hidden'); if (ta) ta.focus(); }
                } else if (act === 'del') {
                  if (!Array.isArray(state.deletedMsgIds)) state.deletedMsgIds = [];
                  if (!state.deletedMsgIds.includes(mid)) state.deletedMsgIds.push(mid);
                  state.chat.messages = (state.chat.messages || []).filter(x => x && x.id !== mid);
                  saveState(true); renderChat();
                  showToast(isZh ? '🗑️ 已删除消息' : '🗑️ 메시지를 삭제했어요');
                }
              });
            });
          };
          listEl.querySelectorAll('.cw-msg-bubble[data-msg-id]').forEach(bub => {
            let lpTimer = null, startX = 0, startY = 0;
            const clearLp = () => { if (lpTimer) { clearTimeout(lpTimer); lpTimer = null; } bub.classList.remove('cw-pressing'); };
            bub.addEventListener('touchstart', (ev) => {
              if (ev.target.closest('button:not(.cw-zoom-photo), a, video, input, textarea')) return;
              const t0 = ev.touches && ev.touches[0];
              if (!t0) return;
              startX = t0.clientX; startY = t0.clientY;
              bub.classList.add('cw-pressing');
              lpTimer = setTimeout(() => {
                lpTimer = null;
                bub.classList.remove('cw-pressing');
                window.__cwSuppressZoomUntil = Date.now() + 600;
                openMsgContextMenu(bub.getAttribute('data-msg-id'), bub);
              }, 420);
            }, { passive: true });
            bub.addEventListener('touchmove', (ev) => {
              if (!lpTimer) return;
              const t0 = ev.touches && ev.touches[0];
              if (t0 && (Math.abs(t0.clientX - startX) > 10 || Math.abs(t0.clientY - startY) > 10)) clearLp();
            }, { passive: true });
            bub.addEventListener('touchend', clearLp, { passive: true });
            bub.addEventListener('touchcancel', clearLp, { passive: true });
            bub.addEventListener('contextmenu', (ev) => {
              if (ev.target.closest('button:not(.cw-zoom-photo), a, video, input, textarea')) return;
              ev.preventDefault();
              openMsgContextMenu(bub.getAttribute('data-msg-id'), bub);
            });
          });
          const ctxBd = document.getElementById('cwMsgContextBackdrop');
          if (ctxBd && !ctxBd.__bound) {
            ctxBd.__bound = true;
            ctxBd.addEventListener('click', closeMsgContextMenu);
          }

          // One-time global tap-outside auto-dismiss for reaction picker, copy popover, sticker tray & plus drawer
          if (!window.__cwOutsideDismissBound) {
            window.__cwOutsideDismissBound = true;
            document.addEventListener('click', (ev) => {
              const t = ev.target;
              const path = typeof ev.composedPath === 'function' ? ev.composedPath() : [];
              const inIdOrCls = (sel) => {
                if (t && typeof t.closest === 'function' && t.closest(sel)) return true;
                return path.some(el => el && el.nodeType === 1 && typeof el.matches === 'function' && el.matches(sel));
              };
              if (!inIdOrCls('[id^="reactPicker_"], .react-toggle-btn')) {
                document.querySelectorAll('[id^="reactPicker_"]:not(.hidden)').forEach(el => el.classList.add('hidden'));
              }
              if (!inIdOrCls('[id^="copyMenu_"], .copy-toggle-btn')) {
                document.querySelectorAll('[id^="copyMenu_"]:not(.hidden)').forEach(el => el.classList.add('hidden'));
              }
              const recentToggle = Date.now() - (window.__cwLastDrawerToggleTs || 0) < 120;
              if (!recentToggle && !inIdOrCls('#chatStickerTray, #chatStickerBtn, .edit-open-emoji-btn')) {
                document.getElementById('chatStickerTray')?.classList.add('hidden');
              }
              if (!recentToggle && !inIdOrCls('#chatPlusDrawer, #chatPlusBtn')) {
                const pd = document.getElementById('chatPlusDrawer');
                if (pd && !pd.classList.contains('hidden')) {
                  pd.classList.add('hidden');
                  if (typeof window.__syncChatPlusBtnIcon === 'function') window.__syncChatPlusBtnIcon(false);
                }
              }
            });
          }
          listEl.querySelectorAll('.pick-react-btn').forEach(btn => {
            btn.addEventListener('click', () => {
              const mid = btn.getAttribute('data-id');
              const em = btn.getAttribute('data-emoji');
              const target = state.chat.messages.find(x => x && x.id === mid);
              if (!target) return;
              if (!Array.isArray(target.reactions)) target.reactions = [];
              const idx = target.reactions.indexOf(em);
              if (idx >= 0) target.reactions.splice(idx, 1);
              else target.reactions.push(em);
              saveState(true);
              renderChat();
              if (typeof window.__sendChatSignal === 'function') window.__sendChatSignal('react', { msgId: mid, reactions: target.reactions });
            });
          });
          listEl.querySelectorAll('.edit-msg-btn').forEach(btn => {
            btn.addEventListener('click', () => {
              const mid = btn.getAttribute('data-id');
              const box = document.getElementById(`editMsgBox_${mid}`);
              const ta = document.getElementById(`editMsgTa_${mid}`);
              if (box) { box.classList.remove('hidden'); if (ta) ta.focus(); }
            });
          });
          listEl.querySelectorAll('.edit-open-emoji-btn').forEach(btn => {
            btn.addEventListener('click', (ev) => {
              ev.preventDefault();
              const tr = document.getElementById('chatStickerTray');
              if (tr) {
                tr.classList.remove('hidden');
                if (typeof renderChatStickers === 'function') renderChatStickers('wechat');
              }
            });
          });
          listEl.querySelectorAll('.cancel-edit-msg-btn').forEach(btn => {
            btn.addEventListener('click', () => {
              const box = document.getElementById(`editMsgBox_${btn.getAttribute('data-id')}`);
              if (box) box.classList.add('hidden');
              document.getElementById('chatStickerTray')?.classList.add('hidden');
            });
          });
          listEl.querySelectorAll('.save-edit-msg-btn').forEach(btn => {
            btn.addEventListener('click', async () => {
              const mid = btn.getAttribute('data-id');
              const target = state.chat.messages.find(x => x && x.id === mid);
              const ta = document.getElementById(`editMsgTa_${mid}`);
              if (!target || !ta || !isMyAuthoredItem(target)) return;
              const newTxt = ta.value.trim();
              if (!newTxt) return;
              btn.disabled = true;
              btn.textContent = state.lang === 'zh' ? '保存中...' : '저장 중...';
              target.original = newTxt;
              target.editedAt = Date.now();
              const isEmojiOnly = !/[a-zA-Z0-9가-힣ㄱ-ㅎㅏ-ㅣ\u4e00-\u9fff]/.test(newTxt);
              if (!isEmojiOnly) {
                try {
                  const newR = await geminiTranslate(newTxt, activeToneMode || 'lover');
                  if (newR && newR.translated) {
                    target.translated = newR.translated;
                    target.pronunciation = newR.pronunciation || '';
                    target.accuracy = Number(newR.accuracy) || 92;
                    target.engine = newR.engine || target.engine || '';
                    target.tgtLang = newR.tgtLang || target.tgtLang || '';
                  }
                } catch (_) {}
              } else {
                target.translated = '';
              }
              saveState(true);
              renderChat();
              if (typeof window.__sendChatSignal === 'function') {
                window.__sendChatSignal('edit', {
                  msgId: mid, original: target.original, translated: target.translated,
                  pronunciation: target.pronunciation, accuracy: target.accuracy,
                  engine: target.engine, tgtLang: target.tgtLang, editedAt: target.editedAt
                });
              }
              showToast(state.lang === 'zh' ? '✏️ 消息已修改并同步' : '✏️ 메시지를 수정했어요');
            });
          });

          listEl.querySelectorAll('.del-msg-btn').forEach(btn => {
            btn.addEventListener('click', () => {
              const delId = btn.getAttribute('data-id');
              const target = state.chat.messages.find(x => x && x.id === delId);
              if (target && !isMyAuthoredItem(target)) {
                showToast(state.lang === 'zh' ? '只能删除自己发送的消息 🔒' : '본인이 보낸 메시지만 삭제할 수 있어요 🔒');
                return;
              }
              openConfirm(
                state.lang === 'zh' ? '删除消息' : '메시지 삭제 확인',
                state.lang === 'zh' ? '确定要删除这条消息吗？删除后无法恢复。' : '이 메시지를 정말 삭제할까요? 삭제하면 되돌릴 수 없어요.',
                () => {
                  if (delId) {
                    if (!Array.isArray(state.deletedMsgIds)) state.deletedMsgIds = [];
                    if (!state.deletedMsgIds.includes(delId)) state.deletedMsgIds.push(delId);
                    if (state.deletedMsgIds.length > 120) state.deletedMsgIds = state.deletedMsgIds.slice(-120);
                  }
                  state.chat.messages = state.chat.messages.filter(x => x.id !== delId);
                  saveState(true); renderChat(); renderHome();
                  showToast(state.lang === 'zh' ? '消息已删除' : '메시지가 삭제되었습니다.');
                }
              );
            });
          });
        }
      }

      function localizeSavedToneOrNuance(text, fallbackType) {
        const raw = String(text || '').trim();
        if (!raw) return '';
        const map = [
          ['다정한 연인체', '甜蜜恋人语气'], ['자연스러운 일상체', '自然日常'], ['부드러운 존댓말', '温柔敬语'], ['정중한 존댓말', '礼貌敬语'],
          ['그리움 · 애틋함', '思念 · 浪漫'], ['깊은 애정 · 설렘', '深情 · 心动'], ['따뜻한 위로 · 배려', '温柔安慰 · 关心'],
          ['위로 · 배려', '关心 · 安慰'], ['다정한 질문', '温柔提问'], ['친근한 안부', '亲切近况'],
          ['진심 어린 사과', '真诚致歉'], ['따뜻한 감사', '真心感谢'], ['진심 어린 감사', '真心感谢'],
          ['다정한 챙김', '暖心照顾'], ['따뜻한 챙김', '暖心照顾'], ['달콤한 칭찬', '甜蜜夸奖'], ['애정 칭찬', '甜蜜夸奖'],
          ['밤 인사 · 배려', '晚安 · 贴心'], ['밤 인사', '晚安问候'], ['아침 인사', '早安问候'],
          ['유쾌한 장난', '轻松打趣'], ['애교 섞인 말투', '撒娇语气'],
          ['안심 · 건강 챙김', '安心 · 关心健康'], ['일과 · 근황 공유', '工作 · 近况分享'], ['날씨 · 다정한 챙김', '天气 · 贴心叮嘱'],
          ['감탄 · 공유', '赞叹 · 分享'], ['감성 공유', '浪漫分享'], ['일상 공유', '日常分享'], ['일상 표현', '日常表达'],
          ['커플 이름 고정 번역', '情侣专属固定翻译'], ['AI 번역', 'AI 精译'],
          ['원문의 따뜻한 감정과 자연스러운 뉘앙스를 그대로 담았어요.', '保留了原文的温柔情感与自然语境。'],
          ['연인 사이의 다정하고 따뜻한 마음을 자연스럽게 담은 표현이에요.', '自然传达了恋人之间温柔甜蜜的心意。']
        ];
        if (state.lang === 'zh') {
          if (!/[가-힣]/.test(raw)) return raw;
          let out = raw;
          for (const [k, z] of map) out = out.split(k).join(z);
          if (/[가-힣]/.test(out)) {
            return fallbackType === 'tone' ? '💜 甜蜜恋人语气' : '保留了原文的温柔情感与自然语境。';
          }
          return out;
        } else {
          if (!/[一-鿿]/.test(raw)) return raw;
          let out = raw;
          for (const [k, z] of map) out = out.split(z).join(k);
          if (/[一-鿿]/.test(out)) {
            return fallbackType === 'tone' ? '💜 다정한 연인체' : '원문의 따뜻한 감정과 자연스러운 뉘앙스를 그대로 담았어요.';
          }
          return out;
        }
      }

      function renderBilingualCard(origText, transText, pronText, compact) {
        const orig = String(origText || '');
        const trans = String(transText || '');
        const origIsKo = /[가-힣]/.test(orig);
        const isZhMode = state.lang === 'zh';
        // When app is in Chinese mode and original is Korean (or vice versa), promote the user's preferred language to TOP primary!
        const shouldSwap = !!trans && ((isZhMode && origIsKo) || (!isZhMode && !origIsKo));
        const topText = shouldSwap ? trans : orig;
        const subText = shouldSwap ? orig : trans;
        const topIsKo = /[가-힣]/.test(topText);
        const topBadge = topIsKo ? '🇰🇷 한국어' : '🇨🇳 中文';
        const subBadge = topIsKo ? '🇨🇳 中文' : '🇰🇷 한국어';
        const padCls = compact ? 'p-2.5' : 'p-3';
        const topLang = topIsKo ? 'ko-KR' : 'zh-CN';
        const subLang = topIsKo ? 'zh-CN' : 'ko-KR';
        return `
          <div class="space-y-1.5">
            <div class="flex items-start gap-2">
              <span class="text-[10px] font-bold px-1.5 py-0.5 rounded-md shrink-0 mt-0.5" style="background: var(--accent-royal-soft); color: var(--accent-royal);">${topBadge}</span>
              <span class="${compact ? 'text-xs sm:text-sm' : 'text-sm'} font-medium leading-relaxed break-words flex-1 min-w-0">${escapeHtml(topText)}</span>
              ${topText ? `<button type="button" class="speak-btn btn-ghost w-7 h-7 rounded-full flex items-center justify-center text-[11px] shrink-0" data-text="${escapeHtml(topText)}" data-lang="${topLang}" title="음성 듣기">🔊</button>` : ''}
            </div>
            ${subText ? `
              <div class="royal-subcard rounded-xl ${padCls} flex items-start gap-2">
                <span class="text-[10px] font-bold px-1.5 py-0.5 rounded-md shrink-0 mt-0.5" style="background: rgba(186, 152, 102, 0.16); color: var(--accent-champagne);">${subBadge}</span>
                <div class="flex-1 min-w-0">
                  <div class="${compact ? 'text-xs' : 'text-xs sm:text-sm'} text-sec leading-relaxed break-words">${escapeHtml(subText)}</div>
                  ${pronText ? `<div class="text-[10px] text-mut mt-0.5 break-words">${escapeHtml(pronText)}</div>` : ''}
                </div>
                <button type="button" class="speak-btn btn-ghost w-7 h-7 rounded-full flex items-center justify-center text-[11px] shrink-0" data-text="${escapeHtml(subText)}" data-lang="${subLang}" title="음성 듣기">🔊</button>
              </div>
            ` : ''}
          </div>
        `;
      }

      function renderDiaryQaMemos() {
        // 1. Diaries
        const dList = document.getElementById('diaryList');
        dList.innerHTML = state.diaries.length ? state.diaries.map(d => `
          <article class="royal-card rounded-3xl p-4 sm:p-5 space-y-2.5">
            <div class="flex flex-wrap items-center justify-between gap-2">
              <div class="flex flex-wrap items-center gap-2 text-xs">
                <span class="font-bold text-gold">${escapeHtml(d.author)}</span>
                <span class="px-2 py-0.5 rounded-full" style="background: var(--accent-royal-soft);">${escapeHtml(d.mood)}</span>
                <span class="text-mut">${escapeHtml(d.date)}</span>
              </div>
              <div class="flex items-center gap-1.5 shrink-0"><button type="button" class="cw-retrans-item-btn btn-ghost px-2 py-0.5 rounded-full text-[10px] font-semibold whitespace-nowrap" data-rtype="diary" data-rid="${escapeHtml(d.id)}">🔄 ${state.lang === 'zh' ? '重译' : '재번역'}</button><button type="button" class="cw-share-chat-item-btn btn-ghost px-2 py-0.5 rounded-full text-[10px] font-semibold whitespace-nowrap" data-stype="diary" data-sid="${escapeHtml(d.id)}">💬 ${state.lang === 'zh' ? '发聊天' : '톡 공유'}</button>${isMyAuthoredItem(d) ? `<button type="button" class="del-diary-btn text-xs text-mut hover:text-rose-400" data-id="${escapeHtml(d.id)}">✕</button>` : ''}</div>
            </div>
            <div class="space-y-0.5">
              <h4 class="text-base font-bold leading-snug break-words">${escapeHtml(state.lang === 'zh' && d.titleTranslated && /[가-힣]/.test(d.title) ? d.titleTranslated : d.title)}</h4>
              ${d.titleTranslated ? `<div class="text-xs font-semibold text-gold break-words">${escapeHtml(state.lang === 'zh' && /[가-힣]/.test(d.title) ? d.title : d.titleTranslated)}</div>` : ''}
            </div>
            ${renderBilingualCard(d.content, d.translated, d.pronunciation, false)}
            ${d.nuance ? `<div class="text-[11px] text-mut px-1 pt-1 leading-relaxed">💎 ${escapeHtml(localizeSavedToneOrNuance(d.nuance, 'nuance'))}</div>` : ''}
            <div class="pt-2 border-t space-y-2" style="border-color: var(--border-subtle);">
              <div class="space-y-1.5">
                ${(d.comments || []).map(c => `
                  <div class="rounded-xl px-2.5 py-1.5 text-[11px]" style="background: var(--surface-2);">
                    <div class="flex items-center justify-between gap-2">
                      <span class="font-bold text-gold">${escapeHtml(c.author)}</span>
                      <div class="flex items-center gap-1.5">
                        <span class="text-[10px] text-mut">${escapeHtml(c.time || '')}</span>
                        ${isMyAuthoredItem(c) ? `<button type="button" class="del-diary-cmt-btn text-[10px] text-mut hover:text-rose-400" data-did="${escapeHtml(d.id)}" data-cid="${escapeHtml(c.id)}">✕</button>` : ''}
                      </div>
                    </div>
                    <div class="text-sec break-words mt-0.5">${escapeHtml(c.text)}</div>
                    ${c.translated ? `<div class="text-[10.5px] text-gold break-words">${escapeHtml(c.translated)}</div>` : ''}
                  </div>
                `).join('')}
              </div>
              <form class="diary-comment-form flex items-center gap-1.5" data-id="${escapeHtml(d.id)}">
                <input type="text" class="diary-comment-input royal-input flex-1 min-w-0 rounded-full px-3 py-1 text-[11px]" placeholder="${state.lang === 'zh' ? '💬 留一句评论（自动翻译）...' : '💬 한 줄 댓글 남기기 (자동 번역)...'}" />
                <button type="submit" class="btn-ghost px-2.5 py-1 rounded-full text-[11px] font-semibold shrink-0 whitespace-nowrap">${state.lang === 'zh' ? '发送' : '등록'}</button>
              </form>
            </div>
          </article>
        `).join('') : `<div class="royal-card rounded-2xl p-8 text-center text-xs text-mut">${state.lang === 'zh' ? '还没有日记，写下第一篇吧 🪶' : '작성된 일기가 없습니다. 첫 일기를 남겨보세요 🪶'}</div>`;

        document.querySelectorAll('.del-diary-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            const delId = btn.getAttribute('data-id');
            const target = state.diaries.find(x => x && x.id === delId);
            if (target && !isMyAuthoredItem(target)) {
              showToast(state.lang === 'zh' ? '只能删除自己写的日记 🔒' : '본인이 작성한 일기만 삭제할 수 있어요 🔒');
              return;
            }
            openConfirm(
              state.lang === 'zh' ? '删除日记' : '일기 삭제 확인',
              state.lang === 'zh' ? '确定要删除这篇日记吗？删除后无法恢复。' : '이 일기를 정말 삭제할까요? 삭제하면 되돌릴 수 없어요.',
              () => {
                state.diaries = state.diaries.filter(x => x.id !== delId);
                saveState(true); renderDiaryQaMemos(); renderHome();
              }
            );
          });
        });
        document.querySelectorAll('.del-diary-cmt-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            const dId = btn.getAttribute('data-did');
            const cId = btn.getAttribute('data-cid');
            const dItem = state.diaries.find(x => x && x.id === dId);
            if (!dItem || !Array.isArray(dItem.comments)) return;
            const cObj = dItem.comments.find(c => c && c.id === cId);
            if (cObj && !isMyAuthoredItem(cObj)) return;
            openConfirm(
              state.lang === 'zh' ? '删除评论' : '답글 삭제 확인',
              state.lang === 'zh' ? '确定要删除这条评论吗？' : '이 답글을 정말 삭제할까요?',
              () => {
                dItem.comments = dItem.comments.filter(c => c && c.id !== cId);
                saveState(true); renderDiaryQaMemos();
              }
            );
          });
        });
        document.querySelectorAll('.diary-comment-form').forEach(form => {
          form.addEventListener('submit', async (e) => {
            e.preventDefault();
            const inp = form.querySelector('.diary-comment-input');
            const submitBtn = form.querySelector('button[type="submit"]');
            const text = inp ? inp.value.trim() : '';
            if (!text) return;
            const item = state.diaries.find(x => x.id === form.getAttribute('data-id'));
            if (!item) return;
            inp.value = '';
            if (submitBtn) submitBtn.disabled = true;
            let translated = '';
            try {
              const res = await geminiTranslate(text, 'lover');
              if (res && res.translated) translated = res.translated;
            } catch (_) {}
            const myRole = state.myRole || 'suwan';
            const author = (myRole === 'jingchan') ? '靖灿(灿)' : '수완(完)';
            if (!Array.isArray(item.comments)) item.comments = [];
            const cmtObj = { id: `dc_${Date.now()}`, authorRole: myRole, author, text, translated, time: getKstTimeShort() };
            item.comments.push(cmtObj);
            saveState(true); renderDiaryQaMemos();
            if (typeof window.__sendChatSignal === 'function') {
              window.__sendChatSignal('comment', { targetType: 'diary', targetId: item.id, comment: cmtObj });
            }
            showToast(state.lang === 'zh' ? '💬 评论已发布' : '💬 일기 답글이 등록됐어요');
            pushNotification('💬', `${author}의 일기 답글`, `${author}评论了日记`, text, translated || text, 'diary', 'diary', 'post', false, myRole);
          });
        });

        // 2. Couple Q&A
        const q = QA_QUESTIONS[(state.chat.qaIdx || 0) % QA_QUESTIONS.length];
        document.getElementById('qaQuestionKo').textContent = q.ko;
        document.getElementById('qaQuestionZh').textContent = q.zh;

        const qaList = document.getElementById('qaHistoryList');
        qaList.innerHTML = state.chat.qaAnswers.length ? state.chat.qaAnswers.map(ans => `
          <div class="royal-card rounded-2xl p-4 space-y-2">
            <div class="flex items-center justify-between gap-2 text-[11px] text-mut">
              <span class="font-semibold text-gold">${ans.sender === 'suwan' ? '수완(完)' : '靖灿(灿)'}</span>
              <div class="flex items-center gap-2">
                <span>${escapeHtml(ans.date)}</span>
                ${isMyAuthoredItem(ans) ? `<button type="button" class="del-qa-btn hover:text-rose-400" data-id="${escapeHtml(ans.id)}">✕</button>` : ''}
              </div>
            </div>
            <div class="text-xs font-medium text-sec leading-snug space-y-0.5">
              <div>Q. ${escapeHtml(ans.questionKo)}</div>
              ${ans.questionZh ? `<div class="text-[11px] text-mut">${escapeHtml(ans.questionZh)}</div>` : ''}
            </div>
            ${renderBilingualCard(ans.original, ans.translated, ans.pronunciation, true)}
            <div class="flex justify-end"><button type="button" class="cw-retrans-item-btn btn-ghost px-2 py-0.5 rounded-full text-[10px] font-semibold whitespace-nowrap" data-rtype="qa" data-rid="${escapeHtml(ans.id)}">🔄 ${state.lang === 'zh' ? '重译' : '재번역'}</button><button type="button" class="cw-share-chat-item-btn btn-ghost px-2 py-0.5 rounded-full text-[10px] font-semibold whitespace-nowrap ml-1.5" data-stype="qa" data-sid="${escapeHtml(ans.id)}">💬 ${state.lang === 'zh' ? '发聊天' : '톡 공유'}</button></div>
            ${ans.nuance ? `<div class="nuance-box rounded-xl p-2.5 text-[11px] text-sec leading-relaxed">💎 ${escapeHtml(localizeSavedToneOrNuance(ans.nuance, 'nuance'))}</div>` : ''}
          </div>
        `).join('') : `<div class="royal-card rounded-2xl p-8 text-center text-xs text-mut">작성된 커플 문답이 없습니다. 첫 답변을 남겨보세요 💌</div>`;

        qaList.querySelectorAll('.del-qa-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            const delId = btn.getAttribute('data-id');
            openConfirm(
              state.lang === 'zh' ? '删除问答记录' : '커플 문답 삭제 확인',
              state.lang === 'zh' ? '确定要删除这条回答吗？' : '이 답변을 정말 삭제할까요?',
              () => {
                state.chat.qaAnswers = state.chat.qaAnswers.filter(x => x.id !== delId);
                saveState(true); renderDiaryQaMemos();
              }
            );
          });
        });

        // 3. Time Capsule Letters
        const today = getKstDateString();
        const cList = document.getElementById('capsuleList');
        cList.innerHTML = (state.capsules || []).length ? state.capsules.map(cap => {
          const remain = diffDays(today, cap.unlockDate);
          const unlocked = remain <= 0 || cap.forceOpened;
          return `
            <div class="royal-card rounded-3xl p-4 sm:p-5 space-y-2.5">
              <div class="flex items-center justify-between gap-2">
                <div class="flex flex-wrap items-center gap-2 text-xs">
                  <span class="font-bold text-gold">${escapeHtml(cap.author)}</span>
                  <span class="px-2 py-0.5 rounded-full text-[10px]" style="background: var(--accent-royal-soft);">${unlocked ? '🔓 봉인 해제됨' : `🔒 D-${remain} (${escapeHtml(cap.unlockDate)})`}</span>
                </div>
                ${isMyAuthoredItem(cap) ? `<button type="button" class="del-cap-btn text-xs text-mut hover:text-rose-400" data-id="${escapeHtml(cap.id)}">✕</button>` : ''}
              </div>
              <div class="space-y-0.5">
                <h4 class="text-base font-bold leading-snug break-words">${escapeHtml(cap.title)}</h4>
                ${cap.titleTranslated ? `<div class="text-xs font-semibold text-gold break-words">${escapeHtml(cap.titleTranslated)}</div>` : ''}
              </div>
              ${unlocked ? `
                ${renderBilingualCard(cap.body, cap.translated, cap.pronunciation, false)}
              ` : `
                <div class="royal-subcard rounded-2xl p-4 text-center space-y-2">
                  <div class="text-xs text-sec">💌 ${escapeHtml(cap.unlockDate)}에 로얄 왁스 봉인이 열립니다.</div>
                  <button type="button" class="open-cap-btn btn-ghost px-3 py-1.5 rounded-full text-[11px]" data-id="${escapeHtml(cap.id)}">미리 열어보기</button>
                </div>
              `}
            </div>
          `;
        }).join('') : `<div class="royal-card rounded-2xl p-8 text-center text-xs text-mut">봉인된 타임캡슐 편지가 없습니다. 미래의 우리에게 첫 편지를 남겨보세요 ⏳</div>`;

        cList.querySelectorAll('.open-cap-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            const item = state.capsules.find(x => x.id === btn.getAttribute('data-id'));
            if (item) { item.forceOpened = true; saveState(true); renderDiaryQaMemos(); showToast(state.lang === 'zh' ? '皇家火漆封印已开启 💌' : '로얄 왁스 봉인이 열렸습니다 💌'); }
          });
        });
        cList.querySelectorAll('.del-cap-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            const delId = btn.getAttribute('data-id');
            openConfirm(
              state.lang === 'zh' ? '删除时光胶囊' : '타임캡슐 삭제 확인',
              state.lang === 'zh' ? '确定要删除这封时光胶囊信件吗？' : '이 타임캡슐 편지를 정말 삭제할까요?',
              () => {
                state.capsules = state.capsules.filter(x => x.id !== delId);
                saveState(true); renderDiaryQaMemos(); renderHome();
              }
            );
          });
        });

        // 4. Memos (Unified inside 일기·메모)
        const recFilter = window.__coupleRecordFilter || 'all';
        const memoWrap = document.getElementById('memoSectionWrap');
        const mList = document.getElementById('memoList');
        if (dList) dList.classList.toggle('hidden', recFilter === 'memo');
        if (memoWrap) {
          const showMemos = recFilter === 'memo' || (recFilter === 'all' && state.memos.length > 0);
          memoWrap.classList.toggle('hidden', !showMemos);
        }
        if (mList) {
          mList.innerHTML = state.memos.length ? state.memos.map(m => `
            <div class="royal-card rounded-2xl p-3.5 space-y-2">
              <div class="space-y-2">
                <div class="flex items-center justify-between gap-2">
                  <label class="flex items-center gap-2 cursor-pointer min-w-0">
                    <input type="checkbox" class="toggle-memo-cb accent-purple-500 shrink-0" style="width:14px;height:14px;min-width:14px;" data-id="${escapeHtml(m.id)}" ${m.done ? 'checked' : ''} />
                    <span class="text-[10px] font-semibold px-2 py-0.5 rounded-full whitespace-nowrap shrink-0" style="background: var(--accent-royal-soft); color: var(--accent-royal);">${state.lang === 'zh' ? '📝 备忘' : '📝 메모'}</span>
                    ${m.author ? `<span class="text-[10px] text-mut truncate">${escapeHtml(m.author)}</span>` : ''}
                  </label>
                  <div class="flex items-center gap-1.5 shrink-0"><button type="button" class="cw-retrans-item-btn btn-ghost px-2 py-0.5 rounded-full text-[10px] font-semibold whitespace-nowrap" data-rtype="memo" data-rid="${escapeHtml(m.id)}">🔄 ${state.lang === 'zh' ? '重译' : '재번역'}</button><button type="button" class="cw-share-chat-item-btn btn-ghost px-2 py-0.5 rounded-full text-[10px] font-semibold whitespace-nowrap" data-stype="memo" data-sid="${escapeHtml(m.id)}">💬 ${state.lang === 'zh' ? '发聊天' : '톡 공유'}</button>${isMyAuthoredItem(m) ? `<button type="button" class="del-memo-btn text-xs text-mut hover:text-rose-400 shrink-0" data-id="${escapeHtml(m.id)}">✕</button>` : ''}</div>
                </div>
                <div class="min-w-0 ${m.done ? 'line-through opacity-50' : ''}">${renderBilingualCard(m.text, m.translated, m.pronunciation, true)}</div>
              </div>
              <div class="pt-1.5 border-t space-y-1.5" style="border-color: var(--border-subtle);">
                ${(m.comments || []).map(c => `
                  <div class="rounded-xl px-2.5 py-1 text-[10.5px]" style="background: var(--surface-2);">
                    <span class="font-bold text-gold">${escapeHtml(c.author)}:</span> <span class="text-sec break-words">${escapeHtml(c.text)}</span>
                    ${c.translated ? `<div class="text-gold break-words">${escapeHtml(c.translated)}</div>` : ''}
                  </div>
                `).join('')}
                <form class="memo-comment-form flex items-center gap-1.5" data-id="${escapeHtml(m.id)}">
                  <input type="text" class="memo-comment-input royal-input flex-1 min-w-0 rounded-full px-3 py-1 text-[11px]" placeholder="${state.lang === 'zh' ? '💬 留一句回复...' : '💬 메모 답글 남기기...'}" />
                  <button type="submit" class="btn-ghost px-2.5 py-1 rounded-full text-[11px] font-semibold shrink-0 whitespace-nowrap">${state.lang === 'zh' ? '发送' : '등록'}</button>
                </form>
              </div>
            </div>
          `).join('') : (recFilter === 'memo' ? `<div class="royal-card rounded-2xl p-8 text-center text-xs text-mut">${state.lang === 'zh' ? '还没有备忘录 📝' : '작성된 메모가 없습니다 📝'}</div>` : '');
        }

        document.querySelectorAll('.toggle-memo-cb').forEach(cb => {
          cb.addEventListener('change', () => {
            const item = state.memos.find(x => x.id === cb.getAttribute('data-id'));
            if (item) { item.done = cb.checked; saveState(true); renderDiaryQaMemos(); }
          });
        });
        document.querySelectorAll('.del-memo-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            const delId = btn.getAttribute('data-id');
            const target = state.memos.find(x => x && x.id === delId);
            if (target && !isMyAuthoredItem(target)) {
              showToast(state.lang === 'zh' ? '只能删除自己写的备忘录 🔒' : '본인이 작성한 메모만 삭제할 수 있어요 🔒');
              return;
            }
            openConfirm(
              state.lang === 'zh' ? '删除备忘录' : '메모 삭제 확인',
              state.lang === 'zh' ? '确定要删除这条备忘录吗？' : '이 메모를 정말 삭제할까요?',
              () => {
                state.memos = state.memos.filter(x => x.id !== delId);
                saveState(true); renderDiaryQaMemos();
              }
            );
          });
        });
        document.querySelectorAll('.memo-comment-form').forEach(form => {
          form.addEventListener('submit', async (e) => {
            e.preventDefault();
            const inp = form.querySelector('.memo-comment-input');
            const submitBtn = form.querySelector('button[type="submit"]');
            const text = inp ? inp.value.trim() : '';
            if (!text) return;
            const item = state.memos.find(x => x.id === form.getAttribute('data-id'));
            if (!item) return;
            inp.value = '';
            if (submitBtn) submitBtn.disabled = true;
            let translated = '';
            try {
              const res = await geminiTranslate(text, 'lover');
              if (res && res.translated) translated = res.translated;
            } catch (_) {}
            const myRole = state.myRole || 'suwan';
            const author = (myRole === 'jingchan') ? '靖灿(灿)' : '수완(完)';
            if (!Array.isArray(item.comments)) item.comments = [];
            const cmtObj = { id: `mc_${Date.now()}`, authorRole: myRole, author, text, translated, time: getKstTimeShort() };
            item.comments.push(cmtObj);
            saveState(true); renderDiaryQaMemos();
            if (typeof window.__sendChatSignal === 'function') {
              window.__sendChatSignal('comment', { targetType: 'memo', targetId: item.id, comment: cmtObj });
            }
            showToast(state.lang === 'zh' ? '💬 备忘录回复已发送' : '💬 메모 답글이 등록됐어요');
            pushNotification('📝', `${author}의 메모 답글`, `${author}回复了备忘录`, text, translated || text, 'diary', 'diary', 'post', false, myRole);
          });
        });
      
        if (typeof window.syncAllTabIconsToStyle === 'function') window.syncAllTabIconsToStyle(null, document.getElementById('tab-diary'));
      }

      function renderBucketAndAlbum() {
        const total = state.buckets.length;
        const done = state.buckets.filter(b => b.done).length;
        const pct = total ? Math.round((done / total) * 100) : 0;
        document.getElementById('bucketProgressText').textContent = `${done} / ${total} (${pct}%)`;
        document.getElementById('bucketProgressBar').style.width = `${pct}%`;

        document.getElementById('bucketListContainer').innerHTML = state.buckets.length ? state.buckets.map(b => `
          <div class="royal-card rounded-2xl p-3.5 flex items-center justify-between gap-3">
            <label class="flex items-start gap-3 cursor-pointer flex-1 min-w-0">
              <input type="checkbox" class="toggle-bucket-cb mt-1 accent-purple-500 shrink-0" data-id="${escapeHtml(b.id)}" ${b.done ? 'checked' : ''} />
              <div class="min-w-0 flex-1 space-y-1.5">
                <span class="inline-block text-[10px] px-2 py-0.5 rounded-full text-gold font-medium" style="background: var(--accent-royal-soft);">${escapeHtml(b.cat)}</span>
                <div class="${b.done ? 'line-through opacity-50' : ''}">${renderBilingualCard(b.text, b.translated, b.pronunciation, true)}</div>
              </div>
            </label>
            <button type="button" class="del-bucket-btn text-xs text-mut hover:text-rose-400 shrink-0" data-id="${escapeHtml(b.id)}">✕</button>
          </div>
        `).join('') : `<div class="royal-card rounded-2xl p-8 text-center text-xs text-mut">등록된 위시리스트가 없습니다. 첫 위시를 추가해 보세요 🦋</div>`;

        document.querySelectorAll('.toggle-bucket-cb').forEach(cb => {
          cb.addEventListener('change', () => {
            const item = state.buckets.find(x => x.id === cb.getAttribute('data-id'));
            if (item) {
              item.done = cb.checked; saveState(true); renderBucketAndAlbum(); renderHome();
              if (item.done) pushNotification('🦋', '위시리스트 달성!', '心愿清单已达成！', `"${item.text}" 완료!`, `已完成「${item.translated}」!`, 'diary', 'bucket', 'post', false);
            }
          });
        });
        document.querySelectorAll('.del-bucket-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            const delId = btn.getAttribute('data-id');
            openConfirm(
              state.lang === 'zh' ? '删除心愿清单' : '위시리스트 삭제 확인',
              state.lang === 'zh' ? '确定要删除这条心愿吗？' : '이 위시리스트 항목을 정말 삭제할까요?',
              () => {
                state.buckets = state.buckets.filter(x => x.id !== delId);
                saveState(true); renderBucketAndAlbum(); renderHome();
              }
            );
          });
        });

        const aGrid = document.getElementById('albumGrid');
        const allFolders = getAllAlbumFolders();
        const activeAlbumCat = window.__activeAlbumCat || 'all';
        const filterBar = document.getElementById('albumCatFilterBar');
        if (filterBar) {
          const isZh = state.lang === 'zh';
          const allCount = (state.albums || []).length;
          const renTarget = window.__renamingAlbumFolder || '';
          filterBar.innerHTML = [
            `<button type="button" class="album-cat-btn ${activeAlbumCat === 'all' ? 'btn-royal' : 'btn-ghost'} px-3 py-1 rounded-full text-[11px] font-semibold whitespace-nowrap" data-cat="all">${isZh ? '全部' : '전체'} (${allCount})</button>`,
            ...allFolders.map(f => {
              const cnt = (state.albums || []).filter(ph => (ph.category || detectPhotoCategory(ph.caption)) === f).length;
              const isSel = activeAlbumCat === f;
              return `<span class="inline-flex items-center gap-0.5 rounded-full ${isSel ? 'pr-1' : ''}" style="${isSel ? 'background: var(--accent-royal-soft);' : ''}">
                <button type="button" class="cw-keep-native-emoji album-cat-btn ${isSel ? 'btn-royal' : 'btn-ghost'} px-3 py-1 rounded-full text-[11px] font-semibold whitespace-nowrap" data-cat="${escapeHtml(f)}">${escapeHtml(f)}${cnt ? ` (${cnt})` : ''}</button>
                ${isSel ? `<button type="button" class="rename-folder-btn text-[11px] px-1 py-0.5 hover:opacity-80" data-folder="${escapeHtml(f)}" title="${isZh ? '重命名文件夹' : '폴더 이름 수정'}">✏️</button>${allFolders.length > 1 ? `<button type="button" class="del-folder-btn text-[11px] text-rose-500 px-1 py-0.5 hover:opacity-80" data-folder="${escapeHtml(f)}" title="${isZh ? '删除文件夹' : '폴더 삭제'}">✕</button>` : ''}` : ''}
              </span>`;
            }),
            renTarget ? `<div class="w-full flex items-center gap-1.5 pt-1.5"><input id="albumRenameFolderInput" type="text" class="royal-input flex-1 min-w-0 rounded-xl px-3 py-1.5 text-xs" value="${escapeHtml(renTarget)}" placeholder="${isZh ? '输入新文件夹名...' : '새 폴더 이름 입력...'}" /><button type="button" id="albumRenameSaveBtn" class="btn-royal px-3 py-1.5 rounded-xl text-xs font-bold shrink-0">${isZh ? '保存' : '저장'}</button><button type="button" id="albumRenameCancelBtn" class="btn-ghost px-2.5 py-1.5 rounded-xl text-xs shrink-0">${isZh ? '取消' : '취소'}</button></div>` : ''
          ].join('');
          filterBar.querySelectorAll('.album-cat-btn').forEach(btn => {
            btn.addEventListener('click', () => {
              window.__activeAlbumCat = btn.getAttribute('data-cat') || 'all';
              window.__renamingAlbumFolder = '';
              renderBucketAndAlbum();
            });
          });
          filterBar.querySelectorAll('.rename-folder-btn').forEach(btn => {
            btn.addEventListener('click', (ev) => {
              ev.stopPropagation();
              window.__renamingAlbumFolder = btn.getAttribute('data-folder') || '';
              renderBucketAndAlbum();
              setTimeout(() => { const ri = document.getElementById('albumRenameFolderInput'); if (ri) { ri.focus(); ri.select(); } }, 30);
            });
          });
          document.getElementById('albumRenameCancelBtn')?.addEventListener('click', () => {
            window.__renamingAlbumFolder = '';
            renderBucketAndAlbum();
          });
          document.getElementById('albumRenameSaveBtn')?.addEventListener('click', () => {
            const oldName = window.__renamingAlbumFolder || '';
            const inpR = document.getElementById('albumRenameFolderInput');
            const rawNew = (inpR && inpR.value || '').trim();
            if (!oldName || !rawNew) return;
            ensureEditableAlbumFolders();
            const newName = /^[^a-zA-Z0-9가-힣一-鿿]/.test(rawNew) ? rawNew : `📁 ${rawNew}`;
            if (newName !== oldName && state.albumFolders.includes(newName)) {
              showToast(isZh ? '已存在同名文件夹' : '같은 이름의 폴더가 이미 있어요');
              return;
            }
            const idxF = state.albumFolders.indexOf(oldName);
            if (idxF !== -1) state.albumFolders[idxF] = newName;
            (state.albums || []).forEach(ph => { if (ph && ph.category === oldName) ph.category = newName; });
            window.__activeAlbumCat = newName;
            window.__renamingAlbumFolder = '';
            state.albumFoldersUpdatedAt = Date.now();
            saveState(true);
            renderBucketAndAlbum();
            showToast(isZh ? `✏️ 文件夹已改名为「${newName}」` : `✏️ 폴더 이름을 「${newName}」(으)로 바꿨어요!`);
          });
          filterBar.querySelectorAll('.del-folder-btn').forEach(btn => {
            btn.addEventListener('click', (ev) => {
              ev.stopPropagation();
              const fname = btn.getAttribute('data-folder');
              openConfirm(
                isZh ? '删除相册文件夹' : '앨범 폴더 삭제',
                isZh ? `确定要删除「${fname}」文件夹吗？（照片会自动移至其他文件夹）` : `「${fname}」 폴더를 삭제할까요? (사진은 다른 폴더로 안전하게 이동돼요)`,
                () => {
                  ensureEditableAlbumFolders();
                  state.albumFolders = (state.albumFolders || []).filter(x => x !== fname);
                  if (!state.albumFolders.length) state.albumFolders = ['✨ 일상 순간'];
                  const fallbackFolder = state.albumFolders[0];
                  (state.albums || []).forEach(ph => { if (ph && ph.category === fname) ph.category = fallbackFolder; });
                  if (window.__activeAlbumCat === fname) window.__activeAlbumCat = 'all';
                  window.__renamingAlbumFolder = '';
                  state.albumFoldersUpdatedAt = Date.now();
                  saveState(true); renderBucketAndAlbum();
                  showToast(isZh ? `文件夹已删除（照片已移至「${fallbackFolder}」）` : `폴더를 삭제했어요 (사진은 「${fallbackFolder}」로 이동)`);
                }
              );
            });
          });
        }
        const filteredAlbums = (state.albums || []).filter(ph => {
          const c = ph.category || detectPhotoCategory(ph.caption);
          return activeAlbumCat === 'all' || c === activeAlbumCat;
        });
        if (!window.__cwAlbumVisibleCount) window.__cwAlbumVisibleCount = 16;
        const visibleAlbums = filteredAlbums.slice(0, window.__cwAlbumVisibleCount);
        const hasMoreAlbums = filteredAlbums.length > visibleAlbums.length;
        aGrid.innerHTML = visibleAlbums.length ? visibleAlbums.map(ph => {
          const catLabel = ph.category || detectPhotoCategory(ph.caption);
          return `
          <div class="royal-card rounded-2xl overflow-hidden flex flex-col">
            <div class="aspect-square overflow-hidden bg-purple-100/40 relative">
              ${ph.mediaType === 'video' ? `<video src="${__cwMediaUrl(ph.dataUrl, 'video/mp4')}" controls playsinline webkit-playsinline preload="metadata" class="w-full h-full object-cover bg-black/85"></video><a href="${__cwMediaUrl(ph.dataUrl, 'video/mp4')}" download="chanwan_album_${escapeHtml(ph.id)}.mp4" class="absolute top-1.5 right-1.5 px-1.5 py-0.5 rounded-md text-[10px] font-bold text-white" style="background: rgba(15,10,28,0.72);" title="저장">📥</a>` : `<img src="${__cwMediaUrl(ph.dataUrl)}" alt="${escapeHtml(ph.caption)}" decoding="async" class="cw-zoom-direct w-full h-full object-cover cursor-pointer" data-src="${__cwMediaUrl(ph.dataUrl)}" />`}
              <span class="cw-keep-native-emoji absolute top-1.5 left-1.5 text-[10px] font-semibold px-2 py-0.5 rounded-full" style="background: rgba(25, 16, 44, 0.72); color: #fffaf2;">${escapeHtml(catLabel)}</span>
            </div>
            <div class="p-2.5 space-y-1 flex-1 flex flex-col justify-between">
              <div class="space-y-1">
                <div class="text-xs font-semibold leading-snug break-words"><span class="text-[10px] mr-1">${/[가-힣]/.test(String(ph.caption || '')) ? '🇰🇷' : '🇨🇳'}</span>${escapeHtml(ph.caption)}</div>
                ${ph.translated && !/^\[(?:한국어|中文)\]\s*/.test(String(ph.translated)) ? `<div class="text-[11px] text-gold leading-snug break-words"><span class="text-[10px] mr-1">${/[가-힣]/.test(String(ph.caption || '')) ? '🇨🇳' : '🇰🇷'}</span>${escapeHtml(ph.translated)}</div>` : (ph.caption ? `<div class="text-[10.5px] text-mut italic">${state.lang === 'zh' ? '点击右侧 🔄 重新翻译' : '오른쪽 🔄 눌러 번역하기'}</div>` : '')}
              </div>
              <div class="pt-1">
                <select class="move-album-folder-sel royal-input w-full rounded-lg px-2 py-1 text-[10px]" data-id="${escapeHtml(ph.id)}" aria-label="폴더 이동">
                  ${allFolders.map(f => `<option value="${escapeHtml(f)}" ${f === catLabel ? 'selected' : ''}>📁 ${escapeHtml(f)}</option>`).join('')}
                </select>
              </div>
              <div class="flex items-center justify-between pt-1 text-[10px] text-mut">
                <span>${escapeHtml(ph.date)}${ph.source === 'messenger' ? ' · 💬' : ''}</span>
                <div class="flex items-center gap-1.5">
                  ${ph.caption ? `<button type="button" class="retrans-album-btn hover:text-gold transition px-1" data-id="${escapeHtml(ph.id)}" title="${state.lang === 'zh' ? '重新翻译' : '재번역'}">🔄</button>` : ''}
                  <button type="button" class="toggle-album-cmt-btn hover:text-gold font-semibold" data-id="${escapeHtml(ph.id)}">💬 ${(ph.comments || []).length}</button>
                  <button type="button" class="del-album-btn hover:text-rose-500 transition px-1" data-id="${escapeHtml(ph.id)}" title="${state.lang === 'zh' ? '删除照片' : '사진 삭제'}">🗑️</button>
                </div>
              </div>
              <div class="album-cmt-box pt-1.5 mt-1 border-t space-y-1.5" data-id="${escapeHtml(ph.id)}" style="border-color: var(--border-subtle);">
                ${(ph.comments || []).map(c => `
                  <div class="rounded-lg px-2 py-1 text-[10px]" style="background: var(--surface-2);">
                    <span class="font-bold text-gold">${escapeHtml(c.author)}:</span> <span class="break-words">${escapeHtml(c.text)}</span>
                    ${c.translated ? `<div class="text-gold break-words">${escapeHtml(c.translated)}</div>` : ''}
                  </div>
                `).join('')}
                <form class="album-comment-form flex items-center gap-1" data-id="${escapeHtml(ph.id)}">
                  <input type="text" class="album-comment-input royal-input flex-1 min-w-0 rounded-full px-2 py-1 text-[10px]" placeholder="${state.lang === 'zh' ? '评论...' : '댓글...'}" />
                  <button type="submit" class="btn-ghost px-2 py-1 rounded-full text-[10px] font-semibold shrink-0">+</button>
                </form>
              </div>
            </div>
          </div>`;
        }).join('') : `<div class="col-span-full royal-card rounded-2xl p-7 text-center text-xs text-mut space-y-3">
          <div>${state.lang === 'zh' ? '该分类暂无照片，在聊天室发照片也会自动分类保存哦 🖼️' : '해당 카테고리에 사진이 없어요. 메신저에서 사진을 보내도 자동 분류되어 저장돼요 🖼️'}</div>
          ${(state.albums || []).length === 0 ? `<div class="pt-1 space-y-1.5">
            <button type="button" class="cw-inline-vault-restore-btn btn-royal px-4 py-2 rounded-full text-xs font-bold shadow-sm">${state.lang === 'zh' ? '☁️ 从云端 · 对方手机一键恢复相册与语音' : '☁️ 서버 · 상대방 폰에서 사진·음성편지 복구하기'}</button>
            <div class="text-[10.5px] text-mut">${state.lang === 'zh' ? '若重装过 App，对方打开网页或点此即可自动找回全部照片' : '앱 재설치 후 사진이 비어 있다면, 징찬이 앱이 켜져 있을 때 누르면 직통 복구돼요'}</div>
          </div>` : ''}
        </div>`;

        if (typeof window.syncAllTabIconsToStyle === 'function') window.syncAllTabIconsToStyle(null, aGrid);
        aGrid.querySelectorAll('.cw-inline-vault-restore-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            if (typeof window.__runFullCloudDataRestore === 'function') window.__runFullCloudDataRestore(false);
          });
        });
        // Prime 3 v41: Retranslate button & auto-fix broken [한국어]/[中文] fallback captions
        document.querySelectorAll('.retrans-album-btn').forEach(btn => {
          btn.addEventListener('click', async () => {
            const pid = btn.getAttribute('data-id');
            const ph = (state.albums || []).find(x => x && x.id === pid);
            if (!ph || !ph.caption) return;
            btn.disabled = true; btn.textContent = '⏳';
            try {
              const r = await geminiTranslate(ph.caption, 'lover');
              if (r && r.translated && !/^\[(?:한국어|中文)\]\s*/.test(String(r.translated))) {
                ph.translated = r.translated;
                saveState(true);
                renderBucketAndAlbum();
                showToast(state.lang === 'zh' ? '🔄 照片说明已重新翻译' : '🔄 사진 설명을 다시 번역했어요!');
              } else {
                btn.disabled = false; btn.textContent = '🔄';
                showToast(state.lang === 'zh' ? '⚠️ 翻译暂时失败，请稍后重试' : '⚠️ 번역을 불러오지 못했어요. 잠시 후 다시 눌러주세요');
              }
            } catch (_) { btn.disabled = false; btn.textContent = '🔄'; }
          });
        });
        if (!window.__cwAlbumAutoFixIds) window.__cwAlbumAutoFixIds = new Set();
        filteredAlbums.forEach(ph => {
          if (!ph || !ph.id || !ph.caption || window.__cwAlbumAutoFixIds.has(ph.id)) return;
          const broken = !ph.translated || /^\[(?:한국어|中文)\]\s*/.test(String(ph.translated));
          if (broken) {
            window.__cwAlbumAutoFixIds.add(ph.id);
            geminiTranslate(ph.caption, 'lover').then(r => {
              if (r && r.translated && !/^\[(?:한국어|中文)\]\s*/.test(String(r.translated))) {
                ph.translated = r.translated;
                saveState(true);
                renderBucketAndAlbum();
              }
            }).catch(() => {});
          }
        });
        document.querySelectorAll('.del-album-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            const delId = btn.getAttribute('data-id');
            const isZh = state.lang === 'zh';
            openConfirm(
              isZh ? '删除相册照片' : '앨범 사진 삭제',
              isZh ? '确定要删除这张相册照片吗？删除后对方相册也会同步移除。' : '이 사진을 앨범에서 삭제할까요? 상대방 앨범에서도 함께 삭제돼요.',
              () => {
                if (!Array.isArray(state.deletedAlbumIds)) state.deletedAlbumIds = [];
                if (delId && !state.deletedAlbumIds.includes(delId)) state.deletedAlbumIds.push(delId);
                if (state.deletedAlbumIds.length > 250) state.deletedAlbumIds = state.deletedAlbumIds.slice(-250);
                try {
                  idbPut('deleted_albums_vault_v1', state.deletedAlbumIds);
                  idbPut('albums_vault_v1', (state.albums || []).filter(x => x && x.id !== delId));
                } catch (_) {}
                state.albums = (state.albums || []).filter(x => x && x.id !== delId);
                saveState(true);
                renderBucketAndAlbum();
                renderHome();
                showToast(isZh ? '🗑️ 照片已删除（已同步至对方相册）' : '🗑️ 사진이 삭제되었어요 (상대방 앨범에도 동기화돼요)');
              }
            );
          });
        });
        document.querySelectorAll('.move-album-folder-sel').forEach(sel => {
          sel.addEventListener('change', () => {
            const ph = (state.albums || []).find(x => x.id === sel.getAttribute('data-id'));
            if (!ph) return;
            ph.category = sel.value;
            ph.categoryUpdatedAt = Date.now();
            try { if (typeof persistMediaVaultsNow === 'function') persistMediaVaultsNow(true); } catch (_) {}
            saveState(true); renderBucketAndAlbum();
            showToast(state.lang === 'zh' ? `📁 已移动到「${sel.value}」` : `📁 「${sel.value}」 폴더로 이동했어요`);
          });
        });
        document.querySelectorAll('.toggle-album-cmt-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            const box = aGrid.querySelector(`.album-cmt-box[data-id="${btn.getAttribute('data-id')}"]`);
            if (box) { box.classList.toggle('hidden'); const inp = box.querySelector('input'); if (!box.classList.contains('hidden') && inp) inp.focus(); }
          });
        });
        document.querySelectorAll('.album-comment-form').forEach(form => {
          form.addEventListener('submit', async (e) => {
            e.preventDefault();
            const inp = form.querySelector('.album-comment-input');
            const submitBtn = form.querySelector('button[type="submit"]');
            const text = inp ? inp.value.trim() : '';
            if (!text) return;
            const item = state.albums.find(x => x.id === form.getAttribute('data-id'));
            if (!item) return;
            inp.value = '';
            if (submitBtn) submitBtn.disabled = true;
            let translated = '';
            try {
              const res = await geminiTranslate(text, 'lover');
              if (res && res.translated) translated = res.translated;
            } catch (_) {}
            const myRole = state.myRole || 'suwan';
            const author = (myRole === 'jingchan') ? '靖灿(灿)' : '수완(完)';
            if (!Array.isArray(item.comments)) item.comments = [];
            const cmtObj = { id: `ac_${Date.now()}`, authorRole: myRole, author, text, translated, time: getKstTimeShort() };
            item.comments.push(cmtObj);
            saveState(true); renderBucketAndAlbum();
            if (typeof window.__sendChatSignal === 'function') {
              window.__sendChatSignal('comment', { targetType: 'album', targetId: item.id, comment: cmtObj });
            }
            showToast(state.lang === 'zh' ? '🖼️ 照片评论已发布' : '🖼️ 사진 답글이 등록됐어요');
            pushNotification('🖼️', `${author}의 사진 답글`, `${author}评论了照片`, text, translated || text, 'diary', 'album', 'post', false, myRole);
          });
        });
      }

      function renderSettings() {
        const key = state.settings.geminiApiKey || '';
        applyTheme(state.theme, true);
        applyFont(state.font, true);
        applyDockFont(state.dockFont, true);
        applyFontSize(state.fontSize, true);
        updateVaultIndicators();
      }

      function openCityModal(target) {
        activeCityTarget = target;
        document.getElementById('cityModalTitle').textContent = target === 'suwan' ? '📍 수완(完) 도시 실시간 설정' : '📍 靖灿(灿) 도시 실시간 설정';
        document.getElementById('customCitySearchInput').value = '';
        const grid = document.getElementById('cityPresetGrid');
        grid.innerHTML = CITY_PRESETS.map((c, idx) => `
          <button type="button" class="city-preset-btn royal-subcard hover:border-purple-400 rounded-xl px-3 py-2 text-left text-xs transition flex items-center gap-1.5 min-w-0" data-idx="${idx}">
            <span class="shrink-0">${c.flag}</span><span class="truncate font-medium">${escapeHtml(c.name)}</span>
          </button>
        `).join('');
        grid.querySelectorAll('.city-preset-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            const c = CITY_PRESETS[Number(btn.getAttribute('data-idx'))];
            state.cities[activeCityTarget] = { ...c, updatedAt: Date.now() };
            saveState(true); renderHome(); updateClocks(); refreshBothCityWeathers();
            document.getElementById('cityModal').classList.add('hidden');
            pushNotification('📍', '도시 설정 변경', '城市设置已更新', `${activeCityTarget === 'suwan' ? '수완' : '징찬'} → ${c.name}`, `${c.name}`, 'home', '', 'post', false);
          });
        });
        document.getElementById('cityModal').classList.remove('hidden');
      }

      function compressImageToDataUrl(file, maxSize) {
        const limit = (maxSize && maxSize < 400) ? maxSize : Math.min(maxSize || 960, 960);
        const readRawDataUrl = () => new Promise((res, rej) => {
          const r = new FileReader();
          r.onload = () => res(String(r.result || ''));
          r.onerror = rej;
          r.readAsDataURL(file);
        });
        return new Promise((resolve, reject) => {
          const objUrl = (typeof URL !== 'undefined' && URL.createObjectURL) ? URL.createObjectURL(file) : '';
          const finishFromImg = (img) => {
            try {
              const canvas = document.createElement('canvas');
              let w = img.naturalWidth || img.width || 0;
              let h = img.naturalHeight || img.height || 0;
              if (!w || !h) throw new Error('zero_dim');
              if (w > limit || h > limit) {
                if (w > h) { h = Math.max(1, Math.round((h * limit) / w)); w = limit; }
                else { w = Math.max(1, Math.round((w * limit) / h)); h = limit; }
              }
              canvas.width = w;
              canvas.height = h;
              const ctx = canvas.getContext('2d');
              if (!ctx) throw new Error('no_ctx');
              ctx.drawImage(img, 0, 0, w, h);
              const __webpTest = canvas.toDataURL('image/webp', 0.82);
              const __mimeOut = (__webpTest && __webpTest.startsWith('data:image/webp')) ? 'image/webp' : 'image/jpeg';
              let out = __mimeOut === 'image/webp' ? __webpTest : canvas.toDataURL('image/jpeg', 0.82);
              if (out.length > 180000) out = canvas.toDataURL(__mimeOut, 0.72);
              if (out.length > 180000) out = canvas.toDataURL(__mimeOut, 0.60);
              if (out.length > 180000) {
                const scale = Math.min(0.72, 720 / Math.max(w, h));
                const c2 = document.createElement('canvas');
                c2.width = Math.max(1, Math.round(w * scale));
                c2.height = Math.max(1, Math.round(h * scale));
                const ctx2 = c2.getContext('2d');
                if (ctx2) {
                  ctx2.drawImage(canvas, 0, 0, c2.width, c2.height);
                  out = c2.toDataURL('image/jpeg', 0.64);
                }
              }
              if (objUrl) { try { URL.revokeObjectURL(objUrl); } catch (_) {} }
              resolve(out);
            } catch (_) {
              if (objUrl) { try { URL.revokeObjectURL(objUrl); } catch (_) {} }
              readRawDataUrl().then(resolve).catch(reject);
            }
          };
          if (objUrl) {
            const img = new Image();
            img.onload = () => finishFromImg(img);
            img.onerror = () => {
              try { URL.revokeObjectURL(objUrl); } catch (_) {}
              readRawDataUrl().then(resolve).catch(reject);
            };
            img.src = objUrl;
          } else {
            readRawDataUrl().then(raw => {
              const img = new Image();
              img.onload = () => finishFromImg(img);
              img.onerror = () => resolve(raw);
              img.src = raw;
            }).catch(reject);
          }
        });
      }

      /* ============================================================
         9. EVENT BINDINGS
         ============================================================ */
      function handleRemoteSync(incoming) {
        if (!incoming || Number(incoming.updatedAt) <= Number(state.updatedAt || 0)) return;
        state = mergeWithDefaults(incoming, state);
        renderAll();
        const latest = (state.notifications || [])[0];
        const curRole = (state && state.myRole) || 'suwan';
        if (latest && latest.unread && latest.fromRole !== curRole && latest.id !== window.__lastRemoteBannerId && latest.createdAt && (Date.now() - Number(latest.createdAt)) < 25000) {
          window.__lastRemoteBannerId = latest.id;
          showLiveBanner(latest);
        }
      }

      function bindEvents() {
        window.addEventListener('pagehide', () => saveState(false));
        document.addEventListener('visibilitychange', () => {
          if (document.visibilityState === 'hidden') {
            saveState(false);
          } else if (document.visibilityState === 'visible') {
            try { clearAllAppBadgesAndOsNotifs(); } catch (_) {}
            if (typeof window.__pullFastChatDeltaNow === 'function') window.__pullFastChatDeltaNow(false);
          }
        });

        if (liveChannel) {
          liveChannel.onmessage = (e) => { if (e.data && e.data.type === 'SYNC_STATE') handleRemoteSync(e.data.core); };
        }
        window.addEventListener('storage', (e) => {
          if (e.key === STORAGE_CORE_KEY && e.newValue) {
            try { handleRemoteSync(JSON.parse(e.newValue)); } catch (_) {}
          }
        });

        document.body.addEventListener('click', (e) => {
          const speakBtn = e.target.closest('.speak-btn');
          if (speakBtn) { speakText(speakBtn.getAttribute('data-text'), speakBtn.getAttribute('data-lang'), speakBtn.getAttribute('data-slow') === '1'); return; }
          const recBtn = e.target.closest('.rec-voice-btn');
          if (recBtn) { toggleRecordCustomVoice(recBtn.getAttribute('data-text'), recBtn); return; }
          const delVBtn = e.target.closest('.del-voice-btn');
          if (delVBtn) {
            const vTxt = delVBtn.getAttribute('data-text');
            openConfirm(
              state.lang === 'zh' ? '删除原声录音' : '더빙 목소리 삭제',
              state.lang === 'zh' ? '确定要删除这段原声录音吗？' : '이 더빙 목소리를 삭제할까요?',
              () => deleteCustomVoice(vTxt)
            );
            return;
          }
          if (e.target.closest('#vrCloseBtn') || e.target.closest('#vrCancelBtn')) { closeVoiceRecorderModal(); return; }
          if (e.target.closest('#homeDDayCardBtn')) { switchTab('anniversary'); return; }
          const copyBtn = e.target.closest('.copy-btn');
          if (copyBtn) { copyText(copyBtn.getAttribute('data-text')); return; }
          const nRetransBtn = e.target.closest('.nuance-retrans-btn');
          if (nRetransBtn) {
            const origT = nRetransBtn.getAttribute('data-orig');
            const prevEng = nRetransBtn.getAttribute('data-engine') || '';
            const container = nRetransBtn.closest('#homeTransResult, #studioTransOutput');
            if (origT && container) {
              nRetransBtn.disabled = true;
              nRetransBtn.textContent = state.lang === 'zh' ? '重译中...' : '재번역 중...';
              translateWithAutoRetry(origT, activeToneMode || 'lover', prevEng || 'Google').then(newR => {
                if (newR) {
                  container.innerHTML = renderNuanceCardHtml(newR);
                  if (typeof window.syncAllTabIconsToStyle === 'function') window.syncAllTabIconsToStyle(localStorage.getItem('chanwan_icon_style_v1') || 'pastel');
                }
              }).catch(() => { nRetransBtn.disabled = false; });
            }
            return;
          }

          const panel = document.getElementById('notifPanel');
          const bell = document.getElementById('notifBellBtn');
          if (panel && !panel.classList.contains('hidden') && !panel.contains(e.target) && !bell.contains(e.target)) {
            panel.classList.add('hidden'); document.getElementById('notifBackdrop')?.classList.add('hidden');
          }
        });

        // Notifications + OS Background System Banner Permission
        const setNotifPanelOpen = (open) => {
          const panel = document.getElementById('notifPanel');
          const bd = document.getElementById('notifBackdrop');
          if (panel) panel.classList.toggle('hidden', !open);
          if (bd) bd.classList.toggle('hidden', !open);
        };
        window.__closeNotifPanel = () => setNotifPanelOpen(false);
        const notifBdEl = document.getElementById('notifBackdrop');
        if (notifBdEl) {
          notifBdEl.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            setNotifPanelOpen(false);
          });
        }
        document.getElementById('notifBellBtn').addEventListener('click', () => {
          const panel = document.getElementById('notifPanel');
          const willOpen = panel.classList.contains('hidden');
          setNotifPanelOpen(willOpen);
          if (willOpen && Array.isArray(state.notifications) && state.notifications.some(n => n && n.unread)) {
            state.notifications.forEach(n => { if (n) n.unread = false; });
            saveState(false);
            renderNotifications();
          }
        });

        const pushChInp = document.getElementById('mobilePushChannelInput');
        const pushChBtn = document.getElementById('saveMobilePushBtn');
        if (pushChInp) {
          const myR = (state && state.myRole) || 'suwan';
          const defRoom = (typeof getSyncRoomCode === 'function' ? getSyncRoomCode() : '') || 'chanwan-suwan-jingchan-live2026';
          if (state.settings && state.settings.mobilePushChannel) pushChInp.value = state.settings.mobilePushChannel;
          pushChInp.placeholder = `${defRoom}-${myR}`;
        }
        if (pushChBtn && pushChInp) {
          pushChBtn.addEventListener('click', () => {
            const clean = pushChInp.value.trim().replace(/[^a-zA-Z0-9_-]/g, '');
            pushChInp.value = clean;
            if (!state.settings) state.settings = {};
            state.settings.mobilePushChannel = clean;
            saveState();
            if (clean) {
              fireSystemNotification('灿完时光', state.lang === 'zh' ? '手机横幅推送通道已连接 ✨' : '휴대폰 배너 푸시 채널이 연결되었어요 ✨');
              showToast(state.lang === 'zh' ? `📱 已绑定推送频道：${clean}` : `📱 휴대폰 푸시 채널 저장됨: ${clean}`);
            } else {
              showToast(state.lang === 'zh' ? '已关闭手机远程推送通道' : '휴대폰 원격 푸시 채널이 해제되었어요.');
            }
          });
        }

        const sSoundCbEl = document.getElementById('settingsSoundToggle');
        if (sSoundCbEl) {
          sSoundCbEl.addEventListener('change', () => {
            state.soundEnabled = sSoundCbEl.checked;
            saveState();
            updateSysNotifStatus();
            const sndBtn = document.getElementById('toggleSoundBtn');
            if (sndBtn) sndBtn.textContent = state.soundEnabled ? (state.lang === 'zh' ? '🔔提示音 开' : '🔔음 ON') : (state.lang === 'zh' ? '🔕提示音 关' : '🔕음 OFF');
            if (state.soundEnabled) playGentleChime();
          });
        }

        document.getElementById('enableSysNotifBtn').addEventListener('click', async () => {
          if (!('Notification' in window)) { showToast(state.lang === 'zh' ? '当前浏览器不支持系统通知' : '이 브라우저는 시스템 알림을 지원하지 않습니다.'); return; }
          try {
            const perm = await Notification.requestPermission();
            updateSysNotifStatus();
            if (perm === 'granted') {
              playGentleChime();
              fireSystemNotification('灿完时光', '이제 다른 탭을 보는 중에도 새글·하트 알림이 배너로 울립니다.');
              showToast(state.lang === 'zh' ? '已开启系统横幅通知 🔔' : '시스템 배너 알림이 허용되었습니다 🔔');
            } else {
              showToast(state.lang === 'zh' ? '未授予通知权限' : '알림 권한이 허용되지 않았습니다.');
            }
          } catch (_) {
            showToast(state.lang === 'zh' ? '当前预览环境可能限制浏览器权限弹窗' : '현재 미리보기 환경에서는 브라우저 권한 창이 제한될 수 있습니다.');
          }
        });
        document.getElementById('liveNotifBannerBtn').addEventListener('click', () => {
          const b = document.getElementById('liveNotifBanner');
          b.style.opacity = '0';
          b.style.transform = 'translate(-50%, -135%)';
          b.classList.add('pointer-events-none');
          navigateToRoute(lastLiveRoute.tab, lastLiveRoute.sub);
        });
        document.getElementById('toggleSoundBtn').addEventListener('click', () => { state.settings.notifSound = !state.settings.notifSound; saveState(); renderNotifications(); });
        document.querySelectorAll('.notif-filter-btn').forEach(btn => btn.addEventListener('click', () => { activeNotifFilter = btn.getAttribute('data-filter'); renderNotifications(); }));
        const _marBtn = document.getElementById('markAllReadBtn'); if (_marBtn) _marBtn.addEventListener('click', () => { (state.notifications || []).forEach(n => { n.unread = false; }); saveState(false); renderNotifications(); clearAllAppBadgesAndOsNotifs(); });
        document.getElementById('clearNotifsBtn')?.addEventListener('click', () => { state.notifications = []; saveState(false); renderNotifications(); clearAllAppBadgesAndOsNotifs(); showToast(state.lang === 'zh' ? '通知已清空 ✨' : '알림창을 비웠어요 ✨'); });
        document.addEventListener('visibilitychange', () => {
          if (!document.hidden) {
            const _myR2 = (state && state.myRole) || 'suwan';
            const _uCnt2 = (Array.isArray(state && state.notifications) ? state.notifications : []).filter(n => n && n.unread && n.fromRole !== _myR2).length;
            const __onChatNow = document.getElementById('tab-translator')?.classList.contains('active');
            if (__onChatNow && Array.isArray(state.notifications)) {
              let __cVis = false;
              state.notifications.forEach(n => { if (n && n.unread && (n.tab === 'translator' || n.category === 'chat' || n.category === 'mood' || !n.tab)) { n.unread = false; __cVis = true; } });
              if (__cVis) { try { renderNotifications(); saveState(false); } catch (_) {} }
            }
            if (_uCnt2 === 0 || __onChatNow) clearAllAppBadgesAndOsNotifs();
          }
        });

        document.getElementById('sendLivePingBtn').addEventListener('click', () => {
          const role = state.myRole || 'suwan';
          const sender = role === 'suwan' ? '수완(完)' : '靖灿(灿)';
          pushNotification('💌', `${sender}의 실시간 하트 알림`, `${sender}发来实时心动提醒`, '지금 네 생각이 나서 하트를 보냈어 💜', '刚刚想到你，给你发了一颗爱心 💜', 'translator', 'messenger', 'post', false, role);
          showToast(state.lang === 'zh' ? '💌 已发送心动提醒！' : '💌 하트 알림을 보냈어요!');
          document.getElementById('notifPanel')?.classList.add('hidden'); document.getElementById('notifBackdrop')?.classList.add('hidden');
        });

        // Designer's Signature Features: Heartbeat & Couple Date Roulette
        const goLearnEl = document.getElementById('homeGoLearnBtn');
        if (goLearnEl) goLearnEl.addEventListener('click', () => switchTab('learn'));

        document.getElementById('heartbeatBtn').addEventListener('click', () => {
          try { const who = (state.myRole === 'jingchan') ? '靖灿' : '수완'; sendPartnerNativePush(`💓 ${who}님이 하트비트를 보냈어요`, '지금 보고 싶어요 💜'); } catch (_) {}
          const hbToday = getKstDateString();
          if (!state.heartResetDate || diffDays(state.heartResetDate, hbToday) >= 3) {
            state.heartCount = 0;
            state.heartResetDate = hbToday;
          }
          state.heartCount = (state.heartCount || 0) + 1;
          if (typeof addLavenderBonusXp === 'function') addLavenderBonusXp('heartbeat', 5);
          const icon = document.getElementById('heartbeatIcon');
          icon.classList.remove('heart-pop');
          void icon.offsetWidth;
          icon.classList.add('heart-pop');
          saveState(true); renderHome();
          const hbRole = state.myRole || 'suwan';
          const hbName = hbRole === 'suwan' ? '수완(完)' : '靖灿(灿)';
          pushNotification('💓', `${hbName}의 보고 싶어 하트!`, `${hbName}发来想你的心跳！`, `누적 ${state.heartCount}번째 마음을 보냈어 💜`, `已发送第 ${state.heartCount} 次心动 💜`, 'home', '', 'post', false, hbRole);
          showToast(state.lang === 'zh' ? `💓 已发送第 ${state.heartCount} 次心动！` : `💓 ${state.heartCount}번째 마음을 보냈어요!`);
        });

        document.getElementById('dateRouletteBtn').addEventListener('click', () => {
          const pick = DATE_ROULETTE_IDEAS[Math.floor(Math.random() * DATE_ROULETTE_IDEAS.length)];
          const primaryLine = state.lang === 'zh' ? pick.zh : pick.ko;
          const secondaryLine = state.lang === 'zh' ? pick.ko : pick.zh;
          const el = document.getElementById('dateRouletteText');
          if (el) {
            el.innerHTML = `<div class="font-semibold text-[11.5px] leading-snug break-words">${escapeHtml(primaryLine)}</div><div class="text-[10.5px] text-mut leading-snug break-words">${escapeHtml(secondaryLine)}</div>`;
          }
          showToast(primaryLine);
        });

        // Language, Dock Tabs, Themes, Fonts
        document.getElementById('langToggleBtn').addEventListener('click', () => applyLanguage(state.lang === 'ko' ? 'zh' : 'ko', false));
        document.querySelectorAll('.dock-item').forEach(btn => btn.addEventListener('click', () => switchTab(btn.getAttribute('data-tab'))));

        const hdrRefBtn = document.getElementById('headerRefreshBtn');
        if (hdrRefBtn) {
          hdrRefBtn.addEventListener('click', () => {
            const ic = document.getElementById('headerRefreshIcon');
            if (ic) ic.style.transform = 'rotate(360deg)';
            try { saveState(false); } catch (_) {}
            try { if (typeof window.__pullCloudSync === 'function') window.__pullCloudSync(true); } catch (_) {}
            showToast(state.lang === 'zh' ? '🔄 正在同步并刷新应用...' : '🔄 최신 상태로 새로고침 중...');
            setTimeout(() => {
              try { location.reload(); } catch (_) { if (ic) ic.style.transform = ''; }
            }, 480);
          });
        }

        document.getElementById('cycleThemeBtn').addEventListener('click', () => {
          const idx = THEMES.findIndex(t => t.id === state.theme);
          applyTheme(THEMES[(idx + 1) % THEMES.length].id, false);
        });
        document.querySelectorAll('.theme-choice-btn').forEach(btn => btn.addEventListener('click', () => applyTheme(btn.getAttribute('data-theme-choice'), false)));


        document.querySelectorAll('.font-choice-btn').forEach(btn => btn.addEventListener('click', () => applyFont(btn.getAttribute('data-font-choice'), false)));
        document.querySelectorAll('.dockfont-choice-btn').forEach(btn => btn.addEventListener('click', () => applyDockFont(btn.getAttribute('data-dockfont-choice'), false)));
        document.querySelectorAll('.fontsize-btn').forEach(btn => btn.addEventListener('click', () => applyFontSize(btn.getAttribute('data-size'), false)));

        // City Modal
        const cModal = document.getElementById('cityModal');
        document.getElementById('editCitySuwanBtn').addEventListener('click', () => openCityModal('suwan'));
        document.getElementById('editCityJingchanBtn').addEventListener('click', () => openCityModal('jingchan'));
        document.getElementById('closeCityModal').addEventListener('click', () => cModal.classList.add('hidden'));
        cModal.addEventListener('click', (e) => { if (e.target === cModal) cModal.classList.add('hidden'); });

        document.getElementById('cityGpsBtn').addEventListener('click', () => {
          if (!navigator.geolocation) { showToast(state.lang === 'zh' ? '当前浏览器不支持 GPS 定位' : '이 브라우저에서는 GPS 위치를 지원하지 않습니다.'); return; }
          showToast(state.lang === 'zh' ? '正在获取当前位置...' : '현재 위치 확인 중...');
          navigator.geolocation.getCurrentPosition((pos) => {
            const lat = Number(pos.coords.latitude.toFixed(4));
            const lon = Number(pos.coords.longitude.toFixed(4));
            const tz = Intl.DateTimeFormat().resolvedOptions().timeZone || 'Asia/Seoul';
            state.cities[activeCityTarget] = { name: `현재 위치 (${lat}, ${lon})`, flag: '📡', lat, lon, tz, updatedAt: Date.now() };
            saveState(true); renderHome(); updateClocks(); refreshBothCityWeathers();
            cModal.classList.add('hidden'); showToast(state.lang === 'zh' ? '已设为实时 GPS 位置 📡' : '실시간 GPS 위치로 설정되었습니다 📡');
          }, () => {
            showToast(state.lang === 'zh' ? '无法使用定位权限，请在下方直接搜索城市' : '위치 권한을 사용할 수 없습니다. 아래에서 도시를 직접 검색해 주세요.');
          }, { timeout: 6000 });
        });

        document.getElementById('customCitySearchBtn').addEventListener('click', async () => {
          const q = document.getElementById('customCitySearchInput').value.trim();
          if (!q) { showToast(state.lang === 'zh' ? '请输入要搜索的城市名称' : '검색할 도시 이름을 입력해 주세요.'); return; }
          try {
            const ctrl = new AbortController();
            const t = setTimeout(() => ctrl.abort(), 5000);
            const res = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(q)}&count=1&language=ko&format=json`, { signal: ctrl.signal });
            clearTimeout(t);
            const hit = (await res.json())?.results?.[0];
            if (hit) {
              const label = hit.country ? `${hit.name} · ${hit.country}` : hit.name;
              state.cities[activeCityTarget] = { name: label, flag: '🌍', lat: hit.latitude, lon: hit.longitude, tz: hit.timezone || 'Asia/Seoul', updatedAt: Date.now() };
              saveState(true); renderHome(); updateClocks(); refreshBothCityWeathers();
              cModal.classList.add('hidden');
              pushNotification('📍', '직접 도시 설정 완료', '自定义城市已更新', `${label} 실시간 날씨·시간 연동됨`, `${label} 实时天气与时间已同步`, 'home', '', 'post', false);
              return;
            }
          } catch (_) {}
          const tz = document.getElementById('customCityTzSelect').value;
          state.cities[activeCityTarget] = { name: q, flag: '📍', lat: null, lon: null, tz, updatedAt: Date.now() };
          saveState(true); renderHome(); updateClocks(); refreshBothCityWeathers();
          cModal.classList.add('hidden'); showToast(state.lang === 'zh' ? `已手动设置城市“${q}”` : `"${q}" 도시가 직접 설정되었습니다.`);
        });

        document.getElementById('customCityManualBtn').addEventListener('click', () => {
          const q = document.getElementById('customCitySearchInput').value.trim();
          if (!q) { showToast(state.lang === 'zh' ? '请先输入城市名称' : '도시 이름을 먼저 입력해 주세요.'); return; }
          const tz = document.getElementById('customCityTzSelect').value;
          state.cities[activeCityTarget] = { name: q, flag: '📍', lat: null, lon: null, tz, updatedAt: Date.now() };
          saveState(true); renderHome(); updateClocks(); refreshBothCityWeathers();
          cModal.classList.add('hidden'); showToast(state.lang === 'zh' ? `已设置城市“${q}”` : `"${q}" 도시가 설정되었습니다.`);
        });

        // Custom Mood Modal
        const mModal = document.getElementById('customMoodModal');
        const openMoodModal = (target) => {
          const myR = state.myRole || 'suwan';
          if (target !== myR) {
            showToast(state.lang === 'zh' ? '只能修改自己的心情状态 🔒' : '기분 상태는 본인만 변경할 수 있어요 🔒');
            return;
          }
          activeMoodTarget = target;
          document.getElementById('customMoodModalTitle').textContent = target === 'suwan' ? '✏️ 수완(完) 기분 직접 입력' : '✏️ 靖灿(灿) 기분 직접 입력';
          document.getElementById('customMoodInput').value = target === 'suwan' ? state.profile.suwanMood : state.profile.jingchanMood;
          mModal.classList.remove('hidden');
        };
        document.getElementById('suwanCustomMoodBtn')?.addEventListener('click', () => openMoodModal('suwan'));
        document.getElementById('jingchanCustomMoodBtn')?.addEventListener('click', () => openMoodModal('jingchan'));
        document.getElementById('closeCustomMoodModal').addEventListener('click', () => mModal.classList.add('hidden'));
        document.getElementById('cancelCustomMoodBtn').addEventListener('click', () => mModal.classList.add('hidden'));
        document.getElementById('saveCustomMoodBtn').addEventListener('click', async () => {
          const myR = state.myRole || 'suwan';
          if (activeMoodTarget !== myR) { mModal.classList.add('hidden'); return; }
          const val = document.getElementById('customMoodInput').value.trim();
          if (!val) return;
          const setMoodVal = (v) => {
            const nowM = Date.now();
            if (activeMoodTarget === 'suwan') { state.profile.suwanMood = v; state.profile.suwanMoodUpdatedAt = nowM; }
            else { state.profile.jingchanMood = v; state.profile.jingchanMoodUpdatedAt = nowM; }
            try { localStorage.setItem('cw_my_mood_guard_v1', JSON.stringify({ role: activeMoodTarget, mood: v, ts: nowM })); } catch (_) {}
          };
          setMoodVal(val);
          try { localStorage.setItem('cw_my_mood_updated_at_v1', String(Date.now())); } catch (_) {}
          saveState(true); renderHome(); mModal.classList.add('hidden');
          // Auto-translate custom mood to bilingual "KO · ZH" so language switching shows Chinese/Korean!
          if (!val.includes(' · ') && typeof geminiTranslate === 'function') {
            try {
              const res = await geminiTranslate(val, 'lover');
              if (res && res.translated && res.translated !== val) {
                const isInputZh = /[\u4e00-\u9fff]/.test(val) && !/[가-힣]/.test(val);
                const bilingual = isInputZh ? `${res.translated} · ${val}` : `${val} · ${res.translated}`;
                setMoodVal(bilingual);
                saveState(true); renderHome();
              }
            } catch (_) {}
          }
        });

        document.getElementById('suwanMoodSelect').addEventListener('change', (e) => {
          if ((state.myRole || 'suwan') !== 'suwan') {
            renderHome();
            showToast(state.lang === 'zh' ? '只能修改自己的心情状态 🔒' : '기분 상태는 본인만 변경할 수 있어요 🔒');
            return;
          }
          if (e.target.value === '__custom__') {
            e.target.value = state.profile.suwanMood || MOOD_PRESETS[0];
            openMoodModal('suwan');
            return;
          }
          const __nowSwM = Date.now();
          state.profile.suwanMood = e.target.value;
          state.profile.suwanMoodUpdatedAt = __nowSwM;
          try {
            localStorage.setItem('cw_my_mood_updated_at_v1', String(__nowSwM));
            localStorage.setItem('cw_my_mood_guard_v1', JSON.stringify({ role: 'suwan', mood: e.target.value, ts: __nowSwM }));
          } catch (_) {}
          saveState(true); renderHome();
          pushNotification('💜', '수완의 기분 변경', '秀完更新了心情', state.profile.suwanMood, state.profile.suwanMood, 'home', '', 'post', false, 'suwan');
          try { if (typeof sendPartnerNativePush === 'function') sendPartnerNativePush('기분 변경', String(state.profile.suwanMood || '').split('·').pop().trim() || state.profile.suwanMood); } catch (_) {}
        });
        document.getElementById('jingchanMoodSelect').addEventListener('change', (e) => {
          if ((state.myRole || 'suwan') !== 'jingchan') {
            renderHome();
            showToast(state.lang === 'zh' ? '只能修改自己的心情状态 🔒' : '기분 상태는 본인만 변경할 수 있어요 🔒');
            return;
          }
          if (e.target.value === '__custom__') {
            e.target.value = state.profile.jingchanMood || MOOD_PRESETS[0];
            openMoodModal('jingchan');
            return;
          }
          const __nowJcM = Date.now();
          state.profile.jingchanMood = e.target.value;
          state.profile.jingchanMoodUpdatedAt = __nowJcM;
          try {
            localStorage.setItem('cw_my_mood_updated_at_v1', String(__nowJcM));
            localStorage.setItem('cw_my_mood_guard_v1', JSON.stringify({ role: 'jingchan', mood: e.target.value, ts: __nowJcM }));
          } catch (_) {}
          saveState(true); renderHome();
          pushNotification('🌸', '징찬의 기분 변경', '靖灿更新了心情', state.profile.jingchanMood, state.profile.jingchanMood, 'home', '', 'post', false, 'jingchan');
          try { if (typeof sendPartnerNativePush === 'function') sendPartnerNativePush('기분 변경', String(state.profile.jingchanMood || '').split('·')[0].trim() || state.profile.jingchanMood); } catch (_) {}
        });

        // Gentle bilingual status/mood reminder toast when user hasn't updated status for 3+ hours
        (function setupStatusUpdateReminderToast() {
          const MOOD_TS_KEY = 'cw_my_mood_updated_at_v1';
          const NUDGE_TS_KEY = 'cw_mood_nudge_ts_v1';
          const STALE_MS = 3 * 60 * 60 * 1000; // 3 hours
          function checkAndNudgeStatusUpdate() {
            try {
              if (document.hidden) return;
              const now = Date.now();
              const lastMood = Number(localStorage.getItem(MOOD_TS_KEY) || 0);
              const lastNudge = Number(localStorage.getItem(NUDGE_TS_KEY) || 0);
              if (lastNudge && (now - lastNudge) < STALE_MS) return;
              if (!lastMood || (now - lastMood) >= STALE_MS) {
                localStorage.setItem(NUDGE_TS_KEY, String(now));
                const isZh = state.lang === 'zh';
                showToast(
                  isZh
                    ? '💜 现在在做什么呢？记得更新一下主页状态栏哦 ✨'
                    : '💜 지금 뭐 하고 있어요? 홈 상태창을 살짝 업데이트해 주세요 ✨',
                  3800
                );
              }
            } catch (_) {}
          }
          setTimeout(checkAndNudgeStatusUpdate, 3600);
          document.addEventListener('visibilitychange', () => {
            if (!document.hidden) setTimeout(checkAndNudgeStatusUpdate, 1800);
          });
        })();

        // Avatars
        const avatarInput = document.getElementById('avatarFileInput');
        document.getElementById('avatarSuwanBtn').addEventListener('click', () => { activeAvatarTarget = 'suwan'; avatarInput.click(); });
        document.getElementById('avatarJingchanBtn').addEventListener('click', () => { activeAvatarTarget = 'jingchan'; avatarInput.click(); });
        avatarInput.addEventListener('change', async (e) => {
          const file = e.target.files && e.target.files[0];
          if (!file) return;
          try {
            const url = await compressImageToDataUrl(file, 260);
            if (activeAvatarTarget === 'suwan') state.profile.suwanAvatar = url;
            else state.profile.jingchanAvatar = url;
            saveState(true); renderHome(); renderChat();