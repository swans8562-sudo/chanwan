        if (/(미안|죄송|잘못|对不起|抱歉|错了)/.test(combined)) {
          return {
            toneKo: '🙏 진심 어린 사과', toneZh: '🙏 真诚致歉',
            nuanceKo: `상대방의 마음을 살피며 미안함을 솔직히 전하는 ${styleKo}이에요.`,
            nuanceZh: `顾及对方感受、真诚表达歉意的${styleZh}。`
          };
        }
        if (/(고마|감사|고맙|덕분|谢谢|感谢|辛苦了)/.test(combined)) {
          return {
            toneKo: '🌷 따뜻한 감사', toneZh: '🌷 真心感谢',
            nuanceKo: `진심을 담아 고마움을 표현하는 따뜻한 ${styleKo}이에요.`,
            nuanceZh: `饱含心意、温暖道谢的${styleZh}。`
          };
        }
        if (/(예쁘|예뻐|멋지|멋져|귀여|귀엽|최고|잘했|대단|漂亮|帅|可爱|棒|厉害)/.test(combined)) {
          return {
            toneKo: '✨ 달콤한 칭찬', toneZh: '✨ 甜蜜夸奖',
            nuanceKo: `상대방을 기분 좋게 띄워주는 애정 가득한 ${styleKo} 칭찬이에요.`,
            nuanceZh: `充满爱意与欣赏、哄对方开心的${styleZh}夸奖。`
          };
        }
        if (isPlayful) {
          return {
            toneKo: '😄 유쾌한 장난', toneZh: '😄 轻松打趣',
            nuanceKo: `웃음기가 섞인 가볍고 유쾌한 ${styleKo} 장난이에요.`,
            nuanceZh: `带着笑意、轻松俏皮的${styleZh}互动。`
          };
        }
        if (/(뭐해|뭐 해|어디야|어디|몇 시|몇시|언제|집에|퇴근|도착|干嘛|在哪|几点|回家|下班|到了)/.test(combined)) {
          return {
            toneKo: '💬 친근한 안부', toneZh: '💬 亲切近况',
            nuanceKo: `지금 뭐 하고 있는지 궁금해서 편하게 말을 거는 ${styleKo} 질문이에요.`,
            nuanceZh: `好奇对方当下动态、拉近距离的${styleZh}问候。`
          };
        }
        if (/^(알았어|알겠어|응+|웅+|오케이|ㅇㅋ|ㅇㅇ|그랭|그래|구래|좋아|조아|知道了|好的|好哒|嗯嗯|明白|收到)[.!~?？,，。\s]*(오빠|자기야|欧巴|哥哥|宝贝|亲爱的)?[.!~?？,，。\s]*$/.test(raw)) {
          return {
            toneKo: isCute ? '🎀 다정한 대답 · 애교' : '💬 다정한 대답',
            toneZh: isCute ? '🎀 温柔乖巧回应' : '💬 温柔回应',
            nuanceKo: `상대방의 말을 부드럽게 받아들이고 공감하는 ${styleKo} 대답이에요.`,
            nuanceZh: `温柔回应并顺从对方心意的${styleZh}表达。`
          };
        }
        if (/(최고|대박|짱|축하|예뻐|이뻐|귀여워|귀여웡|잘했어|멋져|천재|厉害|太棒了|真棒|好看|可爱|恭喜|真厉害)/.test(combined)) {
          return {
            toneKo: '🌟 칭찬 · 설렘', toneZh: '🌟 夸奖 · 开心',
            nuanceKo: `상대방을 기분 좋게 칭찬하고 응원하는 밝은 ${styleKo}이에요.`,
            nuanceZh: `由衷夸奖与鼓励对方的温暖${styleZh}。`
          };
        }
        if (/(서운|흥|시러|시렁|안 놀아|왜 안|삐졌|질투|哼|不理你|委屈|吃醋|生气了)/.test(combined)) {
          return {
            toneKo: '🥺 귀여운 투정 · 서운함', toneZh: '🥺 撒娇委屈',
            nuanceKo: `관심과 애정을 바라며 살짝 투정 부리는 귀여운 ${styleKo}이에요.`,
            nuanceZh: `带着一点小委屈、想让对方哄哄的撒娇${styleZh}。`
          };
        }
        if (/(만나|보자|갈게|데이트|여행|약속|같이 가|몇 시|见面|约会|去找你|一起去|什么时候见)/.test(combined)) {
          return {
            toneKo: '💌 설레는 약속 · 계획', toneZh: '💌 甜蜜约定',
            nuanceKo: `함께할 시간을 기대하며 이야기를 나누는 ${styleKo}이에요.`,
            nuanceZh: `期待彼此相聚与安排计划的甜蜜${styleZh}。`
          };
        }
        if (isPlayful && !isQuestion) {
          return {
            toneKo: '😆 장난 · 유쾌함', toneZh: '😆 俏皮开心',
            nuanceKo: `웃으며 가볍게 장난치듯 분위기를 띄우는 유쾌한 ${styleKo}이에요.`,
            nuanceZh: `轻松逗趣、带着笑意的俏皮${styleZh}。`
          };
        }
        if (/^(안녕|하이|ㅎㅇ|잘\s*가|잘\s*갔다와|조심해서\s*가|嗨|你好|路上小心|注意安全)/.test(raw)) {
          return {
            toneKo: '👋 다정한 인사', toneZh: '👋 温柔问候',
            nuanceKo: `상대방을 반갑게 부르거나 안부를 전하는 다정한 ${styleKo} 인사예요.`,
            nuanceZh: `亲切打招呼或叮嘱平安的温柔${styleZh}。`
          };
        }
        if (/(출근|퇴근|도착|가게|영업|마감|종료|병원|진료|결과|회사|집에|오늘|내일|며칠|주말|闭店|营业|最后一天|上班|下班|到家|医院|检查|今天|明天|这几天)/.test(combined) && !isQuestion) {
          return {
            toneKo: '🗓️ 일상 소식 · 공유', toneZh: '🗓️ 日常分享',
            nuanceKo: `오늘 있었던 일이나 일정·근황을 편하게 들려주는 ${styleKo}이에요.`,
            nuanceZh: `自然向对方分享近况、安排或日常动态的${styleZh}。`
          };
        }
        if (isCute) {
          return {
            toneKo: '🎀 애교 섞인 말투', toneZh: '🎀 撒娇语气',
            nuanceKo: `부드러운 끝음과 애교가 살짝 묻어나는 귀여운 ${styleKo}이에요.`,
            nuanceZh: `语尾轻柔、略带撒娇感的可爱${styleZh}。`
          };
        }
        if (isQuestion) {
          return {
            toneKo: '❓ 다정한 질문', toneZh: '❓ 温柔提问',
            nuanceKo: `상대방의 생각이나 상황을 자연스럽게 묻는 ${styleKo} 질문이에요.`,
            nuanceZh: `自然询问对方想法或情况的${styleZh}提问。`
          };
        }
        if (/(괜찮|안심|약|병원|수술|결석|아프지|건강|나았|没事|不疼|吃药|医院|结石|手术|安心|保重)/.test(combined)) {
          return {
            toneKo: '🌿 안심 · 건강 챙김', toneZh: '🌿 安心 · 关心健康',
            nuanceKo: `상대방의 건강을 챙기거나 안심시키는 따뜻한 ${styleKo}이에요.`,
            nuanceZh: `关心对方身体状况、让人安心的温柔${styleZh}。`
          };
        }
        if (/(일중|일하|가게|매장|회사|출근|퇴근|바빠|양도|폐점|工作|店里|闭店|上班|下班|忙|转让)/.test(combined)) {
          return {
            toneKo: '💼 일과 · 근황 공유', toneZh: '💼 工作 · 近况分享',
            nuanceKo: `지금 일과나 가게·업무 상황을 차분하게 전하는 ${styleKo}이에요.`,
            nuanceZh: `自然分享当下工作与生活近况的${styleZh}。`
          };
        }
        if (/(비|눈|추워|춥|더워|날씨|따뜻|우산|바람|下雨|冷|热|天气|保暖|暖和)/.test(combined)) {
          return {
            toneKo: '🌦️ 날씨 · 다정한 챙김', toneZh: '🌦️ 天气 · 贴心叮嘱',
            nuanceKo: `날씨를 나누며 상대방을 챙기는 포근한 ${styleKo}이에요.`,
            nuanceZh: `借天气叮嘱对方照顾好自己的温暖${styleZh}。`
          };
        }
        return {
          toneKo: isPolite ? '🌸 부드러운 존댓말' : '💬 자연스러운 일상체',
          toneZh: isPolite ? '🌸 温柔敬语' : '💬 自然日常',
          nuanceKo: '',
          nuanceZh: '',
          isGeneric: true
        };
      }

      async function geminiTranslate(rawText, toneOverride, opts) {
        if (opts && opts.skipEngine) return translateWithAutoRetry(rawText, toneOverride, opts.skipEngine);
        return translateWithAutoRetry(rawText, toneOverride, '');
      }

      function renderNuanceCardHtml(res) {
        if (!res) return '';
        const isZh = state.lang === 'zh';
        const showNuance = state.settings.autoNuance !== false;
        const ttsLang = res.tgtLang === 'zh' ? 'zh-CN' : 'ko-KR';
        const safeTrans = escapeHtml(res.translated);
        const engineMapZh = {
          'Gemini 초정밀 큐레이션 👑': 'Gemini 精选精译 👑',
          '실전 치트키 정밀 사전 👑': '261实战词库精译 👑',
          'Google Neural + 뉘앙스 엔진': 'Google 神经网络 + 语感引擎',
          'SimplyTranslate AI 신경망 ✨': 'SimplyTranslate AI 神经网络 ✨',
          '하이브리드 AI 번역': '混合 AI 翻译引擎',
          '로컬 안전 번역 엔진': '本地离线安全引擎'
        };
        const engineLabel = isZh ? (engineMapZh[res.engine] || res.engine) : res.engine;
        const pronLabel = isZh ? '[发音]' : '[발음]';
        const accLabel = isZh ? '准确度' : '정확도';
        const nuanceTitle = isZh ? '💎 含义与语感解析' : '💎 뜻 · 뉘앙스 해설';
        const coreLabel = isZh ? '核心含义：' : '핵심 뜻: ';
        const altsTitle = isZh ? '💡 相似的自然表达' : '💡 비슷한 자연스러운 표현';
        const cleanLiteral = String(res.literal || '').replace(/^핵심 뜻:\s*/, '');
        const cleanPron = isZh
          ? String(res.pronunciation || '').replace(/🔊\s*(원어민[^·]*지원|支持[^·]*(发音|朗读))/g, '').trim().replace(/오프라인\s*안전\s*모드|离线安全模式/g, '').trim()
          : String(res.pronunciation || '');
        const speakIco = window.getAppIconHtml ? window.getAppIconHtml('speak') : '🔈';
        const slowIco = window.getAppIconHtml ? window.getAppIconHtml('slow') : '0.7×';
        const copyIco = window.getAppIconHtml ? window.getAppIconHtml('copy') : '📋';
        const heartIco = window.getAppIconHtml ? window.getAppIconHtml('dday') : '🩷';
        // Build playable natural alternative sentences with Meaning + Pronunciation!
        const ALT_DICT = {
          '想见你': { pron: 'xiǎng jiàn nǐ', meaning: '만나고 싶어' },
          '超级想你': { pron: 'chāo jí xiǎng nǐ', meaning: '엄청 보고 싶어' },
          '太想你了，睡不着': { pron: 'tài xiǎng nǐ le, shuì bu zháo', meaning: '너무 보고 싶어서 잠이 안 와' },
          '脑子里全是你': { pron: 'nǎo zi lǐ quán shì nǐ', meaning: '머릿속이 온통 너뿐이야' },
          '今天辛苦啦，早点休息': { pron: 'jīn tiān xīn kǔ la, zǎo diǎn xiū xi', meaning: '오늘 수고했어, 일찍 쉬어' },
          '你今天真棒，好好放松一下吧': { pron: 'nǐ jīn tiān zhēn bàng, hǎo hǎo fàng sōng yī xià ba', meaning: '오늘 정말 멋졌어, 편하게 쉬어' },
          '好爱你': { pron: 'hǎo ài nǐ', meaning: '정말 많이 사랑해' },
          '爱你哟': { pron: 'ài nǐ yo', meaning: '사랑해요 (귀엽게)' },
          '晚安好梦': { pron: 'wǎn ān hǎo mèng', meaning: '잘 자, 좋은 꿈 꿔' },
          '梦里见': { pron: 'mèng lǐ jiàn', meaning: '꿈에서 만나' },
          '在做什么呢？': { pron: 'zài zuò shén me ne', meaning: '뭐 하고 있어?' },
          '干嘛呢？': { pron: 'gàn ma ne', meaning: '뭐 해?' },
          '在忙什么呢？': { pron: 'zài máng shén me ne', meaning: '무슨 일로 바빠?' },
          '现在在干嘛呀？': { pron: 'xiàn zài zài gàn ma ya', meaning: '지금 뭐 하고 있어?' },
          '现在忙吗？': { pron: 'xiàn zài máng ma', meaning: '지금 바빠?' },
          '此刻在干嘛呢？': { pron: 'cǐ kè zài gàn ma ne', meaning: '지금 이 순간 뭐 하고 있어?' },
          '吃过饭了吗？': { pron: 'chī guò fàn le ma', meaning: '밥 먹었어?' },
          '好好吃饭了吗？': { pron: 'hǎo hǎo chī fàn le ma', meaning: '밥 잘 챙겨 먹었어?' },
          '到哪儿啦？': { pron: 'dào nǎr la', meaning: '어디쯤 왔어?' },
          '现在在哪呢？': { pron: 'xiàn zài zài nǎ ne', meaning: '지금 어디야?' },
          '哈喽~': { pron: 'hā lóu', meaning: '안녕~' },
          '你好呀': { pron: 'nǐ hǎo ya', meaning: '안녕 (다정하게)' },
          '你好': { pron: 'nǐ hǎo', meaning: '안녕하세요' },
          '初次见面，您好': { pron: 'chū cì jiàn miàn, nín hǎo', meaning: '처음 뵙겠습니다' },
          '太感谢你了': { pron: 'tài gǎn xiè nǐ le', meaning: '정말 너무 고마워' },
          '多亏了你': { pron: 'duō kuī le nǐ', meaning: '다 네 덕분이야' },
          '不好意思': { pron: 'bù hǎo yì si', meaning: '죄송해요 / 미안해' },
          '我错了，别生气': { pron: 'wǒ cuò le, bié shēng qì', meaning: '내가 잘못했어, 화내지 마' },
          '别在意': { pron: 'bié zài yì', meaning: '신경 쓰지 마' },
          '不要紧的': { pron: 'bù yào jǐn de', meaning: '괜찮아, 별일 아니야' },
          '好饿呀': { pron: 'hǎo è ya', meaning: '너무 배고파' },
          '想吃好吃的': { pron: 'xiǎng chī hǎo chī de', meaning: '맛있는 거 먹고 싶어' },
          '困死了': { pron: 'kùn sǐ le', meaning: '졸려 죽겠어' },
          '想睡觉了': { pron: 'xiǎng shuì jiào le', meaning: '자고 싶어' },
          '今天好辛苦': { pron: 'jīn tiān hǎo xīn kǔ', meaning: '오늘 너무 힘들었어' },
          '累坏了': { pron: 'lèi huài le', meaning: '완전 지쳤어' },
          '陪我聊聊天吧': { pron: 'péi wǒ liáo liao tiān ba', meaning: '나랑 수다 좀 떨어줘' },
          '有点无聊呢': { pron: 'yǒu diǎn wú liáo ne', meaning: '좀 심심하네' },
          '太可爱了': { pron: 'tài kě ài le', meaning: '너무 귀여워' },
          '怎么这么可爱': { pron: 'zěn me zhè me kě ài', meaning: '어떻게 이렇게 귀여워?' },
          '真美': { pron: 'zhēn měi', meaning: '정말 아름다워' },
          '今天特别好看': { pron: 'jīn tiān tè bié hǎo kàn', meaning: '오늘따라 유독 예쁘네' },
          '太帅了': { pron: 'tài shuài le', meaning: '너무 멋있어' },
          '超有魅力': { pron: 'chāo yǒu mèi lì', meaning: '매력 넘쳐' },
          '早安，睡醒了吗？': { pron: 'zǎo ān, shuì xǐng le ma', meaning: '좋은 아침, 잘 잤어?' },
          '昨晚睡得香吗？': { pron: 'zuó wǎn shuì de xiāng ma', meaning: '어젯밤 꿀잠 잤어?' },
          '早点睡哦': { pron: 'zǎo diǎn shuì o', meaning: '일찍 자요' },
          '做个好梦': { pron: 'zuò gè hǎo mèng', meaning: '좋은 꿈 꿔' },
          '安全到家了': { pron: 'ān quán dào jiā le', meaning: '안전하게 집에 도착했어' },
          '刚进家门': { pron: 'gāng jìn jiā mén', meaning: '방금 현관문 들어왔어' },
          '注意安全': { pron: 'zhù yì ān quán', meaning: '안전 조심해' },
          '到了发消息给我': { pron: 'dào le fā xiāo xi gěi wǒ', meaning: '도착하면 연락해 줘' },
          '你可以的！': { pron: 'nǐ kě yǐ de', meaning: '넌 할 수 있어!' },
          '打起精神！': { pron: 'dǎ qǐ jīng shén', meaning: '힘내!' },
          '慢慢来，我等你': { pron: 'màn màn lái, wǒ děng nǐ', meaning: '천천히 와, 기다릴게' },
          '随时等你': { pron: 'suí shí děng nǐ', meaning: '언제든 기다릴게' },
          '明白啦': { pron: 'míng bai la', meaning: '알겠어!' },
          '好的呀': { pron: 'hǎo de ya', meaning: '좋아요~' },
          '真的假的？': { pron: 'zhēn de jiǎ de', meaning: '진짜야 거짓말이야?' },
          '不会吧': { pron: 'bù huì ba', meaning: '설마~' },
          '今天辛苦你了': { pron: 'jīn tiān xīn kǔ nǐ le', meaning: '오늘 정말 수고했어' },
          '好好休息吧': { pron: 'hǎo hǎo xiū xi ba', meaning: '푹 쉬어' },
          '这里太美了': { pron: 'zhè lǐ tài měi le', meaning: '여기 정말 예쁘다' },
          '风景真好看': { pron: 'fēng jǐng zhēn hǎo kàn', meaning: '풍경 진짜 멋지다' },
          '今天天气真好': { pron: 'jīn tiān tiān qì zhēn hǎo', meaning: '오늘 날씨 정말 좋다' },
          '你看今天的天空': { pron: 'nǐ kàn jīn tiān de tiān kōng', meaning: '오늘 하늘 좀 봐봐' },
          '在吃饭啦': { pron: 'zài chī fàn la', meaning: '밥 먹고 있어' },
          '开动啦~': { pron: 'kāi dòng la', meaning: '잘 먹겠습니다~' },
          '好诱人呀': { pron: 'hǎo yòu rén ya', meaning: '진짜 먹음직스럽다' },
          '我也想吃': { pron: 'wǒ yě xiǎng chī', meaning: '나도 먹고 싶어' },
          '漂亮吗？': { pron: 'piào liang ma', meaning: '예뻐?' },
          '是不是很好看？': { pron: 'shì bù shì hěn hǎo kàn', meaning: '정말 예쁘지?' },
          '是不是很可爱？': { pron: 'shì bù shì hěn kě ài', meaning: '진짜 귀엽지?' },
          '萌不萌？': { pron: 'méng bù méng', meaning: '귀엽지 않아?' },
          '你觉得怎么样？': { pron: 'nǐ jué de zěn me yàng', meaning: '어떻게 생각해?' },
          '好看吗？': { pron: 'hǎo kàn ma', meaning: '예뻐 보여?' },
          '刚到哦': { pron: 'gāng dào o', meaning: '방금 도착했어' },
          '已经到了': { pron: 'yǐ jīng dào le', meaning: '벌써 도착했어' },
          '在路上了': { pron: 'zài lù shàng le', meaning: '가는 중이야' },
          '刚出门': { pron: 'gāng chū mén', meaning: '방금 집에서 나왔어' },
          '靖灿': { pron: 'Jìngcàn', meaning: '징찬' },
          '징찬': { pron: 'Jing-chan', meaning: '靖灿' }
        };
        const rawAlts = Array.isArray(res.alts) ? res.alts.filter(Boolean) : [];
        const playableAlts = rawAlts.map(a => {
          if (a && typeof a === 'object') {
            const speakTarget = String(a.text || '').trim();
            const altLang = (/[\u4E00-\u9FFF]/.test(speakTarget) && !/[\uAC00-\uD7A3]/.test(speakTarget)) ? 'zh-CN' : (/[\uAC00-\uD7A3]/.test(speakTarget) ? 'ko-KR' : ttsLang);
            return { text: speakTarget, pron: String(a.pron || ''), meaning: String(a.meaning || ''), speak: speakTarget, lang: altLang };
          }
          const str = String(a).trim();
          const parenM = str.match(/^([^(（]+)[(（]([^)）]+)[)）]/);
          const speakTarget = (parenM ? parenM[1] : str.split('·')[0]).replace(/^[•·\-]\s*/, '').trim() || str;
          const inlineMeaning = parenM ? parenM[2].trim() : '';
          const dictHit = ALT_DICT[speakTarget] || null;
          const altLang = (/[\u4E00-\u9FFF]/.test(speakTarget) && !/[\uAC00-\uD7A3]/.test(speakTarget)) ? 'zh-CN' : (/[\uAC00-\uD7A3]/.test(speakTarget) ? 'ko-KR' : ttsLang);
          let pron = dictHit ? dictHit.pron : '';
          if (!pron && altLang === 'ko-KR' && typeof romanizeKoreanBasic === 'function') {
            pron = romanizeKoreanBasic(speakTarget);
          }
          let meaning = inlineMeaning || (dictHit ? dictHit.meaning : '');
          if (!meaning) {
            meaning = altLang === 'zh-CN'
              ? (isZh ? `同义自然表达（${cleanLiteral || res.original}）` : `${cleanLiteral || res.original} (비슷한 자연스러운 중국어)`)
              : (isZh ? `${res.original || cleanLiteral}（自然韩语表达）` : `${res.original || cleanLiteral} (비슷한 자연스러운 한국어)`);
          }
          return { text: speakTarget, pron, meaning, speak: speakTarget, lang: altLang };
        });
        const altsHtml = playableAlts.length
          ? `<div class="pt-1.5 space-y-1.5"><div class="text-[10px] text-mut font-semibold">${altsTitle}</div><div class="space-y-1.5">${playableAlts.map(a => `
              <div class="flex items-center justify-between gap-2 text-[11px] px-2.5 py-2 rounded-xl" style="background: var(--surface-1); border: 1px solid var(--border-subtle);">
                <div class="min-w-0 flex-1 space-y-0.5">
                  <div class="font-bold text-gold break-words leading-snug">${escapeHtml(a.text)}</div>
                  ${a.pron ? `<div class="text-[10px] text-mut break-words">${pronLabel} ${escapeHtml(a.pron)}</div>` : ''}
                  ${a.meaning ? `<div class="text-[10.5px] text-sec break-words">${isZh ? '意思：' : '뜻: '}${escapeHtml(a.meaning)}</div>` : ''}
                </div>
                <div class="flex items-center gap-1 shrink-0">
                  <button type="button" class="speak-btn btn-ghost w-7 h-7 rounded-full flex items-center justify-center" data-text="${escapeHtml(a.speak)}" data-lang="${a.lang}" title="${isZh ? '朗读例句' : '문장 듣기'}">${speakIco}</button>
                  <button type="button" class="speak-btn btn-ghost w-7 h-7 rounded-full flex items-center justify-center" data-text="${escapeHtml(a.speak)}" data-lang="${a.lang}" data-slow="1" title="${isZh ? '慢速朗读' : '천천히 듣기'}">${slowIco}</button>
                </div>
              </div>
            `).join('')}</div></div>`
          : '';
        const authorRole = res.author || state.myRole || 'suwan';
        const authorPill = authorRole === 'jingchan'
          ? `<span class="text-[10px] font-bold px-2 py-0.5 rounded-full inline-flex items-center gap-1" style="background: rgba(168,85,247,0.14); color: #7c3aed;">${heartIco} 靖灿(灿)</span>`
          : `<span class="text-[10px] font-bold px-2 py-0.5 rounded-full inline-flex items-center gap-1" style="background: rgba(244,63,94,0.12); color: #e11d48;">${heartIco} 수완(完)</span>`;
        return `
          <div class="space-y-2">
            <div class="flex items-center justify-between gap-2">
              <div class="flex items-center gap-1.5">${authorPill}<span class="text-[10px] text-mut">${isZh ? '正在翻译' : '번역 작성자'}</span></div>
            </div>
            <div class="flex items-start justify-between gap-2">
              <div class="min-w-0 flex-1">
                <div class="flex items-center gap-1.5 flex-wrap">
                  <span class="text-[10px] font-semibold px-2 py-0.5 rounded-full" style="background: var(--accent-royal-soft); color: var(--accent-royal);">${escapeHtml(engineLabel)}</span>
                  <span class="text-[10px] font-bold px-2 py-0.5 rounded-full" style="background: ${(res.accuracy || 92) >= 90 ? 'rgba(16,185,129,0.14)' : ((res.accuracy || 92) >= 82 ? 'rgba(245,158,11,0.16)' : 'rgba(244,63,94,0.16)')}; color: ${(res.accuracy || 92) >= 90 ? '#059669' : ((res.accuracy || 92) >= 82 ? '#d97706' : '#e11d48')};">${accLabel} ${res.accuracy || 92}%${res.autoRetried ? (isZh ? ' · 自动优化' : ' · 자동재번역') : ''}</span>
                  <span class="text-[10px] px-2 py-0.5 rounded-full" style="background: var(--surface-1); border: 1px solid var(--border-subtle);">${escapeHtml(res.tone)}</span>
                  <button type="button" class="nuance-retrans-btn text-[10px] font-semibold px-2 py-0.5 rounded-full btn-ghost" data-orig="${escapeHtml(res.original || '')}" data-engine="${escapeHtml(res.engine || '')}">${isZh ? '🔄 重译' : '🔄 다시 번역'}</button>
                </div>
                <div class="mt-1.5 flex items-center gap-2">
                  <div class="flex-1 h-1.5 rounded-full overflow-hidden" style="background: var(--surface-input);">
                    <div class="h-full rounded-full" style="width: ${Math.max(50, Math.min(100, res.accuracy || 92))}%; background: linear-gradient(90deg, #583894, #c8a56e);"></div>
                  </div>
                  <span class="text-[10px] font-semibold text-champagne shrink-0">${accLabel} ${res.accuracy || 92}%</span>
                </div>
                <div class="text-base font-bold mt-1.5 leading-snug break-words">${safeTrans}</div>
                ${cleanPron ? `<div class="text-[11px] text-mut mt-0.5 break-words">${pronLabel} ${escapeHtml(cleanPron)}</div>` : ''}
              </div>
              <div class="flex gap-1 shrink-0">
                <button type="button" class="speak-btn btn-royal w-8 h-8 rounded-full flex items-center justify-center" data-text="${safeTrans}" data-lang="${ttsLang}" title="${isZh ? '原声朗读' : '원어민 발음 듣기'}">${speakIco}</button>
                <button type="button" class="speak-btn btn-ghost w-8 h-8 rounded-full flex items-center justify-center" data-text="${safeTrans}" data-lang="${ttsLang}" data-slow="1" title="${isZh ? '慢速跟读' : '천천히 듣기'}">${slowIco}</button>
                <button type="button" class="copy-btn btn-ghost w-8 h-8 rounded-full flex items-center justify-center" data-text="${safeTrans}" title="${isZh ? '复制' : '복사'}">${copyIco}</button>
              </div>
            </div>
            ${showNuance ? `
              <div class="nuance-box rounded-xl p-3 text-xs space-y-1.5">
                <div class="font-semibold text-gold">${nuanceTitle}</div>
                ${cleanLiteral ? `<div class="text-sec"><b>${coreLabel}</b>${escapeHtml(cleanLiteral)}</div>` : ''}
                ${res.tone ? `<div class="text-sec"><b>${isZh ? '语气风格：' : '말투: '}</b>${escapeHtml(res.tone)}</div>` : ''}
                <div class="text-sec leading-relaxed"><b>${isZh ? '语感说明：' : '뉘앙스 풀이: '}</b>${escapeHtml(res.nuance)}</div>
                ${altsHtml}
              </div>
            ` : ''}
          </div>
        `;
      }

      /* ============================================================
         5. KOREAN LEARNING DATA (5-LEVEL + 72 CHEAT SHEET)
         ============================================================ */
      const DAILY_CURRICULUM = [
        { ko: '오늘 하루도 정말 고생 많았어', zh: '今天一天也辛苦了', pron: 'o-neul ha-ru-do jeong-mal go-saeng ma-na-sseo', nuance: '하루를 마친 연인을 다정하게 위로하는 한국어 핵심 표현입니다.', nuanceZh: '一天结束时温柔安慰恋人的高频暖心表达，用来对刚下班或忙碌了一天的对方说最贴心。' },
        { ko: '네 생각만 해도 웃음이 나', zh: '一想到你就会笑出来', pron: 'ne saeng-gak-man hae-do u-seu-mi na', nuance: '상대방을 떠올리는 것만으로 행복하다는 달콤한 애정 표현입니다.', nuanceZh: '只要脑海里浮现对方就会忍不住开心笑出来，是很甜的韩语撒娇与告白表达。' },
        { ko: '밥은 꼭 챙겨 먹고 다녀', zh: '一定要按时吃饭呀', pron: 'ba-beun kkok chaeng-gyeo meok-go da-nyeo', nuance: '연인의 건강을 진심으로 걱정하는 한국 특유의 다정한 챙김입니다.', nuanceZh: '韩国人表达关心最地道的方式之一，叮嘱对方别忙忘了吃饭、照顾好身体。' },
        { ko: '조금만 참아, 곧 보러 갈게', zh: '再忍一下，我很快去看你', pron: 'jo-geum-man cha-ma, got bo-reo gal-ge', nuance: '장거리 연애에서 만남을 약속하며 설렘을 전하는 표현입니다.', nuanceZh: '异地恋时约定见面、给对方带来期待感和安全感的温柔承诺。' },
        { ko: '무슨 일 있어? 나한테 다 말해 봐', zh: '发生什么事了？都告诉我吧', pron: 'mu-seun il i-sseo? na-han-te da mal-hae bwa', nuance: '상대방의 기분이 안 좋아 보일 때 든든한 내 편이 되어주는 표현입니다.', nuanceZh: '察觉对方情绪低落时，主动倾听并让对方依靠的暖心表达。' },
        { ko: '오늘따라 유난히 더 보고 싶네', zh: '唯独今天格外想你', pron: 'o-neul-tta-ra yu-nan-hi deo bo-go sip-ne', nuance: '오늘따라를 붙여 평상시보다 더 깊은 그리움을 표현합니다.', nuanceZh: '加上「오늘따라（唯独今天）」能细腻地强调比平时更深、更强烈的想念。' },
        { ko: '무리하지 말고 천천히 해도 돼', zh: '别勉强自己，慢慢来就好', pron: 'mu-ri-ha-ji mal-go cheon-cheon-hi hae-do dwae', nuance: '압박감을 덜어주고 상대방의 페이스를 존중해 주는 따뜻한 응원입니다.', nuanceZh: '帮对方减轻压力、尊重对方节奏的温柔鼓励，非常实用。' },
        { ko: '네가 내 곁에 있어서 정말 다행이야', zh: '你在我身边真是太好了', pron: 'ne-ga nae gyeo-te i-sseo-seo jeong-mal da-haeng-i-ya', nuance: '깊은 안도감과 고마움을 동시에 담은 진심 어린 고백입니다.', nuanceZh: '同时包含安心感与感激之情的真诚告白，表达有对方陪伴真好。' },
        { ko: '우리 다음에 꼭 같이 가자', zh: '我们下次一定要一起去', pron: 'u-ri da-eu-me kkok ga-chi ga-ja', nuance: '예쁜 곳을 봤을 때 미래를 함께 그리며 건네는 설레는 약속입니다.', nuanceZh: '看到好看的风景或好吃的店时，想和对方一起去打卡的甜蜜约定。' }
      ];

      const LEARN_CAT_ZH_MAP = {
        '연애·애정': '恋爱甜蜜', '일상·인사': '日常问候', '맛집·카페': '餐厅咖啡',
        '여행·교통': '旅行交通', '감정·위로': '情绪安慰', '쇼핑·긴급': '购物应急',
        '카톡·전화': '聊天通话', '식당·배달': '点餐外卖', '올영·편의점': '美妆便利店',
        '가족·예절': '长辈礼仪', '택시·길찾기': '打车指路', '리액션·화해': '地道反应与和好',
        '병원·약국': '医院药店应急', '데이트·사진': '约会拍照', '일상·스몰토크': '日常闲聊',
        '💜 수완 맞춤': '💜 完的专属词库'
      };
      const LEARN_CAT_SCENE_ZH = {
        '연애·애정': '恋人之间表达爱意、想念与甜蜜互动时的地道韩语口语。',
        '일상·인사': '韩国人每天打招呼、关心饮食与日常起居的高频实用表达。',
        '맛집·카페': '在韩国咖啡店点冰美式、少冰、少糖、外带或问 Wi-Fi/洗手间密码时的必备句。',
        '여행·교통': '在韩国坐地铁、KTX、机场、办酒店入住或寄存行李时的超实用句。',
        '감정·위로': '安慰疲惫或难过的对方、表达支持与鼓励的暖心韩语。',
        '쇼핑·긴급': '在韩国逛街试穿、换尺码、退税(Tax Refund)或突发紧急情况时的必备表达。',
        '카톡·전화': '发消息、报备行程、刚睡醒、快到了或约打电话时的自然口语。',
        '식당·배달': '在韩国餐厅加小菜、要求不辣/不要香菜、要小碟子或点外卖时的地道说法。',
        '올영·편의점': '逛 Olive Young 试妆买护肤品、在便利店微波加热或充交通卡时的实用句。',
        '가족·예절': '见长辈、朋友或做客吃饭时礼貌得体的韩语敬语表达。',
        '택시·길찾기': '在韩国打车、让司机停车开后备箱、问地铁出口或换乘时的实用口语。',
        '리액션·화해': '韩国年轻人聊天感叹附和，或闹别扭后温柔道歉和好时的自然表达。',
        '병원·약국': '身体不舒服去药店买感冒药、消化药或去医院描述症状时的应急表达。',
        '데이트·사진': '约会打卡、夸氛围好看、请路人帮忙拍情侣合照时的实用表达。',
        '일상·스몰토크': '聊天气、周末计划、下班安排和日常闲聊时的自然开场白。',
        '💜 수완 맞춤': '完专门为你添加到专属词库的实用韩语表达，快点小喇叭跟读吧！'
      };
      function localizeLearnCatZh(cat) { return LEARN_CAT_ZH_MAP[cat] || cat; }
      function localizeLearnNuanceZh(item) {
        if (!item) return '';
        if (item.nuZh && !/[가-힣]/.test(item.nuZh)) return item.nuZh;
        const cz = localizeLearnCatZh(item.cat || '');
        const tip = LEARN_CAT_SCENE_ZH[item.cat || ''] || '韩国人日常对话中非常自然常用的地道口语表达。';
        return `【${cz || '实战口语'}】「${item.ko}」意思是「${item.zh}」— ${tip}`;
      }

      const CHEAT_SHEET_72 = [
        { cat: '연애·애정', ko: '보고 싶어 죽겠어', zh: '想你想得要命', nu: '그리움을 귀엽고 강하게 강조하는 연인 표현' },
        { cat: '연애·애정', ko: '네가 세상에서 제일 좋아', zh: '这世上我最喜欢你', nu: '애정을 아낌없이 표현할 때 쓰는 달콤한 말' },
        { cat: '연애·애정', ko: '내일도 예쁜 꿈 꿔', zh: '祝你今晚做个好梦', nu: '잠들기 전 다정하게 건네는 밤 인사' },
        { cat: '연애·애정', ko: '목소리 듣고 싶어서 전화했어', zh: '想听你的声音所以打给你', nu: '특별한 용건 없이 그리워서 연락할 때' },
        { cat: '연애·애정', ko: '너만 보면 기분이 좋아져', zh: '一看到你心情就变好', nu: '상대방이 내 행복의 이유임을 전하는 표현' },
        { cat: '연애·애정', ko: '오늘따라 더 멋있네', zh: '今天格外帅气呢', nu: '칭찬할 때 "오늘따라"를 붙이면 설렘 상승' },
        { cat: '연애·애정', ko: '항상 내 편이 되어줘서 고마워', zh: '谢谢你一直站在我这边', nu: '깊은 신뢰와 고마움을 전하는 표현' },
        { cat: '연애·애정', ko: '우리 오래오래 행복하자', zh: '我们要长长久久幸福下去', nu: '미래를 함께 약속하는 따뜻한 다짐' },
        { cat: '연애·애정', ko: '지금 바로 안아주고 싶다', zh: '现在就好想抱抱你', nu: '멀리 떨어져 있을 때 전하는 애틋한 표현' },
        { cat: '연애·애정', ko: '나한테만 다 말해줘', zh: '只告诉我一个人吧', nu: '특별한 친밀감과 든든함을 주는 말' },
        { cat: '연애·애정', ko: '네 웃는 얼굴이 제일 좋아', zh: '最喜欢看你笑的样子', nu: '상대방의 미소를 칭찬하는 로맨틱 표현' },
        { cat: '연애·애정', ko: '어디에 있어도 마음은 바로 옆이야', zh: '无论在哪，心就在你身旁', nu: '찬완 커플 전용 장거리 응원 문구' },
        { cat: '일상·인사', ko: '잘 잤어? 좋은 아침!', zh: '睡得好吗？早安！', nu: '아침에 일어나 가장 먼저 건네는 다정한 인사' },
        { cat: '일상·인사', ko: '점심 맛있게 먹어', zh: '好好吃午饭', nu: '점심시간에 상대방을 챙기는 따뜻한 인사' },
        { cat: '일상·인사', ko: '조심히 들어가고 도착하면 연락해', zh: '路上小心，到了告诉我', nu: '귀갓길 안전을 챙기는 한국식 애정 표현' },
        { cat: '일상·인사', ko: '지금 뭐 하고 있어?', zh: '现在在干嘛呢？', nu: '가볍게 대화를 시작할 때 가장 많이 쓰는 말' },
        { cat: '일상·인사', ko: '오늘 하루 어땠어?', zh: '今天过得怎么样？', nu: '하루 일과를 공유하며 공감대를 여는 질문' },
        { cat: '일상·인사', ko: '잠깐만, 금방 답장할게', zh: '等一下，马上回复你', nu: '바쁠 때 상대방이 서운하지 않게 미리 알리는 말' },
        { cat: '일상·인사', ko: '주말에 푹 쉬어', zh: '周末好好休息吧', nu: '주말을 앞두고 건네는 따뜻한 인사' },
        { cat: '일상·인사', ko: '오늘 날씨 진짜 좋다', zh: '今天天气真好啊', nu: '일상 공유와 산책 제안으로 이어가기 좋은 말' },
        { cat: '일상·인사', ko: '우산 꼭 챙겨 나가', zh: '出门一定要带伞', nu: '비 소식이 있을 때 세심하게 챙기는 표현' },
        { cat: '일상·인사', ko: '벌써 퇴근 시간이네', zh: '已经到下班时间了呢', nu: '하루를 마무리하며 반가움을 나누는 말' },
        { cat: '일상·인사', ko: '잠깐 통화 가능해?', zh: '方便打一会儿电话吗？', nu: '상대방 상황을 배려하며 통화를 요청할 때' },
        { cat: '일상·인사', ko: '내일 또 이야기하자', zh: '明天再聊吧', nu: '아쉬움을 남기며 부드럽게 대화를 마무리할 때' },
        { cat: '맛집·카페', ko: '아이스 아메리카노 한 잔 주세요', zh: '请给我一杯冰美式', nu: '한국 카페에서 가장 자주 쓰는 필수 주문' },
        { cat: '맛집·카페', ko: '덜 맵게 해주세요', zh: '请做得不要太辣', nu: '매운 한국 음식을 조절해 달라고 부탁할 때' },
        { cat: '맛집·카페', ko: '여기 메뉴 추천해 주세요', zh: '请推荐一下这里的招牌菜', nu: '식당에서 인기 메뉴를 물어볼 때' },
        { cat: '맛집·카페', ko: '포장해 주세요', zh: '请帮我打包', nu: '음식이나 음료를 테이크아웃할 때' },
        { cat: '맛집·카페', ko: '물 좀 더 주실 수 있나요?', zh: '可以再给一点水吗？', nu: '정중하고 자연스럽게 물을 요청할 때' },
        { cat: '맛집·카페', ko: '계산할게요', zh: '结账', nu: '식사를 마치고 계산대에서 쓰는 표현' },
        { cat: '맛집·카페', ko: '진짜 입에서 살살 녹는다!', zh: '真的入口即化！', nu: '음식이 아주 부드럽고 맛있을 때 감탄사' },
        { cat: '맛집·카페', ko: '여기 분위기 너무 좋다', zh: '这里氛围太棒了', nu: '데이트 카페나 레스토랑에서 공감할 때' },
        { cat: '맛집·카페', ko: '디저트 배는 따로 있지', zh: '装甜品的胃是分开的', nu: '배불러도 케이크나 커피를 즐길 때 재치 있는 말' },
        { cat: '맛집·카페', ko: '두 명 자리 있나요?', zh: '有两位的位置吗？', nu: '식당에 입장할 때 인원수를 말하는 표현' },
        { cat: '맛집·카페', ko: '영수증은 괜찮아요', zh: '不需要小票', nu: '결제 후 영수증을 사양할 때 부드러운 거절' },
        { cat: '맛집·카페', ko: '잘 먹었습니다!', zh: '我吃好了，谢谢款待！', nu: '식사 후 감사함을 전하는 예의 바른 인사' },
        { cat: '여행·교통', ko: '이 버스는 수원역으로 가나요?', zh: '这趟公交车去水原站吗？', nu: '대중교통 방향을 확인할 때 유용한 패턴' },
        { cat: '여행·교통', ko: '여기서 사진 한 장만 찍어주실 수 있나요?', zh: '可以帮我们在这里拍张照吗？', nu: '여행지에서 커플 사진을 정중히 부탁할 때' },
        { cat: '여행·교통', ko: '체크인 부탁드립니다', zh: '麻烦办理入住', nu: '호텔 프런트에서 사용하는 기본 표현' },
        { cat: '여행·교통', ko: '짐 좀 잠시 맡길 수 있을까요?', zh: '可以暂时寄存一下行李吗？', nu: '체크인 전후 짐 보관을 요청할 때' },
        { cat: '여행·교통', ko: '가장 가까운 지하철역이 어디예요?', zh: '最近的地铁站在哪里？', nu: '길을 찾을 때 바로 쓰는 실전 문장' },
        { cat: '여행·교통', ko: '여기서 내려주세요', zh: '请在这里让我下车', nu: '택시에서 목적지에 도착했을 때' },
        { cat: '여행·교통', ko: '공항까지 얼마나 걸려요?', zh: '去机场大概需要多久？', nu: '이동 시간을 미리 확인할 때' },
        { cat: '여행·교통', ko: '창가 자리로 부탁해요', zh: '请给我靠窗的座位', nu: '비행기·기차·카페에서 자리를 고를 때' },
        { cat: '여행·교통', ko: '여권이랑 티켓 여기 있어요', zh: '护照和机票在这里', nu: '공항 수속이나 탑승 시 건네는 말' },
        { cat: '여행·교통', ko: '풍경이 정말 그림 같다', zh: '风景美得像画一样', nu: '여행지 뷰에 감탄할 때 쓰는 감성 표현' },
        { cat: '여행·교통', ko: '길을 좀 잃은 것 같아요', zh: '我好像有点迷路了', nu: '주변에 도움을 요청할 때 부드럽게 시작하는 말' },
        { cat: '여행·교통', ko: '다음 여행은 어디로 갈까?', zh: '下次旅行我们去哪里呢？', nu: '함께 다음 여행을 계획하며 설렘을 나눌 때' },
        { cat: '감정·위로', ko: '괜찮아, 다 잘 될 거야', zh: '没关系，一切都会好起来的', nu: '불안하거나 지친 마음을 달래주는 따뜻한 위로' },
        { cat: '감정·위로', ko: '네가 최선을 다한 거 내가 다 알아', zh: '我知道你已经尽最大努力了', nu: '결과보다 과정을 인정해 주는 깊은 공감' },
        { cat: '감정·위로', ko: '오늘은 아무 생각 말고 푹 쉬어', zh: '今天什么都别想，好好休息', nu: '스트레스 많은 날 건네는 최고의 휴식 처방' },
        { cat: '감정·위로', ko: '많이 힘들었지? 이리 와', zh: '很辛苦吧？过来抱抱', nu: '다정하게 품을 내어주는 연인만의 위로' },
        { cat: '감정·위로', ko: '조금 서운했는데 말하고 나니까 풀렸어', zh: '本来有点委屈，说出来就好多了', nu: '감정을 건강하고 솔직하게 소통하는 법' },
        { cat: '감정·위로', ko: '걱정 마, 내가 옆에 있잖아', zh: '别担心，不是有我在你身边嘛', nu: '흔들릴 때 든든한 믿음을 주는 말' },
        { cat: '감정·위로', ko: '네 마음이 편한 대로 해', zh: '按你觉得舒服的方式来就好', nu: '상대방의 선택을 존중해 주는 배려' },
        { cat: '감정·위로', ko: '나도 같은 마음이야', zh: '我也是同样的心情', nu: '상대방의 이야기에 깊이 공감할 때' },
        { cat: '감정·위로', ko: '너무 자책하지 마', zh: '别太自责了', nu: '실수로 속상해하는 연인을 다독일 때' },
        { cat: '감정·위로', ko: '진심으로 축하해! 너무 멋져', zh: '真心祝贺你！太厉害了', nu: '좋은 일이 생겼을 때 함께 기뻐해 주는 말' },
        { cat: '감정·위로', ko: '천천히 숨 한 번 크게 쉬어 봐', zh: '慢慢深呼吸一次吧', nu: '긴장하거나 급할 때 마음을 진정시켜 주는 말' },
        { cat: '감정·위로', ko: '너는 있는 그대로도 충분히 소중해', zh: '你本来的样子就已经足够珍贵', nu: '자존감을 높여주는 깊은 사랑의 위로' },
        { cat: '쇼핑·긴급', ko: '이거 입어봐도 될까요?', zh: '这件可以试穿吗？', nu: '옷가게에서 피팅을 정중히 요청할 때' },
        { cat: '쇼핑·긴급', ko: '다른 색상이나 사이즈 있나요?', zh: '有其他颜色或尺码吗？', nu: '원하는 옵션을 문의할 때' },
        { cat: '쇼핑·긴급', ko: '카드로 결제할게요', zh: '我刷卡支付', nu: '한국에서 카드 결제 시 가장 많이 쓰는 말' },
        { cat: '쇼핑·긴급', ko: '선물 포장 가능할까요?', zh: '可以帮忙礼盒包装吗？', nu: '선물을 살 때 포장을 요청하는 표현' },
        { cat: '쇼핑·긴급', ko: '면세(택스 리펀) 되나요?', zh: '这里可以退税吗？', nu: '한국 쇼핑 시 외국인 면세 혜택을 물을 때' },
        { cat: '쇼핑·긴급', ko: '조금만 더 둘러볼게요', zh: '我再稍微看看', nu: '직원이 다가왔을 때 부담 없이 편하게 보는 표현' },
        { cat: '쇼핑·긴급', ko: '와이파이 비밀번호가 뭐예요?', zh: 'Wi-Fi密码是多少？', nu: '카페나 숙소에서 인터넷 연결 시 필수 표현' },
        { cat: '쇼핑·긴급', ko: '휴대폰 충전 좀 할 수 있을까요?', zh: '可以稍微充一下手机电吗？', nu: '배터리가 부족할 때 정중히 부탁하는 말' },
        { cat: '쇼핑·긴급', ko: '가까운 약국이 어디예요?', zh: '附近的药店在哪里？', nu: '갑자기 몸이 안 좋을 때 약국을 찾는 표현' },
        { cat: '쇼핑·긴급', ko: '머리가 좀 아파서 약 주세요', zh: '我有点头疼，请给我拿点药', nu: '약국에서 증상을 간단히 설명할 때' },
        { cat: '쇼핑·긴급', ko: '화장실이 어디에 있나요?', zh: '请问洗手间在哪里？', nu: '어디서나 꼭 필요한 기본 질문' },
        { cat: '쇼핑·긴급', ko: '도와주셔서 정말 감사합니다', zh: '非常感谢您的帮助', nu: '도움을 받았을 때 진심을 전하는 정중한 감사' },
        { cat: '카톡·전화', ko: '지금 통화 괜찮아?', zh: '现在方便打电话吗？', nu: '전화 걸기 전 카톡으로 먼저 물어보는 필수 매너 표현' },
        { cat: '카톡·전화', ko: '영상통화 켤까?', zh: '要不要开视频通话？', nu: '얼굴 보고 싶을 때 자연스럽게 제안하는 표현' },
        { cat: '카톡·전화', ko: '배터리 없어서 충전하고 연락할게', zh: '手机没电了，充好电再联系你', nu: '연락이 끊기기 전에 미리 알려주는 실전 카톡 문장' },
        { cat: '카톡·전화', ko: '지금 지하철이라 이따 전화할게', zh: '现在在地铁上，待会儿打给你', nu: '이동 중이라 통화가 어려울 때 쓰는 자연스러운 표현' },
        { cat: '카톡·전화', ko: '잘 안 들려, 다시 말해줄래?', zh: '听不太清，能再说一遍吗？', nu: '통화 음질이 끊길 때 바로 쓰는 실전 문장' },
        { cat: '카톡·전화', ko: '읽씹 아니야, 잠깐 바빴어!', zh: '不是已读不回，刚才有点忙！', nu: '답장이 늦었을 때 귀엽게 해명하는 한국 MZ 표현' },
        { cat: '카톡·전화', ko: '도착하면 바로 톡해!', zh: '到了马上发微信/消息！', nu: '상대방이 안전하게 도착했는지 확인할 때' },
        { cat: '카톡·전화', ko: '지금 출발했어, 거의 다 왔어!', zh: '已经出发啦，快到了！', nu: '약속 장소로 가는 길에 상황을 공유할 때' },
        { cat: '카톡·전화', ko: '사진 좀 보내줘~', zh: '把照片发我一下呀~', nu: '같이 찍은 사진이나 일상 사진을 요청할 때' },
        { cat: '카톡·전화', ko: '뭐해? 밥 먹었어?', zh: '干嘛呢？吃饭了吗？', nu: '한국 커플이 하루에도 몇 번씩 쓰는 안부 인사' },
        { cat: '카톡·전화', ko: 'ㅋㅋㅋ 진짜 웃겨', zh: '哈哈哈太好笑了', nu: '카톡에서 크게 웃을 때 쓰는 가장 자연스러운 리액션' },
        { cat: '카톡·전화', ko: 'ㅇㅇ 알겠어! 이따 봐', zh: '嗯嗯知道啦！待会儿见', nu: '친한 사이에 짧고 편하게 답장하는 줄임말' },
        { cat: '식당·배달', ko: '저기요, 여기 주문할게요!', zh: '你好，我们这边点单！', nu: '한국 식당에서 직원을 부를 때 가장 자연스러운 표현' },
        { cat: '식당·배달', ko: '고수(파) 빼주세요', zh: '请不要放香菜(葱)', nu: '못 먹는 재료를 빼달라고 요청할 때' },
        { cat: '식당·배달', ko: '앞접시랑 휴지 좀 주세요', zh: '请给我小碟子和纸巾', nu: '식당에서 반찬이나 음식을 덜어 먹을 때 필수 표현' },
        { cat: '식당·배달', ko: '여기 물 좀 더 주실 수 있나요?', zh: '可以再给一点水吗？', nu: '정중하고 자연스럽게 물을 요청하는 표현' },
        { cat: '식당·배달', ko: '포장되나요? 남은 거 싸갈게요', zh: '可以打包吗？剩下的我想带走', nu: '음식이 남았거나 테이크아웃할 때 바로 쓰는 표현' },
        { cat: '식당·배달', ko: '여기서 먹고 갈게요', zh: '我在这里吃(堂食)', nu: '카페나 패스트푸드점에서 매장 식사를 선택할 때' },
        { cat: '식당·배달', ko: '카드로 계산할게요', zh: '我刷卡结账', nu: '한국에서 가장 많이 쓰는 결제 표현' },
        { cat: '식당·배달', ko: '영수증은 버려주세요', zh: '小票帮我扔掉就好', nu: '계산 후 영수증이 필요 없을 때 원어민처럼 답하기' },
        { cat: '식당·배달', ko: '문 앞에 두고 벨 눌러주세요', zh: '请放门口并按门铃', nu: '배달 앱 요청사항에 그대로 복사해 쓰는 실전 문구' },
        { cat: '식당·배달', ko: '여기 화장실 비밀번호가 뭐예요?', zh: '请问洗手间密码是多少？', nu: '한국 카페·식당 화장실 이용할 때 초필수 표현' },
        { cat: '식당·배달', ko: '이거 1인분만 주문 가능해요?', zh: '这个可以只点一人份吗？', nu: '혼밥하거나 여러 메뉴를 조금씩 시킬 때' },
        { cat: '올영·편의점', ko: '이거 제일 잘 나가는 거예요?', zh: '这款是最畅销的吗？', nu: '올리브영이나 매장에서 인기 상품을 물어볼 때' },
        { cat: '올영·편의점', ko: '테스트해 봐도 될까요?', zh: '我可以试用一下吗？', nu: '화장품이나 향수를 발라보기 전에 정중히 묻기' },
        { cat: '올영·편의점', ko: '민감성 피부에도 괜찮아요?', zh: '敏感肌也可以用吗？', nu: '스킨케어 제품 고를 때 꼭 물어보는 표현' },
        { cat: '올영·편의점', ko: '새 상품으로 꺼내주실 수 있어요?', zh: '可以帮我拿一件全新的吗？', nu: '진열품 말고 새 재고를 요청할 때' },
        { cat: '올영·편의점', ko: '봉투 하나 주세요', zh: '请给我一个袋子', nu: '편의점·마트에서 비닐봉투나 종이백을 살 때' },
        { cat: '올영·편의점', ko: '전자레인지에 데워주세요', zh: '请帮我用微波炉加热一下', nu: '편의점 도시락·삼각김밥 살 때 바로 쓰는 표현' },
        { cat: '올영·편의점', ko: '1+1 행사 상품 맞나요?', zh: '这个是买一送一的活动商品吗？', nu: '한국 편의점·올리브영 1+1 할인 확인할 때' },
        { cat: '올영·편의점', ko: '택스 리펀(면세) 되나요?', zh: '这里可以办理退税吗？', nu: '여권 보여주고 즉시 환급(면세) 받을 때 필수 표현' },
        { cat: '올영·편의점', ko: '다른 색깔이나 사이즈 있어요?', zh: '有其他颜色或尺码吗？', nu: '옷가게나 신발 매장에서 재고 물어볼 때' },
        { cat: '올영·편의점', ko: '입어봐도 될까요?', zh: '我可以试穿一下吗？', nu: '피팅룸에서 옷을 입어보기 전에 묻는 표현' },
        { cat: '올영·편의점', ko: '교환이나 환불 가능해요?', zh: '可以换货或者退货吗？', nu: '구매 전 교환·환불 규정을 미리 확인할 때' },
        { cat: '올영·편의점', ko: '이거 선물 포장 되나요?', zh: '这个可以帮忙做礼品包装吗？', nu: '기념일이나 가족 선물 살 때 유용한 표현' },
        { cat: '가족·예절', ko: '처음 뵙겠습니다, 징찬이에요', zh: '初次见面，我是靖灿', nu: '어른이나 수완의 친구·가족을 처음 만날 때 완벽한 첫인사' },
        { cat: '가족·예절', ko: '초대해 주셔서 정말 감사합니다', zh: '非常感谢您的邀请', nu: '집이나 식사 자리에 초대받았을 때 감동 주는 인사' },
        { cat: '가족·예절', ko: '정말 맛있게 잘 먹었습니다!', zh: '真的吃得非常香，谢谢款待！', nu: '한국에서 식사 후 최고의 칭찬이자 예절 인사' },
        { cat: '가족·예절', ko: '제가 도와드릴까요?', zh: '需要我帮忙吗？', nu: '상을 차리거나 정리할 때 센스 있게 건네는 말' },
        { cat: '가족·예절', ko: '한국어 아직 서툴지만 열심히 배우고 있어요', zh: '韩语还不太熟练，但我正在努力学习', nu: '어른들께 예쁨받는 겸손하고 따뜻한 표현' },
        { cat: '가족·예절', ko: '신경 써주셔서 너무 감사합니다', zh: '谢谢您这么费心照顾', nu: '배려나 선물을 받았을 때 진심을 전하는 말' },
        { cat: '가족·예절', ko: '다음에 또 놀러 올게요!', zh: '下次再来找您玩！', nu: '헤어질 때 따뜻하게 다음을 기약하는 인사' },
        { cat: '가족·예절', ko: '항상 건강 잘 챙기세요', zh: '请您一直保重身体', nu: '부모님이나 어른께 드리는 가장 기분 좋은 안부' },
        { cat: '가족·예절', ko: '편하게 말 놓으셔도 돼요', zh: '您可以直接说平语，不用客气', nu: '수완의 친한 친구들과 빨리 친해지고 싶을 때' },
        { cat: '가족·예절', ko: '만나서 정말 반가웠어요', zh: '见到您真的很高兴', nu: '처음 만난 자리에서 헤어질 때 쓰는 깔끔한 마무리' },
        { cat: '가족·예절', ko: '먼저 들어가 보겠습니다', zh: '那我就先告辞回去啦', nu: '자리에서 먼저 일어날 때 쓰는 정중한 한국식 인사' },
        { cat: '가족·예절', ko: '덕분에 오늘 너무 즐거웠어요', zh: '托您的福，今天玩得特别开心', nu: '함께한 시간에 고마움을 표현하는 최고의 문장' },
        { cat: '택시·길찾기', ko: '기사님, 여기로 가주세요', zh: '师傅，请去这个地址', nu: '지도 앱 주소를 보여주며 택시 탈 때 바로 쓰는 말' },
        { cat: '택시·길찾기', ko: '저 앞 모퉁이에서 내려주세요', zh: '请在前面拐角处放我下车', nu: '목적지 근처에서 정확히 내리고 싶을 때' },
        { cat: '택시·길찾기', ko: '트렁크 좀 열어주실 수 있어요?', zh: '可以帮我开一下后备箱吗？', nu: '캐리어를 싣거나 내릴 때 필수 공항·택시 표현' },
        { cat: '택시·길찾기', ko: '이 버스 ○○역 가나요?', zh: '这趟公交车去○○站吗？', nu: '버스 타기 전 기사님께 목적지를 확인할 때' },
        { cat: '택시·길찾기', ko: '몇 번 출구로 나가야 해요?', zh: '我应该从几号出口出去？', nu: '한국 지하철 출구가 많아서 길 찾을 때 필수 질문' },
        { cat: '택시·길찾기', ko: '여기서 걸어서 얼마나 걸려요?', zh: '从这里走过去大概要多久？', nu: '택시를 탈지 걸어갈지 결정할 때 물어보는 말' },
        { cat: '택시·길찾기', ko: '체크인하고 싶어요', zh: '我想办理入住', nu: '호텔·숙소 프런트에서 사용하는 기본 표현' },
        { cat: '택시·길찾기', ko: '체크아웃 후에 짐 좀 맡길 수 있어요?', zh: '退房后可以暂时寄存行李吗？', nu: '마지막 날 편하게 여행하기 위한 초필수 표현' },
        { cat: '택시·길찾기', ko: '창가 자리로 부탁드려요', zh: '麻烦给我靠窗的座位', nu: '비행기 체크인이나 기차·카페 좌석 요청할 때' },
        { cat: '택시·길찾기', ko: '이 근처에 현지인 맛집 있어요?', zh: '这附近有当地人推荐的美食店吗？', nu: '진짜 맛있는 동네 맛집을 추천받을 때' },
        { cat: '택시·길찾기', ko: '티머니 카드 충전해 주세요', zh: '请帮我给T-money交通卡充值', nu: '편의점에서 한국 교통카드 충전할 때 바로 쓰는 말' },
        { cat: '리액션·화해', ko: '헐, 진짜?! 대박이다!', zh: '哇，真的吗？！太厉害了！', nu: '깜짝 놀랐을 때 한국인들이 가장 많이 쓰는 리액션' },
        { cat: '리액션·화해', ko: '완전 인정! 너무 공감해', zh: '完全认同！太有共鸣了', nu: '상대방 말에 100% 동의하며 맞장구칠 때' },
        { cat: '리액션·화해', ko: '장난이지? 설마~', zh: '开玩笑的吧？不会吧~', nu: '상대방이 장난칠 때 귀엽게 받아치는 표현' },
        { cat: '리액션·화해', ko: '에이, 거짓말~', zh: '哎呀，骗人~', nu: '칭찬을 듣거나 믿기지 않을 때 애교 섞인 반응' },
        { cat: '리액션·화해', ko: '센스 대박이다!', zh: '太有眼力见/太贴心了！', nu: '상대방이 기분 좋은 배려를 해줬을 때 최고 칭찬' },
        { cat: '리액션·화해', ko: '아깝다, 다음엔 꼭 하자!', zh: '好可惜，下次一定要做到！', nu: '아쉬운 상황에서 긍정적으로 분위기를 바꿀 때' },
        { cat: '리액션·화해', ko: '삐졌어? 화 풀어~', zh: '生气啦？别气了嘛~', nu: '상대방이 토라졌을 때 다정하게 풀어주는 표현' },
        { cat: '리액션·화해', ko: '내가 잘못했어, 미안해', zh: '是我不对，对不起', nu: '솔직하게 사과하며 갈등을 바로 푸는 표현' },
        { cat: '리액션·화해', ko: '많이 서운했지? 앞으로 더 잘할게', zh: '很委屈吧？以后我会对你更好的', nu: '상대방의 서운한 마음을 따뜻하게 어루만질 때' },
        { cat: '리액션·화해', ko: '오해하지 마, 그런 뜻 아니었어', zh: '别误会，我不是那个意思', nu: '언어 차이로 오해가 생겼을 때 차분히 설명하는 말' },
        { cat: '리액션·화해', ko: '진심이야, 나 믿어줘', zh: '我是真心的，相信我', nu: '진지하게 진심을 전하고 싶을 때' },
        { cat: '리액션·화해', ko: '우리 화해하자, 얼른 안아줘', zh: '我们和好吧，快抱抱我', nu: '다툼을 달콤하게 마무리하는 커플 치트키' },
        { cat: '병원·약국', ko: '머리가 너무 아파요', zh: '我头好痛', nu: '병원이나 약국에서 두통 증상을 바로 설명할 때' },
        { cat: '병원·약국', ko: '열이 나는 것 같아요', zh: '我好像发烧了', nu: '몸살·감기 기운이 있을 때 필수 표현' },
        { cat: '병원·약국', ko: '배가 아프고 소화가 안 돼요', zh: '肚子痛，有点消化不良', nu: '여행 중 체했거나 배탈 났을 때 약국에서 바로 쓰는 말' },
        { cat: '병원·약국', ko: '감기약 하나 주세요', zh: '请给我一盒感冒药', nu: '한국 약국에서 종합감기약을 살 때 가장 간단한 표현' },
        { cat: '병원·약국', ko: '진통제 있어요?', zh: '有止痛药吗？', nu: '타이레놀 등 진통제가 필요할 때 바로 묻는 표현' },
        { cat: '병원·약국', ko: '약 알레르기가 있어요', zh: '我对药物过敏', nu: '병원 진료 전 안전을 위해 꼭 알려야 하는 표현' },
        { cat: '병원·약국', ko: '식후 30분에 먹는 건가요?', zh: '是饭后30分钟吃吗？', nu: '약국에서 복용법을 정확히 확인할 때' },
        { cat: '병원·약국', ko: '반창고랑 연고 주세요', zh: '请给我创可贴和药膏', nu: '살짝 다치거나 발이 까졌을 때 약국 필수 표현' },
        { cat: '병원·약국', ko: '도와주세요, 길을 잃었어요', zh: '请帮帮我，我迷路了', nu: '낯선 곳에서 정중하게 도움을 요청할 때' },
        { cat: '병원·약국', ko: '핸드폰을 잃어버렸어요', zh: '我的手机丢了', nu: '분실물 신고나 긴급 상황에 바로 쓰는 표현' },
        { cat: '병원·약국', ko: '중국어 가능한 분 계세요?', zh: '请问这里有会说中文的人吗？', nu: '공항·병원·면세점에서 중국어 안내가 필요할 때' },
        { cat: '데이트·사진', ko: '사진 한 장만 찍어주실 수 있어요?', zh: '可以帮我们拍一张照片吗？', nu: '여행지에서 커플 사진을 부탁할 때 최고의 정중 표현' },
        { cat: '데이트·사진', ko: '전신 나오게 찍어주세요', zh: '麻烦帮我拍出全身', nu: '배경과 전신이 예쁘게 나오게 부탁할 때' },
        { cat: '데이트·사진', ko: '인생네컷 찍으러 가자!', zh: '我们去拍人生四格大头贴吧！', nu: '한국 데이트 필수 코스인 네컷 사진 제안할 때' },
        { cat: '데이트·사진', ko: '오늘 코디 너무 예쁘다!', zh: '你今天的穿搭太好看了！', nu: '만나자마자 상대방 옷차림을 센스 있게 칭찬할 때' },
        { cat: '데이트·사진', ko: '손 잡아도 돼?', zh: '我可以牵你的手吗？', nu: '산책할 때 설렘을 더해주는 다정한 한마디' },
        { cat: '데이트·사진', ko: '야경 보러 가자', zh: '我们去看夜景吧', nu: '저녁 데이트로 로맨틱한 장소를 제안할 때' },
        { cat: '데이트·사진', ko: '카페에서 잠깐 쉬었다 갈까?', zh: '要不要去咖啡店歇一会儿再走？', nu: '많이 걸었을 때 상대방을 배려하는 자연스러운 제안' },
        { cat: '데이트·사진', ko: '앞머리만 조금 다듬어 주세요', zh: '请只帮我修剪一点刘海', nu: '한국 미용실에서 원하는 스타일을 정확히 말할 때' },
        { cat: '데이트·사진', ko: '너무 짧게 자르지 말아 주세요', zh: '请不要剪得太短', nu: '미용실에서 실패를 막는 초필수 표현' },
        { cat: '데이트·사진', ko: '이 사진처럼 자연스럽게 해주세요', zh: '请帮我做得像这张照片一样自然', nu: '헤어·메이크업·네일샵에서 사진 보여주며 쓰는 말' },
        { cat: '데이트·사진', ko: '우리 커플템 맞추자!', zh: '我们买情侣款吧！', nu: '커플 옷·반지·키링을 함께 고를 때' },
        { cat: '데이트·사진', ko: '오늘 데이트 진짜 최고였어!', zh: '今天的约会真的太棒了！', nu: '데이트를 기분 좋게 마무리하는 최고의 한마디' },
        { cat: '일상·스몰토크', ko: '오늘 야근해야 할 것 같아', zh: '我今天好像要加班了', nu: '퇴근이 늦어질 때 미리 알려주는 현실 직장 표현' },
        { cat: '일상·스몰토크', ko: '회의 끝나고 바로 연락할게', zh: '开完会马上联系你', nu: '업무 중 잠시 자리를 비울 때 안심시키는 말' },
        { cat: '일상·스몰토크', ko: '이번 주말에 뭐 할 거야?', zh: '这周末打算干嘛呀？', nu: '주말 계획을 자연스럽게 물어볼 때' },
        { cat: '일상·스몰토크', ko: '비 올 것 같으니까 우산 챙겨', zh: '好像要下雨了，记得带伞', nu: '날씨를 챙겨주는 세심하고 따뜻한 한마디' },
        { cat: '일상·스몰토크', ko: '오늘 날씨 진짜 좋다!', zh: '今天天气真好呀！', nu: '기분 좋은 날 가볍게 대화를 시작할 때' },
        { cat: '일상·스몰토크', ko: '미세먼지 심하니까 마스크 써', zh: '雾霾挺严重的，记得戴口罩', nu: '한국·중국 모두에서 건강을 챙기는 실전 표현' },
        { cat: '일상·스몰토크', ko: '요즘 푹 빠진 드라마 있어?', zh: '最近有在追什么剧吗？', nu: '취향 이야기를 나누며 대화 이어가기 좋은 질문' },
        { cat: '일상·스몰토크', ko: '이 노래 완전 내 취향이야', zh: '这首歌完全是我的菜', nu: '음악이나 카페 분위기를 칭찬할 때 쓰는 MZ 표현' },
        { cat: '일상·스몰토크', ko: '시간 진짜 빨리 간다', zh: '时间过得真快呀', nu: '즐거운 시간이나 하루가 금방 갔을 때 공감 표현' },
        { cat: '일상·스몰토크', ko: '잠깐 쉬면서 해, 무리하지 마', zh: '歇一会儿再做吧，别太累了', nu: '열심히 일하거나 공부하는 연인을 응원할 때' },
        { cat: '일상·스몰토크', ko: '커피 한 잔 마시고 힘내자!', zh: '喝杯咖啡打起精神吧！', nu: '오후에 나른할 때 귀엽게 에너지를 불어넣는 말' },
        { cat: '일상·스몰토크', ko: '다음 주에 꼭 영상통화하자!', zh: '下周一定要打视频电话哦！', nu: '바쁜 일정 속에서도 다정하게 약속을 잡을 때' },
        { cat: '연애·애정', ko: '오늘따라 유난히 보고 싶네', zh: '今天怎么格外想你呢', nu: '평소보다 오늘 특히 보고 싶을 때 전하는 달달한 말' },
        { cat: '연애·애정', ko: '네 생각하다가 웃었어', zh: '想着你就笑了', nu: '일상 중에 문득 상대가 떠올라 미소 지었을 때' },
        { cat: '연애·애정', ko: '얼른 안아주고 싶다', zh: '真想快点抱抱你', nu: '장거리 연애에서 만나고 싶은 마음을 표현할 때' },
        { cat: '연애·애정', ko: '네가 내 편이라서 든든해', zh: '有你站在我这边真踏实', nu: '상대의 지지에 고마움과 안정감을 표현할 때' },
        { cat: '연애·애정', ko: '목소리 들으니까 살 것 같다', zh: '听到你的声音感觉活过来了', nu: '피곤한 하루 끝에 통화하며 기분이 확 풀릴 때' },
        { cat: '연애·애정', ko: '꿈에서 만나자', zh: '梦里见吧', nu: '자기 전에 다정하게 인사할 때' },
        { cat: '연애·애정', ko: '우리 다음엔 어디 갈까?', zh: '我们下次去哪里玩？', nu: '다음 데이트나 여행을 설레며 계획할 때' },
        { cat: '연애·애정', ko: '너랑 있으면 시간이 너무 빨리 가', zh: '和你在一起时间过得太快了', nu: '함께 있는 시간이 너무 즐거울 때' },
        { cat: '카톡·전화', ko: '지금 잠깐 통화돼?', zh: '现在方便通个电话吗？', nu: '전화 걸기 전에 상대 상황을 가볍게 물을 때' },
        { cat: '카톡·전화', ko: '방금 일어났어', zh: '我刚醒', nu: '아침에 눈 뜨자마자 톡 보낼 때' },
        { cat: '카톡·전화', ko: '집에 잘 들어갔어?', zh: '安全到家了吗？', nu: '상대가 귀가했는지 챙겨 물어볼 때' },
        { cat: '카톡·전화', ko: '지금 가는 중이야', zh: '我现在正在路上', nu: '약속 장소로 이동 중일 때' },
        { cat: '카톡·전화', ko: '조금만 기다려 금방 갈게', zh: '稍微等我一下，马上到', nu: '몇 분 늦거나 곧 도착할 때' },
        { cat: '카톡·전화', ko: '배터리 거의 다 됐어', zh: '手机快没电了', nu: '충전기가 없어 연락이 끊길 수 있을 때' },
        { cat: '카톡·전화', ko: '이따가 다시 연락할게', zh: '我待会儿再联系你', nu: '잠깐 바빠서 나중에 톡이나 전화하겠다고 할 때' },
        { cat: '카톡·전화', ko: '사진 좀 보내줘', zh: '把照片发给我一下吧', nu: '같이 찍은 사진이나 일상 사진을 받고 싶을 때' },
        { cat: '맛집·카페', ko: '얼음 조금만 넣어 주세요', zh: '请少放点冰', nu: '음료에 얼음을 적게 넣고 싶을 때' },
        { cat: '맛집·카페', ko: '덜 달게 해 주세요', zh: '请做得少甜一点', nu: '당도를 낮춰서 주문하고 싶을 때' },
        { cat: '맛집·카페', ko: '디카페인으로 변경 되나요?', zh: '可以换成低因咖啡吗？', nu: '늦은 시간에 카페인 없는 커피를 주문할 때' },
        { cat: '맛집·카페', ko: '와이파이 잘 터지나요?', zh: '这里Wi-Fi信号好吗？', nu: '카페에서 인터넷 연결 상태를 물을 때' },
        { cat: '맛집·카페', ko: '화장실 비밀번호가 뭐예요?', zh: '请问洗手间密码是多少？', nu: '한국 카페·상가 화장실 이용 시 초필수 표현' },
        { cat: '식당·배달', ko: '여기 반찬 조금만 더 주세요', zh: '请再给加一点小菜', nu: '한국 식당에서 무료 밑반찬 리필 요청할 때' },
        { cat: '식당·배달', ko: '안 맵게 해 주세요', zh: '请不要放辣', nu: '매운 음식을 못 먹을 때 미리 요청하는 표현' },
        { cat: '식당·배달', ko: '고수는 빼 주세요', zh: '请不要放香菜', nu: '원하지 않는 재료를 빼달라고 할 때' },
        { cat: '식당·배달', ko: '앞접시 좀 주실 수 있나요?', zh: '可以给我几个小碟子吗？', nu: '음식을 덜어 먹을 개인 접시를 요청할 때' },
        { cat: '식당·배달', ko: '물 좀 주실 수 있나요?', zh: '可以给我点水吗？', nu: '식당에서 물을 부탁할 때' },
        { cat: '식당·배달', ko: '물티슈 하나만 주세요', zh: '请给我一张湿巾', nu: '식사 전후 손을 닦고 싶을 때' },
        { cat: '식당·배달', ko: '문 앞에 두고 벨 눌러 주세요', zh: '请放在门口然后按门铃', nu: '배달 앱 요청사항에 자주 쓰는 문장' },
        { cat: '식당·배달', ko: '카드 결제 되나요?', zh: '可以刷卡吗？', nu: '계산 전 카드 가능 여부를 확인할 때' },
        { cat: '올영·편의점', ko: '영수증은 버려 주세요', zh: '小票不用了，帮我扔掉吧', nu: '영수증이 필요 없을 때 자연스럽게 말하는 표현' },
        { cat: '올영·편의점', ko: '전자레인지에 데워도 되나요?', zh: '可以用微波炉加热吗？', nu: '편의점 도시락이나 삼각김밥을 데울 때' },
        { cat: '올영·편의점', ko: '이거 원플러스원 맞나요?', zh: '这个是买一送一吗？', nu: '편의점·올리브영 1+1 행사 상품 확인할 때' },
        { cat: '올영·편의점', ko: '테스터 써 봐도 되나요?', zh: '这个试用装可以试一下吗？', nu: '올리브영·화장품 가게에서 발색·향 테스트할 때' },
        { cat: '올영·편의점', ko: '제일 잘 나가는 제품이 뭐예요?', zh: '这里卖得最好的是哪一款？', nu: '인기 상품 추천을 받고 싶을 때' },
        { cat: '올영·편의점', ko: '민감성 피부에 괜찮은 걸로 추천해 주세요', zh: '请推荐一款适合敏感肌的', nu: '스킨케어 제품 추천받을 때' },
        { cat: '올영·편의점', ko: '교통카드 충전해 주세요', zh: '请帮我给交通卡充值', nu: '편의점에서 티머니 충전할 때' },
        { cat: '쇼핑·긴급', ko: '입어 봐도 되나요?', zh: '可以试穿一下吗？', nu: '옷가게에서 피팅룸 이용을 물을 때' },
        { cat: '쇼핑·긴급', ko: '한 사이즈 큰 거 있나요?', zh: '有大一码的吗？', nu: '옷이나 신발 사이즈를 바꿀 때' },
        { cat: '쇼핑·긴급', ko: '다른 색깔도 있어요?', zh: '还有别的颜色吗？', nu: '다른 컬러 재고를 물어볼 때' },
        { cat: '쇼핑·긴급', ko: '새 상품으로 주실 수 있나요?', zh: '可以给我拿一件全新的吗？', nu: '디스플레이 제품 대신 새 재고를 요청할 때' },
        { cat: '쇼핑·긴급', ko: '교환이나 환불 되나요?', zh: '请问可以退换货吗？', nu: '구매 전 교환·환불 규정을 확인할 때' },
        { cat: '쇼핑·긴급', ko: '세일 기간이 언제까지예요?', zh: '打折活动到什么时候？', nu: '할인 마감일을 물어볼 때' },
        { cat: '쇼핑·긴급', ko: '여권 보여 드리면 되나요?', zh: '出示护照就可以吗？', nu: '즉시 면세(택스 리펀) 받을 때' },
        { cat: '쇼핑·긴급', ko: '지갑을 잃어버렸어요', zh: '我的钱包丢了', nu: '긴급 상황에서 도움을 요청할 때' },
        { cat: '택시·길찾기', ko: '여기서 세워 주세요', zh: '请在这里停一下', nu: '택시에서 목적지에 도착해 내릴 때' },
        { cat: '택시·길찾기', ko: '트렁크 좀 열어 주세요', zh: '请帮忙开一下后备箱', nu: '캐리어를 싣거나 내릴 때' },
        { cat: '택시·길찾기', ko: '여기서 얼마나 걸려요?', zh: '从这里过去要多久？', nu: '소요 시간을 확인할 때' },
        { cat: '택시·길찾기', ko: '이 주소로 가 주세요', zh: '请去这个地址', nu: '택시 기사님께 휴대폰 지도를 보여주며 말할 때' },
        { cat: '택시·길찾기', ko: '어느 쪽으로 가야 해요?', zh: '应该往哪边走？', nu: '갈림길이나 출구에서 방향을 물을 때' },
        { cat: '택시·길찾기', ko: '환승은 어디서 해요?', zh: '请问在哪里换乘？', nu: '지하철·버스 갈아타는 곳을 물을 때' },
        { cat: '택시·길찾기', ko: '이 버스 시청 가나요?', zh: '这趟公交车去市政厅吗？', nu: '버스 타기 전 행선지를 확인할 때' },
        { cat: '여행·교통', ko: '짐 보관하는 곳이 어디예요?', zh: '请问寄存行李的地方在哪里？', nu: '지하철역이나 공항 물품보관함을 찾을 때' },
        { cat: '여행·교통', ko: '체크인 시간보다 일찍 도착했어요', zh: '我比办理入住的时间早到了', nu: '호텔에 일찍 도착해 짐을 맡기거나 체크인 문의할 때' },
        { cat: '여행·교통', ko: '조식은 몇 시부터예요?', zh: '请问早餐几点开始？', nu: '호텔 조식 시간을 물어볼 때' },
        { cat: '여행·교통', ko: '수건 좀 더 주실 수 있나요?', zh: '可以再多给几条毛巾吗？', nu: '호텔 프런트에 추가 수건을 요청할 때' },
        { cat: '일상·스몰토크', ko: '오늘 너무 추워서 꽁꽁 얼겠어', zh: '今天太冷了快冻僵了', nu: '겨울 추위를 실감나게 표현할 때' },
        { cat: '일상·스몰토크', ko: '주말에 뭐 할 거야?', zh: '周末打算干嘛呀？', nu: '상대의 주말 계획을 물을 때' },
        { cat: '일상·스몰토크', ko: '요즘 너무 바빠서 정신없어', zh: '最近太忙了忙得晕头转向', nu: '일이나 일정이 몰려 정신없을 때' },
        { cat: '일상·스몰토크', ko: '오늘 점심 뭐 먹었어?', zh: '今天午饭吃的什么？', nu: '한국인들이 가장 자주 묻는 안부 인사' },
        { cat: '일상·스몰토크', ko: '퇴근하고 뭐 해?', zh: '下班后干嘛呀？', nu: '퇴근 후 저녁 시간을 물어볼 때' },
        { cat: '일상·스몰토크', ko: '잠을 제대로 못 잤어', zh: '没睡好觉', nu: '피곤하거나 수면 부족일 때' },
        { cat: '일상·스몰토크', ko: '커피 한 잔 마시고 힘내자', zh: '喝杯咖啡打起精神吧', nu: '오후에 나른할 때 서로 응원할 때' },
        { cat: '리액션·화해', ko: '헐 진짜 대박이다!', zh: '天呐真的太厉害了！', nu: '놀랍거나 감탄할 때 쓰는 가장 흔한 리액션' },
        { cat: '리액션·화해', ko: '완전 인정!', zh: '完全认同！说得太对了！', nu: '상대방 말에 격하게 공감할 때' },
        { cat: '리액션·화해', ko: '그럴 수도 있지 뭐', zh: '那也是有可能的嘛，没关系', nu: '상대방 실수를 쿨하게 넘겨주며 안심시킬 때' },
        { cat: '리액션·화해', ko: '내가 표현을 잘못했어 미안해', zh: '是我表达得不好，对不起', nu: '오해가 생겼을 때 부드럽게 사과할 때' },
        { cat: '리액션·화해', ko: '화 풀고 나 좀 봐줘', zh: '别生气啦，看看我嘛', nu: '삐진 연인을 애교 있게 달랠 때' },
        { cat: '리액션·화해', ko: '다 내 잘못이야 미안해', zh: '都是我的错，对不起', nu: '솔직하게 먼저 사과하고 화해할 때' },
        { cat: '리액션·화해', ko: '오해하지 마 그런 뜻 아니었어', zh: '别误会，我不是那个意思', nu: '말뜻이 잘못 전달됐을 때 해명할 때' },
        { cat: '감정·위로', ko: '오늘 하루도 정말 고생 많았어', zh: '今天一天也真的辛苦你了', nu: '하루를 마친 상대에게 건네는 따뜻한 위로' },
        { cat: '감정·위로', ko: '너무 무리하지 말고 쉬어', zh: '别太勉强自己，好好休息', nu: '지친 상대를 걱정하며 챙길 때' },
        { cat: '감정·위로', ko: '네 잘못 아니니까 자책하지 마', zh: '不是你的错，别自责了', nu: '속상해하는 상대를 다독여줄 때' },
        { cat: '감정·위로', ko: '잘될 거니까 걱정 마', zh: '一定会顺利的，别担心', nu: '중요한 일을 앞두고 불안해할 때' },
        { cat: '감정·위로', ko: '항상 네 편이야', zh: '我永远站在你这边', nu: '흔들림 없는 응원과 신뢰를 전할 때' },
        { cat: '가족·예절', ko: '초대해 주셔서 감사합니다', zh: '非常感谢您的邀请', nu: '상대방 집이나 식사 자리에 초대받았을 때' },
        { cat: '가족·예절', ko: '정말 맛있게 잘 먹었습니다', zh: '真的非常好吃，我吃得很饱', nu: '식사 후 어른들께 예의 바르게 인사할 때' },
        { cat: '가족·예절', ko: '별거 아니지만 작은 선물 준비했어요', zh: '不成敬意，准备了一点小礼物', nu: '부모님·지인에게 선물을 건넬 때' },
        { cat: '가족·예절', ko: '건강 잘 챙기세요', zh: '请多保重身体', nu: '어른들께 헤어지며 안부를 전할 때' },
        { cat: '병원·약국', ko: '목이 칼칼하고 기침이 나요', zh: '嗓子干痒还咳嗽', nu: '감기 증상을 약사에게 설명할 때' },
        { cat: '병원·약국', ko: '속이 안 좋고 체한 것 같아요', zh: '胃不舒服，好像积食了', nu: '소화제를 살 때 자주 쓰는 표현' },
        { cat: '병원·약국', ko: '식후에 먹는 약인가요?', zh: '这是饭后吃的药吗？', nu: '약 복용 방법을 확인할 때' },
        { cat: '데이트·사진', ko: '사진 한 장만 찍어 주실 수 있나요?', zh: '可以帮我们拍张照吗？', nu: '지나가는 분께 커플 사진 부탁할 때' },
        { cat: '데이트·사진', ko: '여기 분위기 진짜 예쁘다', zh: '这里氛围真的好美啊', nu: '예쁜 카페·야경 데이트 장소에 갔을 때' },
        { cat: '데이트·사진', ko: '이 각도가 제일 잘 나온다!', zh: '这个角度拍出来最好看！', nu: '서로 인생샷 찍어줄 때' },
        { cat: '연애·애정', ko: '목소리 들으니까 너무 좋다', zh: '听到你的声音真好', pron: 'mok-so-ri deu-reu-ni-kka neo-mu jo-ta', nu: '전화 연결됐을 때 따뜻한 표현', nuZh: '接通电话时温暖的表达' },
        { cat: '연애·애정', ko: '영상통화할 수 있어?', zh: '能打视频电话吗？', pron: 'yeong-sang-tong-hwa-hal su i-sseo', nu: '화상 통화 가능 여부 묻기', nuZh: '询问是否方便打视频' },
        { cat: '연애·애정', ko: '오늘 꿈에 나와줘', zh: '今晚来我梦里吧', pron: 'o-neul kku-me na-wa-jwo', nu: '자기 전 달콤한 인사', nuZh: '睡前甜蜜道别' },
        { cat: '연애·애정', ko: '네 생각밖에 안 나', zh: '满脑子都是你', pron: 'ne saeng-gak-ba-kke an na', nu: '보고 싶을 때 진심 표현', nuZh: '想念时的真心告白' },
        { cat: '연애·애정', ko: '우리 빨리 다시 만나자', zh: '我们快点再见面吧', pron: 'u-ri ppal-li da-si man-na-ja', nu: '장거리 커플 다음 만남 기약', nuZh: '异地恋约定下次见面' },
        { cat: '연애·애정', ko: '나만 바라봐 줘', zh: '只看着我就好', pron: 'na-man ba-ra-bwa jwo', nu: '애교 섞인 사랑 표현', nuZh: '撒娇式的爱意表达' },
        { cat: '연애·애정', ko: '네가 있어서 든든해', zh: '有你在我很踏实', pron: 'ne-ga i-sseo-seo deun-deun-hae', nu: '의지되는 마음을 전할 때', nuZh: '表达有对方在很安心' },
        { cat: '연애·애정', ko: '항상 내 편이 돼줘서 고마워', zh: '谢谢你总是站在我这边', pron: 'hang-sang nae pyeo-ni dwae-jwo-seo go-ma-wo', nu: '고마운 마음을 전할 때', nuZh: '表达感谢对方的支持' },
        { cat: '연애·애정', ko: '오늘 사진 한 장 보내줘', zh: '今天发一张照片给我吧', pron: 'o-neul sa-jin han jang bo-nae-jwo', nu: '일상 셀카 부탁할 때', nuZh: '想要对方发日常自拍' },
        { cat: '연애·애정', ko: '웃는 얼굴이 제일 예뻐', zh: '笑起来的样子最好看', pron: 'un-neun eol-gu-ri je-il ye-ppeo', nu: '상대방 칭찬할 때', nuZh: '夸奖对方笑容好看' },
        { cat: '연애·애정', ko: '내 마음이 느껴져?', zh: '能感受到我的心意吗？', pron: 'nae ma-eu-mi neu-kkyeo-jyeo', nu: '진심을 전할 때', nuZh: '传达真心时使用' },
        { cat: '연애·애정', ko: '하루 종일 네 생각했어', zh: '一整天都在想你', pron: 'ha-ru jong-il ne saeng-gak-hae-sseo', nu: '퇴근 후 다정한 인사', nuZh: '下班后的甜蜜问候' },
        { cat: '연애·애정', ko: '손 꼭 잡고 걷고 싶다', zh: '好想紧紧牵着你的手散步', pron: 'son kkok jap-go geot-go sip-da', nu: '데이트 그리워할 때', nuZh: '怀念一起牵手散步' },
        { cat: '연애·애정', ko: '네가 웃으면 나도 행복해', zh: '你笑我也跟着开心', pron: 'ne-ga u-seu-myeon na-do haeng-bok-hae', nu: '사랑 가득한 표현', nuZh: '充满爱意的暖心话' },
        { cat: '연애·애정', ko: '기다려줘서 고마워', zh: '谢谢你等我', pron: 'gi-da-ryeo-jwo-seo go-ma-wo', nu: '기다려 준 연인에게 감사', nuZh: '感谢恋人耐心等待' },
        { cat: '연애·애정', ko: '잠깐이라도 얼굴 보고 싶어', zh: '哪怕看一眼你的脸也好', pron: 'jam-kka-ni-ra-do eol-gul bo-go si-peo', nu: '바쁠 때 잠깐 영통하자고 할 때', nuZh: '忙里偷闲想视频见一面' },
        { cat: '연애·애정', ko: '나한테 제일 소중한 사람이야', zh: '你是我最珍贵的人', pron: 'na-han-te je-il so-jung-han sa-ra-mi-ya', nu: '깊은 애정 표현', nuZh: '深情告白表达' },
        { cat: '연애·애정', ko: '오늘따라 더 보고 싶네', zh: '今天格外想你呢', pron: 'o-neul-tta-ra deo bo-go sip-ne', nu: '유독 그리운 날', nuZh: '某天特别想念时' },
        { cat: '연애·애정', ko: '푹 쉬고 내일 또 연락해', zh: '好好休息，明天再联系哦', pron: 'puk swi-go nae-il tto yeol-la-kae', nu: '밤에 다정하게 마무리할 때', nuZh: '晚上温柔结束聊天' },
        { cat: '일상·인사', ko: '지금 출근하는 길이야', zh: '现在正在上班路上', pron: 'ji-geum chul-geun-ha-neun gi-ri-ya', nu: '출근길 공유', nuZh: '分享上班途中' },
        { cat: '일상·인사', ko: '드디어 퇴근했어!', zh: '终于下班啦！', pron: 'deu-di-eo toe-geun-hae-sseo', nu: '퇴근 기쁨 공유', nuZh: '分享下班的喜悦' },
        { cat: '일상·인사', ko: '오늘 날씨가 엄청 춥네', zh: '今天天气好冷啊', pron: 'o-neul nal-ssi-ga eom-cheong chum-ne', nu: '추운 날 안부 인사', nuZh: '天冷时的问候' },
        { cat: '일상·인사', ko: '따뜻하게 입고 나가', zh: '穿暖和点再出门', pron: 'tta-tteu-ta-ge ip-go na-ga', nu: '옷차림 챙겨줄 때', nuZh: '叮嘱对方穿暖和' },
        { cat: '일상·인사', ko: '비 오니까 우산 챙겨', zh: '下雨了记得带伞', pron: 'bi o-ni-kka u-san chaeng-gyeo', nu: '비 오는 날 챙겨주기', nuZh: '下雨天提醒带伞' },
        { cat: '일상·인사', ko: '잠깐 씻고 올게', zh: '我去洗个澡马上回来', pron: 'jam-kkan ssit-go ol-ge', nu: '자리 비울 때 미리 말하기', nuZh: '暂时离开去洗澡前说一声' },
        { cat: '일상·인사', ko: '머리 말리고 연락할게', zh: '吹完头发联系你', pron: 'meo-ri mal-li-go yeol-la-kal-ge', nu: '씻고 나서 연락 예고', nuZh: '洗完头后预告联系' },
        { cat: '일상·인사', ko: '오늘 좀 피곤하네', zh: '今天有点累呢', pron: 'o-neul jom pi-go-na-ne', nu: '피곤함을 털어놓을 때', nuZh: '向对方倾诉疲惫' },
        { cat: '일상·인사', ko: '주말에 뭐 할 계획이야?', zh: '周末有什么计划？', pron: 'ju-ma-re mwo hal gye-hoe-gi-ya', nu: '주말 일정 묻기', nuZh: '询问周末安排' },
        { cat: '일상·인사', ko: '방금 집에 도착했어', zh: '刚刚到家了', pron: 'bang-geum ji-be do-cha-kae-sseo', nu: '귀가 완료 보고', nuZh: '报备已安全到家' },
        { cat: '일상·인사', ko: '오늘 일찍 자야겠다', zh: '今天得早点睡了', pron: 'o-neul il-jjik ja-ya-get-da', nu: '일찍 잘 때', nuZh: '打算早睡时说' },
        { cat: '일상·인사', ko: '낮잠 좀 자고 왔어', zh: '刚睡了个午觉', pron: 'nat-jam jom ja-go wa-sseo', nu: '낮잠 후 연락할 때', nuZh: '午睡醒来后说' },
        { cat: '일상·인사', ko: '오늘 기분이 아주 좋아', zh: '今天心情超级好', pron: 'o-neul gi-bu-ni a-ju jo-a', nu: '좋은 기분 나누기', nuZh: '分享好心情' },
        { cat: '일상·인사', ko: '주말이 기다려진다', zh: '好期待周末呀', pron: 'ju-ma-ri gi-da-ryeo-jin-da', nu: '평일에 주말 기다릴 때', nuZh: '工作日期待周末' },
        { cat: '맛집·카페', ko: '여기 진짜 맛집이야', zh: '这家店真的超好吃', pron: 'yeo-gi jin-jja mat-ji-bi-ya', nu: '맛집 추천할 때', nuZh: '推荐好吃的宝藏店' },
        { cat: '맛집·카페', ko: '얼음 적게 넣어 주세요', zh: '请少放点冰', pron: 'eo-reum jeok-ge neo-eo ju-se-yo', nu: '음료 커스텀 요청', nuZh: '点单要求少冰' },
        { cat: '맛집·카페', ko: '덜 달게 해주세요', zh: '请做少糖一点', pron: 'deol dal-ge hae-ju-se-yo', nu: '당도 조절 요청', nuZh: '点单要求少糖' },
        { cat: '맛집·카페', ko: '추천 메뉴가 뭐예요?', zh: '推荐菜单是什么？', pron: 'chu-cheon me-nyu-ga mwo-ye-yo', nu: '식당에서 인기 메뉴 묻기', nuZh: '在餐厅询问招牌菜' },
        { cat: '맛집·카페', ko: '안 맵게 해주세요', zh: '请不要放辣', pron: 'an maep-ge hae-ju-se-yo', nu: '매운맛 빼달라고 할 때', nuZh: '要求做成不辣' },
        { cat: '맛집·카페', ko: '고수 빼주세요', zh: '请不要放香菜', pron: 'go-su ppae-ju-se-yo', nu: '못 먹는 재료 빼기', nuZh: '要求不要放香菜' },
        { cat: '맛집·카페', ko: '물 좀 더 주세요', zh: '请再给点水', pron: 'mul jom deo ju-se-yo', nu: '식당에서 물 추가 요청', nuZh: '在餐厅要加水' },
        { cat: '맛집·카페', ko: '반찬 좀 더 주실 수 있나요?', zh: '可以再加点小菜吗？', pron: 'ban-chan jom deo ju-sil su in-na-yo', nu: '한국 식당 반찬 리필', nuZh: '韩国餐厅续小菜' },
        { cat: '맛집·카페', ko: '앞접시 하나만 주세요', zh: '请给我一个小盘子', pron: 'ap-jeop-si ha-na-man ju-se-yo', nu: '나눠 먹을 접시 요청', nuZh: '要分食用的小碟子' },
        { cat: '맛집·카페', ko: '계산서 좀 주세요', zh: '请给我账单', pron: 'gye-san-seo jom ju-se-yo', nu: '식사 후 계산 요청', nuZh: '饭后买单' },
        { cat: '맛집·카페', ko: '배 터질 것 같아', zh: '撑得快走不动了', pron: 'bae teo-jil geot ga-ta', nu: '아주 배부를 때', nuZh: '吃得特别撑时' },
        { cat: '맛집·카페', ko: '오늘 저녁 뭐 먹을까?', zh: '今天晚饭吃什么好呢？', pron: 'o-neul jeo-nyeok mwo meo-geul-kka', nu: '메뉴 고민할 때', nuZh: '纠结晚饭吃什么' },
        { cat: '맛집·카페', ko: '야식으로 치킨 어때?', zh: '夜宵吃炸鸡怎么样？', pron: 'ya-si-geu-ro chi-kin eo-ttae', nu: '야식 제안할 때', nuZh: '提议吃炸鸡当夜宵' },
        { cat: '맛집·카페', ko: '웨이팅이 얼마나 걸려요?', zh: '排队大概要等多久？', pron: 'we-i-ting-i eol-ma-na geol-lyeo-yo', nu: '인기 맛집 대기 시간 묻기', nuZh: '问网红店排队时长' },
        { cat: '맛집·카페', ko: '입에서 살살 녹는다', zh: '入口即化呀', pron: 'i-be-seo sal-sal nong-neun-da', nu: '고기·디저트 극찬', nuZh: '夸赞美食入口即化' },
        { cat: '여행·교통', ko: '비행기 연착됐어', zh: '飞机延误了', pron: 'bi-haeng-gi yeon-chak-dwae-sseo', nu: '공항에서 상황 공유', nuZh: '在机场报备航班延误' },
        { cat: '여행·교통', ko: '방금 비행기에서 내렸어', zh: '刚刚下飞机', pron: 'bang-geum bi-haeng-gi-e-seo nae-ryeo-sseo', nu: '도착 소식 전하기', nuZh: '报备刚下飞机' },
        { cat: '여행·교통', ko: '짐 찾고 나가는 중이야', zh: '正在取行李往外走', pron: 'jim chat-go na-ga-neun jung-i-ya', nu: '입국장 나오기 직전', nuZh: '取行李准备出关' },
        { cat: '여행·교통', ko: '출구 앞에서 기다릴게', zh: '我在出口前面等你', pron: 'chul-gu a-pe-seo gi-da-ril-ge', nu: '마중 나갔을 때', nuZh: '去接机时说' },
        { cat: '여행·교통', ko: '체크인 몇 시부터예요?', zh: '几点开始办理入住？', pron: 'che-keu-in myeot si-bu-teo-ye-yo', nu: '호텔 프런트 문의', nuZh: '在酒店前台问入住时间' },
        { cat: '여행·교통', ko: '짐 먼저 맡길 수 있나요?', zh: '可以先寄存行李吗？', pron: 'jim meon-jeo mat-gil su in-na-yo', nu: '체크인 전 짐 보관', nuZh: '入住前先寄放行李' },
        { cat: '여행·교통', ko: '사진 한 장 찍어 주실 수 있나요?', zh: '可以帮我们拍张照吗？', pron: 'sa-jin han jang jji-geo ju-sil su in-na-yo', nu: '여행지 커플 사진 부탁', nuZh: '请路人帮忙拍合照' },
        { cat: '여행·교통', ko: '여기서 환승해야 돼요?', zh: '要在这里换乘吗？', pron: 'yeo-gi-seo hwan-seung-hae-ya dwae-yo', nu: '지하철 갈아타기 확인', nuZh: '确认地铁是否在此换乘' },
        { cat: '여행·교통', ko: '야경이 정말 예쁘다', zh: '夜景真的好美呀', pron: 'ya-gyeong-i jeong-mal ye-ppeu-da', nu: '상하이·서울 야경 감탄', nuZh: '赞叹城市夜景' },
        { cat: '여행·교통', ko: '날씨가 여행하기 딱 좋다', zh: '天气正适合旅行', pron: 'nal-ssi-ga yeo-haeng-ha-gi ttak jo-ta', nu: '화창한 여행날', nuZh: '天气晴朗适合出游' },
        { cat: '여행·교통', ko: '기념품 사러 가자', zh: '去买纪念品吧', pron: 'gi-nyeom-pum sa-reo ga-ja', nu: '여행 쇼핑 제안', nuZh: '提议买伴手礼' },
        { cat: '여행·교통', ko: '여권 꼭 챙겼지?', zh: '护照肯定带了吧？', pron: 'yeo-gwon kkok chaeng-gyeot-ji', nu: '출국 전 필수 확인', nuZh: '出国前确认带护照' },
        { cat: '여행·교통', ko: '면세점 구경하자', zh: '去逛逛免税店吧', pron: 'myeon-se-jeom gu-gyeong-ha-ja', nu: '공항에서 시간 보낼 때', nuZh: '在机场逛免税店' },
        { cat: '여행·교통', ko: '길 잃어버릴 뻔했어', zh: '差点迷路了', pron: 'gil i-reo-beo-ril ppeon-hae-sseo', nu: '초행길 에피소드 공유', nuZh: '分享差点走丢的经历' },
        { cat: '감정·위로', ko: '오늘 정말 수고 많았어', zh: '今天真的辛苦啦', pron: 'o-neul jeong-mal su-go ma-na-sseo', nu: '하루 끝 따뜻한 위로', nuZh: '一天结束时的暖心安慰' },
        { cat: '감정·위로', ko: '너무 무리하지 마', zh: '别太勉强自己哦', pron: 'neo-mu mu-ri-ha-ji ma', nu: '건강·체력 걱정할 때', nuZh: '心疼对方别太累' },
        { cat: '감정·위로', ko: '다 잘 될 거야, 걱정 마', zh: '一切都会顺利的，别担心', pron: 'da jal doel geo-ya geok-jeong ma', nu: '불안해하는 연인 안심시키기', nuZh: '安抚焦虑的恋人' },
        { cat: '감정·위로', ko: '내가 항상 응원하고 있어', zh: '我一直都在支持你', pron: 'nae-ga hang-sang eung-wo-na-go i-sseo', nu: '힘을 주고 싶을 때', nuZh: '给对方打气加油' },
        { cat: '감정·위로', ko: '무슨 일 있었어? 다 말해봐', zh: '发生什么事了？都跟我说说', pron: 'mu-seun il i-sseo-sseo da mal-hae-bwa', nu: '기분 안 좋아 보일 때', nuZh: '察觉对方心情不好时' },
        { cat: '감정·위로', ko: '속상했겠다, 이리 와', zh: '肯定很委屈吧，过来抱抱', pron: 'sok-sang-haet-get-da i-ri wa', nu: '다정하게 토닥여줄 때', nuZh: '温柔哄委屈的对方' },
        { cat: '감정·위로', ko: '네 잘못이 아니야', zh: '不是你的错哦', pron: 'ne jal-mo-si a-ni-ya', nu: '자책하는 상대 위로하기', nuZh: '安慰自责的对方' },
        { cat: '감정·위로', ko: '잠시 쉬어가도 괜찮아', zh: '稍微休息一下也没关系', pron: 'jam-si swi-eo-ga-do gwaen-cha-na', nu: '지쳤을 때 여유 주기', nuZh: '鼓励累了就歇一歇' },
        { cat: '감정·위로', ko: '너는 충분히 잘하고 있어', zh: '你已经做得足够好了', pron: 'neo-neun chung-bu-ni jal-ha-go i-sseo', nu: '자신감 불어넣기', nuZh: '肯定对方的努力' },
        { cat: '감정·위로', ko: '혼자 끙끙 앓지 마', zh: '别一个人闷在心里', pron: 'hon-ja kkeung-kkeung al-chi ma', nu: '고민 나눠달라고 할 때', nuZh: '希望对方有事别硬扛' },
        { cat: '감정·위로', ko: '오늘 맛있는 거 먹고 기분 풀자', zh: '今天吃点好吃的散散心吧', pron: 'o-neul ma-sin-neun geo meok-go gi-bun pul-ja', nu: '기분 전환 제안', nuZh: '提议吃顿好的放松心情' },
        { cat: '감정·위로', ko: '네가 최고인 거 알지?', zh: '你知道你是最棒的吧？', pron: 'ne-ga choe-go-in geo al-ji', nu: '기운 북돋아 줄 때', nuZh: '夸赞并鼓舞对方' },
        { cat: '감정·위로', ko: '아프지 말고 건강 챙겨', zh: '别生病，照顾好身体', pron: 'a-peu-ji mal-go geon-gang chaeng-gyeo', nu: '아플 때 걱정 표현', nuZh: '提醒注意身体别生病' },
        { cat: '감정·위로', ko: '약 챙겨 먹었어?', zh: '记得吃药了吗？', pron: 'yak chaeng-gyeo meo-geo-sseo', nu: '감기·몸살 걸렸을 때', nuZh: '生病时叮嘱吃药' },
        { cat: '감정·위로', ko: '따뜻한 물 많이 마셔', zh: '多喝点温水哦', pron: 'tta-tteu-tan mul ma-ni ma-syeo', nu: '아플 때 다정한 챙김', nuZh: '温柔提醒多喝热水' },
        { cat: '감정·위로', ko: '조금만 더 힘내자!', zh: '再稍微加把劲吧！', pron: 'jo-geum-man deo him-nae-ja', nu: '함께 화이팅할 때', nuZh: '一起互相打气' },
        { cat: '감정·위로', ko: '기분 좀 나아졌어?', zh: '心情好一点了吗？', pron: 'gi-bun jom na-a-jyeo-sseo', nu: '위로 후 상태 살피기', nuZh: '关心心情是否好转' },
        { cat: '감정·위로', ko: '언제든 나한테 기대도 돼', zh: '随时都可以依靠我', pron: 'eon-je-deun na-han-te gi-dae-do dwae', nu: '든든한 버팀목 표현', nuZh: '表达永远可以依靠' },
        { cat: '감정·위로', ko: '울고 싶으면 그냥 울어도 돼', zh: '想哭的话就哭出来吧', pron: 'ul-go si-peu-myeon geu-nyang u-reo-do dwae', nu: '감정 솔직하게 풀게 해주기', nuZh: '温柔允许对方宣泄情绪' },
        { cat: '감정·위로', ko: '내일은 분명 더 좋은 날일 거야', zh: '明天一定会是更好的一天', pron: 'nae-i-reun bun-myeong deo jo-eun na-ril geo-ya', nu: '희망적인 마무리 위로', nuZh: '充满希望的睡前安慰' },
        { cat: '쇼핑·긴급', ko: '이거 입어 봐도 돼요?', zh: '这件可以试穿吗？', pron: 'i-geo i-beo bwa-do dwae-yo', nu: '옷가게 피팅 문의', nuZh: '服装店询问试穿' },
        { cat: '쇼핑·긴급', ko: '다른 색깔도 있나요?', zh: '有其他颜色吗？', pron: 'da-reun saek-kkal-do in-na-yo', nu: '색상 옵션 물어보기', nuZh: '询问有没有别的颜色' },
        { cat: '쇼핑·긴급', ko: '한 사이즈 큰 걸로 주세요', zh: '请给我大一号的', pron: 'han sa-i-jeu keun geol-lo ju-se-yo', nu: '사이즈 교환 요청', nuZh: '要求换大一码' },
        { cat: '쇼핑·긴급', ko: '한 사이즈 작은 거 있나요?', zh: '有小一号的吗？', pron: 'han sa-i-jeu ja-geun geo in-na-yo', nu: '작은 사이즈 문의', nuZh: '询问小一码' },
        { cat: '쇼핑·긴급', ko: '면세(택스리펀) 되나요?', zh: '可以退税吗？', pron: 'myeon-se doe-na-yo', nu: '한국 쇼핑 세금 환급', nuZh: '韩国购物问能否退税' },
        { cat: '쇼핑·긴급', ko: '영수증 버려 주세요', zh: '小票帮我扔掉吧', pron: 'yeong-su-jeung beo-ryeo ju-se-yo', nu: '영수증 필요 없을 때', nuZh: '不需要小票时说' },
        { cat: '쇼핑·긴급', ko: '가장 잘 나가는 제품이 뭐예요?', zh: '最畅销的产品是哪款？', pron: 'ga-jang jal na-ga-neun je-pu-mi mwo-ye-yo', nu: '올리브영·화장품 가게', nuZh: '在美妆店问爆款' },
        { cat: '쇼핑·긴급', ko: '조금만 둘러볼게요', zh: '我先随便看看', pron: 'jo-geum-man dul-leo-bol-ge-yo', nu: '직원 응대에 정중히 답하기', nuZh: '礼貌回复店员先逛逛' },
        { cat: '쇼핑·긴급', ko: '배터리가 거의 다 닳았어', zh: '手机快没电了', pron: 'bae-teo-ri-ga geo-ui da da-ra-sseo', nu: '연락 끊기기 전 알림', nuZh: '手机快关机前提前说' },
        { cat: '쇼핑·긴급', ko: '보조배터리 빌릴 수 있나요?', zh: '可以租充电宝吗？', pron: 'bo-jo-bae-teo-ri bil-lil su in-na-yo', nu: '카페·식당 충전 문의', nuZh: '询问能否借充电宝' },
        { cat: '쇼핑·긴급', ko: '화장실이 어디예요?', zh: '洗手间在哪里？', pron: 'hwa-jang-si-ri eo-di-ye-yo', nu: '필수 생존 질문', nuZh: '必备生存问路' },
        { cat: '쇼핑·긴급', ko: '두통약 하나 주세요', zh: '请给我一盒头痛药', pron: 'du-tong-yak ha-na ju-se-yo', nu: '약국에서 증상별 구매', nuZh: '在药店买止痛药' },
        { cat: '쇼핑·긴급', ko: '소화제 있어요?', zh: '有消化药吗？', pron: 'so-hwa-je i-sseo-yo', nu: '체했을 때 약국 표현', nuZh: '吃撑或消化不良买药' },
        { cat: '쇼핑·긴급', ko: '지갑을 두고 왔어', zh: '忘带钱包了', pron: 'ji-ga-beul du-go wa-sseo', nu: '당황스러운 긴급 상황', nuZh: '忘带钱包的紧急情况' },
        { cat: '쇼핑·긴급', ko: '천천히 말씀해 주세요', zh: '请说慢一点', pron: 'cheon-cheon-hi mal-sseum-hae ju-se-yo', nu: '한국어가 빠를 때 정중히 요청', nuZh: '对方语速太快时礼貌请求放慢' },
        { cat: '쇼핑·긴급', ko: '다시 한 번만 말해 주세요', zh: '请再说一遍好吗', pron: 'da-si han beon-man mal-hae ju-se-yo', nu: '못 알아들었을 때', nuZh: '没听清请对方重复' },
        { cat: '카톡·전화', ko: '답장이 늦어서 미안해', zh: '不好意思回复晚了', pron: 'dap-jang-i neu-jeo-seo mi-an-hae', nu: '늦게 답장할 때 기본 예의', nuZh: '晚回消息时道歉' },
        { cat: '카톡·전화', ko: '지금 잠깐 통화 가능해?', zh: '现在方便通个电话吗？', pron: 'ji-geum jam-kkan tong-hwa ga-neung-hae', nu: '전화 걸기 전 확인', nuZh: '打电话前先问方便吗' },
        { cat: '카톡·전화', ko: '잠시만, 바로 전화할게', zh: '等一下，我马上打给你', pron: 'jam-si-man ba-ro jeon-hwa-hal-ge', nu: '곧 전화할 때', nuZh: '马上回电话' },
        { cat: '카톡·전화', ko: '잘 안 들려, 다시 말해줘', zh: '听不太清，再说一遍', pron: 'jal an deul-lyeo da-si mal-hae-jwo', nu: '통화 음질 안 좋을 때', nuZh: '通话信号不好听不清' },
        { cat: '카톡·전화', ko: '화면이 잠깐 멈췄어', zh: '画面卡了一下', pron: 'hwa-myeo-ni jam-kkan meom-chwo-sseo', nu: '영상통화 렉 걸릴 때', nuZh: '视频通话卡顿' },
        { cat: '카톡·전화', ko: '오타 났어 ㅋㅋㅋ', zh: '打错字啦哈哈哈', pron: 'o-ta na-sseo', nu: '오타 정정할 때', nuZh: '打错字自我调侃' },
        { cat: '카톡·전화', ko: '진짜 대박이다!', zh: '真的太厉害了！', pron: 'jin-jja dae-ba-gi-da', nu: '놀라움·감탄 리액션', nuZh: '表示惊叹太牛了' },
        { cat: '카톡·전화', ko: '완전 내 스타일이야', zh: '完全是我的菜', pron: 'wan-jeon nae seu-ta-i-ri-ya', nu: '취향 저격일 때', nuZh: '超级符合自己审美' },
        { cat: '카톡·전화', ko: '인정! 완전 공감해', zh: '赞同！太有共鸣了', pron: 'in-jeong wan-jeon gong-ga-mae', nu: '강하게 동의할 때', nuZh: '强烈赞同有共鸣' },
        { cat: '카톡·전화', ko: '헐, 진짜로?', zh: '天呐，真的假的？', pron: 'heol jin-jja-ro', nu: '깜짝 놀랄 때 젊은 표현', nuZh: '年轻人常用的惊讶语气' },
        { cat: '카톡·전화', ko: '꿀팁 고마워!', zh: '谢谢你的宝藏攻略！', pron: 'kkul-tip go-ma-wo', nu: '유용한 정보 얻었을 때', nuZh: '感谢实用小技巧' },
        { cat: '카톡·전화', ko: '센스 넘친다 진짜', zh: '真的太有眼力见了', pron: 'sen-seu neom-chin-da jin-jja', nu: '상대방 센스 칭찬', nuZh: '夸对方特别懂事有品位' },
        { cat: '카톡·전화', ko: '오늘 텐션 좋네!', zh: '今天状态真嗨呀！', pron: 'o-neul ten-syeon jon-ne', nu: '기분 좋아 보일 때', nuZh: '夸对方今天兴致很高' },
        { cat: '카톡·전화', ko: '알겠어, 바로 갈게!', zh: '知道了，马上就到！', pron: 'al-ge-sseo ba-ro gal-ge', nu: '약속 장소 이동할 때', nuZh: '马上赶往约会地点' },
        { cat: '카톡·전화', ko: '거의 다 왔어!', zh: '快到了！', pron: 'geo-ui da wa-sseo', nu: '도착 직전 카톡', nuZh: '即将到达见面点' },
        { cat: '카톡·전화', ko: '링크 보내줄게 확인해봐', zh: '发链接给你看看', pron: 'ling-keu bo-nae-jul-ge hwa-gin-hae-bwa', nu: '맛집·영상 링크 공유', nuZh: '分享链接让对方看' },
        { cat: '카톡·전화', ko: '이거 보니까 네 생각났어', zh: '看到这个就想起你了', pron: 'i-geo bo-ni-kka ne saeng-gang-na-sseo', nu: '귀여운 짤·사진 보낼 때', nuZh: '发可爱图片或视频时说' },
        { cat: '카톡·전화', ko: '녹음해서 보내줘!', zh: '录段语音发给我吧！', pron: 'no-geu-mae-seo bo-nae-jwo', nu: '음성 메시지 부탁', nuZh: '撒娇想要语音消息' },
        { cat: '카톡·전화', ko: '읽씹하지 마~', zh: '别已读不回呀~', pron: 'ik-ssi-pa-ji ma', nu: '장난스럽게 답장 재촉', nuZh: '开玩笑催回复' },
        { cat: '카톡·전화', ko: '나중에 자세히 얘기해줘', zh: '回头详细跟我说说', pron: 'na-jung-e ja-se-hi yae-gi-hae-jwo', nu: '바쁠 때 나중에 듣겠다고 하기', nuZh: '忙时约好之后细聊' },
        { cat: '식당·배달', ko: '배달 시켜 먹을까?', zh: '点个外卖吃吧？', pron: 'bae-dal si-kyeo meo-geul-kka', nu: '집에서 편하게 먹을 때', nuZh: '在家提议点外卖' },
        { cat: '식당·배달', ko: '일회용 수저 필요 없어요', zh: '不需要一次性餐具', pron: 'il-hoe-yong su-jeo pi-ryo eop-seo-yo', nu: '배달 옵션 선택', nuZh: '点外卖勾选环保选项' },
        { cat: '식당·배달', ko: '리뷰 이벤트 참여할게요', zh: '我参加好评活动', pron: 'ri-byu i-ben-teu cha-myeo-hal-ge-yo', nu: '한국 배달 문화 핵심', nuZh: '韩国特色外卖好评送小吃' },
        { cat: '식당·배달', ko: '삼겹살에 냉면 먹자', zh: '吃五花肉配冷面吧', pron: 'sam-gyeop-sa-re naeng-myeon meok-ja', nu: '한국 대표 데이트 조합', nuZh: '韩国经典烤肉配冷面' },
        { cat: '식당·배달', ko: '볶음밥 꼭 볶아 먹어야지', zh: '一定要炒饭吃呀', pron: 'bo-kkeum-bap kkok bo-kka meo-geo-ya-ji', nu: '한국 철판요리 국룰', nuZh: '韩国铁板料理必备收尾炒饭' },
        { cat: '식당·배달', ko: '국물이 끝내준다', zh: '汤头绝了', pron: 'gung-mu-ri kkeun-nae-jun-da', nu: '따뜻한 국물 요리 감탄', nuZh: '夸赞汤汁特别鲜美' },
        { cat: '식당·배달', ko: '여기 공기밥 하나 추가요', zh: '这里加一碗米饭', pron: 'yeo-gi gong-gi-bap ha-na chu-ga-yo', nu: '식당 추가 주문', nuZh: '餐厅加米饭' },
        { cat: '식당·배달', ko: '사이다 하나 주세요', zh: '请给我一瓶雪碧', pron: 'sa-i-da ha-na ju-se-yo', nu: '음료 추가 주문', nuZh: '点碳酸饮料' },
        { cat: '식당·배달', ko: '너무 짜지 않고 딱 좋아', zh: '不会太咸刚刚好', pron: 'neo-mu jja-ji an-ko ttak jo-a', nu: '간이 딱 맞을 때', nuZh: '夸赞咸淡适中' },
        { cat: '식당·배달', ko: '양이 생각보다 엄청 많다', zh: '分量比想象中多好多', pron: 'yang-i saeng-gak-bo-da eom-cheong man-ta', nu: '푸짐한 음식 볼 때', nuZh: '感叹菜量很足' },
        { cat: '식당·배달', ko: '다음에 여기 또 오자', zh: '下次再来这家吧', pron: 'da-eu-me yeo-gi tto o-ja', nu: '만족스러운 식사 후', nuZh: '满意这顿饭约定下次再来' },
        { cat: '식당·배달', ko: '내가 맛있게 구워줄게', zh: '我来帮你烤得香香的', pron: 'nae-ga ma-sit-ge gu-wo-jul-ge', nu: '고깃집에서 다정하게', nuZh: '烤肉店贴心帮烤' },
        { cat: '식당·배달', ko: '뜨거우니까 호호 불어 먹어', zh: '很烫哦吹一吹再吃', pron: 'tteu-geo-u-ni-kka ho-ho bu-reo meo-geo', nu: '다정한 식사 챙김', nuZh: '温柔提醒小心烫' },
        { cat: '식당·배달', ko: '한 입만 먹어봐!', zh: '尝一口看看！', pron: 'han im-man meo-geo-bwa', nu: '내 음식 나눠줄 때', nuZh: '把自己的美食分对方一口' },
        { cat: '가족·예절', ko: '만나서 반갑습니다', zh: '很高兴见到您', pron: 'man-na-seo ban-gap-seum-ni-da', nu: '처음 인사할 때 정중한 표현', nuZh: '初次见面的礼貌问候' },
        { cat: '가족·예절', ko: '잘 먹겠습니다!', zh: '我开动啦！', pron: 'jal meok-get-seum-ni-da', nu: '식사 시작 전 필수 예절', nuZh: '韩国饭前必说礼貌语' },
        { cat: '가족·예절', ko: '작은 선물 준비했어요', zh: '准备了一点小礼物', pron: 'ja-geun seon-mul jun-bi-hae-sseo-yo', nu: '선물 건넬 때 겸손한 표현', nuZh: '送礼物时的谦虚说法' },
        { cat: '가족·예절', ko: '실례합니다', zh: '打扰一下', pron: 'sil-lye-ham-ni-da', nu: '지나가거나 질문할 때', nuZh: '借过或开口询问时' },
        { cat: '가족·예절', ko: '신경 써 주셔서 감사해요', zh: '谢谢您的费心照顾', pron: 'sin-gyeong sseo ju-syeo-seo gam-sa-hae-yo', nu: '배려받았을 때 정중한 감사', nuZh: '感谢对方的细心关照' },
        { cat: '가족·예절', ko: '조심히 들어가세요', zh: '回去路上小心', pron: 'jo-si-mi deu-reo-ga-se-yo', nu: '헤어질 때 정중한 인사', nuZh: '告别时的礼貌叮嘱' },
        { cat: '가족·예절', ko: '건강하게 잘 지내셨어요?', zh: '您身体一直都好吗？', pron: 'geon-gang-ha-ge jal ji-nae-syeo-sseo-yo', nu: '어른께 안부 여쭙기', nuZh: '向长辈问好' },
        { cat: '가족·예절', ko: '새해 복 많이 받으세요!', zh: '新年快乐，万事如意！', pron: 'sae-hae bok ma-ni ba-deu-se-yo', nu: '설날·새해 인사', nuZh: '春节及新年祝福' },
        { cat: '가족·예절', ko: '생일 진심으로 축하해요!', zh: '衷心祝您生日快乐！', pron: 'saeng-il jin-si-meu-ro chu-ka-hae-yo', nu: '정중한 생일 축하', nuZh: '礼貌的生日祝福' },
        { cat: '가족·예절', ko: '다음에 또 뵙겠습니다', zh: '期待下次再见', pron: 'da-eu-me tto boep-get-seum-ni-da', nu: '어른·지인과 작별 인사', nuZh: '与长辈或朋友礼貌道别' },
        { cat: '가족·예절', ko: '한국어 아직 배우는 중이에요', zh: '我还在学韩语中呢', pron: 'han-gu-geo a-jik bae-u-neun jung-i-e-yo', nu: '한국인 만났을 때 자연스러운 소개', nuZh: '认识韩国朋友时的可爱介绍' },
        { cat: '가족·예절', ko: '편하게 말씀하셔도 돼요', zh: '您不用拘束，随便说就好', pron: 'pyeon-ha-ge mal-sseum-ha-syeo-do dwae-yo', nu: '분위기 편하게 만들 때', nuZh: '让气氛更轻松' },
        { cat: '가족·예절', ko: '도움 주셔서 정말 감사해요', zh: '非常感谢您的帮助', pron: 'do-um ju-syeo-seo jeong-mal gam-sa-hae-yo', nu: '도움받았을 때', nuZh: '得到帮助时表达感谢' },
        { cat: '리액션·화해', ko: '오해가 있었던 것 같아', zh: '好像有点误会了', pron: 'o-hae-ga i-sseot-deon geot ga-ta', nu: '차분하게 오해 풀 때', nuZh: '冷静解开误会' },
        { cat: '리액션·화해', ko: '내 말은 그런 뜻이 아니었어', zh: '我不是那个意思', pron: 'nae ma-reun geu-reon tteu-si a-ni-eo-sseo', nu: '말뜻 설명할 때', nuZh: '解释自己的本意' },
        { cat: '리액션·화해', ko: '내가 좀 더 조심할게', zh: '我以后会更注意的', pron: 'nae-ga jom deo jo-si-mal-ge', nu: '진심 어린 사과 후 약속', nuZh: '真诚道歉并承诺改进' },
        { cat: '리액션·화해', ko: '우리 싸우지 말고 얘기하자', zh: '我们别吵架，好好聊聊吧', pron: 'u-ri ssa-u-ji mal-go yae-gi-ha-ja', nu: '건강하게 대화로 풀기', nuZh: '提议和平沟通' },
        { cat: '리액션·화해', ko: '화 풀렸어? 이제 웃어줘', zh: '消气了吗？笑一个嘛', pron: 'hwa pul-lyeo-sseo i-je u-seo-jwo', nu: '애교로 화해 신청', nuZh: '撒娇求和好' },
        { cat: '리액션·화해', ko: '내가 맛있는 거 사줄게, 화 풀어', zh: '我请你吃好吃的，别生气啦', pron: 'nae-ga ma-sin-neun geo sa-jul-ge hwa pu-reo', nu: '맛있는 걸로 달래기', nuZh: '用美食哄开心' },
        { cat: '리액션·화해', ko: '진심으로 미안해', zh: '我是真心道歉的', pron: 'jin-si-meu-ro mi-an-hae', nu: '진정성 있는 사과', nuZh: '诚恳道歉' },
        { cat: '리액션·화해', ko: '앞으로는 바로바로 말할게', zh: '以后有事我立刻跟你说', pron: 'a-peu-ro-neun ba-ro-ba-ro mal-hal-ge', nu: '소통 약속하기', nuZh: '承诺以后及时沟通' },
        { cat: '리액션·화해', ko: '서로 조금씩 맞춰가자', zh: '我们慢慢互相磨合吧', pron: 'seo-ro jo-geum-ssik mat-chwo-ga-ja', nu: '성숙한 연애 대화', nuZh: '成熟的恋爱磨合' },
        { cat: '리액션·화해', ko: '역시 너밖에 없다', zh: '果然还是你最好', pron: 'yeok-si neo-ba-kke eop-da', nu: '감동받았을 때 리액션', nuZh: '感动时夸对方最好' },
        { cat: '리액션·화해', ko: '어떻게 그렇게 귀여워?', zh: '你怎么能这么可爱？', pron: 'eo-tteo-ke geu-reo-ke gwi-yeo-wo', nu: '귀여워 죽겠을 때', nuZh: '觉得对方超级可爱' },
        { cat: '리액션·화해', ko: '심쿵했잖아!', zh: '让我心动了一下！', pron: 'sim-kung-haet-ja-na', nu: '설렜을 때 유행어', nuZh: '表达心动小鹿乱撞' },
        { cat: '리액션·화해', ko: '진짜 웃겨 죽겠어', zh: '真的笑死我了', pron: 'jin-jja ut-gyeo juk-ge-sseo', nu: '빵 터졌을 때', nuZh: '笑到停不下来' },
        { cat: '리액션·화해', ko: '말도 안 돼, 진짜 멋있다!', zh: '太不可思议了，好帅！', pron: 'mal-do an dwae jin-jja meo-sit-da', nu: '극찬 리액션', nuZh: '大力夸赞真棒' },
        { cat: '리액션·화해', ko: '기대 이상이야!', zh: '超出预期了！', pron: 'gi-dae i-sang-i-ya', nu: '생각보다 훨씬 좋을 때', nuZh: '比期待的还要好' },
        { cat: '올영·편의점', ko: '원플러스원 행사 중이에요?', zh: '现在是买一送一活动吗？', pron: 'won-peul-leo-seu-won haeng-sa jung-i-e-yo', nu: '한국 편의점 1+1 확인', nuZh: '韩国便利店确认买一送一' },
        { cat: '올영·편의점', ko: '나무젓가락 하나 주세요', zh: '请给我一双一次性筷子', pron: 'na-mu-jeot-ga-rak ha-na ju-se-yo', nu: '편의점 컵라면 먹을 때', nuZh: '便利店要筷子' },
        { cat: '올영·편의점', ko: '민감성 피부에 좋은 거 추천해 주세요', zh: '请推荐适合敏感肌的产品', pron: 'min-gam-seong pi-bu-e jo-eun geo chu-cheon-hae ju-se-yo', nu: '올리브영 스킨케어 상담', nuZh: '美妆店咨询敏感肌护肤' },
        { cat: '올영·편의점', ko: '촉촉한 수분크림 찾고 있어요', zh: '我在找滋润的保湿霜', pron: 'chok-cho-kan su-bun-keu-rim chat-go i-sseo-yo', nu: '화장품 고를 때', nuZh: '挑选保湿面霜' },
        { cat: '올영·편의점', ko: '이 컬러 저한테 어울릴까요?', zh: '这个色号适合我吗？', pron: 'i keol-leo jeo-han-te eo-ul-lil-kka-yo', nu: '립·블러셔 고를 때', nuZh: '选口红腮红色号' },
        { cat: '올영·편의점', ko: '만 원어치 충전해 주세요', zh: '请充一万韩元', pron: 'ma-nwo-neo-chi chung-jeon-hae ju-se-yo', nu: '금액 지정 충전', nuZh: '指定充值一万韩元' },
        { cat: '올영·편의점', ko: '현금영수증 안 해도 돼요', zh: '不用开现金收据', pron: 'hyeon-geum-yeong-su-jeung an hae-do dwae-yo', nu: '현금 결제 시 단골 질문 대답', nuZh: '现金支付常见对话' },
        { cat: '올영·편의점', ko: '포인트 적립할게요', zh: '我要积分', pron: 'po-in-teu jeong-ni-pal-ge-yo', nu: '멤버십 적립할 때', nuZh: '会员积分' },
        { cat: '택시·길찾기', ko: '안전벨트 꼭 매야지', zh: '一定要系好安全带哦', pron: 'an-jeon-bel-teu kkok mae-ya-ji', nu: '차 탈 때 챙겨주기', nuZh: '上车提醒系安全带' },
        { cat: '택시·길찾기', ko: '차가 좀 막히네요', zh: '路有点堵呢', pron: 'cha-ga jom ma-ki-ne-yo', nu: '이동 중 상황 공유', nuZh: '路上堵车报备' },
        { cat: '택시·길찾기', ko: '막차 몇 시예요?', zh: '末班车几点？', pron: 'mak-cha myeot si-ye-yo', nu: '밤에 대중교통 확인', nuZh: '问末班车时间' },
        { cat: '일상·인사', ko: '요즘 드라마 뭐 봐?', zh: '最近在看什么剧？', pron: 'yo-jeum deu-ra-ma mwo bwa', nu: '취미·드라마 수다', nuZh: '聊最近追的剧' },
        { cat: '일상·인사', ko: '이 노래 같이 듣자', zh: '一起听这首歌吧', pron: 'i no-rae ga-chi deut-ja', nu: '좋아하는 음악 공유', nuZh: '分享喜欢的歌' },
        { cat: '일상·인사', ko: '주말에 영화 보러 갈래?', zh: '周末一起去看电影吗？', pron: 'ju-ma-re yeong-hwa bo-reo gal-lae', nu: '영화 데이트 신청', nuZh: '约对方看电影' },
        { cat: '일상·인사', ko: '운동 다녀왔어!', zh: '刚运动回来！', pron: 'un-dong da-nyeo-wa-sseo', nu: '운동 인증 공유', nuZh: '分享运动打卡' },
        { cat: '일상·인사', ko: '오늘 한국어 공부 다 했어!', zh: '今天韩语学习打卡完成啦！', pron: 'o-neul han-gu-geo gong-bu da hae-sseo', nu: '학습실 완료 자랑하기', nuZh: '学习打卡完成炫耀' },
        { cat: '연애·애정', ko: '한국어 실력이 점점 느네!', zh: '韩语水平越来越棒啦！', pron: 'han-gu-geo sil-lyeo-gi jeom-jeom neu-ne', nu: '칭찬해 줄 때', nuZh: '夸奖韩语进步神速' },
        { cat: '연애·애정', ko: '발음이 진짜 원어민 같아', zh: '发音简直像韩国本地人', pron: 'ba-reu-mi jin-jja wo-neo-min ga-ta', nu: '발음 폭풍 칭찬', nuZh: '猛夸发音地道' },
        { cat: '연애·애정', ko: '나도 중국어 열심히 배울게', zh: '我也会努力学中文的', pron: 'na-do jung-gu-geo yeol-si-mi bae-ul-ge', nu: '서로 언어 배우는 다짐', nuZh: '互相学习语言的约定' },
        { cat: '연애·애정', ko: '중국어로 이건 뭐라고 해?', zh: '这个用中文怎么说？', pron: 'jung-gu-geo-ro i-geon mwo-ra-go hae', nu: '중국어 물어볼 때', nuZh: '向对方请教中文表达' },
        { cat: '연애·애정', ko: '한국어로 이건 뭐라고 해?', zh: '这个用韩语怎么说？', pron: 'han-gu-geo-ro i-geon mwo-ra-go hae', nu: '한국어 물어볼 때', nuZh: '向对方请教韩语表达' },
        { cat: '일상·인사', ko: '오늘 머리가 너무 잘 됐다', zh: '今天发型弄得好好看', pron: 'o-neul meo-ri-ga neo-mu jal dwaet-da', nu: '외모 칭찬·일상 수다', nuZh: '夸今天造型好看' },
        { cat: '일상·인사', ko: '새 옷 입었어? 잘 어울린다!', zh: '穿新衣服啦？好搭呀！', pron: 'sae o-si-beo-sseo jal eo-ul-lin-da', nu: '스타일 칭찬', nuZh: '夸新衣服好看' },
        { cat: '일상·인사', ko: '커피 한 잔 마시면서 쉬어', zh: '喝杯咖啡歇会儿吧', pron: 'keo-pi han jan ma-si-myeon-seo swi-eo', nu: '오후 휴식 챙김', nuZh: '下午提醒喝咖啡休息' },
        { cat: '일상·인사', ko: '점심 맛있게 먹어!', zh: '午饭吃得香香的哦！', pron: 'jeom-sim ma-sit-ge meo-geo', nu: '점심시간 다정한 인사', nuZh: '午饭时间暖心问候' },
        { cat: '일상·인사', ko: '저녁에 뭐 먹을지 골라놔', zh: '晚饭想吃啥先选好哦', pron: 'jeo-nyeo-ge mwo meo-geul-ji gol-la-nwa', nu: '저녁 약속 챙기기', nuZh: '提前约好晚饭' },
        { cat: '일상·인사', ko: '내일 일찍 일어나야 해', zh: '明天得早起呢', pron: 'nae-il il-jjik i-reo-na-ya hae', nu: '다음 날 일정 공유', nuZh: '分享明天要早起' },
        { cat: '일상·인사', ko: '알람 꼭 맞추고 자', zh: '记得定好闹钟再睡', pron: 'al-lam kkok mat-chu-go ja', nu: '다정한 밤 챙김', nuZh: '提醒定好闹钟' },
        { cat: '일상·인사', ko: '일어나면 바로 연락해 줘', zh: '醒了马上联系我哦', pron: 'i-reo-na-myeon ba-ro yeol-la-kae jwo', nu: '아침 연락 약속', nuZh: '约定醒来第一时间联系' },
        { cat: '일상·인사', ko: '오늘 하루도 화이팅이야!', zh: '今天也要元气满满哦！', pron: 'o-neul ha-ru-do hwa-i-ting-i-ya', nu: '아침 응원 인사', nuZh: '早晨打气问候' },
        { cat: '연애·애정', ko: '네 덕분에 오늘도 힘난다', zh: '多亏了你今天也充满力量', pron: 'ne deok-bu-ne o-neul-do him-nan-da', nu: '고마운 애정 표현', nuZh: '表达因对方充满动力' },
        { cat: '연애·애정', ko: '우리 다음 여행 어디로 갈까?', zh: '我们下次旅行去哪里好呢？', pron: 'u-ri da-eum yeo-haeng eo-di-ro gal-kka', nu: '여행 계획 세우기', nuZh: '一起规划下次旅行' },
        { cat: '연애·애정', ko: '같이 찍은 사진 또 보고 있어', zh: '我又在翻我们一起拍的照片了', pron: 'ga-chi jji-geun sa-jin tto bo-go i-sseo', nu: '추억 되새길 때', nuZh: '翻看合照想念对方' },
        { cat: '연애·애정', ko: '너랑 있으면 시간 가는 줄 몰라', zh: '和你在一起都忘记时间了', pron: 'neo-rang i-sseu-myeon si-gan ga-neun jul mol-la', nu: '함께할 때의 행복', nuZh: '表达在一起时光飞逝' },
        { cat: '연애·애정', ko: '다음엔 내가 상하이로 갈게', zh: '下次我飞去上海找你', pron: 'da-eu-men nae-ga sang-ha-i-ro gal-ge', nu: '장거리 방문 약속', nuZh: '约定下次飞去上海' },
        { cat: '연애·애정', ko: '다음엔 한국에서 오래 놀자', zh: '下次来韩国多玩几天吧', pron: 'da-eu-men han-gu-ge-seo o-rae nol-ja', nu: '한국 데이트 약속', nuZh: '约定下次来韩国长玩' },
        { cat: '맛집·카페', ko: '이 디저트 진짜 인생 맛이야', zh: '这个甜品好吃到封神', pron: 'i di-jeo-teu jin-jja in-saeng ma-si-ya', nu: '최고의 맛 표현', nuZh: '形容超级惊艳的美味' },
        { cat: '맛집·카페', ko: '따뜻한 라떼 한 잔 주세요', zh: '请给我一杯热拿铁', pron: 'tta-tteu-tan la-tte han jan ju-se-yo', nu: '카페 주문 표현', nuZh: '点热拿铁' },
        { cat: '맛집·카페', ko: '빨대 하나만 주세요', zh: '请给我一根吸管', pron: 'ppal-dae ha-na-man ju-se-yo', nu: '카페·편의점 요청', nuZh: '要吸管' },
        { cat: '맛집·카페', ko: '냅킨 좀 주실 수 있나요?', zh: '可以给我点纸巾吗？', pron: 'naep-kin jom ju-sil su in-na-yo', nu: '식당·카페 휴지 요청', nuZh: '要餐巾纸' },
        { cat: '맛집·카페', ko: '여기 자리 있나요?', zh: '这里有位子吗？', pron: 'yeo-gi ja-ri in-na-yo', nu: '식당 입장 시 확인', nuZh: '进店问有没有空座' },
        { cat: '맛집·카페', ko: '두 명이에요', zh: '两位', pron: 'du myeong-i-e-yo', nu: '식당 인원 말하기', nuZh: '告诉店员两位用餐' },
        { cat: '맛집·카페', ko: '메뉴판 좀 보여 주세요', zh: '请给我看一下菜单', pron: 'me-nyu-pan jom bo-yeo ju-se-yo', nu: '메뉴 요청하기', nuZh: '要菜单' },
        { cat: '맛집·카페', ko: '주문할게요!', zh: '我要点单！', pron: 'ju-mun-hal-ge-yo', nu: '직원 부를 때', nuZh: '喊服务员点单' },
        { cat: '맛집·카페', ko: '이거랑 이거 하나씩 주세요', zh: '请给我这个和这个各一份', pron: 'i-geo-rang i-geo ha-na-ssik ju-se-yo', nu: '가리키며 주문할 때', nuZh: '指着菜单各点一份' },
        { cat: '맛집·카페', ko: '너무 맛있어서 기절할 뻔', zh: '好吃到快晕过去了', pron: 'neo-mu ma-si-sseo-seo gi-jeol-hal ppeon', nu: '재밌는 극찬 표현', nuZh: '夸张形容太好吃' },
        { cat: '여행·교통', ko: '비행기 표 예매했어!', zh: '机票订好啦！', pron: 'bi-haeng-gi pyo ye-mae-hae-sseo', nu: '만남 확정 기쁜 소식', nuZh: '订好机票报喜' },
        { cat: '여행·교통', ko: '날짜가 빨리 왔으면 좋겠다', zh: '真希望那天快点到来', pron: 'nal-jja-ga ppal-li wa-sseu-myeon jo-ket-da', nu: '디데이 기다림', nuZh: '期待见面日快点到来' },
        { cat: '여행·교통', ko: '짐 싸는 중이야, 설렌다!', zh: '正在收拾行李，好激动！', pron: 'jim ssa-neun jung-i-ya seol-len-da', nu: '여행 전날 설렘', nuZh: '出发前夜收拾行李' },
        { cat: '여행·교통', ko: '날씨 앱 보니까 맑대', zh: '看天气预报说是晴天', pron: 'nal-ssi aep bo-ni-kka mak-dae', nu: '여행 날씨 체크', nuZh: '查旅行天气' },
        { cat: '여행·교통', ko: '지도 링크 보내줄게', zh: '把地图定位发给你', pron: 'ji-do ling-keu bo-nae-jul-ge', nu: '장소 공유할 때', nuZh: '发位置链接' },
        { cat: '감정·위로', ko: '오늘도 내 옆에 있어줘서 고마워', zh: '谢谢你今天也在我身边', pron: 'o-neul-do nae yeo-pe i-sseo-jwo-seo go-ma-wo', nu: '일상 속 감사 표현', nuZh: '感谢日常陪伴' },
        { cat: '감정·위로', ko: '별일 아니니까 너무 신경 쓰지 마', zh: '没什么大事别太放在心上', pron: 'byeo-ril a-ni-ni-kka neo-mu sin-gyeong sseu-ji ma', nu: '걱정 덜어줄 때', nuZh: '宽慰对方别太在意' },
        { cat: '감정·위로', ko: '네 이야기 듣는 게 제일 좋아', zh: '我最喜欢听你说话了', pron: 'ne i-ya-gi deun-neun ge je-il jo-a', nu: '공감과 경청 표현', nuZh: '表达喜欢倾听对方' },
        { cat: '감정·위로', ko: '힘들 땐 나한테 다 털어놔', zh: '累的时候都可以向我倾诉', pron: 'him-deul ttaen na-han-te da teo-reo-nwa', nu: '든든한 위로', nuZh: '让对方放心倾诉' },
        { cat: '감정·위로', ko: '네가 건강해야 나도 안심돼', zh: '你健健康康的我就安心了', pron: 'ne-ga geon-gang-hae-ya na-do an-sim-dwae', nu: '건강 걱정 표현', nuZh: '表达健康最重要' },
        { cat: '리액션·화해', ko: '우리 방금 텔레파시 통했다!', zh: '我们刚刚心有灵犀啦！', pron: 'u-ri bang-geum tel-le-pa-si tong-haet-da', nu: '똑같은 말·생각 했을 때', nuZh: '默契十足时说' },
        { cat: '리액션·화해', ko: '그건 진짜 생각지도 못했어', zh: '那我真的完全没想到', pron: 'geu-geon jin-jja saeng-gak-ji-do mo-tae-sseo', nu: '놀라운 반전 리액션', nuZh: '表示出乎意料' },
        { cat: '리액션·화해', ko: '네 말 들으니까 기분이 확 풀리네', zh: '听你这么一说心情一下子就好了', pron: 'ne mal deu-reu-ni-kka gi-bu-ni hwak pul-li-ne', nu: '위로받고 기분 풀릴 때', nuZh: '被安慰后瞬间开心' },
        { cat: '리액션·화해', ko: '앞으로도 지금처럼만 사랑하자', zh: '以后也要像现在这样相爱哦', pron: 'a-peu-ro-do ji-geum-cheo-reom-man sa-rang-ha-ja', nu: '변함없는 사랑 약속', nuZh: '约定一如既往相爱' },
        { cat: '리액션·화해', ko: '오늘도 사랑해, 잘 자!', zh: '今天也爱你，晚安！', pron: 'o-neul-do sa-rang-hae jal ja', nu: '매일 밤 완벽한 마무리', nuZh: '每晚甜蜜晚安' },
        { cat: '일상·인사', ko: '오늘 점심 메뉴 뭐야?', zh: '今天午饭吃什么呀？', pron: 'o-neul jeom-sim me-nyu mwo-ya', nu: '점심시간 가벼운 안부', nuZh: '午饭时间轻松问候' },
        { cat: '일상·인사', ko: '지금 카페에서 쉬고 있어', zh: '现在在咖啡馆休息呢', pron: 'ji-geum ka-pe-e-seo swi-go i-sseo', nu: '현재 위치·일상 공유', nuZh: '分享在咖啡馆放松' },
        { cat: '일상·인사', ko: '산책하면서 바람 쐬는 중이야', zh: '正在散步吹吹风', pron: 'san-chae-ka-myeon-seo ba-ram ssoe-neun jung-i-ya', nu: '여유로운 일상 공유', nuZh: '分享散步吹风' },
        { cat: '일상·인사', ko: '오늘 하늘이 진짜 맑다', zh: '今天天空真的好蓝好清澈', pron: 'o-neul ha-neu-ri jin-jja mak-da', nu: '하늘 사진 보낼 때', nuZh: '发天空照片时配文' },
        { cat: '일상·인사', ko: '갑자기 비가 쏟아지네', zh: '突然下起倾盆大雨了', pron: 'gap-ja-gi bi-ga sso-da-ji-ne', nu: '날씨 변화 공유', nuZh: '分享突然下大雨' },
        { cat: '일상·인사', ko: '오늘 야근할 것 같아', zh: '今天可能要加班', pron: 'o-neul ya-geun-hal geot ga-ta', nu: '야근 소식 미리 알리기', nuZh: '提前报备要加班' },
        { cat: '일상·인사', ko: '오늘은 집에서 푹 쉬려고', zh: '今天打算在家好好躺平休息', pron: 'o-neu-reun ji-be-seo puk swi-ryeo-go', nu: '휴일 계획 공유', nuZh: '分享居家休息计划' },
        { cat: '연애·애정', ko: '우리 커플룩 맞춰 입을까?', zh: '我们一起穿情侣装吧？', pron: 'u-ri keo-peul-luk mat-chwo i-beul-kka', nu: '데이트 커플룩 제안', nuZh: '提议穿情侣装约会' },
        { cat: '연애·애정', ko: '네 목소리가 제일 좋은 자장가야', zh: '你的声音是最好的催眠曲', pron: 'ne mok-so-ri-ga je-il jo-eun ja-jang-ga-ya', nu: '밤 통화 중 달콤한 멘트', nuZh: '睡前通话甜蜜情话' },
        { cat: '연애·애정', ko: '아침마다 네 메시지로 하루를 시작해', zh: '每天早上都是看着你的消息开启一天', pron: 'a-chim-ma-da ne me-si-ji-ro ha-ru-reul si-ja-kae', nu: '달달한 아침 고백', nuZh: '甜蜜的早安告白' },
        { cat: '연애·애정', ko: '나랑 사귀어 줘서 고마워', zh: '谢谢你愿意和我在一起', pron: 'na-rang sa-gwi-eo jwo-seo go-ma-wo', nu: '기념일·특별한 날 진심', nuZh: '纪念日深情感谢' },
        { cat: '맛집·카페', ko: '디카페인으로 바꿀 수 있나요?', zh: '可以换成低因咖啡吗？', pron: 'di-ka-pe-i-neu-ro ba-kkul su in-na-yo', nu: '저녁 카페 주문 팁', nuZh: '晚上点咖啡换低因' },
        { cat: '맛집·카페', ko: '시럽 한 번만 넣어 주세요', zh: '糖浆只压一泵就好', pron: 'si-reop han beon-man neo-eo ju-se-yo', nu: '카페 당도 세밀 주문', nuZh: '精细控制咖啡甜度' },
        { cat: '맛집·카페', ko: '겉바속촉 그 자체야!', zh: '外酥里嫩本尊啊！', pron: 'geot-ba-sok-chok geu ja-che-ya', nu: '한국인 최애 음식 표현', nuZh: '韩国超火美食形容词' },
        { cat: '여행·교통', ko: '보딩 패스 받았어!', zh: '拿到登机牌啦！', pron: 'bo-ding pae-seu ba-da-sseo', nu: '출국 직전 설레는 보고', nuZh: '拿到登机牌报喜' },
        { cat: '여행·교통', ko: '비행기 타기 전에 전화할게', zh: '登机前给你打电话', pron: 'bi-haeng-gi ta-gi jeo-ne jeon-hwa-hal-ge', nu: '탑승 전 마지막 통화 약속', nuZh: '登机前最后通话约定' },
        { cat: '여행·교통', ko: '도착하자마자 메시지 보낼게', zh: '一落地就马上发消息给你', pron: 'do-cha-ka-ja-ma-ja me-si-ji bo-nael-ge', nu: '도착 연락 약속', nuZh: '承诺落地报平安' },
        { cat: '쇼핑·긴급', ko: '알레르기가 있어서요', zh: '因为我对这个过敏', pron: 'al-le-reu-gi-ga i-sseo-seo-yo', nu: '식당·약국에서 중요 표현', nuZh: '餐厅或药店说明过敏' }
      ];

      const QUIZ_BANK = {
        starter: [
          { tag: '기초 인사', audio: '안녕하세요', q: '"你好"를 한국어 정중한 인사로 가장 바르게 말한 것은?', zh: '"你好"用韩语礼貌问候是？', opts: ['안녕하세요', '감사합니다', '죄송합니다', '잘 먹었습니다'], ans: 0, exp: '"안녕하세요"는 언제 어디서나 쓸 수 있는 가장 기본적인 한국어 인사입니다.' },
          { tag: '기초 감사', audio: '고마워요', q: '"谢谢"를 부드럽고 친근한 존댓말로 표현하면?', zh: '"谢谢"用温柔亲切的敬语表达是？', opts: ['미안해요', '고마워요', '괜찮아요', '좋아요'], ans: 1, exp: '"고마워요"는 친근하면서도 예의 바른 감사 표현입니다.' },
          { tag: '기초 단어', audio: '사랑해', q: '연인에게 "我爱你"라고 고백할 때 쓰는 말은?', zh: '对恋人说"我爱你"是？', opts: ['배고파', '사랑해', '추워', '졸려'], ans: 1, exp: '"사랑해"는 반말 연인체로 가장 따뜻한 사랑 고백입니다.' },
          { tag: '기초 숫자', audio: '두 잔 주세요', q: '카페에서 "请给我两杯"라고 주문할 때 알맞은 표현은?', zh: '在咖啡店说"请给我两杯"是？', opts: ['한 잔 주세요', '두 잔 주세요', '세 잔 주세요', '물 주세요'], ans: 1, exp: '한국어 고유수사 하나(한), 둘(두), 셋(세) 뒤에 잔을 붙입니다.' },
          { tag: '기초 안부', audio: '잘 잤어?', q: '아침에 연인에게 "睡得好吗？"라고 다정하게 묻는 말은?', zh: '早上问恋人"睡得好吗？"是？', opts: ['잘 잤어?', '어디야?', '몇 시야?', '얼마야?'], ans: 0, exp: '"잘 잤어?"는 아침에 가장 먼저 건네는 다정한 안부입니다.' }
        ],
        beginner: [
          { tag: '연인 회화', audio: '오늘도 수고 많았어', q: '연인이 퇴근했을 때 가장 자연스러운 따뜻한 인사는?', zh: '恋人下班时最自然温暖的问候是？', opts: ['오늘도 수고 많았어', '안녕히 계세요', '처음 뵙겠습니다', '얼마예요?'], ans: 0, exp: '"수고 많았어"는 하루 동안 애쓴 상대방을 다정하게 위로하는 핵심 표현입니다.' },
          { tag: '식당 주문', audio: '덜 맵게 해주세요', q: '식당에서 "请做得不要太辣"라고 요청할 때 쓰는 말은?', zh: '在餐厅说"请做得不要太辣"是？', opts: ['더 맵게 해주세요', '덜 맵게 해주세요', '포장해 주세요', '계산해 주세요'], ans: 1, exp: '"덜"은 정도를 줄여달라는 뜻으로 "덜 맵게 해주세요"가 정확한 표현입니다.' },
          { tag: '빈칸 문법', audio: '상하이에 가고 싶어요', q: '빈칸에 알맞은 조사는? "내년에 상하이(___) 가고 싶어요."', zh: '填入最合适的助词："明年想去上海。"', opts: ['에', '을', '이', '는'], ans: 0, exp: '도착지/목적지 뒤에는 방향 조사 "에"를 씁니다.' },
          { tag: '일상 안부', audio: '밥 먹었어?', q: '한국에서 상대방을 챙길 때 가장 흔히 묻는 애정 어린 안부는?', zh: '韩国人最常用来关心对方的日常问候是？', opts: ['밥 먹었어?', '물 주세요', '몇 시예요?', '여기 어디예요?'], ans: 0, exp: '한국에서는 "밥 먹었어?"가 안부와 애정을 동시에 담고 있습니다.' },
          { tag: '약속 표현', audio: '도착하면 연락해', q: '"到了告诉我"를 자연스러운 한국어 연인 말투로 옮기면?', zh: '"到了告诉我"用自然的韩语恋人语气是？', opts: ['도착하면 연락해', '출발하면 연락해', '지금 어디 가?', '내일 만나자'], ans: 0, exp: '"~하면 연락해"는 귀갓길을 챙기는 따뜻한 한국식 배려 표현입니다.' }
        ],
        intermediate: [
          { tag: '감정 뉘앙스', audio: '서운해', q: '한국어 "서운해"가 연인 대화에서 가지는 진짜 뉘앙스는?', zh: '韩语"서운해"在恋人对话中的真实语感是？', opts: ['아주 화가 나서 절교하고 싶다', '기대했는데 조금 아쉽고 마음을 알아줬으면 한다', '너무 배가 고프다', '정말 고맙다'], ans: 1, exp: '"서운해"는 좋아하기 때문에 조금 아쉽고 다독여주길 바라는 부드러운 감정입니다.' },
          { tag: '표현 비교', audio: '네가 있어서 정말 든든해', q: '상대방에게 "有你在我特别踏实"와 가장 가까운 표현은?', zh: '与"有你在我特别踏实"最贴切的表达是？', opts: ['네가 있어서 정말 든든해', '그냥 그런 것 같아', '나중에 다시 얘기해', '신경 쓰지 마'], ans: 0, exp: '"든든해"는 상대방이 큰 버팀목이 되어준다는 깊은 신뢰와 안정감을 뜻합니다.' },
          { tag: '문법 활용', audio: '비가 올 것 같아서 우산을 챙겼어', q: '빈칸에 알맞은 연결어미는? "비가 올 것 (___) 우산을 챙겼어."', zh: '填入合适的连接词尾："好像要下雨，所以带了伞。"', opts: ['같아서', '같지만', '같거나', '같으려고'], ans: 0, exp: '이유나 원인을 나타낼 때 "~것 같아서"를 사용합니다.' },
          { tag: '생활 배려', audio: '무리하지 말고 푹 쉬어', q: '"别勉强自己，好好休息吧"의 가장 자연스러운 한국어는?', zh: '"别勉强自己，好好休息吧"最自然的韩语是？', opts: ['빨리 일해', '무리하지 말고 푹 쉬어', '우리 놀러 가자', '내일 봐'], ans: 1, exp: '"무리하지 마"는 스스로에게 부담을 주지 말라는 따뜻한 배려입니다.' },
          { tag: '구어체', audio: '오늘따라 유난히 보고 싶네', q: '"오늘따라"가 문장에 더해 주는 섬세한 뉘앙스는?', zh: '"오늘따라"给句子增添的细腻语感是？', opts: ['평소와 달리 유독 오늘 더 그렇다는 강조', '내일도 똑같을 거라는 뜻', '어제 이미 끝났다는 뜻', '아무 상관없다는 뜻'], ans: 0, exp: '"오늘따라"는 평소보다 오늘 유독 감정이 깊어졌음을 감성적으로 강조합니다.' }
        ],
        advanced: [
          { tag: '심층 뉘앙스', audio: '네가 있어서 정말 다행이야', q: '"네가 있어서 정말 다행이야"에서 "다행이야"의 깊은 감정은?', zh: '"네가 있어서 정말 다행이야"中"다행이야"的深层情感是？', opts: ['단순히 운이 좋았다', '깊은 안도감과 존재 자체에 대한 진심 어린 감사', '아쉬움이 남는다', '조금 부담스럽다'], ans: 1, exp: '연인에게 쓰는 "다행이야"는 내 삶에 네가 와주어 감사하고 안심이 된다는 최고의 고백입니다.' },
          { tag: '한국 문화어', audio: '눈치 보지 말고 편하게 말해', q: '"눈치 보지 말고 편하게 말해"의 정확한 상황 의미는?', zh: '"눈치 보지 말고 편하게 말해"的准确含义是？', opts: ['눈을 감고 말하라는 뜻', '상대 기분 살피며 위축되지 말고 솔직하게 말하라는 배려', '조용히 하라는 뜻', '시선을 피하라는 뜻'], ans: 1, exp: '"눈치 보다"는 상대 기분을 지나치게 살피는 것으로, 이를 하지 말라는 것은 편안함을 주는 배려입니다.' },
          { tag: '관용 표현', audio: '마음이 놓인다', q: '무사히 도착했다는 연락을 받고 "마음이 놓인다"고 했을 때 뜻은?', zh: '收到平安到达消息后说"마음이 놓인다"的意思是？', opts: ['마음이 떠났다', '걱정이 사라지고 안심이 된다', '화풀이하고 싶다', '기억이 안 난다'], ans: 1, exp: '"마음이 놓이다"는 긴장이나 걱정이 풀려 안심이 된다는 자연스러운 관용구입니다.' },
          { tag: '고급 문법', audio: '바쁠 텐데 챙겨줘서 고마워', q: '"바쁠 (___) 챙겨줘서 고마워"에서 추측과 배려를 담는 표현은?', zh: '表达"你肯定很忙，谢谢还照顾我"应填入？', opts: ['텐데', '뿐만 아니라', '탓에', '김에'], ans: 0, exp: '"~(으)ㄹ 텐데"는 상대의 바쁜 상황을 짐작하며 고마움을 강조할 때 씁니다.' },
          { tag: '정서적 지지', audio: '언제든 나한테 기대도 돼', q: '"언제든 나한테 기대도 돼"에서 "기대다"의 문맥적 의미는?', zh: '"언제든 나한테 기대도 돼"中"기대다"的语境含义是？', opts: ['무언가를 기다리다(期待)', '힘들 때 심리적으로 의지하다(依靠)', '돈을 빌리다', '약속을 미루다'], ans: 1, exp: '동사 "기대다(依靠)"는 지칠 때 마음 편히 의지하라는 깊은 위로입니다.' }
        ],
        master: [
          { tag: '원어민 뉘앙스', audio: '말만이라도 고마워', q: '상대방의 호의를 정중히 사양하며 "말만이라도 고마워"라고 할 때 가장 적절한 뜻은?', zh: '婉拒对方好意时说"말만이라도 고마워"最恰当的意思是？', opts: ['말만 하지 말고 행동으로 보여줘', '실제로 그렇게 안 해줘도 그 마음만으로 충분히 고마워', '네 말이 이해가 안 돼', '다음에 꼭 사줘'], ans: 1, exp: '상대의 따뜻한 마음을 진심으로 인정하면서 부담을 덜어주는 원어민 고급 배려 표현입니다.' },
          { tag: '관용·속담', audio: '가는 말이 고와야 오는 말이 곱다', q: '한국 속담 "가는 말이 고와야 오는 말이 곱다"의 핵심 교훈은?', zh: '韩国俗语"가는 말이 고와야 오는 말이 곱다"的核心含义是？', opts: ['말을 빨리 해야 이긴다', '내가 먼저 예쁘고 다정하게 말해야 상대방도 좋게 대답한다', '침묵이 금이다', '멀리 갈수록 말을 아껴야 한다'], ans: 1, exp: '소통에서 먼저 따뜻한 어조를 건네는 태도의 중요성을 일깨우는 대표 속담입니다.' },
          { tag: '드라마 고급 회화', audio: '너한테만큼은 솔직해지고 싶어', q: '"너한테만큼은 솔직해지고 싶어"에서 조사 "만큼은"의 정밀한 효과는?', zh: '"너한테만큼은 솔직해지고 싶어"中助词"만큼은"的精准效果是？', opts: ['다른 사람에겐 몰라도 최소한 너에게만은 예외 없이 진심이라는 강조', '너와 비슷한 수준이라는 비교', '너 때문에 어쩔 수 없다는 불만', '시간이 부족하다는 뜻'], ans: 0, exp: '"~만큼은"은 오직 상대방만을 특별히 구분해 진심을 강조하는 고급 표현입니다.' },
          { tag: '미묘한 어감', audio: '괜찮긴 뭐가 괜찮아, 얼굴이 안 좋잖아', q: '연인이 "괜찮아"라고 했을 때 "괜찮긴 뭐가 괜찮아"라고 되묻는 진짜 감정은?', zh: '恋人说"没事"时反问"괜찮긴 뭐가 괜찮아"的真实情感是？', opts: ['상대방에게 화를 내며 비난하는 것', '애써 괜찮은 척하는 상대가 안쓰러워 진심으로 걱정하고 챙기는 애정', '관심이 없어서 넘기는 것', '농담으로 놀리는 것'], ans: 1, exp: '괜찮은 척하는 연인을 진심으로 걱정하는 한국어 특유의 반어적 애정 표현입니다.' },
          { tag: '장문 뉘앙스', audio: '멀리 떨어져 있어도 마음만은 늘 곁에 있는 것 같아', q: '"멀리 떨어져 있어도 마음만은 늘 곁에 있는 것 같아"와 가장 잘 어울리는 중국어 의역은?', zh: '最贴合"멀리 떨어져 있어도 마음만은 늘 곁에 있는 것 같아"的中文意译是？', opts: ['虽然相隔很远，但心仿佛一直陪在彼此身边', '距离太远所以联系变少了', '我想搬家去附近住', '今天天气很适合散步'], ans: 0, exp: '"~만은"과 "~는 것 같아"가 어우러져 시적이고 따뜻한 감성을 전달합니다.' }
        ]
      };

      const LEVEL_META = {
        starter: { nameKo: '1단계 입문', nameZh: '1级 入门', xp: 15, badge: '🌱 입문', badgeZh: '🌱 入门' },
        beginner: { nameKo: '2단계 초급', nameZh: '2级 初级', xp: 20, badge: '🌿 초급', badgeZh: '🌿 初级' },
        intermediate: { nameKo: '3단계 중급', nameZh: '3级 中级', xp: 30, badge: '🌸 중급', badgeZh: '🌸 中级' },
        advanced: { nameKo: '4단계 고급', nameZh: '4级 高级', xp: 40, badge: '💎 고급', badgeZh: '💎 高级' },
        master: { nameKo: '5단계 마스터', nameZh: '5级 大师', xp: 50, badge: '👑 마스터', badgeZh: '👑 大师' }
      };

      const DAILY_STUDY_GOAL = 20;
      const DAILY_XP_CAP = 500;
      const XP_PER_LEVEL = 100;
      const QUIZ_LEVEL_UNLOCK = {
        starter: 1,
        beginner: 3,
        intermediate: 6,
        advanced: 10,
        master: 15
      };

      function getTodayXpEarned() {
        const todayK = getKstDateString();
        if (state.learn.todayXpDate !== todayK) return 0;
        return Number(state.learn.todayXpEarned) || 0;
      }

      function normalizeKoreanCompare(s) {
        return String(s || '').replace(/[^가-힣a-zA-Z0-9]/g, '').toLowerCase();
      }

      function calcKoreanSpeechSimilarity(target, spoken) {
        const a = normalizeKoreanCompare(target);
        const b = normalizeKoreanCompare(spoken);
        if (!a || !b) return 0;
        if (a === b) return 100;
        if (b.includes(a) || a.includes(b)) {
          return Math.round((Math.min(a.length, b.length) / Math.max(a.length, b.length)) * 100);
        }
        // Levenshtein distance
        const m = a.length, n = b.length;
        const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
        for (let i = 0; i <= m; i++) dp[i][0] = i;
        for (let j = 0; j <= n; j++) dp[0][j] = j;
        for (let i = 1; i <= m; i++) {
          for (let j = 1; j <= n; j++) {
            const cost = a[i - 1] === b[j - 1] ? 0 : 1;
            dp[i][j] = Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + cost);
          }
        }
        const dist = dp[m][n];
        return Math.max(0, Math.round((1 - dist / Math.max(m, n)) * 100));
      }
      const PRAISE_STICKER_TYPES = {
        best:  { icon: '⭐', ko: '최고야!', zh: '最棒啦!' },
        good:  { icon: '💜', ko: '잘했어!', zh: '做得好!' },
        honor: { icon: '🏆', ko: '우등생!', zh: '优等生!' },
        kiss:  { icon: '💋', ko: '뽀뽀 보상!', zh: '亲亲奖励!' }
      };

      function romanizeKoreanBasic(str) {
        const CHO = ['g','kk','n','d','tt','r','m','b','pp','s','ss','','j','jj','ch','k','t','p','h'];
        const JUNG = ['a','ae','ya','yae','eo','e','yeo','ye','o','wa','wae','oe','yo','u','wo','we','wi','yu','eu','ui','i'];
        const JONG = ['','k','k','k','n','n','n','t','l','l','l','l','l','l','l','l','m','p','p','t','t','ng','t','t','k','t','p','t'];
        return String(str || '').split('').map(ch => {
          const code = ch.charCodeAt(0);
          if (code >= 0xAC00 && code <= 0xD7A3) {
            const idx = code - 0xAC00;
            const c = Math.floor(idx / 588);
            const j = Math.floor((idx % 588) / 28);
            const t = idx % 28;
            return CHO[c] + JUNG[j] + JONG[t];
          }
          return ch;
        }).join('');
      }

      function getKoreanChoseong(str) {
        const CHO = ['ㄱ','ㄲ','ㄴ','ㄷ','ㄸ','ㄹ','ㅁ','ㅂ','ㅃ','ㅅ','ㅆ','ㅇ','ㅈ','ㅉ','ㅊ','ㅋ','ㅌ','ㅍ','ㅎ'];
        const out = [];
        for (const ch of String(str || '')) {
          const code = ch.charCodeAt(0);
          if (code >= 0xAC00 && code <= 0xD7A3) {
            out.push(CHO[Math.floor((code - 0xAC00) / 588)]);
          } else if (ch === ' ') {
            out.push(' ');
          }
        }
        return out.join(' ').replace(/\s{3,}/g, '  ').trim();
      }

      function getRankInfo(xp) {
        const safeXp = Math.max(0, Number(xp) || 0);
        const isZh = state.lang === 'zh';
        const level = Math.floor(safeXp / XP_PER_LEVEL) + 1;
        const inLv = safeXp % XP_PER_LEVEL;
        const need = XP_PER_LEVEL - inLv;
        const pct = Math.round((inLv / XP_PER_LEVEL) * 100);
        let tier = isZh ? '🌱 入门' : '🌱 입문';
        if (level >= 20) tier = isZh ? '✨ 传奇' : '✨ 레전드';
        else if (level >= 15) tier = isZh ? '👑 大师' : '👑 마스터';
        else if (level >= 10) tier = isZh ? '💎 高级' : '💎 고급';
        else if (level >= 6) tier = isZh ? '🌸 中级' : '🌸 중급';
        else if (level >= 3) tier = isZh ? '🌿 初级' : '🌿 초급';
        return {
          level,
          label: `Lv.${level} ${tier}`,
          pct,
          next: isZh
            ? `Lv.${level + 1} 升级还差 ${need} XP (${inLv}/${XP_PER_LEVEL})`
            : `Lv.${level + 1} 레벨업까지 ${need} XP (${inLv}/${XP_PER_LEVEL})`
        };
      }

      function canEarnJingchanXp() {
        return state.myRole === 'jingchan';
      }

      function recordJingchanStudyProgress(xpGain, opts) {
        const options = opts || {};
        // Protect Jingchan's XP when Suwan is testing/playing!
        if (!options.forcePraise && !canEarnJingchanXp()) {
          return { earned: false, actualGain: 0, capped: false, leveledUp: false };
        }
        const todayK = getKstDateString();
        if (state.learn.todayXpDate !== todayK) {
          state.learn.todayXpDate = todayK;
          state.learn.todayXpEarned = 0;
        }
        const reqGain = Math.max(0, Number(xpGain) || 0);
        let actualGain = reqGain;
        let capped = false;
        if (!options.bypassDailyCap) {
          const remaining = Math.max(0, DAILY_XP_CAP - (Number(state.learn.todayXpEarned) || 0));
          actualGain = Math.min(reqGain, remaining);
          if (actualGain < reqGain) capped = true;
          state.learn.todayXpEarned = (Number(state.learn.todayXpEarned) || 0) + actualGain;
        }
        const prevXp = Number(state.learn.xp) || 0;
        const prevLv = Math.floor(prevXp / XP_PER_LEVEL) + 1;
        state.learn.xp = prevXp + actualGain;
        const newLv = Math.floor(state.learn.xp / XP_PER_LEVEL) + 1;
        if (!options.skipSolvedCount) {
          state.learn.solved = (state.learn.solved || 0) + 1;
          if (state.learn.todaySolvedDate !== todayK) { state.learn.todaySolvedDate = todayK; state.learn.todaySolvedCount = 0; }
          state.learn.todaySolvedCount = (state.learn.todaySolvedCount || 0) + 1;
          if (!state.learn.studyLog || typeof state.learn.studyLog !== 'object') state.learn.studyLog = {};
          state.learn.studyLog[todayK] = (state.learn.studyLog[todayK] || 0) + 1;
          state.learn.lastStudyTime = `${todayK} ${new Date().toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' })}`;
        }
        if (capped && actualGain === 0) {
          setTimeout(() => {
            showToast(state.lang === 'zh'
              ? `🎉 今日经验值已达上限 (${DAILY_XP_CAP} XP)！明天零点重置，继续练习也很棒 💜`
              : `🎉 오늘 최대 경험치(${DAILY_XP_CAP} XP)를 모두 채웠어요! 내일 다시 쌓여요 💜`, 3200);
          }, 250);
        }
        const leveledUp = newLv > prevLv;
        if (leveledUp) {
          setTimeout(() => {
            showToast(state.lang === 'zh'
              ? `🎉 恭喜升级！靖灿达成 Lv.${newLv}！`
              : `🎉 LEVEL UP! 징찬이 Lv.${newLv} 달성!`, 3600);
          }, 350);
          pushNotification('👑', `징찬이 Lv.${newLv} 레벨업!`, `靖灿升级啦！Lv.${newLv}！`, `누적 ${state.learn.xp} XP 돌파 🎉`, `累计突破 ${state.learn.xp} XP 🎉`, 'learn', 'quiz', 'post', true, 'jingchan');
        }
        return { earned: true, actualGain, capped, leveledUp, prevLv, newLv };
      }

      function awardPraiseStickerToJingchan(praiseId) {
        if (state.myRole !== 'suwan') {
          showToast(state.lang === 'zh' ? '仅限完(수완)赠送表扬贴纸哦 👑' : '칭찬 스티커는 수완(完) 모드에서만 줄 수 있어요 👑');
          return;
        }
        const p = PRAISE_STICKER_TYPES[praiseId] || PRAISE_STICKER_TYPES.best;
        if (!Array.isArray(state.learn.praiseStickers)) state.learn.praiseStickers = [];
        const todayK = getKstDateString();
        const nowT = new Date().toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' });
        state.learn.praiseStickers.unshift({
          id: `pr_${Date.now()}`,
          type: praiseId,
          icon: p.icon,
          ko: p.ko,
          zh: p.zh,
          date: todayK,
          time: nowT
        });
        if (state.learn.praiseStickers.length > 60) state.learn.praiseStickers.length = 60;
        recordJingchanStudyProgress(20, { forcePraise: true, skipSolvedCount: true, bypassDailyCap: true });
        saveState(true);
        playNotifChime();
        renderHome();
        renderLearn();
        showToast(state.lang === 'zh'
          ? `已送给靖灿 ${p.icon}「${p.zh}」贴纸！(+20 XP)`
          : `징찬에게 ${p.icon}「${p.ko}」 칭찬 스티커를 붙였어요! (+20 XP)`);
        pushNotification(p.icon, `수완이 칭찬 스티커를 보냈어요! (${p.ko})`, `完送给你一张表扬贴纸！（${p.zh}）`, `보너스 +20 XP 획득 💜`, `获得奖励 +20 XP 💜`, 'home', '', 'post', true, 'suwan');
      }

      function buildMasterQuestionCatalog() {
        const catalog = [];
        // 1) All curated level-specific grammar & nuance questions
        Object.keys(QUIZ_BANK).forEach(lvl => {
          (QUIZ_BANK[lvl] || []).forEach((q, i) => {
            catalog.push({ ...q, qId: `cur_${lvl}_${i}`, lvl });
          });
        });
        // 2) 4 distinct practical question angles per phrase (265+ * 4 = 1,060+ unique questions!)
        const pool = CHEAT_SHEET_72;
        const n = pool.length;
        for (let i = 0; i < n; i++) {
          const target = pool[i];
          const pickDistractors = (seedOffset) => {
            const ds = [];
            let step = 1;
            while (ds.length < 3 && step < n) {
              const cand = pool[(i + seedOffset + step * 7) % n];
              if (cand.ko !== target.ko && cand.zh !== target.zh && !ds.some(d => d.ko === cand.ko || d.zh === cand.zh)) ds.push(cand);
              step++;
            }
            return ds;
          };
          const makeShuffled = (ds, shift) => {
            const all = [target, ...ds];
            const sh = all.map((_, k) => all[(k + shift) % all.length]);
            return { sh, ans: sh.findIndex(x => x.ko === target.ko) };
          };
          // Mode A: Korean -> Chinese Meaning
          {
            const { sh, ans } = makeShuffled(pickDistractors(3), i % 4);
            catalog.push({
              qId: `ko2zh_${i}`, lvl: i % 2 === 0 ? 'starter' : 'beginner',
              tag: `뜻 맞추기 · ${target.cat}`, tagZh: `词义理解 · ${target.cat}`, audio: target.ko,
              q: `"${target.ko}"의 가장 자연스러운 중국어 뜻은?`,
              zh: `选出韩语「${target.ko}」最准确的中文意思：`,
              opts: sh.map(x => x.zh), ans,
              exp: `💡 ${target.nu} (${target.ko} = ${target.zh})`,
              expZh: `🇨🇳 中文解析：${localizeLearnNuanceZh(target)}`
            });
          }
          // Mode B: Chinese -> Natural Spoken Korean
          {
            const { sh, ans } = makeShuffled(pickDistractors(11), (i + 1) % 4);
            catalog.push({
              qId: `zh2ko_${i}`, lvl: i % 2 === 0 ? 'beginner' : 'intermediate',
              tag: `실전 회화 · ${target.cat}`, tagZh: `地道口语 · ${target.cat}`, audio: target.ko,
              q: `"${target.zh}"를 실제 한국어로 가장 자연스럽게 말하면?`,
              zh: `「${target.zh}」用韩语最地道地怎么说？`,
              opts: sh.map(x => x.ko), ans,
              exp: `💡 ${target.nu} (${target.ko} = ${target.zh})`,
              expZh: `🇨🇳 中文解析：「${target.zh}」地道韩语就是「${target.ko}」，点击小喇叭跟读一遍吧！`
            });
          }
          // Mode C: Listening Comprehension (Audio -> Match Meaning)
          {
            const { sh, ans } = makeShuffled(pickDistractors(19), (i + 2) % 4);
            catalog.push({
              qId: `listen_${i}`, lvl: i % 2 === 0 ? 'intermediate' : 'advanced',
              tag: `듣기 평가 · ${target.cat}`, tagZh: `听力实战 · ${target.cat}`, audio: target.ko,
              q: `🔊 발음을 듣고 알맞은 한국어 문장을 골라보세요!`,
              zh: `点击右侧 🔊/🐢 听韩语发音，选出你听到的句子：`,
              opts: sh.map(x => `${x.ko} (${x.zh})`), ans,
              exp: `💡 정답: ${target.ko} = ${target.zh} (${target.nu})`,
              expZh: `🇨🇳 听力解析：刚才读的是「${target.ko}」，意思是「${target.zh}」哦！`
            });
          }
          // Mode D: Real-Life Situation -> Best Korean Expression
          {
            const { sh, ans } = makeShuffled(pickDistractors(29), (i + 3) % 4);
            catalog.push({
              qId: `sit_${i}`, lvl: i % 2 === 0 ? 'advanced' : 'master',
              tag: `상황 회화 · ${target.cat}`, tagZh: `情景实战 · ${target.cat}`, audio: target.ko,
              q: `상황: ${target.nu} — 이럴 때 가장 자연스러운 한국어는?`,
              zh: `情景「${target.zh}」— 这时候最自然该说哪句韩语？`,
              opts: sh.map(x => x.ko), ans,
              exp: `💡 ${target.ko} = ${target.zh} (${target.nu})`,
              expZh: `🇨🇳 情景解析：在这种场景下韩国人最常说「${target.ko}」（${target.zh}）！`
            });
          }
        }
        return catalog;
      }
      const MASTER_QUIZ_CATALOG = buildMasterQuestionCatalog();

      function getAllCheatPhrases() {
        const custom = Array.isArray(state && state.customPhrases) ? state.customPhrases : [];
        return [...custom, ...CHEAT_SHEET_72];
      }

      function buildCustomPhraseQuestions() {
        const custom = Array.isArray(state && state.customPhrases) ? state.customPhrases : [];
        if (!custom.length) return [];
        const pool = getAllCheatPhrases();
        const out = [];
        custom.forEach((target, idx) => {
          const ds = [];
          for (let k = 0; k < pool.length && ds.length < 3; k++) {
            const c = pool[(idx * 5 + k * 7 + 3) % pool.length];
            if (c.ko !== target.ko && c.zh !== target.zh && !ds.some(d => d.ko === c.ko)) ds.push(c);
          }
          if (ds.length < 3) return;
          const all = [target, ...ds];
          const sh = all.map((_, i) => all[(i + idx) % all.length]);
          const ans = sh.findIndex(x => x.ko === target.ko);
          out.push({
            qId: `cust_ko2zh_${target.id || idx}`, lvl: 'starter',
            tag: '💜 수완 맞춤 · 뜻 맞추기', tagZh: '💜 完的专属题 · 词义', audio: target.ko,
            q: `"${target.ko}"의 가장 자연스러운 중국어 뜻은?`,
            zh: `选出完添加的专属韩语「${target.ko}」的中文意思：`,
            opts: sh.map(x => x.zh), ans,
            exp: `💡 ${target.nu || '수완 맞춤 표현'} (${target.ko} = ${target.zh})`,
            expZh: `🇨🇳 中文解析：「${target.ko}」意思是「${target.zh}」${target.nu ? ' · ' + target.nu : ''}`
          });
          out.push({
            qId: `cust_zh2ko_${target.id || idx}`, lvl: 'beginner',
            tag: '💜 수완 맞춤 · 실전 회화', tagZh: '💜 完的专属题 · 口语', audio: target.ko,
            q: `"${target.zh}"를 실제 한국어로 말하면?`,
            zh: `「${target.zh}」用韩语怎么说？`,
            opts: sh.map(x => x.ko), ans,
            exp: `💡 ${target.nu || '수완 맞춤 표현'} (${target.ko} = ${target.zh})`,
            expZh: `🇨🇳 中文解析：「${target.zh}」用韩语说就是「${target.ko}」！`
          });
        });
        return out;
      }

      function getQuestionFor(level, counter) {
        const kstSeed = Math.abs(Math.floor(parseYmd(getKstDateString()).getTime() / 86400000));
        const solvedSet = new Set(Array.isArray(state.learn?.solvedQIds) ? state.learn.solvedQIds : []);
        // Prefer questions matching current level, then fall back to entire 1,000+ catalog without repeats
        const fullCatalog = [...buildCustomPhraseQuestions(), ...MASTER_QUIZ_CATALOG];
        const levelMatches = fullCatalog.filter(q => q.lvl === level);
        let candidates = levelMatches.filter(q => !solvedSet.has(q.qId));
        if (!candidates.length) candidates = fullCatalog.filter(q => !solvedSet.has(q.qId));
        if (!candidates.length) candidates = levelMatches.length ? levelMatches : fullCatalog;
        const pickIdx = (kstSeed * 17 + (counter || 0) * 13) % candidates.length;
        return candidates[pickIdx];
      }

      const QA_QUESTIONS = [
        { ko: '우리가 처음 만났을 때 가장 기억에 남았던 순간은?', zh: '我们第一次见面时，你印象最深刻的瞬间是什么？' },
        { ko: '꼭 같이 먹어보고 싶은 음식은?', zh: '你最想和我一起吃的美食是什么？' },
        { ko: '상대방의 어떤 작은 습관이 가장 사랑스럽게 느껴져?', zh: '对方的哪一个小习惯让你觉得最可爱？' },
        { ko: '갑자기 하루 자유 시간이 생긴다면 둘이 무엇을 하고 싶어?', zh: '如果突然多出一天空闲时间，最想两个人一起做什么？' },
        { ko: '최근에 상대방 덕분에 가장 감동받았던 순간은?', zh: '最近因为对方而最感动的瞬间是什么？' },
        { ko: '1년 뒤 오늘, 우리는 어떤 모습으로 어디에 있을까?', zh: '一年后的今天，我们会以怎样的模样在哪里呢？' }
      ];

      /* ============================================================
         6. CLEAN DEFAULT STATE & PERSISTENCE
         ============================================================ */
      const DEFAULT_STATE = {
        version: 'Prime 2',
        updatedAt: 0,
        theme: 'pastel-royal',
        font: 'sans',
        dockFont: 'sans',
        fontSize: 'md',
        lang: 'ko',
        heartCount: 0,
        cities: {
          suwan: { name: '수원 · Suwon', flag: '🇰🇷', lat: 37.2636, lon: 127.0286, tz: 'Asia/Seoul', updatedAt: 0 },
          jingchan: { name: '상하이 · 上海', flag: '🇨🇳', lat: 31.2304, lon: 121.4737, tz: 'Asia/Shanghai', updatedAt: 0 }
        },
        notifications: [],
        transHistory: [],
        capsules: [],
        profile: {
          suwanMood: '💜 보고 싶어 · 好想你',
          jingchanMood: '🌸 기분 최고 · 心情超好',
          suwanAvatar: '',
          jingchanAvatar: '',
          suwanSleep: { status: '', time: '', date: '', updatedAt: 0 },
          jingchanSleep: { status: '', time: '', date: '', updatedAt: 0 },
          suwanEnergy: { level: 100, updatedAt: 0 },
          jingchanEnergy: { level: 100, updatedAt: 0 }
        },
        hugs: { count: 0, date: '', lastBy: '', updatedAt: 0 },
        tmiBook: {
          suwan: { likeFood: '', dislikeFood: '', cafe: '', size: '', color: '', gift: '', memo: '', updatedAt: 0 },
          jingchan: { likeFood: '', dislikeFood: '', cafe: '', size: '', color: '', gift: '', memo: '', updatedAt: 0 }
        },
        complimentJar: [],
        coupleQuizzes: [],
        customFoods: [],
        meals: {
          date: '',
          suwan: { breakfast: { done: false, menu: '', menuTr: '', time: '' }, lunch: { done: false, menu: '', menuTr: '', time: '' }, dinner: { done: false, menu: '', menuTr: '', time: '' } },
          jingchan: { breakfast: { done: false, menu: '', menuTr: '', time: '' }, lunch: { done: false, menu: '', menuTr: '', time: '' }, dinner: { done: false, menu: '', menuTr: '', time: '' } },
          updatedAt: 0
        },
        lavender: {
          xp: 0,
          totalWaters: 0,
          lastWaterSuwan: '',
          lastWaterJingchan: '',
          bonusLog: {},
          updatedAt: 0
        },
        balanceGame: {
          currentIdx: 0,
          answers: {},
          updatedAt: 0
        },
        dateStamps: {
          filter: 'all',
          stamps: {},
          customSpots: [],
          deletedIds: [],
          updatedAt: 0
        },
        startDate: '2026-01-01',
        anniversaries: [],
        learn: { xp: 0, solved: 0, streak: 0, currentLevel: 'starter', quizIdx: 0, wrongNotes: [] },
        chat: { activeSender: 'suwan', qaIdx: 0, messages: [], qaAnswers: [] },
        diaries: [],
        memos: [],
        buckets: [],
        albums: [],
        customVoices: {},
        voiceLetters: [],
        customPhrases: [],
        settings: { geminiApiKey: '', autoNuance: true, notifSound: true },
        lastSaved: ''
      };

      const DUMMY_IDS = new Set([
        'msg_init_1', 'msg_init_2', 'diary_init_1',
        'memo_1', 'memo_2', 'bkt_1', 'bkt_2', 'bkt_3', 'ann_1', 'ann_2'
      ]);

      let state = JSON.parse(JSON.stringify(DEFAULT_STATE));
      window.__cwApi = {
        getState: () => state,
        saveState: (sync) => { try { return typeof saveState === 'function' ? saveState(sync) : undefined; } catch (_) {} },
        renderChat: () => { try { return typeof renderChat === 'function' ? renderChat() : undefined; } catch (_) {} },
        showToast: (msg) => { try { return typeof showToast === 'function' ? showToast(msg) : undefined; } catch (_) {} },
        speakText: (t, l, s) => { try { return typeof speakText === 'function' ? speakText(t, l, s) : undefined; } catch (_) {} },
        escapeHtml: (s) => { try { return typeof escapeHtml === 'function' ? escapeHtml(s) : String(s || ''); } catch (_) { return String(s || ''); } },
        compressImageToDataUrl: (f, maxW) => (typeof compressImageToDataUrl === 'function' ? compressImageToDataUrl(f, maxW) : Promise.reject(new Error('no_comp'))),
        mediaUrl: (u, mime) => { try { return typeof __cwMediaUrl === 'function' ? __cwMediaUrl(u, mime) : u; } catch (_) { return u; } }
      };
        // Prime 4 v26: Fast zero-stuck auto-resolver for any message on '⏳ 正在翻译...' / '⏳ 번역 중...'
        const __cwTranslatingIds = new Set();
        const __cwRepairedV64Ids = new Set();
        async function autoResolvePendingTranslations() {
          try {
            const allRecent = (state.chat && Array.isArray(state.chat.messages)) ? state.chat.messages.slice(-30) : [];
            let repairedAny = false;
            for (const rm of allRecent) {
              if (!rm || !rm.id || __cwRepairedV64Ids.has(rm.id)) continue;
              __cwRepairedV64Ids.add(rm.id);
              const origS = String(rm.original || '').trim();
              const trS = String(rm.translated || '').trim();
              if (!origS || !trS) continue;
              let fixedTr = trS;
              if (/[靖静晶京景精正青清金敬竞净贞郑俊军君张章长陈真珍][禅蝉璨粲婵]/.test(fixedTr) && /징찬/.test(origS)) {
                fixedTr = fixedTr
                  .replace(/靖灿[\s,，、]*[靖静晶京景精正青清金敬竞净贞郑俊军君张章长陈真珍][禅蝉璨粲婵]/g, '靖灿')
                  .replace(/[靖静晶京景精正青清金敬竞净贞郑俊军君张章长陈真珍][禅蝉璨粲婵]/g, '靖灿')
                  .replace(/靖灿\s*(?=你在|在干嘛)/g, '靖灿，')
                  .replace(/你在(?:做什么|干什么)([？?]*)$/g, '在干嘛呀$1');
              }
              if (/가게|매장/.test(origS) && /店里还在吗/.test(fixedTr)) {
                fixedTr = fixedTr.replace(/店里还在吗/g, '还在店里吗');
              }
              if (/^(?:뭐|머|모)\s*해\s*[ㅠㅜ]+[!?.~\s]*$/.test(origS) && /^你在(?:干什么|做什么)[？?]*$/.test(fixedTr)) {
                fixedTr = '在干嘛呀呜呜';
              } else if (/^(?:뭐|머|모)\s*해[?!.~\s]*$/.test(origS) && /^你在(?:干什么|做什么)[？?]*$/.test(fixedTr)) {
                fixedTr = '在干嘛呀？';
              }
              if (fixedTr !== trS) {
                rm.translated = fixedTr;
                repairedAny = true;
              }
            }
            if (repairedAny) {
              saveState(true);
              if (typeof renderChat === 'function') renderChat();
            }
            const msgs = allRecent.slice(-15);
            const now = Date.now();
            for (const m of msgs) {
              if (!m || !m.id || !m.original || __cwTranslatingIds.has(m.id)) continue;
              const tr = String(m.translated || '').trim();
              const isMixedHalfKo = (m.tgtLang === 'zh' || (/[가-힣]/.test(String(m.original || '')) && !/[\u4e00-\u9fff]/.test(String(m.original || '')))) && /[가-힣]/.test(tr) && /[\u4e00-\u9fff]/.test(tr);
              const isStuck = ((!tr || tr === '⏳ 正在翻译...' || tr === '⏳ 번역 중...') && (now - Number(m.ts || 0)) > 2600) || isMixedHalfKo;
              if (!isStuck) continue;
              if (!/[a-zA-Z가-힣一-鿿]/.test(m.original) || /^https?:\/\/\S+$/i.test(m.original)) continue;
              __cwTranslatingIds.add(m.id);
              (async (targetMsg) => {
                try {
                  let res = await geminiTranslate(targetMsg.original, 'lover');
                  if (!res || !res.translated) {
                    res = await _coreTranslate(targetMsg.original, 'lover').catch(() => null);
                  }
                  if (res && res.translated && !/^(⏳ 번역 중\.\.\.|⏳ 正在翻译\.\.\.)$/.test(String(res.translated).trim())) {
                    targetMsg.translated = res.translated;
                    if (res.altTranslated) targetMsg.altTranslated = res.altTranslated;
                    targetMsg.pronunciation = res.pronunciation || '';
                    targetMsg.tone = res.tone || targetMsg.tone || '';
                    targetMsg.toneZh = res.toneZh || targetMsg.toneZh || '';
                    targetMsg.nuance = res.nuance || targetMsg.nuance || '';
                    targetMsg.nuanceZh = res.nuanceZh || targetMsg.nuanceZh || '';
                    targetMsg.engine = res.engine || '';
                    targetMsg.accuracy = Number(res.accuracy) || 95;
                    if (typeof updateChatNotifsForMsg === 'function') updateChatNotifsForMsg(targetMsg.id, targetMsg.original, targetMsg.translated);
                    saveState(true);
                    renderChat();
                  }
                } catch (_) {} finally {
                  setTimeout(() => __cwTranslatingIds.delete(targetMsg.id), 5000);
                }
              })(m);
            }
          } catch (_) {}
        }
        // Global 0.001ms Active-Typing Tracker: defers heavy background polling, JSON.stringify & DOM sweeps while fingers are typing!
        window.__cwLastUserTypingTs = 0;
        window.__cwIsImeComposing = false;
        window.__isActivelyTyping = function() {
          return !!window.__cwIsImeComposing || ((performance.now ? performance.now() : Date.now()) - (window.__cwLastUserTypingTs || 0)) < 950;
        };
        document.addEventListener('compositionstart', () => {
          window.__cwIsImeComposing = true;
          window.__cwLastUserTypingTs = performance.now ? performance.now() : Date.now();
        }, { passive: true, capture: true });
        document.addEventListener('compositionend', () => {
          window.__cwIsImeComposing = false;
          window.__cwLastUserTypingTs = performance.now ? performance.now() : Date.now();
        }, { passive: true, capture: true });
        document.addEventListener('keydown', (ev) => {
          const t = ev.target;
          if (t && (t.tagName === 'TEXTAREA' || t.tagName === 'INPUT')) {
            window.__cwLastUserTypingTs = performance.now ? performance.now() : Date.now();
          }
        }, { passive: true, capture: true });
        document.addEventListener('input', (ev) => {
          const t = ev.target;
          if (t && (t.tagName === 'TEXTAREA' || t.tagName === 'INPUT')) {
            window.__cwLastUserTypingTs = performance.now ? performance.now() : Date.now();
            if (t.spellcheck !== false) t.spellcheck = false;
          }
        }, { passive: true, capture: true });

        setInterval(() => {
          if (!document.hidden && !(window.__isActivelyTyping && window.__isActivelyTyping())) {
            autoResolvePendingTranslations();
          }
        }, 3500);

      let activeAvatarTarget = 'suwan';
      let activeCityTarget = 'suwan';
      let activeMoodTarget = 'suwan';

      function extractLightweightCore(fullState) {
        return {
          ...fullState,
          albums: [],
          customVoices: {},
          voiceLetters: [],
          chat: {
            ...(fullState.chat || {}),
            messages: Array.isArray(fullState.chat?.messages) ? fullState.chat.messages.map(m => ({ ...m, photoUrl: '', photoUrls: undefined, videoUrl: '', audioUrl: '' })) : []
          },
          profile: { ...fullState.profile, suwanAvatar: '', jingchanAvatar: '' }
        };
      }

      // Prime 4 v60: Never-Shrink Monotonic Korean Study Merger (protects XP, streak, solvedHistory, studyLog, praiseStickers, wrongNotes & bookmarks!)
      const CW_LEVEL_RANK = { starter: 1, beginner: 2, intermediate: 3, advanced: 4, master: 5 };
      function mergeLearnMonotonic(curRaw, incRaw) {
        const cur = (curRaw && typeof curRaw === 'object') ? curRaw : {};
        const inc = (incRaw && typeof incRaw === 'object') ? incRaw : {};
        const curReset = Number(cur.resetAt || 0);
        const incReset = Number(inc.resetAt || 0);
        if (incReset > 0 && incReset > curReset) {
          return { ...DEFAULT_STATE.learn, ...inc, resetAt: incReset };
        }
        if (curReset > 0 && curReset > incReset) {
          return { ...DEFAULT_STATE.learn, ...cur, resetAt: curReset };
        }
        const mergeObjList = (aList, bList, keyFn, cap) => {
          const map = new Map();
          const out = [];
          for (const item of [...(Array.isArray(aList) ? aList : []), ...(Array.isArray(bList) ? bList : [])]) {
            if (!item || typeof item !== 'object') continue;
            const k = keyFn(item);
            if (!k) continue;
            if (!map.has(k)) {
              const copy = { ...item };
              map.set(k, copy);
              out.push(copy);
            } else {
              const ex = map.get(k);
              if (item.reviewedDone && !ex.reviewedDone) {
                ex.correct = true;
                ex.reviewedDone = true;
                ex.reviewedAt = item.reviewedAt || Date.now();
              }
            }
          }
          return cap ? out.slice(0, cap) : out;
        };

        const mergedPraises = mergeObjList(inc.praiseStickers, cur.praiseStickers, x => x.id || `${x.date}_${x.time}_${x.type}`, 80);
        const mergedHist = mergeObjList(inc.solvedHistory, cur.solvedHistory, x => x.id || `${x.date}_${x.time}_${x.q}`, 80);
        const reviewedSet = new Set(mergedHist.filter(h => h && h.reviewedDone).map(h => h.q));
        const mergedWrong = mergeObjList(cur.wrongNotes, inc.wrongNotes, x => x.id || x.q, 80).filter(w => !reviewedSet.has(w.q));
        const mergedStarred = mergeObjList(cur.starredProblems, inc.starredProblems, x => `${x.q || ''}|${x.answer || ''}`, 80);
        const mergedBookmarks = Array.from(new Set([...(Array.isArray(cur.bookmarks) ? cur.bookmarks : []), ...(Array.isArray(inc.bookmarks) ? inc.bookmarks : [])].filter(Boolean))).slice(0, 150);
        const mergedSolvedQIds = Array.from(new Set([...(Array.isArray(cur.solvedQIds) ? cur.solvedQIds : []), ...(Array.isArray(inc.solvedQIds) ? inc.solvedQIds : [])].filter(Boolean)));
        const mergedSpoken = Array.from(new Set([...(Array.isArray(cur.spokenPhrases) ? cur.spokenPhrases : []), ...(Array.isArray(inc.spokenPhrases) ? inc.spokenPhrases : [])].filter(Boolean))).slice(-200);

        const mergedLog = { ...(cur.studyLog && typeof cur.studyLog === 'object' ? cur.studyLog : {}) };
        if (inc.studyLog && typeof inc.studyLog === 'object') {
          Object.keys(inc.studyLog).forEach(dk => {
            mergedLog[dk] = Math.max(Number(mergedLog[dk] || 0), Number(inc.studyLog[dk] || 0));
          });
        }

        const curXp = Number(cur.xp || 0);
        const incXp = Number(inc.xp || 0);
        const curSolved = Number(cur.solved || 0);
        const incSolved = Number(inc.solved || 0);
        const bestStreak = incSolved > curSolved ? Math.max(Number(inc.streak || 0), Number(cur.streak || 0)) : Math.max(Number(cur.streak || 0), Number(inc.streak || 0));

        const curLv = CW_LEVEL_RANK[cur.currentLevel] ? cur.currentLevel : 'starter';
        const incLv = CW_LEVEL_RANK[inc.currentLevel] ? inc.currentLevel : 'starter';
        const bestLevel = CW_LEVEL_RANK[incLv] > CW_LEVEL_RANK[curLv] ? incLv : curLv;

        const curXpDate = String(cur.todayXpDate || '');
        const incXpDate = String(inc.todayXpDate || '');
        const bestXpDate = incXpDate >= curXpDate ? (incXpDate || curXpDate) : curXpDate;
        const bestTodayXp = (curXpDate && curXpDate === incXpDate)
          ? Math.max(Number(cur.todayXp || 0), Number(inc.todayXp || 0))
          : (incXpDate > curXpDate ? Number(inc.todayXp || 0) : Number(cur.todayXp || 0));
        const bestTodayXpEarned = (curXpDate && curXpDate === incXpDate)
          ? Math.max(Number(cur.todayXpEarned || 0), Number(inc.todayXpEarned || 0))
          : (incXpDate > curXpDate ? Number(inc.todayXpEarned || 0) : Number(cur.todayXpEarned || 0));

        const curSolvDate = String(cur.todaySolvedDate || '');
        const incSolvDate = String(inc.todaySolvedDate || '');
        const bestSolvDate = incSolvDate >= curSolvDate ? (incSolvDate || curSolvDate) : curSolvDate;
        const bestTodaySolvedCnt = (curSolvDate && curSolvDate === incSolvDate)
          ? Math.max(Number(cur.todaySolvedCount || 0), Number(inc.todaySolvedCount || 0))
          : (incSolvDate > curSolvDate ? Number(inc.todaySolvedCount || 0) : Number(cur.todaySolvedCount || 0));

        const curSpkDate = String(cur.spokenDoneDate || '');
        const incSpkDate = String(inc.spokenDoneDate || '');
        const bestSpkDate = incSpkDate >= curSpkDate ? (incSpkDate || curSpkDate) : curSpkDate;
        const bestSpkList = (curSpkDate && curSpkDate === incSpkDate)
          ? Array.from(new Set([...(Array.isArray(cur.spokenDoneList) ? cur.spokenDoneList : []), ...(Array.isArray(inc.spokenDoneList) ? inc.spokenDoneList : [])]))
          : (incSpkDate > curSpkDate ? (Array.isArray(inc.spokenDoneList) ? inc.spokenDoneList : []) : (Array.isArray(cur.spokenDoneList) ? cur.spokenDoneList : []));

        const lastStudyTime = String(inc.lastStudyTime || '') > String(cur.lastStudyTime || '')
          ? String(inc.lastStudyTime || '')
          : String(cur.lastStudyTime || inc.lastStudyTime || '');

        return {
          ...DEFAULT_STATE.learn,
          ...cur,
          ...inc,
          xp: Math.max(curXp, incXp),
          solved: Math.max(curSolved, incSolved),
          streak: bestStreak,
          currentLevel: bestLevel,
          quizIdx: Math.max(Number(cur.quizIdx || 0), Number(inc.quizIdx || 0)),
          quizInputMode: cur.quizInputMode || inc.quizInputMode || 'choice',
          gameBest: Math.max(Number(cur.gameBest || 0), Number(inc.gameBest || 0)),
          suwanGameBest: Math.max(Number(cur.suwanGameBest || 0), Number(inc.suwanGameBest || 0)),
          todayXpDate: bestXpDate,
          todayXp: bestTodayXp,
          todayXpEarned: bestTodayXpEarned,
          todaySolvedDate: bestSolvDate,
          todaySolvedCount: bestTodaySolvedCnt,
          spokenDoneDate: bestSpkDate,
          spokenDoneList: bestSpkList,
          lastStudyTime,
          studyLog: mergedLog,
          praiseStickers: mergedPraises,
          solvedHistory: mergedHist,
          wrongNotes: mergedWrong,
          bookmarks: mergedBookmarks,
          solvedQIds: mergedSolvedQIds,
          spokenPhrases: mergedSpoken,
          starredProblems: mergedStarred,
          resetAt: Math.max(curReset, incReset)
        };
      }
      window.__mergeLearnMonotonic = mergeLearnMonotonic;

      let __cwStateLoaded = false;
      let __cwIdbFlushTimer = null;
      let __cwPendingCoreObj = null;
      let __cwChatMediaCache = {};
      function persistMediaVaultsNow(force) {
        if (!__cwStateLoaded) return;
        try {
          const __aLen = Array.isArray(state.albums) ? state.albums.length : 0;
          const __vLen = Array.isArray(state.voiceLetters) ? state.voiceLetters.length : 0;
          const __mList = Array.isArray(state.chat?.messages) ? state.chat.messages : [];
          let __cmCnt = 0;
          for (let i = 0; i < __mList.length; i++) {
            const m = __mList[i];
            if (m && (m.photoUrl || m.videoUrl || m.audioUrl || (Array.isArray(m.photoUrls) && m.photoUrls.length))) __cmCnt++;
          }
          const __albCatTs = Array.isArray(state.albums) ? state.albums.reduce((acc, a) => acc + Number((a && a.categoryUpdatedAt) || 0), 0) : 0;
          const __lSig = `${Number(state.learn?.xp || 0)}:${Number(state.learn?.solved || 0)}:${(state.learn?.praiseStickers || []).length}:${Number(state.learn?.resetAt || 0)}`;
          const __sig = `${__aLen}:${__vLen}:${__cmCnt}:${(state.deletedAlbumIds || []).length}:${(state.deletedVoiceIds || []).length}:${__albCatTs}:${__lSig}`;
          if (!force && __sig === __cwLastMediaVaultSig) return;
          __cwLastMediaVaultSig = __sig;
          if (state.learn && (Number(state.learn.xp || 0) > 0 || Number(state.learn.solved || 0) > 0 || (state.learn.praiseStickers || []).length > 0 || Number(state.learn.resetAt || 0) > 0)) {
            idbPut('learn_vault_v1', state.learn);
          }
          // Never wipe non-empty IDB vaults with accidental empty arrays unless explicit deletions exist
          if (Array.isArray(state.albums) && (state.albums.length > 0 || (Array.isArray(state.deletedAlbumIds) && state.deletedAlbumIds.length > 0))) {
            idbPut('albums_vault_v1', state.albums);
          }
          if (Array.isArray(state.voiceLetters) && (state.voiceLetters.length > 0 || (Array.isArray(state.deletedVoiceIds) && state.deletedVoiceIds.length > 0))) {
            idbPut('voice_letters_vault_v1', state.voiceLetters);
          }
          if (Array.isArray(state.deletedAlbumIds) && state.deletedAlbumIds.length) {
            idbPut('deleted_albums_vault_v1', state.deletedAlbumIds);
          }
          if (Array.isArray(state.deletedVoiceIds) && state.deletedVoiceIds.length) {
            idbPut('deleted_voices_vault_v1', state.deletedVoiceIds);
          }
          // Dedicated persistent vault for messenger photos, videos, and voice messages
          if (Array.isArray(state.chat?.messages)) {
            let mediaCount = 0;
            const nextMap = { ...(__cwChatMediaCache || {}) };
            for (const m of state.chat.messages) {
              if (!m || !m.id) continue;
              const hasM = !!(m.photoUrl || m.videoUrl || m.audioUrl || (Array.isArray(m.photoUrls) && m.photoUrls.length));
              if (hasM) {
                nextMap[m.id] = {
                  photoUrl: m.photoUrl || '',
                  photoUrls: Array.isArray(m.photoUrls) && m.photoUrls.length ? m.photoUrls : undefined,
                  videoUrl: m.videoUrl || '',
                  audioUrl: m.audioUrl || ''
                };
                mediaCount++;
              }
            }
            if (mediaCount > 0 || Object.keys(nextMap).length > 0) {
              __cwChatMediaCache = nextMap;
              idbPut('chat_media_vault_v1', nextMap);
            }
          }
        } catch (_) {}
      }
      function normalizeAudioDataUrl(raw) {
        if (!raw || typeof raw !== 'string') return '';
        if (raw.startsWith('data:audio/')) return raw;
        if (/^data:(video\/(mp4|webm|ogg|3gpp)|application\/octet-stream|);base64,/i.test(raw)) {
          const m = raw.match(/^data:([^;]*);base64,/i);
          const sub = m && m[1] ? m[1].toLowerCase() : '';
          const targetMime = sub.includes('webm') ? 'audio/webm' : (sub.includes('ogg') ? 'audio/ogg' : 'audio/mp4');
          return raw.replace(/^data:[^;]*;base64,/i, `data:${targetMime};base64,`);
        }
        return raw;
      }
      window.__normalizeAudioDataUrl = normalizeAudioDataUrl;

      async function requestSafeAudioStream() {
        if (!navigator.mediaDevices || typeof navigator.mediaDevices.getUserMedia !== 'function') {
          throw new Error('NO_MEDIA_DEVICES');
        }
        try {
          return await navigator.mediaDevices.getUserMedia({ audio: true });
        } catch (_) {
          // Android WebView fallback when MODIFY_AUDIO_SETTINGS is absent: disable hardware AEC/AGC/NS so raw RECORD_AUDIO succeeds!
          return await navigator.mediaDevices.getUserMedia({
            audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false }
          });
        }
      }
      window.__requestSafeAudioStream = requestSafeAudioStream;

      // Lightweight Blob ObjectURL cache: replaces multi-MB base64 strings in DOM with 50-byte blob: URLs (prevents Android OOM crashes!)
      const __cwBlobUrlMap = new Map();
      function __cwMediaUrl(raw, fallbackMime) {
        if (!raw || typeof raw !== 'string') return '';
        if (raw.startsWith('data:image/')) return raw;
        if (!raw.startsWith('data:') || (raw.length < 400000 && !fallbackMime)) return raw;
        const key = `${fallbackMime || ''}:${raw.length}:${raw.slice(0, 48)}:${raw.slice(-24)}`;
        const cached = __cwBlobUrlMap.get(key);
        if (cached) return cached;
        try {
          const commaIdx = raw.indexOf(',');
          if (commaIdx < 0) return raw;
          const head = raw.slice(5, commaIdx);
          let mime = (head.split(';')[0] || '').trim().toLowerCase();
          if (!mime || mime === 'application/octet-stream' || (fallbackMime === 'video/mp4' && (mime === 'video/quicktime' || !mime.startsWith('video/')))) {
            mime = fallbackMime || 'application/octet-stream';
          }
          const b64 = raw.slice(commaIdx + 1);
          const bin = atob(b64);
          const len = bin.length;
          const bytes = new Uint8Array(len);
          for (let i = 0; i < len; i++) bytes[i] = bin.charCodeAt(i);
          const url = URL.createObjectURL(new Blob([bytes], { type: mime }));
          __cwBlobUrlMap.set(key, url);
          if (__cwBlobUrlMap.size > 160) {
            const oldestKey = __cwBlobUrlMap.keys().next().value;
            const oldestUrl = __cwBlobUrlMap.get(oldestKey);
            __cwBlobUrlMap.delete(oldestKey);
            try { URL.revokeObjectURL(oldestUrl); } catch (_) {}
          }
          return url;
        } catch (_) {
          return raw;
        }
      }
      window.__cwMediaUrl = __cwMediaUrl;

      function flushIdbStateNow(forceImmediate) {
        if (!__cwStateLoaded) return;
        if (!forceImmediate && !document.hidden && window.__isActivelyTyping && window.__isActivelyTyping()) {
          if (__cwIdbFlushTimer) clearTimeout(__cwIdbFlushTimer);
          __cwIdbFlushTimer = setTimeout(() => flushIdbStateNow(false), 1200);
          return;
        }
        flushLocalCoreNow(forceImmediate);
        if (__cwIdbFlushTimer) { clearTimeout(__cwIdbFlushTimer); __cwIdbFlushTimer = null; }
        try {
          // Persist media vaults first (dirty-checked), then store lightweight state in full_state_v6 to avoid 2x RAM spike on mobile!
          persistMediaVaultsNow();
          const liteFull = {
            ...extractLightweightCore(state),
            customVoices: state.customVoices || {},
            profile: { ...(state.profile || {}) }
          };
          idbPut('full_state_v6', liteFull);
          if (__cwPendingCoreObj) { idbPut('core_state_v6', __cwPendingCoreObj); __cwPendingCoreObj = null; }
        } catch (_) {}
      }
      // Request persistent browser storage so mobile OS never auto-evicts IndexedDB photos/voices
      try {
        if (navigator.storage && typeof navigator.storage.persist === 'function') {
          navigator.storage.persist().catch(() => {});
        }
      } catch (_) {}
      window.addEventListener('pagehide', () => flushIdbStateNow(true));
      document.addEventListener('visibilitychange', () => { if (document.hidden) flushIdbStateNow(true); });

      let __cwLastMediaVaultSig = '';
      let __cwLsWriteTimer = null;
      let __cwBroadcastTimer = null;
      function flushLocalCoreNow(forceImmediate) {
        if (__cwLsWriteTimer) { clearTimeout(__cwLsWriteTimer); __cwLsWriteTimer = null; }
        if (!__cwStateLoaded) return;
        if (!forceImmediate && !document.hidden && window.__isActivelyTyping && window.__isActivelyTyping()) {
          __cwLsWriteTimer = setTimeout(() => flushLocalCoreNow(false), 700);
          return;
        }
        try {
          const coreObj = __cwPendingCoreObj || extractLightweightCore(state);
          __cwPendingCoreObj = coreObj;
          localStorage.setItem(STORAGE_CORE_KEY, JSON.stringify(coreObj));
        } catch (_) {}
      }
      function saveState(broadcast) {
        if (!__cwStateLoaded) return;
        state.updatedAt = Date.now();
        if (Array.isArray(state.notifications) && state.notifications.length > 60) state.notifications = state.notifications.slice(0, 60);
        if (Array.isArray(state.transHistory) && state.transHistory.length > 60) state.transHistory = state.transHistory.slice(0, 60);
        __cwPendingCoreObj = null;
        // Zero-blocking UI thread: defer cloning & JSON.stringify into idle timer (260ms) + IDB flush (2000ms)
        if (__cwLsWriteTimer) clearTimeout(__cwLsWriteTimer);
        __cwLsWriteTimer = setTimeout(flushLocalCoreNow, 260);
        if (__cwIdbFlushTimer) clearTimeout(__cwIdbFlushTimer);
        __cwIdbFlushTimer = setTimeout(flushIdbStateNow, 2000);
        if (broadcast) {
          if (__cwBroadcastTimer) clearTimeout(__cwBroadcastTimer);
          __cwBroadcastTimer = setTimeout(() => {
            __cwBroadcastTimer = null;
            try {
              state.lastSaved = new Date().toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
              const coreObj = extractLightweightCore(state);
              __cwPendingCoreObj = coreObj;
              if (typeof window.__pushCloudSyncDelta === 'function') window.__pushCloudSyncDelta(coreObj);
              else if (typeof pushCloudSyncDelta === 'function') pushCloudSyncDelta(coreObj);
              if (liveChannel) { try { liveChannel.postMessage({ type: 'SYNC_STATE', core: coreObj }); } catch (_) {} }
            } catch (_) {}
          }, 16);
        }
        const setPanel = document.getElementById('tab-settings');
        if (setPanel && setPanel.classList.contains('active')) setTimeout(updateVaultIndicators, 60);
      }

      function updateVaultIndicators() {
        const dCnt = (state.diaries || []).length;
        const mCnt = (state.memos || []).length;
        const aCnt = (state.anniversaries || []).length;
        const pCnt = (state.albums || []).length;
        const vCnt = (state.voiceLetters || []).length;
        const isZh = state.lang === 'zh';
        const badge = document.getElementById('storageStatusBadge');
        if (badge) badge.textContent = isZh ? `🛡️ 日记 ${dCnt} · 备忘 ${mCnt} · 照片 ${pCnt}` : `🛡️ 일기 ${dCnt} · 메모 ${mCnt} · 사진 ${pCnt}`;
        const info = document.getElementById('lastSavedInfo');
        if (info) info.textContent = `${isZh ? '最后安全同步' : '마지막 안전 동기화'}: ${state.lastSaved || (isZh ? '刚刚' : '방금 전')}`;
        const grid = document.getElementById('vaultSummaryGrid');
        if (grid) {
          grid.innerHTML = `
            <div class="royal-subcard rounded-2xl p-2.5"><div class="text-[10px] text-mut">${isZh ? '日记 / 备忘' : '일기 · 메모'}</div><div class="text-sm font-bold text-gold">${dCnt} / ${mCnt}</div></div>
            <div class="royal-subcard rounded-2xl p-2.5"><div class="text-[10px] text-mut">${isZh ? '纪念日' : '기념일'}</div><div class="text-sm font-bold text-gold">${aCnt}${isZh ? '个' : '건'}</div></div>
            <div class="royal-subcard rounded-2xl p-2.5"><div class="text-[10px] text-mut">${isZh ? '相册照片(永久)' : '사진(영구금고)'}</div><div class="text-sm font-bold text-gold">${pCnt}${isZh ? '张' : '장'}</div></div>
            <div class="royal-subcard rounded-2xl p-2.5"><div class="text-[10px] text-mut">${isZh ? '语音信件(永久)' : '음성편지(영구금고)'}</div><div class="text-sm font-bold text-gold">${vCnt}${isZh ? '封' : '통'}</div></div>
          `;
        }
      }

      function uid() {
        return 'cw_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 8);
      }

      // Auto-prefix a matching emoji on Couple Space direct inputs if user didn't include one
      function autoPrefixCoupleEmoji(rawText) {
        const txt = String(rawText || '').trim();
        if (!txt) return txt;
        try {
          if (/\p{Extended_Pictographic}/u.test(txt)) return txt;
        } catch (_) {
          if (/[\uD83C-\uDBFF][\uDC00-\uDFFF]/.test(txt)) return txt;
        }
        const RULES = [
          [/(찌개|국밥|탕|전골|샤브|수제비|칼국수|설렁탕|갈비탕|火锅|汤)/, '🍲'],
          [/(마라|훠궈|떡볶이|매운|불닭|麻辣|辣)/, '🌶️'],
          [/(치킨|닭|통닭|炸鸡|鸡)/, '🍗'],
          [/(삼겹|갈비|고기|스테이크|소고기|한우|양꼬치|烤肉|牛排|羊肉串)/, '🥩'],
          [/(초밥|스시|회|연어|해산물|꽃게|새우|寿司|生鱼片|海鲜)/, '🍣'],
          [/(피자|披萨)/, '🍕'],
          [/(버거|햄버거|汉堡)/, '🍔'],
          [/(라면|라멘|짜장|짬뽕|국수|파스타|우동|냉면|쌀국수|面|拉面|米线)/, '🍜'],
          [/(김밥|비빔밥|볶음밥|덮밥|초밥|밥|炒饭|盖饭|拌饭)/, '🍚'],
          [/(만두|딤섬|교자|饺子|包子)/, '🥟'],
          [/(커피|카페|라떼|아메리카노|버블티|밀크티|차|咖啡|奶茶|茶)/, '☕'],
          [/(케이크|빵|디저트|아이스크림|마카롱|와플|딸기|과일|蛋糕|甜品|冰淇淋|草莓)/, '🍰'],
          [/(맥주|소주|술|와인|막걸리|하이볼|啤酒|酒|红酒)/, '🍺'],
          [/(여행|비행기|공항|제주|칭다오|서울|일본|도쿄|유럽|호텔|호캉스|旅游|旅行|飞机|青岛|首尔)/, '✈️'],
          [/(바다|해변|수영|서핑|海边|大海|沙滩)/, '🌊'],
          [/(영화|드라마|넷플릭스|극장|电影|看剧)/, '🎬'],
          [/(쇼핑|선물|옷|가방|반지|목걸이|购物|礼物|买)/, '🎁'],
          [/(사진|인생네컷|촬영|카메라|拍照|照片|合影)/, '📸'],
          [/(산책|공원|꽃|벚꽃|피크닉|데이트|散步|公园|约会|樱花)/, '🌸'],
          [/(노래|음악|콘서트|노래방|唱歌|音乐|演唱会)/, '🎶'],
          [/(놀이공원|에버랜드|롯데월드|디즈니|游乐园|迪士尼)/, '🎡'],
          [/(생일|축하|파티|기념일|生日|纪念日|庆祝)/, '🎂'],
          [/(결혼|약속|프로포즈|커플링|结婚|约定|戒指)/, '💍'],
          [/(사랑|좋아|보고싶|보고 싶|뽀뽀|안아|설레|爱你|想你|喜欢|抱抱|亲亲)/, '💜'],
          [/(고마|감사|감동|谢谢|感谢|感动)/, '🌷'],
          [/(아프|병원|약|건강|감기|生病|吃药|健康|医院)/, '💊'],
          [/(운동|헬스|요가|필라테스|러닝|수영|健身|运动|跑步)/, '💪'],
          [/(공부|한국어|중국어|시험|책|독서|学习|韩语|中文|考试|看书)/, '📚'],
          [/(잠|잘자|수면|꿀잠|睡觉|晚安|早睡)/, '🌙']
        ];
        for (const [re, em] of RULES) {
          if (re.test(txt)) return `${em} ${txt}`;
        }
        return txt;
      }

      function saveSuwanVoicesNow() {
        try {
          if (state && state.customVoices && typeof state.customVoices === 'object') {
            idbPut('suwan_voices_v1', { ...state.customVoices });
          }
          flushIdbStateNow();
        } catch (_) {}
      }

      function mergeWithDefaults(candidate, mediaSource) {
        const validThemes = ['pastel-royal', 'violet-bloom', 'velvet-dusk', 'coral-pink', 'pastel-blue', 'pastel-lavender', 'midnight-black', 'midnight-navy', 'rose-noir', 'pearl-silk', 'royal-amethyst'];
        const validFonts = FONTS.map(f => f.id);
        const validSizes = ['sm', 'md', 'lg', 'xl'];
        const albums = (Array.isArray(candidate.albums) && candidate.albums.length)
          ? candidate.albums
          : (mediaSource && Array.isArray(mediaSource.albums) ? mediaSource.albums : []);
        const customVoices = {
          ...(mediaSource && mediaSource.customVoices && typeof mediaSource.customVoices === 'object' ? mediaSource.customVoices : {}),
          ...(candidate.customVoices && typeof candidate.customVoices === 'object' ? candidate.customVoices : {})
        };
        const voiceLetters = (Array.isArray(candidate.voiceLetters) && candidate.voiceLetters.length)
          ? candidate.voiceLetters
          : (mediaSource && Array.isArray(mediaSource.voiceLetters) ? mediaSource.voiceLetters : []);
        const mediaMsgMap = new Map((mediaSource && mediaSource.chat && Array.isArray(mediaSource.chat.messages) ? mediaSource.chat.messages : []).map(m => [m.id, m]));
        if (candidate.chat && Array.isArray(candidate.chat.messages)) {
          candidate.chat.messages = candidate.chat.messages.map(m => {
            const fullM = mediaMsgMap.get(m.id);
            return fullM ? { ...m, photoUrl: m.photoUrl || fullM.photoUrl || '', photoUrls: (Array.isArray(m.photoUrls) && m.photoUrls.length) ? m.photoUrls : (Array.isArray(fullM.photoUrls) && fullM.photoUrls.length ? fullM.photoUrls : undefined), videoUrl: m.videoUrl || fullM.videoUrl || '', audioUrl: m.audioUrl || fullM.audioUrl || '' } : m;
          });
        }
        const suwanAvatar = (candidate.profile && candidate.profile.suwanAvatar) || (mediaSource && mediaSource.profile && mediaSource.profile.suwanAvatar) || '';
        const jingchanAvatar = (candidate.profile && candidate.profile.jingchanAvatar) || (mediaSource && mediaSource.profile && mediaSource.profile.jingchanAvatar) || '';
        const clean = (arr) => Array.isArray(arr) ? arr.filter(x => x && !DUMMY_IDS.has(x.id)) : [];

        return {
          ...DEFAULT_STATE,
          ...candidate,
          theme: validThemes.includes(candidate.theme) ? candidate.theme : 'pastel-royal',
          font: validFonts.includes(candidate.font) ? candidate.font : 'sans',
          dockFont: validFonts.includes(candidate.dockFont) ? candidate.dockFont : 'sans',
          fontSize: validSizes.includes(candidate.fontSize) ? candidate.fontSize : 'md',
          lang: candidate.lang === 'zh' ? 'zh' : 'ko',
          heartCount: Number(candidate.heartCount) || 0,
          cities: {
            suwan: { ...DEFAULT_STATE.cities.suwan, ...(candidate.cities?.suwan || {}) },
            jingchan: { ...DEFAULT_STATE.cities.jingchan, ...(candidate.cities?.jingchan || {}) }
          },
          albums,
          customVoices,
          voiceLetters,
          customPhrases: Array.isArray(candidate.customPhrases) ? candidate.customPhrases : [],
          notifications: Array.isArray(candidate.notifications) ? candidate.notifications : [],
          transHistory: Array.isArray(candidate.transHistory) ? candidate.transHistory : [],
          capsules: Array.isArray(candidate.capsules) ? candidate.capsules : [],
          anniversaries: clean(candidate.anniversaries),
          diaries: clean(candidate.diaries),
          memos: clean(candidate.memos),
          buckets: clean(candidate.buckets),
          profile: {
            ...DEFAULT_STATE.profile,
            ...(candidate.profile || {}),
            suwanAvatar,
            jingchanAvatar,
            suwanSleep: { ...DEFAULT_STATE.profile.suwanSleep, ...(candidate.profile?.suwanSleep || {}) },
            jingchanSleep: { ...DEFAULT_STATE.profile.jingchanSleep, ...(candidate.profile?.jingchanSleep || {}) }
          },
          meals: {
            ...DEFAULT_STATE.meals,
            ...(candidate.meals || {}),
            suwan: {
              breakfast: { ...DEFAULT_STATE.meals.suwan.breakfast, ...(candidate.meals?.suwan?.breakfast || {}) },
              lunch: { ...DEFAULT_STATE.meals.suwan.lunch, ...(candidate.meals?.suwan?.lunch || {}) },
              dinner: { ...DEFAULT_STATE.meals.suwan.dinner, ...(candidate.meals?.suwan?.dinner || {}) }
            },
            jingchan: {
              breakfast: { ...DEFAULT_STATE.meals.jingchan.breakfast, ...(candidate.meals?.jingchan?.breakfast || {}) },
              lunch: { ...DEFAULT_STATE.meals.jingchan.lunch, ...(candidate.meals?.jingchan?.lunch || {}) },
              dinner: { ...DEFAULT_STATE.meals.jingchan.dinner, ...(candidate.meals?.jingchan?.dinner || {}) }
            }
          },
          lavender: { ...DEFAULT_STATE.lavender, ...(candidate.lavender || {}), bonusLog: { ...(candidate.lavender?.bonusLog || {}) } },
          balanceGame: { ...DEFAULT_STATE.balanceGame, ...(candidate.balanceGame || {}), answers: { ...(candidate.balanceGame?.answers || {}) } },
          dateStamps: {
            ...DEFAULT_STATE.dateStamps,
            ...(candidate.dateStamps || {}),
            stamps: { ...(candidate.dateStamps?.stamps || {}) },
            customSpots: Array.isArray(candidate.dateStamps?.customSpots) ? candidate.dateStamps.customSpots : [],
            deletedIds: Array.isArray(candidate.dateStamps?.deletedIds) ? candidate.dateStamps.deletedIds : []
          },
          learn: { ...DEFAULT_STATE.learn, ...(candidate.learn || {}), wrongNotes: Array.isArray(candidate.learn?.wrongNotes) ? candidate.learn.wrongNotes : [] },
          chat: { ...DEFAULT_STATE.chat, ...(candidate.chat || {}), messages: clean(candidate.chat?.messages) },
          settings: { ...DEFAULT_STATE.settings, ...(candidate.settings || {}) }
        };
      }

      async function loadState() {
        const candidates = [];
        [STORAGE_CORE_KEY, STORAGE_PREV_CORE, STORAGE_LEGACY_KEY].forEach(k => {
          try { const r = localStorage.getItem(k); if (r) candidates.push(JSON.parse(r)); } catch (_) {}
        });
        try { const r = sessionStorage.getItem(STORAGE_CORE_KEY); if (r) candidates.push(JSON.parse(r)); } catch (_) {}
        try {
          if (typeof window.name === 'string' && window.name.startsWith('CHANWAN_V6:')) {
            candidates.push(JSON.parse(window.name.slice('CHANWAN_V6:'.length)));
          }
        } catch (_) {}
        const [idbV6, idbV6Core, idbV5, idbSuwanVoices, idbAlbumsVault, idbVoiceLettersVault, idbDelAlbumsVault, idbDelVoicesVault, idbChatMediaVault, idbLearnVault] = await Promise.all([
          idbGet('full_state_v6'),
          idbGet('core_state_v6'),
          idbGet('full_state'),
          idbGet('suwan_voices_v1'),
          idbGet('albums_vault_v1'),
          idbGet('voice_letters_vault_v1'),
          idbGet('deleted_albums_vault_v1'),
          idbGet('deleted_voices_vault_v1'),
          idbGet('chat_media_vault_v1'),
          idbGet('learn_vault_v1')
        ]);
        if (idbV6) candidates.push(idbV6);
        if (idbV6Core) candidates.push(idbV6Core);
        if (idbV5) candidates.push(idbV5);

        const valid = candidates.filter(c => c && typeof c === 'object');
        if (valid.length) {
          valid.sort((a, b) => (Number(b.updatedAt) || 0) - (Number(a.updatedAt) || 0));
          const mediaSource = idbV6 || idbV5 || valid.find(v => (v.albums && v.albums.length) || v.profile?.suwanAvatar);
          state = mergeWithDefaults(valid[0], mediaSource);
        }
        // Always union-merge Korean Study progress across all local candidates + dedicated learn_vault_v1!
        [idbV5 && idbV5.learn, idbV6 && idbV6.learn, idbV6Core && idbV6Core.learn, idbLearnVault].forEach(candL => {
          if (candL && typeof candL === 'object') {
            state.learn = mergeLearnMonotonic(state.learn, candL);
          }
        });
        // Always merge all persisted Suwan Voices from dedicated IDB vault so recordings NEVER disappear!
        state.customVoices = {
          ...(idbV5 && idbV5.customVoices && typeof idbV5.customVoices === 'object' ? idbV5.customVoices : {}),
          ...(idbV6 && idbV6.customVoices && typeof idbV6.customVoices === 'object' ? idbV6.customVoices : {}),
          ...(idbSuwanVoices && typeof idbSuwanVoices === 'object' ? idbSuwanVoices : {}),
          ...(state.customVoices && typeof state.customVoices === 'object' ? state.customVoices : {})
        };
        // Union-merge dedicated IDB Albums & Voice Letters vaults so photos/voice letters NEVER disappear!
        const __delAlbSet = new Set([
          ...(Array.isArray(state.deletedAlbumIds) ? state.deletedAlbumIds : []),
          ...(Array.isArray(idbDelAlbumsVault) ? idbDelAlbumsVault : [])
        ]);
        state.deletedAlbumIds = Array.from(__delAlbSet);
        const __albMap = new Map();
        const __addAlbums = (arr) => {
          if (!Array.isArray(arr)) return;
          for (const a of arr) {
            if (!a || !a.id || __delAlbSet.has(a.id)) continue;
            const prev = __albMap.get(a.id);
            if (!prev || (!prev.dataUrl && a.dataUrl)) __albMap.set(a.id, prev ? { ...prev, ...a, dataUrl: a.dataUrl || prev.dataUrl } : a);
          }
        };
        __addAlbums(idbV5 && idbV5.albums);
        __addAlbums(idbV6 && idbV6.albums);
        __addAlbums(idbAlbumsVault);
        __addAlbums(state.albums);
        state.albums = Array.from(__albMap.values()).sort((a, b) => Number(b.createdAt || 0) - Number(a.createdAt || 0));

        const __delVlSet = new Set([
          ...(Array.isArray(state.deletedVoiceIds) ? state.deletedVoiceIds : []),
          ...(Array.isArray(idbDelVoicesVault) ? idbDelVoicesVault : [])
        ]);
        state.deletedVoiceIds = Array.from(__delVlSet);
        const __vlMap = new Map();
        const __addVls = (arr) => {
          if (!Array.isArray(arr)) return;
          for (const v of arr) {
            if (!v || !v.id || __delVlSet.has(v.id)) continue;
            const prev = __vlMap.get(v.id);
            if (!prev || (!prev.audioUrl && v.audioUrl)) __vlMap.set(v.id, prev ? { ...prev, ...v, audioUrl: v.audioUrl || prev.audioUrl } : v);
          }
        };
        __addVls(idbV5 && idbV5.voiceLetters);
        __addVls(idbV6 && idbV6.voiceLetters);
        __addVls(idbVoiceLettersVault);
        __addVls(state.voiceLetters);
        state.voiceLetters = Array.from(__vlMap.values()).sort((a, b) => Number(b.createdAt || 0) - Number(a.createdAt || 0));
        // Always restore messenger photos/videos/voices from dedicated chat_media_vault_v1
        if (idbChatMediaVault && typeof idbChatMediaVault === 'object') {
          __cwChatMediaCache = { ...idbChatMediaVault };
          if (Array.isArray(state.chat?.messages)) {
            state.chat.messages = state.chat.messages.map(m => {
              if (!m || !m.id) return m;
              const cm = idbChatMediaVault[m.id];
              if (!cm) return m;
              return {
                ...m,
                photoUrl: m.photoUrl || cm.photoUrl || '',
                photoUrls: (Array.isArray(m.photoUrls) && m.photoUrls.length) ? m.photoUrls : (Array.isArray(cm.photoUrls) && cm.photoUrls.length ? cm.photoUrls : undefined),
                videoUrl: m.videoUrl || cm.videoUrl || '',
                audioUrl: m.audioUrl || cm.audioUrl || ''
              };
            });
          }
        }
        __cwStateLoaded = true;
      }

      /* ============================================================
         7. THEME, FONT, LANGUAGE, NAVIGATION, CLOCKS & WEATHER
         ============================================================ */
      const THEMES = [
        { id: 'pastel-royal', icon: '☀️', labelKo: '라이트 퍼플', labelZh: '浅紫光韵' },
        { id: 'violet-bloom', icon: '🪻', labelKo: '라일락 블룸', labelZh: '丁香花语' },
        { id: 'velvet-dusk', icon: '🌙', labelKo: '다크 퍼플', labelZh: '深紫夜幕' },
        { id: 'coral-pink', icon: '🍑', labelKo: '코랄 핑크', labelZh: '珊瑚蜜桃粉' }
      ,
        { id: 'pastel-blue', icon: '🩵', labelKo: '파스텔 블루', labelZh: '粉彩晴空蓝' },
        { id: 'pastel-lavender', icon: '🔮', labelKo: '파스텔 보라', labelZh: '粉彩薰衣草紫' },
        { id: 'midnight-navy', icon: '✨', labelKo: '미드나잇 네이비', labelZh: '午夜深蓝' },
        { id: 'rose-noir', icon: '🥀', labelKo: '로즈 누아르', labelZh: '黑玫瑰酒红' },
        { id: 'midnight-black', icon: '🖤', labelKo: '미드나잇 블랙', labelZh: '午夜纯黑' }
      ];
      const DARK_THEME_IDS = new Set(['velvet-dusk', 'royal-amethyst', 'midnight-black', 'midnight-navy', 'rose-noir']);

      function applyFont(fontId, silent) {
        const valid = FONTS.find(f => f.id === fontId) || FONTS[0];
        state.font = valid.id;
        document.documentElement.setAttribute('data-font', valid.id);
        document.querySelectorAll('.font-choice-btn').forEach(btn => {
          const isMatch = btn.getAttribute('data-font-choice') === valid.id;
          btn.style.borderColor = isMatch ? 'var(--accent-royal)' : 'var(--border-subtle)';
          btn.style.boxShadow = isMatch ? '0 0 0 2px var(--accent-royal-soft)' : 'none';
        });
        if (!silent) { saveState(); showToast(state.lang === 'zh' ? `🔤 已应用 ${valid.label} 字体` : `🔤 ${valid.label} 글꼴 적용`); }
      }

      function applyDockFont(fontId, silent) {
        const valid = FONTS.find(f => f.id === fontId) || FONTS[0];
        state.dockFont = valid.id;
        document.documentElement.setAttribute('data-dockfont', valid.id);
        document.querySelectorAll('.dockfont-choice-btn').forEach(btn => {
          const isMatch = btn.getAttribute('data-dockfont-choice') === valid.id;
          btn.className = `dockfont-choice-btn ${isMatch ? 'btn-royal' : 'btn-ghost'} px-3 py-1.5 rounded-full text-xs`;
        });
        if (!silent) { saveState(); showToast(state.lang === 'zh' ? `📌 底部导航字体: ${valid.label}` : `📌 하단 탭 글꼴: ${valid.label}`); }
      }

      let activeVoiceRecorder = null, activeVoiceStream = null, activeRecordPhrase = '', activeRecordTimer = null;

      function stopCustomVoiceRecording() {
        if (activeRecordTimer) { clearTimeout(activeRecordTimer); activeRecordTimer = null; }
        if (activeVoiceRecorder && activeVoiceRecorder.state !== 'inactive') {
          try { activeVoiceRecorder.stop(); } catch (_) {}
        }
        if (activeVoiceStream) {
          try { activeVoiceStream.getTracks().forEach(t => t.stop()); } catch (_) {}
          activeVoiceStream = null;
        }
        activeVoiceRecorder = null;
        activeRecordPhrase = '';
      }

      let vrPendingDataUrl = '';
      let vrCurrentPhrase = '';
      let vrTimerInterval = null;
      let vrStartTs = 0;
      let vrPcmCtx = null;
      let vrPcmProcessor = null;
      let vrPcmBuffers = [];
      let vrIsRecording = false;

      function encodePcmToWavDataUrl(floatBuffers, sampleRate) {
        let totalLen = 0;
        for (const b of floatBuffers) totalLen += b.length;
        const merged = new Float32Array(totalLen);
        let offset = 0;
        for (const b of floatBuffers) { merged.set(b, offset); offset += b.length; }
        const buffer = new ArrayBuffer(44 + merged.length * 2);
        const view = new DataView(buffer);
        const writeStr = (pos, str) => { for (let i = 0; i < str.length; i++) view.setUint8(pos + i, str.charCodeAt(i)); };
        writeStr(0, 'RIFF');
        view.setUint32(4, 36 + merged.length * 2, true);
        writeStr(8, 'WAVE');
        writeStr(12, 'fmt ');
        view.setUint32(16, 16, true);
        view.setUint16(20, 1, true);
        view.setUint16(22, 1, true);
        view.setUint32(24, sampleRate || 16000, true);
        view.setUint32(28, (sampleRate || 16000) * 2, true);
        view.setUint16(32, 2, true);
        view.setUint16(34, 16, true);
        writeStr(36, 'data');
        view.setUint32(40, merged.length * 2, true);
        let p = 44;
        for (let i = 0; i < merged.length; i++) {
          const s = Math.max(-1, Math.min(1, merged[i]));
          view.setInt16(p, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
          p += 2;
        }
        const bytes = new Uint8Array(buffer);
        let bin = '';
        for (let i = 0; i < bytes.length; i += 0x8000) {
          bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
        }
        return 'data:audio/wav;base64,' + btoa(bin);
      }

      function vrCleanupTracks() {
        if (vrTimerInterval) { clearInterval(vrTimerInterval); vrTimerInterval = null; }
        if (activeRecordTimer) { clearTimeout(activeRecordTimer); activeRecordTimer = null; }
        if (vrPcmProcessor) { try { vrPcmProcessor.disconnect(); } catch (_) {} vrPcmProcessor = null; }
        if (vrPcmCtx) { try { vrPcmCtx.close(); } catch (_) {} vrPcmCtx = null; }
        if (activeVoiceStream) {
          try { activeVoiceStream.getTracks().forEach(t => t.stop()); } catch (_) {}
          activeVoiceStream = null;
        }
        activeVoiceRecorder = null;
        vrIsRecording = false;
      }

      function vrSetPreview(dataUrl) {
        vrPendingDataUrl = dataUrl || '';
        const wrap = document.getElementById('vrPreviewWrap');
        const aud = document.getElementById('vrPreviewAudio');
        const saveBtn = document.getElementById('vrSaveBtn');
        if (vrPendingDataUrl && wrap && aud) {
          aud.src = vrPendingDataUrl;
          wrap.classList.remove('hidden');
          if (saveBtn) { saveBtn.classList.remove('opacity-50', 'pointer-events-none'); }
        } else {
          if (wrap) wrap.classList.add('hidden');
          if (aud) { aud.pause(); aud.removeAttribute('src'); }
          if (saveBtn) { saveBtn.classList.add('opacity-50', 'pointer-events-none'); }
        }
      }

      function vrUpdateRecBtnUI(recording) {
        const btn = document.getElementById('vrRecordBtn');
        const dot = document.getElementById('vrStatusDot');
        const st = document.getElementById('vrStatusText');
        const isZh = state.lang === 'zh';
        if (btn) {
          btn.innerHTML = recording
            ? `<span class="inline-flex items-center gap-1.5">${CW_MEDIA_SVG.stopBadge}<span>${isZh ? '停止录音' : '녹음 중지'}</span></span>`
            : `<span class="inline-flex items-center gap-1.5">${CW_MEDIA_SVG.recDot}<span>${isZh ? '开始录音' : '녹음 시작'}</span></span>`;
          btn.classList.toggle('badge-pulse', recording);
        }
        if (dot) dot.style.background = recording ? '#e11d48' : '#a855f7';
        if (st) st.textContent = recording ? (isZh ? '正在录音... 读完点停止' : '녹음 중이에요! 다 읽으면 중지를 눌러주세요') : (isZh ? '点击下方按钮朗读，或导入手机录音文件' : '녹음 시작을 누르거나 휴대폰 녹음 파일을 불러오세요');
      }

      function stopVrRecordingNow() {
        if (!vrIsRecording) return;
        const isZh = state.lang === 'zh';
        vrUpdateRecBtnUI(false);
        if (vrTimerInterval) { clearInterval(vrTimerInterval); vrTimerInterval = null; }
        if (activeRecordTimer) { clearTimeout(activeRecordTimer); activeRecordTimer = null; }

        if (activeVoiceRecorder && activeVoiceRecorder.state !== 'inactive') {
          try { activeVoiceRecorder.requestData && activeVoiceRecorder.requestData(); } catch (_) {}
          try { activeVoiceRecorder.stop(); } catch (_) { vrCleanupTracks(); }
          return;
        }
        if (vrPcmBuffers.length > 0) {
          const sr = vrPcmCtx ? vrPcmCtx.sampleRate : 16000;
          const wavUrl = encodePcmToWavDataUrl(vrPcmBuffers, sr);
          vrPcmBuffers = [];
          vrCleanupTracks();
          vrSetPreview(wavUrl);
          const st = document.getElementById('vrStatusText');
          if (st) st.textContent = isZh ? '录音完成！先试听再点保存 💜' : '녹음 완료! 미리듣기 후 저장을 눌러주세요 💜';
          return;
        }
        vrCleanupTracks();
      }

      let vrConnecting = false;
      async function startVrRecordingNow() {
        const isZh = state.lang === 'zh';
        if (vrIsRecording) { stopVrRecordingNow(); return; }
        if (vrConnecting) return;

        const st = document.getElementById('vrStatusText');
        const btn = document.getElementById('vrRecordBtn');
        const fl = document.getElementById('vrFileLabel');
        const dot = document.getElementById('vrStatusDot');

        const showMicFallbackNotice = (reasonKo, reasonZh) => {
          vrConnecting = false;
          vrCleanupTracks();
          vrUpdateRecBtnUI(false);
          if (dot) dot.style.background = '#f59e0b';
          if (st) st.textContent = isZh ? reasonZh : reasonKo;
          if (fl) { fl.classList.remove('btn-ghost'); fl.classList.add('btn-gold'); }
          showToast(isZh ? reasonZh : reasonKo);
        };

        const isLocalFile = window.location && window.location.protocol === 'file:';
        const isEmbedded = (() => { try { return window.self !== window.top; } catch (_) { return true; } })();
        if (isLocalFile || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
          // On local file:// HTML (where browsers block Web Mic API), open native phone mic/audio picker immediately in 1 tap!
          const fi = document.getElementById('vrFileInput');
          if (st) st.textContent = isZh ? '已打开手机录音/音频选择，录完后自动载入 💜' : '기기 녹음기/파일 선택창을 열었어요. 녹음하거나 파일을 고르면 바로 들어와요 💜';
          if (fi) { fi.click(); return; }
          showMicFallbackNotice(
            '로컬 HTML 파일에서는 브라우저 정책상 「🎙️ 기기 녹음·파일」 버튼으로 녹음해 주세요!',
            '本地 HTML 文件请点击「🎙️ 手机录音·文件」直接录音哦！'
          );
          return;
        }

        // Instant visual feedback the millisecond the button is clicked!
        vrConnecting = true;
        if (btn) btn.textContent = isZh ? '⏳ 连接麦克风...' : '⏳ 마이크 연결 중...';
        if (st) st.textContent = isZh ? '正在请求麦克风权限，请点击允许...' : '마이크 권한을 요청 중이에요. 팝업이 뜨면 허용을 눌러주세요...';
        if (dot) dot.style.background = '#f59e0b';

        try {
          const micPromise = requestSafeAudioStream();
          const waitMs = isEmbedded ? 2500 : 25000;
          const timeoutPromise = new Promise((_, reject) => setTimeout(() => reject(new Error('MIC_TIMEOUT')), waitMs));
          const stream = await Promise.race([micPromise, timeoutPromise]);
          vrConnecting = false;

          activeVoiceStream = stream;
          vrIsRecording = true;
          vrStartTs = Date.now();
          vrUpdateRecBtnUI(true);
          const tEl = document.getElementById('vrTimerText');
          if (tEl) tEl.textContent = '00:00';
          vrTimerInterval = setInterval(() => {
            const sec = Math.floor((Date.now() - vrStartTs) / 1000);
            if (tEl) tEl.textContent = `${String(Math.floor(sec / 60)).padStart(2, '0')}:${String(sec % 60).padStart(2, '0')}`;
          }, 250);

          let startedMediaRecorder = false;
          if (typeof MediaRecorder !== 'undefined') {
            try {
              const mimeCandidates = ['audio/mp4', 'audio/webm;codecs=opus', 'audio/webm', 'audio/ogg;codecs=opus', 'audio/ogg'];
              const chosenMime = mimeCandidates.find(m => MediaRecorder.isTypeSupported && MediaRecorder.isTypeSupported(m)) || '';
              const rec = chosenMime ? new MediaRecorder(stream, { mimeType: chosenMime }) : new MediaRecorder(stream);
              const chunks = [];
              activeVoiceRecorder = rec;
              rec.ondataavailable = (ev) => { if (ev.data && ev.data.size > 0) chunks.push(ev.data); };
              rec.onstop = () => {
                try {
                  const blob = new Blob(chunks, { type: chosenMime || (chunks[0] && chunks[0].type) || 'audio/webm' });
                  if (blob.size > 100) {
                    const reader = new FileReader();
                    reader.onloadend = () => {
                      vrSetPreview(String(reader.result || ''));
                      if (st) st.textContent = isZh ? '录音完成！先试听再点保存 💜' : '녹음 완료! 미리듣기 후 저장을 눌러주세요 💜';
                    };
                    reader.readAsDataURL(blob);
                  } else {
                    if (st) st.textContent = isZh ? '录音时间太短，请说满1秒再点停止 🎙️' : '녹음이 너무 짧아요. 1초 이상 말하고 중지를 눌러주세요 🎙️';
                  }
                } catch (_) {}
                vrCleanupTracks();
              };
              rec.start(250);
              startedMediaRecorder = true;
            } catch (_) {
              activeVoiceRecorder = null;
            }
          }

          // Fallback Engine 2: Universal PCM WAV Capture
          if (!startedMediaRecorder) {
            const AC = window.AudioContext || window.webkitAudioContext;
            if (!AC) throw new Error('no_audio_ctx');
            vrPcmCtx = new AC();
            const src = vrPcmCtx.createMediaStreamSource(stream);
            vrPcmProcessor = vrPcmCtx.createScriptProcessor(4096, 1, 1);
            vrPcmBuffers = [];
            vrPcmProcessor.onaudioprocess = (e) => {
              if (vrIsRecording) vrPcmBuffers.push(new Float32Array(e.inputBuffer.getChannelData(0)));
            };
            src.connect(vrPcmProcessor);
            vrPcmProcessor.connect(vrPcmCtx.destination);
          }

          activeRecordTimer = setTimeout(() => { if (vrIsRecording) stopVrRecordingNow(); }, 15000);
        } catch (err) {
          const isTimeout = err && err.message === 'MIC_TIMEOUT';
          const koMsg = isEmbedded
            ? '미리보기 창에서는 웹 마이크가 제한돼요 → 옆의 「🎙️ 기기 녹음·파일」을 눌러 주세요!'
            : (isTimeout
              ? '마이크 응답이 지연돼요 → 옆의 「🎙️ 기기 녹음·파일」 버튼으로 바로 녹음해 주세요!'
              : '브라우저 마이크 권한이 차단돼 있어요 → 주소창 권한을 허용하거나 「🎙️ 기기 녹음·파일」을 눌러 주세요!');
          const zhMsg = isEmbedded
            ? '当前预览窗口限制了网页麦克风 → 请点旁边「🎙️ 手机录音·文件」！'
            : '浏览器未授予麦克风权限 → 请点「🎙️ 手机录音·文件」直接录音！';
          showMicFallbackNotice(koMsg, zhMsg);
        }
      }

      function closeVoiceRecorderModal() {
        stopVrRecordingNow();
        vrCleanupTracks();
        const modal = document.getElementById('voiceRecorderModal');
        if (modal) modal.classList.add('hidden');
      }

      function toggleRecordCustomVoice(phraseText, btnEl) {
        const phrase = String(phraseText || '').trim();
        if (!phrase) return;
        vrCurrentPhrase = phrase;
        const isZh = state.lang === 'zh';
        const matchItem = CHEAT_SHEET_72.find(x => x.ko === phrase);
        document.getElementById('vrModalTitle').textContent = isZh ? '🎙️ 秀完原声录音' : '🎙️ 수완 보이스 녹음';
        document.getElementById('vrPhraseKo').textContent = phrase;
        document.getElementById('vrPhraseZh').textContent = matchItem ? matchItem.zh : '';
        document.getElementById('vrTimerText').textContent = '00:00';
        vrUpdateRecBtnUI(false);

        const existingUrl = state.customVoices && state.customVoices[phrase];
        const delBtn = document.getElementById('vrDeleteBtn');
        if (existingUrl) {
          vrSetPreview(existingUrl);
          if (delBtn) delBtn.classList.remove('hidden');
        } else {
          vrSetPreview('');
          if (delBtn) delBtn.classList.add('hidden');
        }
        document.getElementById('voiceRecorderModal').classList.remove('hidden');

      }

      // Bind Voice Recorder Modal events once
      (function initVoiceRecorderModal() {
        const closeBtn = document.getElementById('vrCloseBtn');
        const cancelBtn = document.getElementById('vrCancelBtn');
        const recBtn = document.getElementById('vrRecordBtn');
        const saveBtn = document.getElementById('vrSaveBtn');
        const delBtn = document.getElementById('vrDeleteBtn');
        const fileInp = document.getElementById('vrFileInput');
        const vrModal = document.getElementById('voiceRecorderModal');
        if (vrModal) vrModal.addEventListener('click', (e) => { if (e.target === vrModal) closeVoiceRecorderModal(); });
        if (closeBtn) closeBtn.addEventListener('click', closeVoiceRecorderModal);
        if (cancelBtn) cancelBtn.addEventListener('click', closeVoiceRecorderModal);
        if (recBtn) recBtn.addEventListener('click', startVrRecordingNow);
        if (fileInp) {
          fileInp.addEventListener('change', (e) => {
            const f = e.target.files && e.target.files[0];
            if (!f) return;
            if (f.size > 5 * 1024 * 1024) { showToast(state.lang === 'zh' ? '语音文件需小于 5MB 才能保存哦' : '음성 파일은 5MB 이하만 저장할 수 있어요.'); return; }
            const reader = new FileReader();
            reader.onloadend = () => {
              vrSetPreview(String(reader.result || ''));
              const st = document.getElementById('vrStatusText');
              if (st) st.textContent = state.lang === 'zh' ? '音频已载入！试听后点保存 💜' : '음성 파일이 준비됐어요! 미리듣기 후 저장하세요 💜';
            };
            reader.readAsDataURL(f);
            e.target.value = '';
          });
        }
        if (saveBtn) {
          saveBtn.addEventListener('click', () => {
            if (!vrCurrentPhrase || !vrPendingDataUrl) return;
            if (!state.customVoices || typeof state.customVoices !== 'object') state.customVoices = {};
            state.customVoices[vrCurrentPhrase] = vrPendingDataUrl;
            saveSuwanVoicesNow();
            saveState(true);
            if (typeof window.__pushMediaSyncPacket === 'function') {
              const ext = vrPendingDataUrl.includes('audio/wav') ? 'wav' : (vrPendingDataUrl.includes('audio/mp4') ? 'mp4' : 'webm');
              window.__pushMediaSyncPacket('custom_voice', { phrase: vrCurrentPhrase }, vrPendingDataUrl, `voice.${ext}`);
            }
            try { playGentleChime(); } catch (_) {}
            closeVoiceRecorderModal();
            try { renderLearn(); } catch (_) {}
            try { renderHome(); } catch (_) {}
            showToast(state.lang === 'zh' ? '🎧 秀完原声已保存！点喇叭就能听到啦' : '🎧 수완 보이스로 저장됐어요! 이제 스피커를 누르면 바로 들려요');
          });
        }
        if (delBtn) {
          delBtn.addEventListener('click', () => {
            deleteCustomVoice(vrCurrentPhrase);
            closeVoiceRecorderModal();
          });
        }
      })();

      function deleteCustomVoice(phraseText) {
        const phrase = String(phraseText || '').trim();
        if (state.customVoices && state.customVoices[phrase]) {
          delete state.customVoices[phrase];
          saveSuwanVoicesNow();
          saveState(true);
          renderLearn();
          renderHome();
          showToast(state.lang === 'zh' ? '已删除录音，恢复默认语音' : '녹음을 삭제하고 기본 음성으로 되돌렸어요.');
        }
      }

      function suwanVoicePillHtml(phrase) {
        if (!phrase || !state.customVoices || !state.customVoices[phrase]) return '';
        const lbl = state.lang === 'zh' ? '🎧 秀完原声' : '🎧 수완 보이스';
        return `<span class="cw-suwan-voice-pill">${lbl}</span>`;
      }

      function speakKorean(text) { speakText(text, 'ko-KR'); }
      function speakChinese(text) { speakText(text, 'zh-CN'); }

      function applyFontSize(sizeId, silent) {
        const valid = ['sm', 'md', 'lg', 'xl'].includes(sizeId) ? sizeId : 'md';
        state.fontSize = valid;
        document.documentElement.setAttribute('data-fontsize', valid);
        const labelMapKo = { sm: '작게 · 85%', md: '보통 · 100%', lg: '크게 · 112%', xl: '아주 크게 · 125%' };
        const labelMapZh = { sm: '小 · 85%', md: '中 · 100%', lg: '大 · 112%', xl: '超大 · 125%' };
        const badge = document.getElementById('fontSizeBadge');
        if (badge) badge.textContent = (state.lang === 'zh' ? labelMapZh : labelMapKo)[valid];
        document.querySelectorAll('.fontsize-btn').forEach(btn => {
          const isMatch = btn.getAttribute('data-size') === valid;
          btn.className = `fontsize-btn px-2.5 py-1 rounded-full text-[11px] font-semibold ${isMatch ? 'btn-royal' : 'btn-ghost'}`;
        });
        if (!silent) {
          saveState();
          showToast(state.lang === 'zh' ? `字号已调整：${labelMapZh[valid]} ✨` : `글자 크기 변경: ${labelMapKo[valid]} ✨`);
        }
      }

      function applyTheme(themeId, silent) {
        const valid = THEMES.find(t => t.id === themeId) || THEMES[0];
        state.theme = valid.id;
        document.documentElement.setAttribute('data-theme', valid.id);
        const tcMeta = document.getElementById('themeColorMeta');
        const isDarkTheme = DARK_THEME_IDS.has(valid.id);
        document.documentElement.setAttribute('data-dark', isDarkTheme ? '1' : '0');
        try { localStorage.setItem(isDarkTheme ? 'cw_last_dark_theme' : 'cw_last_light_theme', valid.id); } catch (_) {}
        const tcMap = { 'pastel-royal': '#ffffff', 'velvet-dusk': '#120d1f', 'midnight-black': '#09090b', 'midnight-navy': '#0a1222', 'rose-noir': '#170e15', 'pearl-silk': '#ffffff', 'violet-bloom': '#ffffff', 'royal-amethyst': '#120d1f', 'coral-pink': '#ffffff', 'pastel-blue': '#ffffff', 'pastel-lavender': '#ffffff' };
        const bgHex = tcMap[valid.id] || '#f6f2f9';
        if (tcMeta) tcMeta.setAttribute('content', bgHex);
        const csMeta = document.getElementById('colorSchemeMeta');
        if (csMeta) csMeta.setAttribute('content', isDarkTheme ? 'dark' : 'light');
        document.documentElement.style.colorScheme = isDarkTheme ? 'dark' : 'light';
        document.documentElement.style.backgroundColor = bgHex;
        if (document.body) document.body.style.backgroundColor = bgHex;
        const iconEl = document.getElementById('themeIcon');
        const themeBtn = document.getElementById('cycleThemeBtn');
        if (iconEl) {
          delete iconEl.dataset.origEmoji;
          iconEl.classList.add('cw-keep-native-emoji');
          iconEl.textContent = valid.icon;
        }
        if (themeBtn) themeBtn.title = state.lang === 'zh' ? valid.labelZh : valid.labelKo;
        const hdrThIco = document.getElementById('headerThemeToggleIcon');
        if (hdrThIco) { delete hdrThIco.dataset.origEmoji; hdrThIco.textContent = isDarkTheme ? '☀️' : '🌙'; }
        if (typeof window.__syncPartnerBubbleForTheme === 'function') window.__syncPartnerBubbleForTheme();
        if (typeof window.scheduleIconSync === 'function') window.scheduleIconSync(document.querySelector('header'));
        document.querySelectorAll('.theme-choice-btn').forEach(btn => {
          const isMatch = btn.getAttribute('data-theme-choice') === valid.id;
          btn.style.borderColor = isMatch ? 'var(--accent-royal)' : 'var(--border-subtle)';
          btn.style.boxShadow = isMatch ? '0 0 0 2px var(--accent-royal-soft)' : 'none';
        });
        const lAct = document.getElementById('themeDrawerLightActive');
        const dAct = document.getElementById('themeDrawerDarkActive');
        const activeLabel = state.lang === 'zh' ? valid.labelZh : valid.labelKo;
        if (lAct) { lAct.textContent = activeLabel; lAct.classList.toggle('hidden', isDarkTheme); }
        if (dAct) { dAct.textContent = activeLabel; dAct.classList.toggle('hidden', !isDarkTheme); }
        if (!silent) { saveState(); showToast(`${valid.icon} ${state.lang === 'zh' ? valid.labelZh : valid.labelKo}`); }
      }

      function applyLanguage(lang, silent) {
        state.lang = lang === 'zh' ? 'zh' : 'ko';
        document.documentElement.lang = state.lang === 'zh' ? 'zh-CN' : 'ko';
        const dict = I18N[state.lang];
        document.querySelectorAll('[data-i18n]').forEach(el => {
          const key = el.getAttribute('data-i18n');
          if (dict[key]) { delete el.dataset.origEmoji; el.textContent = dict[key]; }
        });
        document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
          const key = el.getAttribute('data-i18n-placeholder');
          if (dict[key]) el.setAttribute('placeholder', dict[key]);
        });
        const langActiveEl = document.getElementById('langToggleActive');
        const langNextEl = document.getElementById('langToggleNext');
        if (langActiveEl && langNextEl) {
          langActiveEl.textContent = state.lang === 'zh' ? '中' : '한';
          langNextEl.textContent = state.lang === 'zh' ? '한' : '中';
        }
        applyTheme(state.theme, true);
        applyFontSize(state.fontSize, true);
        document.querySelectorAll('.chat-quick-chip').forEach(ch => {
          ch.textContent = ch.getAttribute(state.lang === 'zh' ? 'data-zh' : 'data-ko');
        });
        renderNotifications();
        if (typeof renderChat === 'function') renderChat();
        const __runDeferredRenders = () => {
          if (typeof renderDiaryQaMemos === 'function') renderDiaryQaMemos();
          if (typeof renderBucketAndAlbum === 'function') renderBucketAndAlbum();
          if (typeof renderCoupons === 'function') renderCoupons();
          if (typeof renderVoiceLetters === 'function') renderVoiceLetters();
          if (typeof renderChatStickers === 'function') renderChatStickers();
          if (typeof renderAnniversary === 'function') renderAnniversary();
        };
        if (document.getElementById('tab-space')?.classList.contains('active')) {
          __runDeferredRenders();
        } else {
          setTimeout(__runDeferredRenders, 60);
        }
        if (typeof syncChinaModeUi === 'function') syncChinaModeUi();
        if (typeof window.__syncHideNotifPrevUi === 'function') window.__syncHideNotifPrevUi();
        if (typeof updateSysNotifStatus === 'function') updateSysNotifStatus();
        if (typeof applyMyRole === 'function') applyMyRole(state.myRole || 'suwan', true);
        if (typeof window.__refreshE2eeUi === 'function') window.__refreshE2eeUi();
        if (typeof updateClocks === 'function') updateClocks();
        if (typeof refreshBothCityWeathers === 'function') refreshBothCityWeathers();
        if (typeof renderLearn === 'function') renderLearn();
        if (typeof renderHome === 'function') renderHome();
        if (typeof renderComplimentJar === 'function') renderComplimentJar(); if (typeof window.renderTruthDare === 'function') window.renderTruthDare(); if (typeof renderCoupleQuizzes === 'function') renderCoupleQuizzes();
        if (typeof renderCoupleQuizzes === 'function') renderCoupleQuizzes();
        if (typeof renderFoodRouletteMeta === 'function') renderFoodRouletteMeta();
        if (typeof renderCoupleFortune === 'function') renderCoupleFortune();
        if (typeof renderLoveThermometer === 'function') renderLoveThermometer();
        if (typeof window.__renderPresenceBadges === 'function') window.__renderPresenceBadges();
        if (typeof window.__syncPartnerBubbleForTheme === 'function') window.__syncPartnerBubbleForTheme();
        if (typeof window.__renderErrorMemoUi === 'function') window.__renderErrorMemoUi();
        if (typeof window.__syncGeminiKeyUi === 'function') window.__syncGeminiKeyUi();
        if (typeof window.__autoFixLayoutSpacing === 'function') setTimeout(window.__autoFixLayoutSpacing, 80);
        if (typeof window.scheduleIconSync === 'function') window.scheduleIconSync();
        if (typeof renderTmiBook === 'function') renderTmiBook();
        if (typeof renderComplimentJar === 'function') renderComplimentJar();
        if (typeof renderCoupleFortune === 'function') renderCoupleFortune();
        if (typeof renderFoodRouletteMeta === 'function') renderFoodRouletteMeta();
        if (typeof renderCoupleQuizzes === 'function') renderCoupleQuizzes();
        if (typeof renderBalanceGame === 'function') renderBalanceGame();
        if (typeof renderDateStampMap === 'function') renderDateStampMap();
        // Localize Sleep Sounds labels cleanly in ZH/KO
        const isZhL = state.lang === 'zh';
        const sMap = {
          rain: isZhL ? ['温柔雨声', '窗外淅沥小雨'] : ['빗소리', '창밖의 잔잔한 빗방울'],
          ocean: isZhL ? ['海浪轻拍', '舒缓夜晚海浪'] : ['파도소리', '느리게 밀려오는 밤바다'],
          fire: isZhL ? ['温暖壁炉', '噼啪木柴暖音'] : ['모닥불', '포근한 장작 타는 소리'],
          night: isZhL ? ['静谧晚风', '深夜柔和微风'] : ['밤바람', '깊은 밤의 부드러운 바람']
        };
        document.querySelectorAll('.sleep-snd-btn').forEach(btn => {
          const k = btn.getAttribute('data-sound');
          const divs = btn.querySelectorAll('div');
          if (sMap[k] && divs.length >= 3) { divs[1].textContent = sMap[k][0]; divs[2].textContent = sMap[k][1]; }
        });
        const slTitle = document.getElementById('sleepSndTitle');
        const slSub = document.getElementById('sleepSndSubLabel');
        const slVol = document.getElementById('sleepVolLabel');
        const slStop = document.getElementById('sleepStopBtn');
        if (slTitle) slTitle.textContent = isZhL ? '🌙 晚安助眠白噪音' : '🌙 굿나잇 수면 사운드';
        if (slSub) slSub.textContent = isZhL ? '🌧️ 100% 离线治愈 ASMR' : '🌧️ 100% 오프라인 힐링 ASMR';
        if (slVol) slVol.textContent = isZhL ? '🔊 音量大小' : '🔊 소리 크기';
        if (slStop) slStop.innerHTML = `<span class="inline-flex items-center gap-1">${CW_MEDIA_SVG.stopSoft}<span>${isZhL ? '停止' : '멈추기'}</span></span>`;
        setTimeout(() => {
          if (typeof window.syncAllTabIconsToStyle === 'function') {
            const actPanel = document.querySelector('.tab-panel.active');
            window.syncAllTabIconsToStyle(localStorage.getItem('chanwan_icon_style_v1') || (state.settings && state.settings.iconStyle) || 'pastel', actPanel || document.body);
          }
        }, 30);
        const mAnd = document.getElementById('manualStepAndroid');
        const mBai = document.getElementById('manualStepBaidu');
        const mIos = document.getElementById('manualStepIos');
        if (mAnd && mBai && mIos) {
          if (state.lang === 'zh') {
            mAnd.innerHTML = '• <b>安卓 / 三星手机</b>：打开手机「文件管理」长按 <code>chanwan_shiguang_plus1_0.html</code> → 点 <b>更多(⋮) → 「添加到主屏幕」</b>';
            mBai.innerHTML = '• <b>百度浏览器 (中国大陆)</b>：微信点开文件 → 右上角 <b>··· → 「用其他应用打开」 → 百度浏览器</b> → 底部 <b>菜单(≡) → 「添加到桌面 / 收藏」</b>';
            mIos.innerHTML = '• <b>苹果手机 (Safari · 网页版)</b>：点底部 <b>分享(□↑)</b> → <b>「添加到主屏幕」</b> → <b>添加</b>';
          } else {
            mAnd.innerHTML = '• <b>안드로이드 / 삼성폰</b>: 「내 파일」 앱에서 <code>chanwan_shiguang_plus1_0.html</code> 길게 누르기 → 오른쪽 아래 <b>더보기(⋮) → 「홈 화면에 추가」</b>';
            mBai.innerHTML = '• <b>중국 바이두 브라우저 (百度浏览器)</b>: 위챗에서 파일 열기 → 오른쪽 위 <b>··· → 「用其他应用打开」 → 바이두 브라우저</b> → 하단 <b>메뉴(≡) → 「添加到桌面 / 收藏」</b>';
            mIos.innerHTML = '• <b>아이폰 (Safari · 웹 주소로 열었을 때)</b>: 하단 <b>공유(□↑)</b> 버튼 → <b>「홈 화면에 추가」</b> → <b>추가</b>';
          }
        }
        const studioInp = document.getElementById('studioTransInput');
        const studioDet = document.getElementById('studioTransDetected');
        if (studioInp && studioDet) {
          const sv = studioInp.value.trim();
          if (!sv) {
            studioDet.textContent = state.lang === 'zh' ? '⚡ 输入即自动实时翻译' : '⚡ 입력하면 바로 실시간 자동 번역돼요';
          } else {
            studioDet.textContent = state.lang === 'zh'
              ? (detectLanguage(sv) === 'ko' ? '🇰🇷 识别到韩语 → 🇨🇳 实时自动翻译中' : '🇨🇳 识别到中文 → 🇰🇷 实时自动翻译中')
              : (detectLanguage(sv) === 'ko' ? '🇰🇷 한국어 감지 → 🇨🇳 실시간 자동 번역 중' : '🇨🇳 중국어 감지 → 🇰🇷 실시간 자동 번역 중');
            if (typeof triggerStudioLiveTranslate === 'function') triggerStudioLiveTranslate(false);
          }
        }
        const homeInp = document.getElementById('homeTransInput');
        if (homeInp && homeInp.value.trim()) {
          homeInp.dispatchEvent(new Event('input'));
        }
        if (typeof runAutoBugFixer === 'function') runAutoBugFixer(false);
        const sndBtn = document.getElementById('toggleSoundBtn');
        if (sndBtn) sndBtn.textContent = state.soundEnabled !== false ? (state.lang === 'zh' ? '🔔提示音 开' : '🔔음 ON') : (state.lang === 'zh' ? '🔕提示音 关' : '🔕음 OFF');
        document.querySelectorAll('.coupon-preset-btn').forEach(b => {
          b.textContent = b.getAttribute(state.lang === 'zh' ? 'data-zh' : 'data-ko');
        });
        if (typeof refreshMiniGamesLanguage === 'function') refreshMiniGamesLanguage();
        if (typeof renderBalanceGame === 'function') renderBalanceGame();
        if (typeof renderDateStampMap === 'function') renderDateStampMap();
        if (typeof renderHome === 'function') renderHome();
        if (typeof window.__renderHomeCouplePhrase === 'function') window.__renderHomeCouplePhrase(false);
        if (typeof window.__drawHomeTimeMachine === 'function') window.__drawHomeTimeMachine(false);
        if (typeof window.__renderQuickPhraseBar === 'function') window.__renderQuickPhraseBar();
        const __zh = state.lang === 'zh';
        const __setI18nId = (id, ko, zh) => { const el = document.getElementById(id); if (el) el.textContent = __zh ? zh : ko; };
        __setI18nId('hideNotifPrevTitle', '🔒 알림 메시지 미리보기 끄기', '🔒 隐藏通知内容预览');
        __setI18nId('hideNotifPrevDesc', '켜두면 상단 배너에 내용 대신 "새 메시지가 도착했어요"만 떠요.', '开启后通知横幅仅显示“收到一条新消息”，保护隐私。');
        __setI18nId('e2eeTitleLabel', '🔐 둘만의 종단간 암호화 (AES-256 E2EE)', '🔐 专属端到端加密 (AES-256 E2EE)');
        __setI18nId('e2eeDescLabel', '두 사람 폰에 똑같은 비밀 암호키를 입력하면 모든 사진·대화·음성·일기가 AES-256으로 암호화되어 전송돼요.', '两台手机输入相同密钥后，聊天、照片、语音与日记将全程 AES-256 加密传输。');
        __setI18nId('e2eeSaveBtn', '암호화 켜기', '开启加密');
        __setI18nId('e2eeClearBtn', '해제', '关闭');
        __setI18nId('customSoundToneBtn', '🎙️ 내 알림음', '🎙️ 自定义铃声');
        const __ahEl = document.getElementById('autoHealLastRunText');
        if (__ahEl && /부팅·재연결|启动与重连/.test(__ahEl.textContent || '')) {
          __ahEl.textContent = __zh ? '启动与重连时自动轻量自检（流畅不卡顿）' : '부팅·재연결 시 가벼운 항목만 자동 점검해요 (버벅거림 없음)';
        }
        if (!silent) { saveState(); showToast(state.lang === 'zh' ? '已切换为中文界面 ✨' : '한국어 화면으로 전환되었어요 ✨'); }
      }

      function switchTab(tab, swipeDir) {
        if (tab) setTimeout(() => { try { localStorage.setItem('cw_last_active_tab', tab); } catch (_) {} }, 0);
        if (typeof window.__closeNotifPanel === 'function') window.__closeNotifPanel();
        const lockChat = (tab === 'translator');
        if (lockChat && Array.isArray(state.notifications)) {
          setTimeout(() => {
            let __clearedAny = false;
            state.notifications.forEach(n => {
              if (n && n.unread && (n.tab === 'translator' || n.category === 'chat' || n.category === 'mood' || !n.tab)) {
                n.unread = false;
                __clearedAny = true;
              }
            });
            if (__clearedAny) {
              try { renderNotifications(); } catch (_) {}
              try { saveState(false); } catch (_) {}
            }
            try { if (typeof clearAllAppBadgesAndOsNotifs === 'function') clearAllAppBadgesAndOsNotifs(); } catch (_) {}
          }, 50);
        }
        document.documentElement.classList.toggle('cw-chat-lock', lockChat);
        document.body.classList.toggle('cw-chat-lock', lockChat);
        if (!lockChat) {
          document.documentElement.classList.remove('cw-kb-open');
          document.body.classList.remove('cw-kb-open');
          document.documentElement.style.removeProperty('--cw-vvh');
          document.documentElement.style.removeProperty('--cw-vv-top');
        } else if (typeof window.__syncChatKeyboardViewport === 'function') {
          setTimeout(() => window.__syncChatKeyboardViewport(), 30);
        }
        if (lockChat) {
          requestAnimationFrame(() => {
            try {
              const sb = document.getElementById('chatSendBtn');
              if (sb && sb.disabled) { sb.disabled = false; sb.textContent = state.lang === 'zh' ? '发送' : '전송'; }
              const ml = document.getElementById('chatMessagesList');
              if (ml && !ml.children.length && typeof renderChat === 'function') renderChat();
              if (ml) ml.scrollTop = ml.scrollHeight;
              if (typeof window.__emitChatReadIfVisible === 'function') window.__emitChatReadIfVisible(false);
              try {
                let _clearedChatNotif = false;
                (state.notifications || []).forEach(n => {
                  if (n && n.unread && n.tab === 'translator') { n.unread = false; _clearedChatNotif = true; }
                });
                if (_clearedChatNotif && typeof renderNotifications === 'function') { saveState(false); renderNotifications(); }
              } catch (_) {}
            } catch (_) {}
          });
        }
        document.querySelectorAll('.dock-item').forEach(b => b.classList.toggle('active', b.getAttribute('data-tab') === tab));
        document.querySelectorAll('.tab-panel').forEach(p => {
          const isTarget = p.id === `tab-${tab}`;
          p.classList.remove('cw-anim-from-right', 'cw-anim-from-left');
          p.style.transform = '';
          p.style.transition = '';
          p.classList.toggle('active', isTarget);
          if (isTarget && swipeDir) {
            p.classList.add(swipeDir === 'left' ? 'cw-anim-from-right' : 'cw-anim-from-left');
            setTimeout(() => { p.classList.remove('cw-anim-from-right', 'cw-anim-from-left'); }, 140);
          }
        });
        if (!lockChat) { const mEl = document.querySelector('main'); if (mEl) mEl.scrollTop = 0; window.scrollTo(0, 0); }
        if (typeof window.syncAllTabIconsToStyle === 'function') {
          const panelEl = document.getElementById('tab-' + tab);
          const curIconMode = (localStorage.getItem('chanwan_icon_style_v1') || (state.settings && state.settings.iconStyle) || 'pastel') + ':' + (state.lang || 'ko');
          if (panelEl && panelEl.dataset.cwIconSynced !== curIconMode) {
            setTimeout(() => {
              if (panelEl.dataset.cwIconSynced !== curIconMode) {
                window.syncAllTabIconsToStyle(null, panelEl);
                panelEl.dataset.cwIconSynced = curIconMode;
              }
            }, 20);
          }
        }
        if (window.__cwDirtyTabs && window.__cwDirtyTabs.has(tab)) {
          window.__cwDirtyTabs.delete(tab);
          setTimeout(() => {
            try {
              if (tab === 'home') renderHome();
              else if (tab === 'translator') renderChat();
              else if (tab === 'diary') {
                const vis = document.querySelector('#tab-diary > div[id^="diary-sub-"]:not(.hidden)');
                const sid = vis ? vis.id.replace('diary-sub-', '') : 'diary';
                if (sid === 'diary' || sid === 'qa' || sid === 'memo') renderDiaryQaMemos();
                else if (sid === 'album' || sid === 'bucket') renderBucketAndAlbum();
                else if (sid === 'coupon') renderCoupons();
                else if (sid === 'calendar' && typeof renderCoupleCalendar === 'function') renderCoupleCalendar();
                else if (sid === 'balance' && typeof renderBalanceGame === 'function') renderBalanceGame();
                else if (sid === 'datemap' && typeof renderDateStampMap === 'function') renderDateStampMap();
              } else if (tab === 'learn') renderLearn();
              else if (tab === 'anniversary') renderAnniversary();
              else if (tab === 'settings') { renderSettings(); updateVaultIndicators(); }
            } catch (_) {}
          }, 0);
        }
      }

      window.switchTab = switchTab;
      function switchTransSubtab(sub) {
        document.querySelectorAll('.trans-subtab').forEach(b => {
          const act = b.getAttribute('data-subtab') === sub;
          b.className = `trans-subtab ${act ? 'btn-royal' : 'btn-ghost'} px-4 py-2 rounded-full text-xs font-semibold whitespace-nowrap`;
        });
        document.getElementById('trans-sub-studio').classList.toggle('hidden', sub !== 'studio');
        document.getElementById('trans-sub-messenger').classList.toggle('hidden', sub !== 'messenger');
        // Sender follows Settings profile automatically for cleaner Messenger header
      }

      const COUPLE_CAT_MAP = {
        diary: 'record', qa: 'record', balance: 'record', tmi: 'record', memo: 'record',
        album: 'memory', voice: 'memory', capsule: 'memory', jar: 'memory',
        calendar: 'promise', bucket: 'promise', datemap: 'promise', coupon: 'promise',
        food: 'play', fortune: 'play', sleep: 'play', quiz: 'play', drawquiz: 'play', rps: 'play', truthdare: 'play'
      };
      const COUPLE_CAT_DEFAULT = { record: 'diary', memory: 'album', promise: 'calendar', play: 'food' };

      function switchDiarySubtab(sub) {
        if (sub === 'anniv-jump') { switchTab('anniversary'); return; }
        if (sub === 'memo') sub = 'diary';
        if (sub === 'sleep') sub = 'food';
        const activeCat = COUPLE_CAT_MAP[sub] || 'record';
        document.querySelectorAll('.couple-cat-btn').forEach(cBtn => {
          const isCat = cBtn.getAttribute('data-couple-cat') === activeCat;
          cBtn.className = `couple-cat-btn ${isCat ? 'btn-royal' : 'btn-ghost'} py-1.5 px-1 rounded-lg text-[11.5px] font-bold whitespace-nowrap`;
        });
        const subBarEl = document.getElementById('coupleSubtabBar');
        if (subBarEl) {
          const colCls = activeCat === 'promise' ? 'grid-cols-5' : (activeCat === 'play' ? 'grid-cols-3' : 'grid-cols-4');
          subBarEl.className = `grid ${colCls} gap-1`;
        }
        document.querySelectorAll('.diary-subtab').forEach(b => {
          const bCat = b.getAttribute('data-cat');
          const act = b.getAttribute('data-subtab') === sub;
          const show = bCat === activeCat;
          b.className = `diary-subtab ${show ? '' : 'hidden'} ${act ? 'btn-royal' : 'btn-ghost'} rounded-xl font-semibold whitespace-nowrap`;
        });
        ['diary', 'qa', 'balance', 'tmi', 'capsule', 'memo', 'calendar', 'bucket', 'datemap', 'album', 'coupon', 'voice', 'jar', 'food', 'fortune', 'sleep', 'quiz', 'drawquiz', 'rps', 'truthdare'].forEach(id => {
          const el = document.getElementById(`diary-sub-${id}`);
          if (el) el.classList.toggle('hidden', id !== sub);
        });
        if (sub === 'calendar' && typeof renderCoupleCalendar === 'function') renderCoupleCalendar();
        if (sub === 'balance' && typeof renderBalanceGame === 'function') renderBalanceGame();
        if (sub === 'datemap' && typeof renderDateStampMap === 'function') renderDateStampMap();
        if (sub === 'tmi' && typeof renderTmiBook === 'function') renderTmiBook();
        if (sub === 'jar' && typeof renderComplimentJar === 'function') renderComplimentJar();
        if (sub === 'fortune' && typeof renderCoupleFortune === 'function') renderCoupleFortune();
        if (sub === 'food' && typeof renderFoodRouletteMeta === 'function') renderFoodRouletteMeta();
        if (sub === 'quiz' && typeof renderCoupleQuizzes === 'function') renderCoupleQuizzes();
        if (sub === 'drawquiz' && typeof renderDrawQuizzes === 'function') renderDrawQuizzes();
        if (sub === 'rps' && typeof renderRpsGame === 'function') renderRpsGame();
        if (sub === 'truthdare' && typeof renderTruthDare === 'function') renderTruthDare();
        if (sub === 'truthdare' && typeof renderTruthDare === 'function') renderTruthDare();
        if (typeof window.syncAllTabIconsToStyle === 'function') {
          setTimeout(() => {
            const subEl = document.getElementById('diary-sub-' + sub);
            if (subEl) window.syncAllTabIconsToStyle(null, subEl);
          }, 16);
        }
      }

      function updateClocks() {
        const now = new Date();
        const c1 = state.cities.suwan;
        const c2 = state.cities.jingchan;
        const fmtTime = (tz) => {
          try { return new Intl.DateTimeFormat('ko-KR', { timeZone: tz, hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }).format(now); }
          catch (_) { return now.toLocaleTimeString('ko-KR', { hour12: false }); }
        };
        const fmtDate = (tz) => {
          try { return new Intl.DateTimeFormat(state.lang === 'zh' ? 'zh-CN' : 'ko-KR', { timeZone: tz, month: 'long', day: 'numeric', weekday: 'short' }).format(now); }
          catch (_) { return ''; }
        };
        document.getElementById('clockSuwon').textContent = fmtTime(c1.tz);
        document.getElementById('dateSuwon').textContent = fmtDate(c1.tz);
        document.getElementById('clockShanghai').textContent = fmtTime(c2.tz);
        document.getElementById('dateShanghai').textContent = fmtDate(c2.tz);
      }

      function mapWeatherCode(code) {
        const zh = state.lang === 'zh';
        if (code === 0) return { icon: '☀️', desc: zh ? '晴朗' : '맑음' };
        if (code <= 3) return { icon: '⛅', desc: zh ? '多云' : '구름 조금' };
        if (code <= 48) return { icon: '🌫️', desc: zh ? '有雾' : '안개' };
        if (code <= 67) return { icon: '🌧️', desc: zh ? '下雨' : '비' };
        if (code <= 77) return { icon: '❄️', desc: zh ? '下雪' : '눈' };
        return { icon: '🌦️', desc: zh ? '阵雨' : '소나기' };
      }

      function refreshBothCityWeathers() {
        const c1 = state.cities.suwan;
        const c2 = state.cities.jingchan;
        const zh = state.lang === 'zh';
        fetchCityWeather(c1.lat, c1.lon, 'weatherIconSuwon', 'weatherTempSuwon', 'weatherDescSuwon', '12°C', zh ? '晴朗' : '맑음');
        fetchCityWeather(c2.lat, c2.lon, 'weatherIconShanghai', 'weatherTempShanghai', 'weatherDescShanghai', '16°C', zh ? '晴朗' : '맑음');
      }

      async function fetchCityWeather(lat, lon, iconId, tempId, descId, fallbackTemp, fallbackDesc) {
        if (lat === null || lat === undefined || lon === null || lon === undefined) {
          document.getElementById(iconId).textContent = '🌤️';
          document.getElementById(tempId).textContent = '--°C';
          document.getElementById(descId).textContent = state.lang === 'zh' ? '自定义城市' : '직접 설정 도시';
          return;
        }
        try {
          const ctrl = new AbortController();
          const t = setTimeout(() => ctrl.abort(), 5000);
          const res = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true`, { signal: ctrl.signal });
          clearTimeout(t);
          if (!res.ok) throw new Error('err');
          const cw = (await res.json()).current_weather;
          const mapped = mapWeatherCode(cw.weathercode);
          document.getElementById(iconId).textContent = mapped.icon;
          document.getElementById(tempId).textContent = `${Math.round(cw.temperature)}°C`;
          document.getElementById(descId).textContent = mapped.desc;
        } catch (_) {
          document.getElementById(iconId).textContent = '🌤️';
          document.getElementById(tempId).textContent = fallbackTemp;
          document.getElementById(descId).textContent = fallbackDesc;
        }
      }

      /* ============================================================
         8. RENDERERS
         ============================================================ */
      function formatMoodByLang(raw) {
        const s = String(raw || '').trim();
        if (!s || !s.includes('·')) return s;
        const parts = (s.includes(' · ') ? s.split(' · ') : s.split('·')).map(p => p.trim());
        if (parts.length < 2) return s;
        const koPart = parts[0];
        const zhPart = parts.slice(1).join(' · ');
        // Preserve leading emoji when switching to Chinese!
        const emojiMatch = koPart.match(/^(\S+\s+)/);
        const leadEmoji = (emojiMatch && /[^a-zA-Z0-9가-힣\u4e00-\u9fff]/.test(emojiMatch[1])) ? emojiMatch[1] : '';
        if (state.lang === 'zh') {
          return (leadEmoji && !zhPart.startsWith(leadEmoji.trim())) ? `${leadEmoji}${zhPart}` : zhPart;
        }
        return koPart;
      }

      function populateMoodSelect(selectId, currentVal) {
        const sel = document.getElementById(selectId);
        if (!sel) return;
        const options = [...MOOD_PRESETS];
        const isPreset = options.includes(currentVal);
        const customOptLabel = state.lang === 'zh' ? '✏️ 自定义输入...' : '✏️ 직접 입력...';
        const placeholderOpt = !isPreset
          ? `<option value="__current__" disabled selected>${state.lang === 'zh' ? '✨ 自定义状态中...' : '✨ 직접 입력 사용 중'}</option>`
          : '';
        sel.innerHTML = placeholderOpt
          + `<option value="__custom__">${customOptLabel}</option>`
          + options.map(m => `<option value="${escapeHtml(m)}">${escapeHtml(formatMoodByLang(m))}</option>`).join('');
        if (isPreset) sel.value = currentVal;
      }

      function renderWeeklyReportCard() {
        const grid = document.getElementById('weeklyReportGrid');
        const titleEl = document.getElementById('weeklyReportTitle');
        const rangeEl = document.getElementById('weeklyReportRange');
        if (!grid) return;
        const isZh = state.lang === 'zh';
        if (titleEl) titleEl.textContent = isZh ? '本周情侣周报' : '이번 주 우리 커플 리포트';
        if (rangeEl) rangeEl.textContent = isZh ? '近 7 天' : '최근 7일';
        const weekAgo = Date.now() - 7 * 24 * 60 * 60 * 1000;
        const weekMsgs = (state.chat?.messages || []).filter(m => m && Number(m.ts || 0) >= weekAgo).length;
        const weekPhotos = (state.albums || []).filter(a => {
          if (!a) return false;
          if (a.createdAt && Number(a.createdAt) >= weekAgo) return true;
          if (a.date) { const t = Date.parse(a.date); return !isNaN(t) && t >= weekAgo; }
          return false;
        }).length;
        const hearts = Number(state.heartCount || 0);
        const learnXp = Number(state.learn?.xp || 0);
        const cards = [
          { ico: '💬', lbl: isZh ? '聊天' : '대화', val: `${weekMsgs}${isZh ? '条' : '건'}` },
          { ico: '🖼️', lbl: isZh ? '照片' : '사진', val: `${weekPhotos}${isZh ? '张' : '장'}` },
          { ico: '💓', lbl: isZh ? '心动' : '하트', val: `${hearts}${isZh ? '次' : '회'}` },
          { ico: '📚', lbl: isZh ? '韩语' : '학습', val: `${learnXp} XP` }
        ];
        grid.innerHTML = cards.map(c => `
          <div class="royal-subcard rounded-2xl py-2 px-1">
            <div class="text-sm leading-none">${c.ico}</div>
            <div class="text-[11px] font-bold text-gold mt-1 tabular-nums">${c.val}</div>
            <div class="text-[9.5px] text-mut mt-0.5">${c.lbl}</div>
          </div>
        `).join('');
      }
      function renderHome() {
        try { renderWeeklyReportCard(); } catch (_) {}
        const today = getKstDateString();
        const days = Math.max(1, diffDays(state.startDate, today) + 1);
        const c1 = state.cities.suwan;
        const c2 = state.cities.jingchan;

        document.getElementById('homeDDayCount').textContent = `D+${days}`;
        document.getElementById('homeStartDateText').textContent = `${state.startDate} · ${c1.name.split('·')[0].trim()} ↔ ${c2.name.split('·')[0].trim()}`;

        const next100 = Math.ceil(days / 100) * 100;
        const remain = next100 - days;
        document.getElementById('homeNextMilestone').textContent = remain === 0
          ? `🎉 ${next100}일 D-DAY!`
          : `${next100}${state.lang === 'zh' ? '天纪念日' : '일까지'} D-${remain}`;
