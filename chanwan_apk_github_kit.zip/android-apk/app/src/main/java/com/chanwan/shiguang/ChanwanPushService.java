package com.chanwan.shiguang;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.IBinder;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class ChanwanPushService extends Service {
    private static final String CH_FG = "chanwan_fg_channel";
    private static final String CH_MSG = "chanwan_msg_channel";
    private static final String BASE_ROOM = "chanwan-suwan-jingchan-live2026";
    private volatile boolean running = true;
    private Thread worker;

    @Override
    public void onCreate() {
        super.onCreate();
        createChannels();
        startForeground(1, buildForegroundNotif());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (worker == null || !worker.isAlive()) {
            running = true;
            worker = new Thread(this::streamLoop);
            worker.start();
        }
        return START_STICKY;
    }

    private void createChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            NotificationChannel fg = new NotificationChannel(CH_FG, "灿完时光 실시간 연결", NotificationManager.IMPORTANCE_MIN);
            fg.setShowBadge(false);
            nm.createNotificationChannel(fg);

            NotificationChannel msg = new NotificationChannel(CH_MSG, "새 메시지 · 하트 알림", NotificationManager.IMPORTANCE_HIGH);
            msg.enableVibration(true);
            nm.createNotificationChannel(msg);
        }
    }

    private Notification buildForegroundNotif() {
        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CH_FG)
                : new Notification.Builder(this);
        return b.setContentTitle("灿完时光")
                .setContentText("실시간 알림 대기 중 💜")
                .setSmallIcon(R.drawable.ic_stat_heart)
                .setOngoing(true)
                .build();
    }

    private void streamLoop() {
        String lastId = getSharedPreferences("cw_prefs", MODE_PRIVATE).getString("last_id", "");
        while (running) {
            HttpURLConnection conn = null;
            try {
                SharedPreferences prefs = getSharedPreferences("cw_prefs", MODE_PRIVATE);
                String role = prefs.getString("role", "suwan");
                String topic = BASE_ROOM + "-" + role;
                String sinceParam = (lastId != null && !lastId.isEmpty()) ? ("?since=" + lastId) : "";
                URL url = new URL("https://ntfy.sh/" + topic + "/json" + sinceParam);
                conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(90000);
                conn.setConnectTimeout(15000);
                conn.connect();

                BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                String line;
                while (running && (line = br.readLine()) != null) {
                    line = line.trim();
                    if (line.isEmpty()) continue;
                    JSONObject obj = new JSONObject(line);
                    String ev = obj.optString("event", "");
                    String id = obj.optString("id", "");
                    if (!id.isEmpty()) {
                        lastId = id;
                        prefs.edit().putString("last_id", id).apply();
                    }
                    if ("message".equals(ev)) {
                        String title = obj.optString("title", "💜 灿完时光");
                        String body = obj.optString("message", "새 메시지가 도착했어요");
                        showMessageNotif(title, body, (int) (System.currentTimeMillis() & 0x7fffffff));
                    }
                }
            } catch (Exception ignored) {
                try { Thread.sleep(4000); } catch (InterruptedException ie) { break; }
            } finally {
                if (conn != null) conn.disconnect();
            }
        }
    }

    private void showMessageNotif(String title, String body, int notifId) {
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        PendingIntent pi = PendingIntent.getActivity(this, notifId, open, flags);

        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CH_MSG)
                : new Notification.Builder(this);
        b.setContentTitle(title)
                .setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setSmallIcon(R.drawable.ic_stat_heart)
                .setAutoCancel(true)
                .setPriority(Notification.PRIORITY_HIGH)
                .setContentIntent(pi);

        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(notifId, b.build());
    }

    @Override
    public void onDestroy() {
        running = false;
        if (worker != null) worker.interrupt();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
